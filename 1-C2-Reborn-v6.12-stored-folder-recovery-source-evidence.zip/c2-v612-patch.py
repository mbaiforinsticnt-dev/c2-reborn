from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.11-folder-name-safety-candidate.html').read_text().replace('v6.11 handset parity','v6.12 handset parity').replace('C2 Reborn v6.11 |','C2 Reborn v6.12 |')
a='function galActualFiles(n){let originals=(GAL_FILES[n]||[]).concat'
b="function galOwnText(map,key){return map&&Object.prototype.hasOwnProperty.call(map,key)&&typeof map[key]==='string'?map[key]:undefined}\nfunction galActualFiles(n){let originals=(Object.prototype.hasOwnProperty.call(GAL_FILES,n)&&Array.isArray(GAL_FILES[n])?GAL_FILES[n]:[]).concat"
assert s.count(a)==1;s=s.replace(a,b)
p=s.find('function galActualFiles');e=s.find('function galFolderBytes',p);t=s[p:e].replace('moved[f.n]','galOwnText(moved,f.n)').replace('copied[f.n]','galOwnText(copied,f.n)').replace('moved[o.n]','galOwnText(moved,o.n)');s=s[:p]+t+s[e:]
a="return (phoneState.galFolderNames||{})[n]||(phoneState.galFolderAliases||{})[n]||n"
b="return galOwnText(phoneState.galFolderNames,n)||galOwnText(phoneState.galFolderAliases,n)||n";assert s.count(a)==1;s=s.replace(a,b)
a="((phoneState.galFolderParents||{})[n]||'Memory card')===parent"
b="(galOwnText(phoneState.galFolderParents,n)||'Memory card')===parent";assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('d.galFolderAliases={};','d.galFolderAliases=Object.create(null);',1).replace('d.galFolderParents={};d.galFolderNames={};','d.galFolderParents=Object.create(null);d.galFolderNames=Object.create(null);',1)
Path('/downloads/C2-Reborn-v6.12-stored-folder-recovery-candidate.html').write_text(s)
