C2 Reborn v5.58 - destination-picker Options, 30 September 2026
Upload-ready HTML is index.html in this archive. This is not a direct deployment.
HTML SHA256: 13181fb8cf04e1a87a0b3dcf274140804b5de18409a288ba99c034be358fa4db

Changed from v5.57:
- Folder Move/Copy target picker carries its own destination location and nested Back trail.
- Root target order stays fixed. Opening a folder lists children and files; opening Memory card lists real card children, not the built-in phone folders.
- Target Options uses Open drive/Open folder only for folders, plus Add folder, Details, Type of view, Sort and Search. Files omit Open folder.
- Add folder creates under the browsed destination, returns there with the new folder highlighted, and does not move the source.
- Empty destination offers Options/Add/Back.
- List with details, List and Grid work; sort has four modes and Ascending/Descending submenus, ending with Sorted.
- Target Details shows grounded name, size and available date; it does not reuse the normal photo Details screen's hard-coded resolution.
- Root Back cancels and restores source Options on Move folder/Copy folder. Nested Back returns one destination level.
- Populated subtree Move and name-clash handling remain from v5.57. Six-field fresh-contact default remains from v5.56.

Known unfinished:
- Target Search currently opens an explicit Not implemented in this prototype page with Back only. The SDK search is a full content-search flow, not a folder filter.
- Selected destination files have Open in the SDK, including full photo viewing. In this candidate Open honestly reports Not implemented in this prototype with Back only; the photo Options/Zoom return context needs further work.
- SDK Memory card child 2 showed Open folder grey in one fixture, while other target folders opened normally. The reason is not verified; this candidate does not generalize that anomaly into a blanket restriction.
- Handset evidence outranks SDK evidence. These new target-picker details are SDK-derived, not a claim of full handset parity.

Validation:
- JavaScript syntax checked.
- 34 new destination action/edge checks passed.
- All 51 earlier contact/explorer/move/copy regressions passed.
- Pixels inspected: destination root Options, opened Images list, sort mode and direction panels, empty destination and Add folder editor.
- Source/evidence banking only. No index.html deployment.
