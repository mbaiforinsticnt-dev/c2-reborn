exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.58-target-options-candidate.html'))
checks=[
('fixture',"phoneState=migrateState(null);phoneState.galleryFolders=['P','Dup'];phoneState.galFolderParents.P='Graphics';phoneState.galFolderNames.Dup='P';phoneState.galFolderParents.Dup='Images';page='galfolder';galFolderName='Graphics';sel=0;open=false;history=[];pageSub=null;notice='';galFolderMoveStart();return galTarget.folder==='P'"),
('nested collision source restored',"sel=1;press('OK');return page==='galfolder'&&open&&notice==='Name already exists'&&phoneState.galFolderParents.P==='Graphics'"),
('re-enter after clash',"notice='';open=false;galFolderMoveStart();sel=1;press('LSK');press('OK');return galTarget.browse==='Images'"),
('Add Options editor retains input',"press('LSK');os=currentOptions().indexOf('Add folder');press('OK');folderName='Hello';press('LSK');let ok=page==='foldername'&&open;press('RSK');return ok&&folderName==='Hello'&&!open"),
('add destination not root',"press('OK');return page==='galfoldertarget'&&galTargetRows()[sel].n==='Hello'&&phoneState.galFolderParents.Hello==='Images'"),
('case-insensitive target clash',"press('LSK');os=currentOptions().indexOf('Add folder');press('OK');folderName='hello';press('OK');return page==='foldername'&&notice==='Name already exists'&&phoneState.galleryFolders.filter(x=>x==='Hello').length===1"),
('empty name blocked',"notice='';folderName='';press('OK');return page==='foldername'&&notice==='Enter folder name'"),
('editor back stays target',"notice='';press('RSK');return page==='galfoldertarget'&&galTarget.browse==='Images'"),
('Search honest Back only',"press('LSK');os=currentOptions().indexOf('Search');press('OK');return galTarget.pane==='unsupported'&&document.body.innerText.includes('Not implemented in this prototype')"),
('Search Back no mutation',"let before=JSON.stringify(phoneState.galFolderParents);press('RSK');return !galTarget.pane&&JSON.stringify(phoneState.galFolderParents)===before"),
('file preview honest',"sel=galTargetRows().findIndex(x=>!x.folderRow);press('OK');return galTarget.pane==='unsupported'"),
('file preview Back retains file',"let old=sel;press('RSK');return !galTarget.pane&&sel===old"),
('sort notice dismiss',"press('LSK');os=currentOptions().indexOf('Sort ▸');press('OK');press('OK');press('OK');let ok=notice==='Sorted';press('RSK');return ok&&notice===''&&galTarget.browse==='Images'"),
('submenu Back no sort commit',"let old=phoneState.galSort;press('LSK');os=currentOptions().indexOf('Sort ▸');press('OK');press('DOWN');press('OK');press('RSK');let ok=galTarget.pane==='sort';press('RSK');return ok&&open&&phoneState.galSort===old"),
('end menu closes not source',"press('END');return !open&&page==='galfoldertarget'"),
('end nested returns root',"press('END');return galTarget.browse===''"),
('end root source options',"press('END');return page==='galfolder'&&open&&currentOptions()[os]==='Move folder'"),
]
for label,x in checks:
 z=ev('(()=>{'+x+'})()');print(label,z);assert z is True,(label,z)
print('PASS',len(checks))
