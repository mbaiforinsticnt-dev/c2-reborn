exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.58-target-options-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
shots=[('target-root',"phoneState=migrateState(null);phoneState.galleryFolders=['P','M'];phoneState.galFolderParents.P='Graphics';page='galfolder';galFolderName='Graphics';sel=0;history=[];open=false;notice='';pageSub=null;galFolderMoveStart()"),('target-options',"press('LSK')"),('target-Images',"press('RSK');sel=1;press('LSK');press('OK')"),('target-file-options',"sel=0;press('LSK')"),('target-sort',"os=currentOptions().indexOf('Sort ▸');press('OK')"),('target-sort-dir',"press('OK')"),('target-empty',"galTarget.pane=null;open=false;galTarget.browse='M';sel=0;draw()"),('target-add',"press('OK');folderName='New';draw()")]
for label,x in shots:
 z=ev(x);assert not isinstance(z,dict),z
 r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path='/downloads/c2-v558-'+label+'.png';open(path,'wb').write(base64.b64decode(r['result']['data']));print(path)
