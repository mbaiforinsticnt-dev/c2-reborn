from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.71-countdown-expiry-rollback-candidate.html').read_text().replace('v6.71 handset parity','v6.72 handset parity').replace('C2 Reborn v6.71 |','C2 Reborn v6.72 |')
a="else{phoneState.countdownAutoRepeat=!phoneState.countdownAutoRepeat;persist()}draw()}else if(['templates','savedmessages']"
b="else{let beforeRepeat=phoneState.countdownAutoRepeat;phoneState.countdownAutoRepeat=!beforeRepeat;try{persist()}catch(err){phoneState.countdownAutoRepeat=beforeRepeat;notice='Unable to save timer'}}draw()}else if(['templates','savedmessages']"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.72-countdown-repeat-setting-rollback-candidate.html').write_text(s)
