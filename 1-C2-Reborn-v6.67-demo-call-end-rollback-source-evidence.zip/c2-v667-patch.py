from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.66-backup-profile-sync-candidate.html').read_text().replace('v6.66 handset parity','v6.67 handset parity').replace('C2 Reborn v6.66 |','C2 Reborn v6.67 |')
a="function endCall(){if(activeCall){let sec=Math.max(0,Math.floor(callHeld?callHeldAt:(Date.now()-callStarted)/1000));callTimerSecs[0]=sec;callTimerSecs[2]+=sec;callTimerSecs[3]+=sec;phoneState.callTimerSecs=callTimerSecs.slice();persist();activeCall=null;notice='Call ended';history=[];page='home';draw()}}"
b="function endCall(){if(activeCall){let sec=Math.max(0,Math.floor(callHeld?callHeldAt:(Date.now()-callStarted)/1000)),beforeTimer=callTimerSecs,beforeSaved=phoneState.callTimerSecs;let nextTimer=callTimerSecs.slice();nextTimer[0]=sec;nextTimer[2]+=sec;nextTimer[3]+=sec;callTimerSecs=nextTimer;phoneState.callTimerSecs=nextTimer.slice();try{persist()}catch(err){callTimerSecs=beforeTimer;phoneState.callTimerSecs=beforeSaved;notice='Unable to save demo call';draw();return}activeCall=null;notice='Call ended';history=[];page='home';draw()}}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.67-demo-call-end-rollback-candidate.html').write_text(s)
