exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.67-demo-call-end-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['','cancel','endcancel']:
 ev("clearTimeout(alarmFlashTimer);phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState.alarm);page='alarmclock';alarmInit();alarmDraft.on=true;alarmDraft.time='09:31';alarmDraft.repeat=true;alarmDraft.days=[0,2];base=alarmBase;alarmMode="+json.dumps(mode)+";alarmExitHome="+('true' if mode=='endcancel' else 'false')+";oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+('alarmSave()' if not mode else "press('OK')"))
 t(mode+' exact alarm rollback',"return JSON.stringify(phoneState.alarm)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' draft and dirty retained',"return alarmDraft.time==='09:31'&&alarmDraft.on&&alarmDraft.repeat&&JSON.stringify(alarmDraft.days)==='[0,2]'&&alarmDirty()&&alarmBase===base")
 t(mode+' visible error no success',"return alarmMode==='saveerror'&&page==='alarmclock'&&document.getElementById('screen').innerText.includes('Unable to save alarm')")
 if not mode:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v639-alarm-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("press('RSK');Storage.prototype.setItem=oldStore;alarmSave();clearTimeout(alarmFlashTimer)")
 t(mode+' retry saved exact',"return phoneState.alarm.time==='09:31'&&phoneState.alarm.on&&phoneState.alarm.repeat&&JSON.stringify(phoneState.alarm.days)==='[0,2]'&&!alarmDirty()&&alarmMode==='saved'")
 ev("alarmFinish()")
 t(mode+' exit destination retained',"return page==="+json.dumps('home' if mode=='endcancel' else 'organiser'))
 call('Page.reload');time.sleep(.15)
 t(mode+' reload keeps exact',"return phoneState.alarm.time==='09:31'&&phoneState.alarm.on&&phoneState.alarm.repeat&&JSON.stringify(phoneState.alarm.days)==='[0,2]'")
print('PASS',len(checks))
