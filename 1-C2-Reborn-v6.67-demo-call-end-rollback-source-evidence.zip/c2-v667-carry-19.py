exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.67-demo-call-end-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'TargetProbe'};draw();press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
ev("galEditor=null;galTarget={op:'Copy',folder:'ProbeFolder',browse:'Images',trail:[]};page='galfoldertarget';sel=galTargetRows().findIndex(x=>x.n==='TargetProbe.gif');draw();press('OK');press('LSK');press('DOWN');press('OK')")
time.sleep(.1)
t('Preview Details format and actual dimensions',"return galTarget.pane==='details'&&document.getElementById('screen').innerText.includes('GIF')&&document.getElementById('screen').innerText.includes('240 x 320')")
ev("press('BACK');press('BACK');press('BACK');open=true;os=galTargetOptions().indexOf('Details');draw();press('OK')")
time.sleep(.1)
t('List Details same format and dimensions',"return galTarget.pane==='details'&&document.getElementById('screen').innerText.includes('GIF')&&document.getElementById('screen').innerText.includes('240 x 320')")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v600-target-details.png','wb').write(base64.b64decode(d['result']['data']))
t('Back restores list without committing Copy',"press('BACK');return galTarget.pane===null&&phoneState.galFolderItems.length===0")
t('No image facts on folder details',"galTarget.browse='';sel=galTargetRows().findIndex(x=>x.n==='Images');open=true;os=galTargetOptions().indexOf('Details');draw();press('OK');return !galTarget.detail.src&&!galTarget.detail.format")
print('PASS',len(checks))
