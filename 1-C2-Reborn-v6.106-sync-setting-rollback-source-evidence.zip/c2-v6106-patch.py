from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.105-profile-rename-rollback-candidate.html').read_text().replace('v6.105 handset parity','v6.106 handset parity').replace('C2 Reborn v6.105 |','C2 Reborn v6.106 |')
a="if(k==='OK'){if(syncField==='user')phoneState.syncUser=syncDraft||'';else phoneState.syncPass=syncDraft;persist();syncEditing=false;back();return}"
b="if(k==='OK'){let field=syncField==='user'?'syncUser':'syncPass',hadField=Object.prototype.hasOwnProperty.call(phoneState,field),beforeValue=phoneState[field];phoneState[field]=syncDraft||'';try{persist()}catch(err){if(hadField)phoneState[field]=beforeValue;else delete phoneState[field];notice='Unable to save sync setting';draw();return}syncEditing=false;back();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save profile name|Folder memory full','Unable to save profile name|Unable to save sync setting|Folder memory full')
Path('/downloads/C2-Reborn-v6.106-sync-setting-rollback-candidate.html').write_text(s)
