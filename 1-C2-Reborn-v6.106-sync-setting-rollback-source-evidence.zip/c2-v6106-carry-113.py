exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.106-sync-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for playing in ['true','false']:
 ev("phoneState=migrateState(null);phoneState.player.playing="+playing+";phoneState.player.elapsed=15;playerTickBase=Date.now();persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);beforePlayer=phoneState.player;beforeTick=playerTickBase;page='allsongs';history=['musiclibrary'];sel=0;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(playing+' exact rollback aliases',"return JSON.stringify(phoneState)===before&&phoneState.player===beforePlayer&&playerTickBase===beforeTick&&localStorage.getItem('c2state')===stored")
 t(playing+' list context retained',"return page==='allsongs'&&history.length===1&&notice==='Unable to save player'&&document.getElementById('screen').innerText.includes(notice)")
 if playing=='false':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v689-allsongs-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(playing+' repeat failure exact',"return JSON.stringify(phoneState)===before&&phoneState.player===beforePlayer")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(playing+' retry starts and opens',"return phoneState.player.playing===true&&phoneState.player.track===0&&phoneState.player.elapsed===15&&page==='player'&&history.length===2")
 t(playing+' stored playback exact',"return JSON.parse(localStorage.getItem('c2state')).player.playing===true&&JSON.parse(localStorage.getItem('c2state')).player.elapsed===15")
print('PASS',len(checks))
