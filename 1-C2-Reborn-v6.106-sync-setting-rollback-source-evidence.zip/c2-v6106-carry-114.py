exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.106-sync-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for theme in ['Light.nth','Nokia.nth','Dark.nth']:
 ev("phoneState=migrateState(null);phoneState.theme='Black.nth';document.body.dataset.theme=phoneState.theme;persist();stored=localStorage.getItem('c2state');page='themeselect';sel=themeChoices.findIndex(t=>t[4]==='"+theme+"');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(theme+' exact visible/state rollback',"return phoneState.theme==='Black.nth'&&document.body.dataset.theme==='Black.nth'&&localStorage.getItem('c2state')===stored")
 t(theme+' warning visible',"return notice==='Unable to save theme'&&document.getElementById('screen').innerText.includes(notice)")
 if theme=='Light.nth':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v690-theme-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(theme+' repeat failure exact',"return phoneState.theme==='Black.nth'&&document.body.dataset.theme==='Black.nth'")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(theme+' retry exact',"return phoneState.theme==='"+theme+"'&&document.body.dataset.theme===phoneState.theme&&notice===phoneState.theme+' selected'")
 call('Page.reload');time.sleep(.15)
 t(theme+' reload exact',"return phoneState.theme==='"+theme+"'&&document.body.dataset.theme===phoneState.theme")
print('PASS',len(checks))
