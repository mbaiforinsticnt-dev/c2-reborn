exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.60-contact-memory-candidate.html'))
checks=[
('fixture',"phoneState=migrateState(null);phoneState.galleryFolders=['P'];phoneState.galFolderParents.P='Graphics';page='galfolder';galFolderName='Graphics';sel=0;history=[];open=false;notice='';pageSub=null;galFolderMoveStart();sel=1;press('LSK');press('OK');sel=galTargetRows().findIndex(r=>!r.folderRow);return sel>=0"),
('Open preview stays target',"let key=galTargetRows()[sel].key;press('OK');return galTarget.pane==='preview'&&galTarget.preview.key===key&&page==='galfoldertarget'"),
('narrow preview Options',"press('LSK');return galTarget.previewOpen&&document.querySelector('.submenuPanel').innerText==='View full screen\\nDetails'"),
('fullscreen and Back',"press('OK');let ok=galTarget.full;press('RSK');return ok&&!galTarget.full&&galTarget.pane==='preview'"),
('Details returns menu',"press('LSK');press('DOWN');press('OK');let ok=galTarget.pane==='details'&&galTarget.previewDetails;press('RSK');return ok&&galTarget.pane==='preview'&&galTarget.previewOpen"),
('Details format from file',"press('OK');return galTarget.detail.format==='JPEG'&&!document.querySelector('.galDetails').innerText.includes('1600 x 1200')"),
('Close detail menu then zoom',"press('RSK');press('RSK');press('OK');return galTarget.zoom===2&&!document.querySelector('.galPhotoSoft').innerText.includes('Options')"),
('zoom hides Options action',"press('LSK');return !galTarget.previewOpen"),
('zoom second stage and Back',"press('OK');let ok=galTarget.zoom===4&&!document.querySelector('.galPhotoSoft').innerText.includes('Zoom');press('RSK');return ok&&galTarget.zoom===2"),
('preview returns exact item',"let key=galTarget.preview.key;press('RSK');press('RSK');return !galTarget.pane&&galTargetRows()[sel].key===key&&galTarget.browse==='Images'"),
('search preview return preserves query',"press('LSK');os=currentOptions().indexOf('Search');press('OK');press('7');sel=0;let key=galTargetRows()[sel].key;press('OK');press('RSK');return galTarget.search&&galTarget.query==='P'&&sel===0"),
('no state mutation',"return phoneState.galFolderParents.P==='Graphics'&&phoneState.galDeleted.length===0")
]
checks += [('search preview resets selected result',"galTarget.browse='Images';galTarget.search=true;galTarget.query='';sel=galTargetRows().findIndex(r=>!r.folderRow);press('OK');press('RSK');return !galTarget.pane&&galTarget.search&&sel===0")]
for label,x in checks:
 z=ev('(()=>{'+x+'})()');print(label,z);assert z is True,(label,z)
print('PASS',len(checks))
