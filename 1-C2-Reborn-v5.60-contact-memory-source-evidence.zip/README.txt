C2 Reborn v5.60 - single-contact memory Copy and Move, 2026-09-30
No index.html deployment.

Changes:
- Names > Edit > Copy contact asks before duplicating into the other memory.
- No restores the exact Edit submenu choice. Yes opens copied Contact details; Back selects the new duplicate row.
- Copy preserves all local fields and uses an independent deep copy, with marking reset.
- Names > Edit > Move contact asks before changing a non-colliding record's memory; no duplicate is added.
- Editing a SIM-stored contact no longer silently changes its store to Phone.
- Destination collisions on Move stop with an honest prototype limit, not a fabricated merge.

Evidence:
SDK 1430: Copy to phone memory question; 1431: No restores Copy selection.
SDK 1433: copied Contact details; 1434: duplicate Jane Doe row selected.
SDK 1436: Move to phone memory question; 1438: Move to SIM memory question.
Mobile HTML pixels inspected: Copy/Move questions with Yes/No, No return, copied details and duplicated selected row.
14 new behavioral checks and 81 regression checks passed. JavaScript syntax passed.

Limits:
Not a full parity certification. Bulk move/copy routes remain outside this pass and still need real state mutation/audit.
SIM field-loss, capacity, destination dedupe/merge and memory-filter/icon parity are not certified.
Full local records are preserved conservatively; no fields are discarded based on the SDK.
SDK input delays make post-Move duplicate handling ambiguous; collision behavior is explicitly unsupported.
The current Names list reads contacts[]. Separate legacy simContacts[] integration needs a later bounded pass.
Handset evidence remains authoritative over SDK findings. No emulator-driven removals.

Rebuild:
Apply v5.59-to-v5.60.patch to the byte-exact v5.59 final HTML. Final HTML is authoritative.
Test scripts use the local Chrome debugging harness and may need paths changed when reproducing.
