exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.57-demo-reply-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState({galleryFolders:['Source','Dest','Old'],galFolderSerial:0,galFolderItems:[{folder:'Source',n:'Original',source:'Photo0001.jpg',s:'1 B'},{folder:'Old',n:'copyfile-2',display:'Unrelated.jpg',s:'2 B'}],galDeleted:['copyfile-3'],galMoved:{'copyfile-4':'Images'},galCopied:{'copyfile-5':'Themes'},galFileNames:{'copyfile-6':'Old.jpg'}});result=galCopyFolderTo('Source','Dest')")
t('New copy skips stored and historical IDs',"return galActualFiles(result.key)[0].n==='copyfile-7'&&phoneState.galFolderSerial===7")
t('New copy not accidentally moved deleted or renamed',"galFolderName=result.key;return galFolderFiles().length===1&&galFolderFiles()[0].n==='Original'&&galFolderFiles()[0].big===GAL_FILES.Images[0].big")
t('Unrelated old record unchanged',"return galActualFiles('Old').length===1&&galActualFiles('Old')[0].n==='copyfile-2'&&galActualFiles('Old')[0].s==='2 B'")
call('Page.reload');time.sleep(.3)
t('Reload keeps independent copy identities',"return phoneState.galFolderItems.map(f=>f.n).join()==='Original,copyfile-2,copyfile-7'")
ev("galFolderName=phoneState.galleryFolders.find(x=>x.startsWith('foldercopy-'));page='galfolder';notice='';sel=0;draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v622-new-copy.png','wb').write(base64.b64decode(d['result']['data']))
print('PASS',len(checks))
