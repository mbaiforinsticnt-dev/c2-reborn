from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.56-message-status-rollback-candidate.html').read_text().replace('v6.56 handset parity','v6.57 handset parity').replace('C2 Reborn v6.56 |','C2 Reborn v6.57 |')
a="messageStore.threads.alex.unshift({id:messageId(),icon:'unread',unread:true,dir:'in',number:CONV_NUMBER,date:todayDate(),time:t,sentTime:t+':00',text:'Thanks - got it, will take a look.'});persist();if(page==='home')"
b="let beforeThread=messageStore.threads.alex.slice(),beforeNextId=messageStore.nextId;messageStore.threads.alex.unshift({id:messageId(),icon:'unread',unread:true,dir:'in',number:CONV_NUMBER,date:todayDate(),time:t,sentTime:t+':00',text:'Thanks - got it, will take a look.'});try{persist()}catch(err){messageStore.threads.alex.splice(0,messageStore.threads.alex.length,...beforeThread);messageStore.nextId=beforeNextId;notice='Unable to save demo reply';draw();return}if(page==='home')"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save message status|Folder memory full|';b='Unable to save message status|Unable to save demo reply|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.57-demo-reply-rollback-candidate.html').write_text(s)
