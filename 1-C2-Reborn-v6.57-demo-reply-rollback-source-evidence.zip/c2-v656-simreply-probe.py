exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.56-message-status-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);messageStore=seedMessageStore();messageStore.threads={alex:[]};phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='home';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};simReply()")
print(ev("JSON.stringify({same:JSON.stringify(phoneState)===before,thread:messageStore.threads.alex,diskSame:localStorage.getItem('c2state')===stored})"))
