from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.17-target-date-order-candidate.html').read_text().replace('v6.17 handset parity','v6.18 handset parity').replace('C2 Reborn v6.17 |','C2 Reborn v6.18 |')
s=s.replace("for(let key of ['galMoved','galCopied','galFileNames']){d[key]={};","for(let key of ['galMoved','galCopied','galFileNames']){d[key]=Object.create(null);")
Path('/downloads/C2-Reborn-v6.18-file-map-recovery-candidate.html').write_text(s)
