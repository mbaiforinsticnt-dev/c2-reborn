exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.45-todo-save-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.todos=[{s:'One',p:'Medium',d:todoToday(),t:'09:00',done:false}];persist();stored=localStorage.getItem('c2state');page='todolist';sel=0;open=true;os=currentOptions().indexOf('Mark note as done');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({todos:phoneState.todos,page,notice,diskSame:localStorage.getItem('c2state')===stored})"))
