from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.45-todo-save-rollback-candidate.html').read_text().replace('v6.45 handset parity','v6.46 handset parity').replace('C2 Reborn v6.45 |','C2 Reborn v6.46 |')
a="list.sort((a,b)=>todoDeadlineKey(a).localeCompare(todoDeadlineKey(b)));sel=0;persist();notice='Sorted by deadline'"
b="let beforeTodos=list.slice(),beforeSel=sel;list.sort((a,b)=>todoDeadlineKey(a).localeCompare(todoDeadlineKey(b)));sel=0;try{persist()}catch(err){phoneState.todos=beforeTodos;sel=beforeSel;notice='Unable to sort to-do notes';draw();return}notice='Sorted by deadline'"
assert s.count(a)==1;s=s.replace(a,b)
a="_tv.done=!_tv.done;persist();notice=_tv.done?";b="let beforeDone=_tv.done;_tv.done=!_tv.done;try{persist()}catch(err){_tv.done=beforeDone;notice='Unable to save to-do status';draw();return}notice=_tv.done?";assert s.count(a)==1;s=s.replace(a,b)
a="_td.done=!_td.done;persist();notice=_td.done?";b="let beforeDone=_td.done;_td.done=!_td.done;try{persist()}catch(err){_td.done=beforeDone;notice='Unable to save to-do status';draw();return}notice=_td.done?";assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save to-do note|Folder memory full|';b='Unable to save to-do note|Unable to save to-do status|Unable to sort to-do notes|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.46-todo-status-sort-rollback-candidate.html').write_text(s)
