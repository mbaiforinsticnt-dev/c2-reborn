exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.46-todo-status-sort-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for which in [0,1]:
 ev("phoneState=migrateState(null);phoneState.contacts=[{name:'Personal demo',number:'123'}];phoneState.groups=[{name:'Personal group',image:'Photo0001.jpg'}];phoneState.theme='Blue.nth';messageStore=seedMessageStore();phoneState.messageStore=messageStore;messageStore.inbox[0].body='Personal inbox demo';persist();before=JSON.stringify(phoneState);messagesBefore=JSON.stringify(messageStore);stored=localStorage.getItem('c2state');stateRef=phoneState;messageRef=messageStore;page='securitycode';secReturn='factoryconfirm';frWhich="+str(which)+";secCode='12345';history=['factoryreset','factoryconfirm'];trail=JSON.stringify(history);notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(which)+' restore quota keeps exact state and messages',"return JSON.stringify(phoneState)===before&&JSON.stringify(messageStore)===messagesBefore&&phoneState===stateRef&&messageStore===messageRef&&localStorage.getItem('c2state')===stored")
 t(str(which)+' failure keeps reset choice and code',"return page==='securitycode'&&secCode==='12345'&&JSON.stringify(history)===trail&&notice==='Unable to restore settings'")
 if which==1:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v631-reset-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(str(which)+' retry reaches home',"return page==='home'&&secCode===''&&phoneState.theme===defaultState.theme")
 if which==0:t('Settings-only retry retains personal data',"return phoneState.contacts[0].name==='Personal demo'&&phoneState.groups[0].name==='Personal group'&&messageStore.inbox[0].body==='Personal inbox demo'")
 else:t('Full retry clears personal data',"return phoneState.contacts[0].name==='Alex Morgan'&&!phoneState.groups&&messageStore.inbox[0].body!=='Personal inbox demo'")
 call('Page.reload');time.sleep(.3)
 t(str(which)+' reload confirms reset',"return phoneState.theme===defaultState.theme&&phoneState.contacts[0].name==="+json.dumps('Personal demo' if which==0 else 'Alex Morgan'))
print('PASS',len(checks))
