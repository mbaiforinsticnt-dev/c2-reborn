exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.73-radio-volume-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for folder,prefix,ext in [('Images','DemoPhoto','jpg'),('Video clips','DemoClip','mp4')]:
 ev("phoneState=migrateState(null);phoneState.galDeleted=['"+prefix+"0006."+ext+"'];phoneState.galMoved={'"+prefix+"0007."+ext+"':'Themes'};phoneState.galCopied={'"+prefix+"0008."+ext+"':'Images'};phoneState.galFileNames={'"+prefix+"0009."+ext+"':'Renamed'};saved=recordDemoCapture("+json.dumps(folder)+")")
 t(prefix+' skips historical ids',"return saved==='"+prefix+"0010."+ext+"'&&galActualFiles("+json.dumps(folder)+").some(f=>f.n===saved)")
 call('Page.reload');time.sleep(.3)
 t(prefix+' next identity after reload',"return recordDemoCapture("+json.dumps(folder)+")==='"+prefix+"0011."+ext+"'")
ev("phoneState=migrateState(null);phoneState.galCaptures=[{folder:'Recordings',n:'DemoRecording0001.amr',s:'0 B'},{folder:'Recordings',n:'DemoRecording0003.amr',s:'0 B'}];page='voicerecorder';recording=false;notice='';press('OK');press('OK')")
t('Gapped recordings choose maximum next not count',"return phoneState.galCaptures.at(-1).n==='DemoRecording0004.amr'&&new Set(phoneState.galCaptures.map(f=>f.n)).size===3")
t('Malformed huge historical suffix no invalid name',"phoneState.galDeleted=['DemoPhoto'+'9'.repeat(200)+'.jpg'];return /^DemoPhoto[0-9]+\.jpg$/.test(galNextDemoName('Images','DemoPhoto','jpg',6))")
ev("phoneState=migrateState(null);phoneState.galDeleted=['DemoPhoto0006.jpg'];recordDemoCapture('Images');galFolderName='Images';page='galfolder';notice='';sel=galFolderFiles().findIndex(f=>f.n==='DemoPhoto0007.jpg');draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v629-demo-identity.png','wb').write(base64.b64decode(d['result']['data']))
print('PASS',len(checks))
