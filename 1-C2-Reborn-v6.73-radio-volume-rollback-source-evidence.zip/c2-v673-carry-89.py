exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.73-radio-volume-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);phoneState.theme='Light.nth';makeLocalBackup();phoneState.theme='Black.nth';document.body.dataset.theme=phoneState.theme;persist();page='restorebackup';press('OK')")
t('Restored theme runtime exact',"return phoneState.theme==='Light.nth'&&document.body.dataset.theme==='Light.nth'")
ev("notice='';page='menu';sel=0;draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v665-restored-theme.png','wb').write(base64.b64decode(d['result']['data']))
call('Page.reload');time.sleep(.15)
t('Reload exact theme',"return phoneState.theme==='Light.nth'&&document.body.dataset.theme==='Light.nth'")
ev("phoneState.theme='Black.nth';document.body.dataset.theme=phoneState.theme;persist();beforeTheme=document.body.dataset.theme;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};result=restoreLocalBackup()")
t('Failed restore theme untouched',"return result===null&&phoneState.theme==='Black.nth'&&document.body.dataset.theme===beforeTheme")
print('PASS',len(checks))
