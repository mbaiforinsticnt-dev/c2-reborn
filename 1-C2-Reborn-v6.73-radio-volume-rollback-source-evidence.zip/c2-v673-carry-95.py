exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.73-radio-volume-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("window.expiryTick=()=>{let now=new Date(),hm=now.toTimeString().slice(0,5),day=now.toDateString(),alarmKey=day+' '+hm;if(phoneState.alarm.on&&phoneState.alarm.time===hm&&lastAlarmKey!==alarmKey&&page!=='alarmring'){lastAlarmKey=alarmKey;notice='';history=[];page='alarmring';sel=0;draw();return}if(intervalRunning&&Date.now()>=intervalEndsAt){if(intervalPhase==='Interval'){intervalPhase='Rest';intervalEndsAt=Date.now()+30000}else if(--intervalsLeft>0){intervalPhase='Interval';intervalEndsAt=Date.now()+60000}else{intervalRunning=false;notice='Interval timer finished'}}if(phoneState.timerEndsAt&&Date.now()>=phoneState.timerEndsAt){let beforeEnds=phoneState.timerEndsAt,dur=phoneState.timerValue.split(':').reduce((a,x)=>a*60+(+x),0),repeat=phoneState.countdownAutoRepeat&&dur;phoneState.timerEndsAt=repeat?Date.now()+dur*1000:0;try{persist();notice=repeat?'Timer repeated':'Countdown finished'}catch(err){phoneState.timerEndsAt=beforeEnds;notice='Unable to save timer'}draw()}if((page==='player'&&phoneState.player.playing)||(page==='incall'&&activeCall&&!callHeld)||(recording&&(page==='videorecorder'||page==='voicerecorder'))||(page==='intervaltimer'&&intervalRunning)||(page==='organiser'&&normalTimerActive()))draw()}")
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for repeat in ['true','false']:
 ev("window.expiryTick=()=>{let now=new Date(),hm=now.toTimeString().slice(0,5),day=now.toDateString(),alarmKey=day+' '+hm;if(phoneState.alarm.on&&phoneState.alarm.time===hm&&lastAlarmKey!==alarmKey&&page!=='alarmring'){lastAlarmKey=alarmKey;notice='';history=[];page='alarmring';sel=0;draw();return}if(intervalRunning&&Date.now()>=intervalEndsAt){if(intervalPhase==='Interval'){intervalPhase='Rest';intervalEndsAt=Date.now()+30000}else if(--intervalsLeft>0){intervalPhase='Interval';intervalEndsAt=Date.now()+60000}else{intervalRunning=false;notice='Interval timer finished'}}if(phoneState.timerEndsAt&&Date.now()>=phoneState.timerEndsAt){let beforeEnds=phoneState.timerEndsAt,dur=phoneState.timerValue.split(':').reduce((a,x)=>a*60+(+x),0),repeat=phoneState.countdownAutoRepeat&&dur;phoneState.timerEndsAt=repeat?Date.now()+dur*1000:0;try{persist();notice=repeat?'Timer repeated':'Countdown finished'}catch(err){phoneState.timerEndsAt=beforeEnds;notice='Unable to save timer'}draw()}if((page==='player'&&phoneState.player.playing)||(page==='incall'&&activeCall&&!callHeld)||(recording&&(page==='videorecorder'||page==='voicerecorder'))||(page==='intervaltimer'&&intervalRunning)||(page==='organiser'&&normalTimerActive()))draw()}")
 ev("phoneState=migrateState(null);phoneState.alarm.on=false;phoneState.timerValue='00:01:00';phoneState.countdownAutoRepeat="+repeat+";phoneState.timerEndsAt=Date.now()-100;page='organiser';persist();beforeEnd=phoneState.timerEndsAt;stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};notice='';expiryTick()")
 t(repeat+' exact deadline rollback',"return phoneState.timerEndsAt===beforeEnd&&localStorage.getItem('c2state')===stored")
 t(repeat+' no false finished/repeated',"return notice==='Unable to save timer'&&document.getElementById('screen').innerText.includes(notice)")
 if repeat=='true':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v671-countdown-expiry-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("expiryTick()")
 t(repeat+' repeated failure exact',"return phoneState.timerEndsAt===beforeEnd&&notice==='Unable to save timer'")
 ev("Storage.prototype.setItem=oldStore;expiryTick()")
 t(repeat+' retry succeeds',"return "+("phoneState.timerEndsAt>Date.now()&&notice==='Timer repeated'" if repeat=='true' else "phoneState.timerEndsAt===0&&notice==='Countdown finished'"))
 t(repeat+' persisted deadline matches',"return JSON.parse(localStorage.getItem('c2state')).timerEndsAt===phoneState.timerEndsAt")
 ev("savedEnd=phoneState.timerEndsAt;expiryTick()")
 t(repeat+' second tick no duplicate',"return phoneState.timerEndsAt===savedEnd")
 expectedEnd=ev('phoneState.timerEndsAt');call('Page.reload');time.sleep(.15)
 t(repeat+' reload exact',"return phoneState.timerEndsAt==="+str(expectedEnd))
print('PASS',len(checks))
