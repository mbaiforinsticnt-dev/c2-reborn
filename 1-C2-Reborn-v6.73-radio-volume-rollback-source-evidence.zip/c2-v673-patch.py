from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.72-countdown-repeat-setting-rollback-candidate.html').read_text().replace('v6.72 handset parity','v6.73 handset parity').replace('C2 Reborn v6.72 |','C2 Reborn v6.73 |')
a="if(page==='radio'&&(k==='UP'||k==='DOWN')){phoneState.radioVolume=Math.max(0,Math.min(10,(phoneState.radioVolume??6)+(k==='UP'?1:-1)));persist();notice='Volume '+phoneState.radioVolume;draw();return}"
b="if(page==='radio'&&(k==='UP'||k==='DOWN')){let hadVolume=Object.prototype.hasOwnProperty.call(phoneState,'radioVolume'),beforeVolume=phoneState.radioVolume;phoneState.radioVolume=Math.max(0,Math.min(10,(phoneState.radioVolume??6)+(k==='UP'?1:-1)));try{persist()}catch(err){if(hadVolume)phoneState.radioVolume=beforeVolume;else delete phoneState.radioVolume;notice='Unable to save radio volume';draw();return}notice='Volume '+phoneState.radioVolume;draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save timer|Folder memory full','Unable to save timer|Unable to save radio volume|Folder memory full')
Path('/downloads/C2-Reborn-v6.73-radio-volume-rollback-candidate.html').write_text(s)
