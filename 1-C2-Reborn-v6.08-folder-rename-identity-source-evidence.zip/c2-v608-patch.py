from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.07-folder-edit-rollback-candidate.html').read_text().replace('v6.07 handset parity','v6.08 handset parity').replace('C2 Reborn v6.07 |','C2 Reborn v6.08 |')
a="let _old=phoneState.galleryFolders[galRenameIdx-screens.gallery.length],_new=folderName.trim();phoneState.galleryFolders[galRenameIdx-screens.gallery.length]=_new;"
b="let _old=phoneState.galleryFolders[galRenameIdx-screens.gallery.length],_new=folderName.trim(),_parent=phoneState.galFolderParents[_old]||'Memory card';if(_new!==_old&&(screens.gallery.includes(_new)||phoneState.galleryFolders.some(v=>v!==_old&&v.toLowerCase()===_new.toLowerCase())||galChildFolders(_parent).some(v=>v!==_old&&galDisplayName(v).toLowerCase()===_new.toLowerCase()))){notice='Folder name already exists';draw();return}if(_new!==_old){phoneState.galleryFolders[galRenameIdx-screens.gallery.length]=_new;"
assert s.count(a)==1;s=s.replace(a,b)
a="if(_map[_id]===_old)_map[_id]=_new;(()=>{try{persist()}"
b="if(_map[_id]===_old)_map[_id]=_new;}(()=>{try{persist()}"
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('Name already exists|Selected memory empty','Name already exists|Folder name already exists|Selected memory empty',1)
Path('/downloads/C2-Reborn-v6.08-folder-rename-identity-candidate.html').write_text(s)
