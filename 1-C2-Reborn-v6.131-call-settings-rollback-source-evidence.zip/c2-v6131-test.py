exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.131-call-settings-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices={2:['off','On'],3:['off','On'],4:['off','On'],5:['Inactive','Active'],6:['off','On'],8:['off','On'],9:['off','On'],10:['Set by network','Yes','No'],11:['Yes','No']}
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in [2,3,4,5,6,8,9,10,11]:
  for choice in range(len(choices[row])):
   for absent in [False,True]:
    val=choices[row][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.callVals;" if absent else "phoneState.callVals=pickerDefaults('callsettings');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.callVals;stored=localStorage.getItem('c2state');history=['callsettings'];notice='';noticeBack=false;open=false;"+("page='callsettings';sel="+str(row)+";pickerDraft={page:'callsettings',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'callsettings',row:"+str(row)+",title:'Call setting',opts:"+json.dumps(choices[row])+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.callVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='callsettings'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save call setting'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and row==2 and choice==1 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6131-call-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.callVals["+str(row)+"]==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.callVals["+str(row)+"]==="+json.dumps(val))
print('PASS',len(checks))
