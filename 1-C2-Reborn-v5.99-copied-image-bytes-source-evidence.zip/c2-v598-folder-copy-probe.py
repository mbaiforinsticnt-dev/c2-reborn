exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.98-saved-image-details-candidate.html'))
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'CopyProbe',layer:{text:'2',bold:true,rotation:0}};draw();press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
print(ev("(()=>{let row=phoneState.galEditedImages[0];phoneState.galleryFolders=['Source','Destination'];phoneState.galFolderParents={Source:'Memory card',Destination:'Memory card'};phoneState.galMoved={CopyProbe:'Source'};phoneState.galMoved={'CopyProbe.gif':'Source'};let result=galCopyFolderTo('Source','Destination');galFolderName=result.key;let f=galFolderFiles()[0];return JSON.stringify({result,big:f.big,src:f.src,source:row.src.slice(0,35),n:f.n})})()"))
