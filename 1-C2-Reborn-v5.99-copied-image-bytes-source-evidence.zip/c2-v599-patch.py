from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.98-saved-image-details-candidate.html').read_text().replace('v5.98 handset parity','v5.99 handset parity').replace('C2 Reborn v5.98 |','C2 Reborn v5.99 |')
a='s:cleanText(v.s,20),source:cleanText(v.source,100)})):[];d.galDeleted'
b="s:cleanText(v.s,20),source:cleanText(v.source,100),...(/^data:image\\/gif;base64,/.test(v.src||'')&&v.src.length<1000000?{src:v.src,big:v.src}:{})})):[];d.galDeleted"
assert s.count(a)==1;s=s.replace(a,b)
a="s:f.s||'0 B',source:f.source||f.n})"
b="s:f.s||'0 B',source:f.source||f.n,...(/^data:image\\/gif;base64,/.test(f.src||'')&&f.src.length<1000000?{src:f.src,big:f.src}:{})})"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v5.99-copied-image-bytes-candidate.html').write_text(s)
