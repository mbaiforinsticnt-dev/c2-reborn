from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.05-file-rename-rollback-candidate.html').read_text().replace('v6.05 handset parity','v6.06 handset parity').replace('C2 Reborn v6.05 |','C2 Reborn v6.06 |')
a="if(k==='LSK'){if(gd==='delfolder'){"
b="if(k==='LSK'){let deletionRollback=gd!=='sendwarn'?{galleryFolders:phoneState.galleryFolders.slice(),galFolderItems:phoneState.galFolderItems.slice(),galFolderParents:{...phoneState.galFolderParents},galFolderNames:{...phoneState.galFolderNames},galDeleted:phoneState.galDeleted.slice()}:null;if(gd==='delfolder'){"
assert s.count(a)==1;s=s.replace(a,b)
start=s.find("if(galDialog){let gd=galDialog");end=s.find("if(gd==='format')",start)
t=s[start:end];assert t.count('persist();')==3
t=t.replace("persist();","try{persist()}catch(err){Object.assign(phoneState,deletionRollback);notice='Unable to save deletion';draw();return}")
s=s[:start]+t+s[end:];s=s.replace('Fax not activated|Unable to save file name','Fax not activated|Unable to save deletion|Unable to save file name',1)
Path('/downloads/C2-Reborn-v6.06-gallery-delete-rollback-candidate.html').write_text(s)
