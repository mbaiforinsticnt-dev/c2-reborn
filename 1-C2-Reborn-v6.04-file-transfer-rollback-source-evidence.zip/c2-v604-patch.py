from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.03-folder-move-rollback-candidate.html').read_text().replace('v6.03 handset parity','v6.04 handset parity').replace('C2 Reborn v6.03 |','C2 Reborn v6.04 |')
a="phoneState.galMoved=phoneState.galMoved||{};phoneState.galCopied=phoneState.galCopied||{};galTarget.names.forEach(id=>{if(galTarget.op==='Move')phoneState.galMoved[id]=_dst;else phoneState.galCopied[id]=_dst});persist()"
b="let oldMoved={...phoneState.galMoved},oldCopied={...phoneState.galCopied};phoneState.galMoved=phoneState.galMoved||{};phoneState.galCopied=phoneState.galCopied||{};galTarget.names.forEach(id=>{if(galTarget.op==='Move')phoneState.galMoved[id]=_dst;else phoneState.galCopied[id]=_dst});try{persist()}catch(err){phoneState.galMoved=oldMoved;phoneState.galCopied=oldCopied;notice='Unable to save file '+(galTarget.op==='Move'?'move':'copy');draw();return}"
assert s.count(a)==1;s=s.replace(a,b).replace('Fax not activated|Unable to save copied folder','Fax not activated|Unable to save file (move|copy)|Unable to save copied folder',1)
Path('/downloads/C2-Reborn-v6.04-file-transfer-rollback-candidate.html').write_text(s)
