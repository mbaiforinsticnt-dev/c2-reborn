exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.27-wallpaper-rollback-candidate.html'))
print(ev("phoneState=migrateState(null);phoneState.groups=[{name:'Demo group',number:'123'}];galUseFile={id:'Photo0001.jpg'};page='galusegroups';sel=0;galUsePress('OK');JSON.stringify({notice,group:phoneState.groups[0]})"))
call('Page.reload');time.sleep(.3)
print(ev("JSON.stringify(phoneState.groups[0])"))
