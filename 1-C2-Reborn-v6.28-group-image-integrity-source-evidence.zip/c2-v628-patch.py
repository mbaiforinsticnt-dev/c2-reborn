from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.27-wallpaper-rollback-candidate.html').read_text().replace('v6.27 handset parity','v6.28 handset parity').replace('C2 Reborn v6.27 |','C2 Reborn v6.28 |')
a="d.groups=x.groups.slice(0,50).filter(v=>v&&typeof v==='object').map(v=>({name:cleanText(v.name,80),number:cleanText(v.number,40)}))"
b="d.groups=x.groups.slice(0,50).filter(v=>v&&typeof v==='object').map(v=>({name:cleanText(v.name,80),number:cleanText(v.number,40),...(typeof v.image==='string'?{image:cleanText(v.image,164)}:{})}))"
assert s.count(a)==1;s=s.replace(a,b)
a="g[sel].image=galUseFile?galUseFile.id:'';persist();notice='Image applied';draw()"
b="let row=g[sel],had=Object.prototype.hasOwnProperty.call(row,'image'),old=row.image;row.image=galUseFile?galUseFile.id:'';try{persist()}catch(err){if(had)row.image=old;else delete row.image;notice='Unable to save group image';draw();return true}notice='Image applied';draw()"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save wallpaper|Folder memory full|';b='Unable to save wallpaper|Unable to save group image|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.28-group-image-integrity-candidate.html').write_text(s)
