from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.64-backup-call-timer-sync-candidate.html').read_text().replace('v6.64 handset parity','v6.65 handset parity').replace('C2 Reborn v6.64 |','C2 Reborn v6.65 |')
a="callTimerSecs=phoneState.callTimerSecs;return true}function seedMessageStore()";b="callTimerSecs=phoneState.callTimerSecs;document.body.dataset.theme=phoneState.theme;return true}function seedMessageStore()";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.65-backup-theme-sync-candidate.html').write_text(s)
