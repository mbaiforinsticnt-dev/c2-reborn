exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.65-backup-theme-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['inbox','messageread','msgopen-template','msgopen-calendar']:
 p='msgopen' if mode.startswith('msgopen') else mode
 act="open=true;os=currentOptions().indexOf("+json.dumps('Copy to Calendar' if mode.endswith('calendar') else 'Copy as template')+");press('OK')"
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();let items=[{id:'copy',body:'Copy',text:'Copy',name:'Demo',dir:'in',unread:false}];messageStore.inbox=items.slice();messageStore.threads={alex:items.slice()};phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps(p)+";sel=0;readMessageIndex=0;openMsgIdx=0;conversationKey='alex';notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' source page and identity retained',"return page==="+json.dumps(p)+"&&sel===0&&openMsgIdx===0&&readMessageIndex===0&&messageStore.inbox[0].id==='copy'&&messageStore.threads.alex[0].id==='copy'")
 t(mode+' visible warning',"return notice==='Unable to copy message'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='inbox':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v655-message-copy-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="phoneState.calendar.filter(x=>x.text==='Copy').length===1" if mode.endswith('calendar') else "phoneState.templates.filter(x=>x==='Copy').length===1"
 t(mode+' retry copies once',"return "+expect+"&&messageStore.inbox.length===1&&messageStore.threads.alex.length===1")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
