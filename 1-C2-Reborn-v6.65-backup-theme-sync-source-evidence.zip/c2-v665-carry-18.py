exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.65-backup-theme-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['existing','new','multiple']:
 nums=['+44 7700 900123'] if mode=='existing' else ['+44 7700 900888'] if mode=='new' else ['+44 7700 900888','+44 7700 900999']
 ev("clearTimeout(window._simT);window._simT=0;phoneState=migrateState(null);phoneState.messageRecipients=[];messageStore=seedMessageStore();messageStore.threads={alex:[]};messageStore.numberedKeys=[];phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='compose';draft='New sent';recipientText="+json.dumps(';'.join(nums)+';')+";composeSubject='Subject';subjectEditor=false;conversationKey='alex';conversationNumber='old';conversationName='old';cursor=4;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};sendDraft()")
 t(mode+' exact store and recipients rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&phoneState.messageStore===messageStore")
 t(mode+' composer conversation retained',"return page==='compose'&&draft==='New sent'&&composeSubject==='Subject'&&cursor===4&&conversationKey==='alex'&&conversationNumber==='old'&&conversationName==='old'&&!window._simT")
 t(mode+' visible warning',"return notice==='Unable to save sent message'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='multiple':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v650-demo-send-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';sendDraft();clearTimeout(window._simT);window._simT=0")
 t(mode+' retry intended messages once',"return Object.values(messageStore.threads).flat().filter(x=>x.text==='New sent').length==="+str(len(nums))+"&&phoneState.messageRecipients.length==="+str(len(nums))+"&&page==='conversation'&&draft===''")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return Object.values(messageStore.threads).flat().filter(x=>x.text==='New sent').length==="+str(len(nums))+"&&phoneState.messageRecipients.length==="+str(len(nums)))
print('PASS',len(checks))
