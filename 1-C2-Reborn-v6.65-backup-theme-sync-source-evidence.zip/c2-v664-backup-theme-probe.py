exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.64-backup-call-timer-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.theme='Light.nth';makeLocalBackup();phoneState.theme='Black.nth';document.body.dataset.theme=phoneState.theme;persist();restoreLocalBackup()")
print(ev("JSON.stringify({storedTheme:phoneState.theme,visibleTheme:document.body.dataset.theme})"))
