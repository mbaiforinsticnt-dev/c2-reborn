exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.65-backup-theme-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
def details(name,pg='galfolder'):
 ev("galEditor=null;page="+json.dumps(pg)+";galFolderName='Images';sel=galFolderFiles().findIndex(f=>f.n==="+json.dumps(name)+");open=true;os=currentOptions().indexOf('Details');draw();press('OK')");time.sleep(.1)
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'DetailProbe'};draw();press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
details('DetailProbe.gif')
t('Saved GIF actual format and dimensions',"return page==='galfolderdetails'&&document.getElementById('screen').innerText.includes('GIF')&&document.getElementById('screen').innerText.includes('240 x 320')&&!document.getElementById('screen').innerText.includes('JPG')&&!document.getElementById('screen').innerText.includes('1600 x 1200')")
t('Unknown copyright not invented',"return !document.getElementById('screen').innerText.includes('Copyright')")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v598-gif-details.png','wb').write(base64.b64decode(d['result']['data']))
t('Back restores selected folder file',"press('BACK');return page==='galfolder'&&galFolderFiles()[sel].n==='DetailProbe.gif'")
details('DetailProbe.gif','galphoto')
t('Photo viewer Details corrected',"return document.getElementById('screen').innerText.includes('GIF')&&document.getElementById('screen').innerText.includes('240 x 320')")
call('Page.reload');time.sleep(.3);details('DetailProbe.gif')
t('Previously stored GIF decoded after reload',"return document.getElementById('screen').innerText.includes('240 x 320')")
details('Photo0001.jpg')
t('Static fixture details unchanged',"return !galDetailEdited&&document.getElementById('screen').innerText.includes('JPG')&&document.getElementById('screen').innerText.includes('1600 x 1200')")
t('Folder details clears image metadata',"page='gallery';sel=galOrder().findIndex(x=>x.n==='Images');open=true;os=currentOptions().indexOf('Details');draw();press('OK');return !galDetailEdited&&!document.getElementById('screen').innerText.includes('Format:')")
t('No leaked late image callback',"let d=galEditedDetail({src:phoneState.galEditedImages[0].src});galDetailEdited=null;page='home';draw();return page==='home'")
time.sleep(.1);t('Home remains after load',"return page==='home'&&!galDetailEdited")
print('PASS',len(checks))
