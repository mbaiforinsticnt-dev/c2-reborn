from pathlib import Path
import re,subprocess
logs=[];total=0;fail=[]
fs=list(Path('/tmp').glob('reg573*test.py'))+[Path('/tmp/c2-v572-test.py'),Path('/tmp/c2-v573-test.py')]
for i,p in enumerate(fs):
 t=p.read_text();t=re.sub(r'file:///downloads/[^\x27\x22]+\.html','file:///downloads/C2-Reborn-v5.77-alarm-form-candidate.html',t)
 t=t.replace("check('Unverified Delete all guarded',\"swFlash==='Delete all needs handset evidence'&&swSaves().length===1\")", "check('Delete all confirmation preserves until Yes',\"swConfirm==='all'&&swSaves().length===1\");act(\"press('RSK')\")")
 if 'Starts timer and selects its parent row' in t:t=t.replace("press('OK');return page==='organiser'", "press('OK');press('OK');return page==='organiser'")
 q=Path('/tmp/reg577-' +str(i)+'.py');q.write_text(t);r=subprocess.run(['python3',str(q)],capture_output=True,text=True);logs.append(p.name+'\n'+r.stdout+r.stderr)
 if r.returncode:fail.append(p.name)
 else:total+=sum(int(n) for n in re.findall(r'PASS (\d+)',r.stdout))
Path('/tmp/c2-v577-regression.log').write_text('\n'.join(logs));print('FILES',len(fs),'PASS CHECKS',total,'FAILED',fail)
