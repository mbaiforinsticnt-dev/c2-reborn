exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.77-alarm-form-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False});time.sleep(.1)
checks=[]
def t(label,expr):
 v=ev(expr);checks.append((label,v));print(label,v);assert v is True,(label,v)
def keys(*ks):
 for k in ks:ev('press('+json.dumps(k)+')')
def snap(name):
 d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v577-'+name+'.png','wb').write(base64.b64decode(d['result']['data']))
ev("phoneState.alarm={on:false,time:'07:00',repeat:false,tone:'Standard',snooze:10,days:[]};persist();go('alarmclock')")
t('inline Save clean Back',"sm.textContent==='Save'&&sr.textContent==='Back'&&document.querySelector('.alarmWrap')!==null")
snap('alarm-entry');keys('RIGHT');t('draft only not persisted',"alarmDraft.on===true&&phoneState.alarm.on===false&&sr.textContent==='Cancel'")
keys('RSK');t('cancel question',"alarmMode==='cancel'&&sl.textContent==='No'&&sm.textContent==='Yes'&&sr.textContent==='Back'");snap('alarm-save-question');keys('RSK');t('Back keeps editing',"alarmMode===''&&alarmDraft.on===true");keys('RSK','LSK');t('No discards',"page==='organiser'&&phoneState.alarm.on===false")
ev("go('alarmclock')");keys('RIGHT','DOWN','0','9','3','0');t('inline time entry',"alarmDraft.time==='09:30'&&phoneState.alarm.time==='07:00'&&sl.textContent===''");keys('DOWN','RIGHT');t('conditional repeat days',"alarmFields().includes('days')&&phoneState.alarm.repeat===false");keys('DOWN','LSK');t('Change menu',"alarmMode==='change'");keys('OK','OK','DOWN','DOWN','OK');t('marked Mon Wed',"JSON.stringify(alarmDraft.days)==='[0,2]'");keys('LSK','OK');t('mark all',"alarmDraft.days.length===7");keys('LSK','DOWN','OK');t('unmark all',"alarmDraft.days.length===0");keys('LSK','DOWN','DOWN','OK');t('undo picker selections',"alarmDraft.days.length===0");keys('OK','RSK');t('single day label',"alarmDaysLabel()==='Wednesday'");keys('DOWN','LSK','OK');t('real tone picker',"alarmMode==='tones'&&document.querySelector('#screen').innerText.includes('Open Gallery')&&document.querySelector('#screen').innerText.includes('Tone downloads')");snap('tone-picker');keys('DOWN','OK');t('Radio draft',"alarmDraft.tone==='Radio'&&phoneState.alarm.tone==='Standard'");keys('LSK','OK','DOWN','OK');t('gallery honest boundary',"alarmMode==='unimplemented'&&alarmDraft.tone==='Radio'&&sm.textContent===''");keys('RSK','RSK','DOWN','2','2');t('numeric snooze no fake cycle',"alarmDraft.snooze==='22'&&sl.textContent===''");snap('snooze');keys('RSK','OK');t('Yes persists and check notice',"alarmMode==='saved'&&phoneState.alarm.time==='09:30'&&phoneState.alarm.snooze===22&&phoneState.alarm.repeat===true");snap('saved');keys('OK');t('returns Organiser repeat subtitle',"page==='organiser'&&document.querySelector('#screen').innerText.includes('09:30 Repeat on')")
call('Page.reload');time.sleep(.3);ev("go('alarmclock')");t('saved reload state',"alarmDraft.time==='09:30'&&alarmDraft.snooze==='22'&&alarmDraft.days[0]===2&&alarmDraft.tone==='Radio'")
keys('END');t('End exits',"page==='home'&&alarmDraft===null")
print('PASS',len(checks))
