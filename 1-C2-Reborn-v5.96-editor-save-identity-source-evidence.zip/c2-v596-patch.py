from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.95-editor-gif-compression-candidate.html').read_text().replace('v5.95 handset parity','v5.96 handset parity').replace('C2 Reborn v5.95 |','C2 Reborn v5.96 |')
s=s.replace("galActualFiles('Images').some(f=>((phoneState.galFileNames||{})[f.n]||f.display||f.n).toLowerCase()===name.toLowerCase())", "Object.values(GAL_FILES).flat().concat(phoneState.galEditedImages||[],phoneState.galCaptures||[],phoneState.galFolderItems||[]).some(f=>f.n.toLowerCase()===name.toLowerCase()||((phoneState.galFileNames||{})[f.n]||f.display||f.n).toLowerCase()===name.toLowerCase())",1)
Path('/downloads/C2-Reborn-v5.96-editor-save-identity-candidate.html').write_text(s)
