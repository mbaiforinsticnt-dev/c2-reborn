exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.95-editor-gif-compression-candidate.html'))
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';sel=0;galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'Probe'};draw();press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
ev("phoneState.galDeleted=['Probe.gif'];galEditor.stage='saveName';press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
print(ev("JSON.stringify({stage:galEditor.stage,copies:phoneState.galEditedImages.length,visible:galActualFiles('Images').filter(f=>f.n==='Probe.gif').length})"))
