from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.99-home-content-assignment-rollback-candidate.html').read_text().replace('v6.99 handset parity','v6.100 handset parity').replace('C2 Reborn v6.99 |','C2 Reborn v6.100 |')
a="else if(page==='contentoptions'){if(!phoneState.homeContentMarks)phoneState.homeContentMarks=CONTENT_OPTS.map((_,i)=>i!==10);phoneState.homeContentMarks[sel]=!phoneState.homeContentMarks[sel];persist();draw();return}"
b="else if(page==='contentoptions'){let hadMarks=Object.prototype.hasOwnProperty.call(phoneState,'homeContentMarks'),beforeMarks=phoneState.homeContentMarks;phoneState.homeContentMarks=(beforeMarks||CONTENT_OPTS.map((_,i)=>i!==10)).slice();phoneState.homeContentMarks[sel]=!phoneState.homeContentMarks[sel];try{persist()}catch(err){if(hadMarks)phoneState.homeContentMarks=beforeMarks;else delete phoneState.homeContentMarks;notice='Unable to save content options';draw();return}draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save home content|Folder memory full','Unable to save home content|Unable to save content options|Folder memory full')
Path('/downloads/C2-Reborn-v6.100-content-options-rollback-candidate.html').write_text(s)
