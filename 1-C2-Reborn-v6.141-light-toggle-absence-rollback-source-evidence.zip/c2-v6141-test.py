exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.141-light-toggle-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for before in ['absent',True,False]:
 ev("phoneState=migrateState(null);"+("delete phoneState.lights;" if before=='absent' else "phoneState.lights="+json.dumps(before)+";")+"persist();before=JSON.stringify(phoneState);had=Object.prototype.hasOwnProperty.call(phoneState,'lights');stored=localStorage.getItem('c2state');page='lights';sel=0;history=['settings'];notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(before)+' rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'lights')===had&&localStorage.getItem('c2state')===stored")
 t(str(before)+' context',"return page==='lights'&&notice==='Unable to save lights'")
 if before=='absent':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6141-toggle-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(str(before)+' repeat',"return Object.prototype.hasOwnProperty.call(phoneState,'lights')===had")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(str(before)+' retry',"return phoneState.lights==="+json.dumps(not before if before!='absent' else True))
 call('Page.reload');time.sleep(.15)
 t(str(before)+' reload',"return phoneState.lights==="+json.dumps(not before if before!='absent' else True))
print('PASS',len(checks))
