from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.91-display-restore-rollback-candidate.html').read_text().replace('v6.91 handset parity','v6.92 handset parity').replace('C2 Reborn v6.91 |','C2 Reborn v6.92 |')
a="else if(page==='lights'){phoneState.lights=!phoneState.lights;persist();draw();return}"
b="else if(page==='lights'){let beforeLights=phoneState.lights;phoneState.lights=!beforeLights;try{persist()}catch(err){phoneState.lights=beforeLights;notice='Unable to save lights';draw();return}draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to restore display settings|Folder memory full','Unable to restore display settings|Unable to save lights|Folder memory full')
Path('/downloads/C2-Reborn-v6.92-lights-toggle-rollback-candidate.html').write_text(s)
