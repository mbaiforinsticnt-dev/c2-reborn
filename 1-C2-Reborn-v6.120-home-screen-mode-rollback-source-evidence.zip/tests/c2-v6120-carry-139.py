exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.120-home-screen-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for filt in ['marked','unmarked']:
 for origin,dest in [('conversations','home'),('conversations','messaging'),('messaging','conversations'),('home','conversations')]:
  ev("phoneState=migrateState(null);messageStore.markFilter="+json.dumps(filt)+";persist();before=JSON.stringify(phoneState);storeAlias=messageStore;stored=localStorage.getItem('c2state');page="+json.dumps(origin)+";sel=0;history=[];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};go("+json.dumps(dest)+")")
  label=filt+' '+origin+' '+dest
  t(label+' rollback',"return JSON.stringify(phoneState)===before&&messageStore===storeAlias&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return page==="+json.dumps(origin)+"&&history.length===0&&notice==='Unable to save conversation filter'&&document.getElementById('screen').innerText.includes(notice)")
  if filt=='marked' and origin=='conversations' and dest=='home':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6115-filter-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';go("+json.dumps(dest)+")")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';go("+json.dumps(dest)+")")
  t(label+' retry',"return page==="+json.dumps(dest)+"&&messageStore.markFilter===''&&history.length===1")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return messageStore.markFilter===''")
print('PASS',len(checks))
