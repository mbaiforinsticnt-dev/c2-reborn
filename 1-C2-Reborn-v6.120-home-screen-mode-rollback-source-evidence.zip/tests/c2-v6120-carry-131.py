exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.120-home-screen-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['OK','LSK']:
 for existing in [False,True]:
  ev("phoneState=migrateState(null);"+("phoneState.callDiverts={'All voice calls:If busy':{active:false,number:'Prior'},Other:{active:true,number:'901'}};" if existing else "phoneState.callDiverts={};")+"persist();before=JSON.stringify(phoneState);beforeDiverts=phoneState.callDiverts;stored=localStorage.getItem('c2state');page='divertnum';divertScope='All voice calls';divertName='If busy';divertNumVal='+447700900123';history=['divertdest'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press("+json.dumps(key)+")")
  label=key+str(existing)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.callDiverts===beforeDiverts&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save call divert'&&document.getElementById('screen').innerText.includes(notice)&&page==='divertnum'&&divertNumVal==='+447700900123'&&history.length===1")
  if key=='OK' and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6107-divert-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press("+json.dumps(key)+")")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press("+json.dumps(key)+")")
  t(label+' retry',"return phoneState.callDiverts['All voice calls:If busy'].active&&phoneState.callDiverts['All voice calls:If busy'].number==='+447700900123'&&notice==='Call divert activated'")
  saved=ev('JSON.stringify(phoneState.callDiverts)');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(phoneState.callDiverts)==="+json.dumps(saved))
print('PASS',len(checks))
