exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.120-home-screen-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['inbox','messageread','msgmove']:
 act="press('OK')" if mode=='msgmove' else "open=true;os=currentOptions().indexOf('Move');press('OK')"
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();let items=[{id:'move',body:'Move',text:'Move',name:'Demo',dir:'in',unread:false},{id:'keep',body:'Keep',text:'Keep',name:'Demo',dir:'in',unread:false}];messageStore.inbox=items.slice();messageStore.threads={alex:items.slice()};messageStore.saved=[];DEMO_THREAD=messageStore.threads.alex;phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps(mode)+";sel=0;readMessageIndex=0;openMsgIdx=0;conversationKey='alex';history=[{page:'conversation',sel:0},{page:'msgopen',sel:0}];notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' selection source retained',"return page==="+json.dumps(mode)+"&&sel===0&&openMsgIdx===0&&readMessageIndex===0&&history.length===2")
 t(mode+' visible warning',"return notice==='Unable to move message'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='inbox':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v653-message-move-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="messageStore.saved.length===1&&messageStore.saved[0].id==='move'&&"+('messageStore.threads.alex' if mode=='msgmove' else 'messageStore.inbox')+".length===1&&"+('messageStore.threads.alex' if mode=='msgmove' else 'messageStore.inbox')+"[0].id==='keep'"
 t(mode+' retry moves once',"return "+expect)
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
