exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.120-home-screen-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['activate','timed','expired']:
 ev("phoneState=migrateState(null);phoneState.tones=profileToneStore('General');phoneState.flight=false;page='profileopts';profileOptsFor=screens.profiles.indexOf('Flight');sel="+('2' if mode=='timed' else '0')+";history=['profiles'];notice=''")
 if mode=='expired':ev("phoneState.profile='Flight';phoneState.flight=true;phoneState.tones=profileToneStore('Flight');phoneState.timedProfile={name:'Flight',until:Date.now()-1000};phoneState.timedProfilePrev='General';page='home'")
 ev("persist();before=JSON.stringify(phoneState);beforeTones=phoneState.tones;beforeProfileTones=phoneState.profileTones;beforeTimed=phoneState.timedProfile;stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')}")
 action='draw()' if mode=='expired' else "press('OK')"
 ev(action)
 t(mode+' exact state rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' exact aliases',"return phoneState.tones===beforeTones&&phoneState.profileTones===beforeProfileTones&&phoneState.timedProfile===beforeTimed")
 t(mode+' warning visible',"return notice==='Unable to save profile'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='activate':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v680-profile-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';"+action)
 t(mode+' repeated failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';writes=0;Storage.prototype.setItem=function(k,v){writes++;return oldStore.call(this,k,v)};"+action+";Storage.prototype.setItem=oldStore")
 t(mode+' retry atomic persist',"return writes===1&&phoneState.tones===phoneState.profileTones[phoneState.profile]")
 t(mode+' retry outcome',"return "+("phoneState.profile==='General'&&!phoneState.flight&&phoneState.timedProfile===null&&notice==='Timed profile expired - General restored'" if mode=='expired' else "phoneState.profile==='Flight'&&phoneState.flight&&page==='home'&&notice==='Flight "+('timed for 1 hour' if mode=='timed' else 'activated')+"'"))
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact profile',"return phoneState.profile==='"+('General' if mode=='expired' else 'Flight')+"'&&phoneState.tones===phoneState.profileTones[phoneState.profile]")
print('PASS',len(checks))
