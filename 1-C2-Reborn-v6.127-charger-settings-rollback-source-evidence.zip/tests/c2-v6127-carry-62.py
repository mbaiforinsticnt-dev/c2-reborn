exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.127-charger-settings-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);phoneState.groups=[{name:'Demo group',number:'123'}];galUseFile={id:'Photo0001.jpg'};page='galusegroups';sel=0;galUsePress('OK')")
t('Assigned image written to group',"return phoneState.groups[0].image==='Photo0001.jpg'&&notice==='Image applied'")
call('Page.reload');time.sleep(.3)
t('Group image survives reload',"return phoneState.groups[0].image==='Photo0001.jpg'&&phoneState.groups[0].name==='Demo group'")
t('Long GIF ID survives group migration',"let id='x'.repeat(160)+'.gif',d=migrateState({groups:[{name:'Demo',number:'123',image:id}]});return d.groups[0].image===id")
t('Absent or invalid image remains absent',"let d=migrateState({groups:[{name:'A'},{name:'B',image:{bad:true}}]});return d.groups.every(g=>!Object.prototype.hasOwnProperty.call(g,'image'))")
for had in [False,True]:
 ev("phoneState=migrateState(null);phoneState.groups=[{name:'Demo group',number:'123'"+(",image:'Old.jpg'" if had else '')+"}];persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');galUseFile={id:'Photo0001.jpg'};page='galusegroups';sel=0;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};galUsePress('OK')")
 t(str(had)+' quota exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&notice==='Unable to save group image'&&page==='galusegroups'")
 if not had:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v628-group-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';galUsePress('OK')")
 t(str(had)+' retry commits image once',"return phoneState.groups.length===1&&phoneState.groups[0].image==='Photo0001.jpg'&&notice==='Image applied'")
 call('Page.reload');time.sleep(.3)
 t(str(had)+' retry reload persisted',"return phoneState.groups[0].image==='Photo0001.jpg'")
print('PASS',len(checks))
