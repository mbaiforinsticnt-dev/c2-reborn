exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.127-charger-settings-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for count in [0,1,8]:
 ev("phoneState=migrateState(null);phoneState.radioSaved=Array.from({length:"+str(count)+"},(_,i)=>({frequency:(88+i).toFixed(1),name:'Keep'+i}));phoneState.radioFrequency='99.9';phoneState.radioStationIndex=0;persist();beforeSaved=phoneState.radioSaved;before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='radio';open=true;os=currentOptions().indexOf('Save station');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(count)+' exact rollback alias',"return phoneState.radioSaved===beforeSaved&&JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(str(count)+' visible warning',"return notice==='Unable to save radio station'&&document.getElementById('screen').innerText.includes(notice)")
 if count==1:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v675-radio-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';open=true;os=currentOptions().indexOf('Save station');press('OK')")
 t(str(count)+' repeated failure exact',"return phoneState.radioSaved===beforeSaved&&JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=currentOptions().indexOf('Save station');press('OK')")
 t(str(count)+' retry once',"return phoneState.radioSaved.length==="+str(count+1)+"&&phoneState.radioStationIndex==="+str(count)+"&&phoneState.radioSaved["+str(count)+"].frequency==='99.9'&&notice==='Station 99.9 saved'")
 ev("notice='';open=true;os=currentOptions().indexOf('Save station');press('OK')")
 t(str(count)+' duplicate guard',"return phoneState.radioSaved.length==="+str(count+1)+"&&notice==='Station already saved'")
 call('Page.reload');time.sleep(.15)
 t(str(count)+' reload exact',"return phoneState.radioSaved.length==="+str(count+1)+"&&phoneState.radioSaved["+str(count)+"].frequency==='99.9'")
ev("phoneState=migrateState(null);phoneState.radioSaved=Array.from({length:9},(_,i)=>({frequency:(88+i).toFixed(1),name:'Keep'+i}));phoneState.radioFrequency='99.9';before=JSON.stringify(phoneState);page='radio';open=true;os=currentOptions().indexOf('Save station');press('OK')")
t('Full guard unchanged',"return JSON.stringify(phoneState)===before&&notice==='Station list full'")
print('PASS',len(checks))
