exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.127-charger-settings-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for key in ['OK','LSK']:
  for absent in [False,True]:
   ev("phoneState=migrateState(null);"+("delete phoneState.tvVals;" if absent else "phoneState.tvVals=pickerDefaults('tvcable');phoneState.tvVals[1]='PAL';")+"persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');history=['tvcable'];notice='';open=false;"+("page='tvcable';sel=1;pickerDraft={page:'tvcable',row:1,value:'NTSC'};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel=1;pickerDraft=null;radioCtx={page:'tvcable',row:1,title:'TV system',opts:['PAL','NTSC']};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press("+json.dumps(key)+")")
   label=route+key+str(absent)
   t(label+' rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
   t(label+' context',"return "+("pickerDraft===draftAlias&&page==='tvcable'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save TV system setting'&&document.getElementById('screen').innerText.includes(notice)")
   if route=='picker' and key=='OK' and not absent:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6124-tv-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("notice='';press("+json.dumps(key)+")")
   t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
   ev("Storage.prototype.setItem=oldStore;notice='';press("+json.dumps(key)+")")
   t(label+' retry',"return phoneState.tvVals[1]==='NTSC'&&"+("pickerDraft===null" if route=='picker' else "radioCtx===null"))
   call('Page.reload');time.sleep(.15)
   t(label+' reload',"return phoneState.tvVals[1]==='NTSC'")
print('PASS',len(checks))
