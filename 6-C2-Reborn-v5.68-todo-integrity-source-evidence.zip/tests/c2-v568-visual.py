exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.68-todo-integrity-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
start="phoneState=migrateState(null);phoneState.todos=[{s:'Existing alarm',p:'High',d:'01-10-2099',t:'09:00',done:true,al:'With tone',ad:'01-10-2099',at:'08:30'}];page='todoview';todoViewIdx=0;sel=0;open=false;notice='';draw();press('OK')"
for n,e in [('alarm-form',start),('invalid-due',"todoDate='31022026';todoTime='2560';press('OK')"),('saved',"notice='';todoDate='01102099';todoTime='0900';noteText='Edited subject';press('OK');notice='';draw()")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v568-todo-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
