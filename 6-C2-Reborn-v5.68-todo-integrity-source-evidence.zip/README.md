# C2 Reborn v5.68: To-do data integrity

No index deployment. Includes previous delivered pending-bank snapshots v5.64-v5.67. Banking remains parked.

Edit now hydrates saved alarm mode/date/time rather than silently resetting to No alarm. Subject-only save preserves alarm and done state. Explicit No alarm still removes alarm fields. Validated DD-MM-YYYY/HH:MM due and alarm values stop writes on impossible dates/times. Existing past-alarm rejection rule unchanged. Stored date/time text is escaped in list and View.

11 focused plus 174 carried checks and syntax pass. Subject-only alarm retention survives reload; Silent/No alarm, invalid due date/time, invalid alarm, valid leap day and markup escaping tested. Inspected mobile normal editor, invalid-due notice and saved completed item. Editor alarm fields are below LCD in current layout; not visually certified. That pre-existing editor viewport issue is the next audit gap.

This is internal data-integrity repair, not new handset/SDK certification. Alarm policy/timing, editor scroll layout, Notes send, earlier Contacts gaps remain unclaimed. Patch rebuild byte-exact.
