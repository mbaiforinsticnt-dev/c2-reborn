exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.115-conversation-filter-exit-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);phoneState.alarm.on=true;page='alarmring';notice='';draw()")
time.sleep(.1)
t('firmware image decoded',"let i=document.querySelector('.alarmRingIcon');return i&&i.complete&&i.naturalWidth===56&&i.naturalHeight===56")
src=ev("document.querySelector('.alarmRingIcon').src");raw=base64.b64decode(src.split(',')[1]);assert raw==open('/tmp/c2-firmware-assets/icons/png_3799504_56x56.png','rb').read();checks.append(('firmware bytes exact',True));print('firmware bytes exact',True)
t('no emoji',"return !document.querySelector('.alarmRing').textContent.includes('⏰')")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6111-alarm-firmware.png','wb').write(base64.b64decode(d['result']['data']))
ev("press('OK')")
t('stop behavior retained',"return page==='home'&&notice==='Alarm stopped'&&!phoneState.alarm.on")
print('PASS',len(checks))
