from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.114-photo-wallpaper-setting-rollback-candidate.html').read_text().replace('v6.114 handset parity','v6.115 handset parity').replace('C2 Reborn v6.114 |','C2 Reborn v6.115 |')
a="if(p==='conversations'&&page!=='conversations'&&messageStore.markFilter){messageStore.markFilter='';persist()}if(page==='conversations'&&p!=='conversations'&&messageStore.markFilter){messageStore.markFilter='';persist()}"
b="if(((p==='conversations'&&page!=='conversations')||(page==='conversations'&&p!=='conversations'))&&messageStore.markFilter){let beforeFilter=messageStore.markFilter;messageStore.markFilter='';try{persist()}catch(err){messageStore.markFilter=beforeFilter;notice='Unable to save conversation filter';draw();return}}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save wallpaper setting|Folder memory full','Unable to save wallpaper setting|Unable to save conversation filter|Folder memory full')
Path('/downloads/C2-Reborn-v6.115-conversation-filter-exit-rollback-candidate.html').write_text(s)
