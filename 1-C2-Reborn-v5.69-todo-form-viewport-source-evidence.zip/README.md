# C2 Reborn v5.69: To-do editor viewport

No index deployment. Includes prior delivered pending-bank snapshots v5.64-v5.68. Banking remains parked.

Editor form content now lives in a bounded viewport under its unchanged title. Focused field scrolls into view; Subject focus returns to top. Values, labels, field navigation, validation, alarm hydration and Save mechanics stay unchanged. Before capture shows field 6 focused below LCD; after shows its 08:30 alarm time on-LCD.

12 focused plus 185 carried checks and syntax pass. All seven field boxes checked inside mobile LCD, Up navigation, Subject reset, No alarm hides date/time fields and Save retains values. Inspected actual Subject, Due time, Alarm time and return-Subject mobile pixels.

This is an internal visibility fix, not new handset/SDK certification. Exact firmware scrolling/spacing remains unproven. Other Contacts/Notes/To-do evidence gaps and alarm firing/past-alarm policy remain outside pass. Patch rebuild byte-exact.
