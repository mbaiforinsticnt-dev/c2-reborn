exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.69-todo-form-viewport-candidate.html'))
checks=[
('Phone filter shared row source',"phoneState=migrateState(null);phoneState.contacts=[{name:'Same',number:'111',store:'SIM',email:'sim@example.invalid'},{name:'Same',number:'222',store:'Phone',email:'phone@example.invalid'},{name:'Legacy',number:'333'}];pickerCommit('contactsettings',0,'Phone');page='names';sel=0;open=false;notice='';draw();return selectableRows('names').length===2&&namesRecord()===phoneState.contacts[1]&&document.querySelector('#screen').textContent==='NamesSameLegacy'"),
('Details indexes selected backing identity',"press('OK');return page==='contact'&&contactIndex===1&&document.querySelector('#screen').textContent.includes('222')"),
('Back restores filtered selection',"press('RSK');return page==='names'&&sel===0&&namesRecord()===phoneState.contacts[1]"),
('Phone Delete question identity',"open=true;os=currentOptions().indexOf('Delete contact');press('OK');return contactDeleteConfirm.record===phoneState.contacts[1]"),
('Delete No does not touch hidden SIM',"press('RSK');return phoneState.contacts.length===3&&namesRecord()===phoneState.contacts[1]&&open"),
('Delete Yes removes visible Phone only',"press('OK');press('OK');return phoneState.contacts.length===2&&phoneState.contacts[0].store==='SIM'&&namesRecord().name==='Legacy'"),
('SIM filter and persisted setting',"pickerCommit('contactsettings',0,'SIM');page='names';sel=0;open=false;notice='';draw();return namesContacts().length===1&&namesRecord()===phoneState.contacts[0]&&migrateState(JSON.parse(localStorage.getItem('c2state'))).contVals[0]==='SIM'"),
('Mark all only visible memory',"phoneState.contacts.forEach(c=>c.marked=false);namesSubmenu='Marking options';open=true;os=1;press('OK');return phoneState.contacts[0].marked&&!phoneState.contacts[1].marked"),
('Edit filtered backing identity',"open=true;namesSubmenu='Edit';os=0;press('OK');return page==='addcontact'&&contactIndex===0&&editingContact&&contactEmail==='sim@example.invalid'"),
('Empty memory Details and OK inert',"editingContact=false;phoneState.contacts=[{name:'Hidden',number:'444',store:'Phone'}];page='names';sel=0;open=false;namesSubmenu=null;notice='';draw();press('OK');return page==='names'&&sm.textContent===''&&document.querySelector('#screen').textContent==='Names'"),
('Empty memory Delete cannot fake prompt',"open=true;os=currentOptions().indexOf('Delete contact');press('OK');return !contactDeleteConfirm&&phoneState.contacts.length===1"),
('Both memory restores all records',"open=false;pickerCommit('contactsettings',0,'Phone and SIM');phoneState.contacts.push({name:'SIM',number:'555',store:'SIM'});page='names';sel=0;draw();return namesContacts().length===2"),
('Filtered Move uses correct source',"pickerCommit('contactsettings',0,'SIM');page='names';sel=0;open=true;namesSubmenu='Edit';os=1;notice='';draw();press('OK');return contactMemoryPending.source===phoneState.contacts[1]&&contactMemoryPending.destination==='Phone'"),
('Move preserves hidden sibling and filter result',"press('OK');return page==='contact'&&contactIndex===1&&phoneState.contacts[0].name==='Hidden'&&phoneState.contacts[1].store==='Phone'&&namesContacts().length===0"),
('Back after Move has empty filtered Names',"press('RSK');return page==='names'&&sm.textContent===''&&namesContacts().length===0"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
