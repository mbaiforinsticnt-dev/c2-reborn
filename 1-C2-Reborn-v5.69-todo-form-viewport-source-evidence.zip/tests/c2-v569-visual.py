exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.69-todo-form-viewport-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
start="phoneState=migrateState(null);page='todoedit';noteText='Existing alarm';todoDate='01102099';todoTime='0900';todoAlarm=2;todoAlarmDate='01102099';todoAlarmTime='0830';todoField=0;open=false;notice='';draw()"
for n,e in [('subject',start),('due-time',"todoField=3;draw()"),('alarm-time',"todoField=6;draw()"),('back-subject',"todoField=0;draw()")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v569-form-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
