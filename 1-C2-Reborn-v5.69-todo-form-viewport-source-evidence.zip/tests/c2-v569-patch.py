from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.68-todo-integrity-upload-ready.html').read_text().replace('v5.68','v5.69')
a="var _bx=function(f,inner,bg,fg){return '<div style=\"padding:1px 6px\"><div style=\"background:'"
b="var _bx=function(f,inner,bg,fg){return '<div data-todo-field=\"'+f+'\" style=\"padding:1px 6px\"><div style=\"background:'"
assert s.count(a)==1;s=s.replace(a,b)
a="+(256-noteText.length)+'</span></div><div style=\"padding:4px 6px 0;font-size:1.7vh\">Subject:</div>'"
b="+(256-noteText.length)+'</span></div><div class=\"todoFormViewport\" style=\"overflow:hidden\"><div style=\"padding:4px 6px 0;font-size:1.7vh\">Subject:</div>'"
assert s.count(a)==1;s=s.replace(a,b)
a="todoHiSeg(_atv,6)+'</div>','#fff','#000'):'');soft(noteText?'Options':'','Save',todoField===4?'Cancel':'Back')"
b="todoHiSeg(_atv,6)+'</div>','#fff','#000'):'')+'</div>';let viewport=s.querySelector('.todoFormViewport'),focused=viewport.querySelector('[data-todo-field=\"'+todoField+'\"]');viewport.style.height=Math.max(0,s.clientHeight-s.querySelector('.title').offsetHeight)+'px';if(focused){let vr=viewport.getBoundingClientRect(),fr=focused.getBoundingClientRect();if(fr.bottom>vr.bottom)viewport.scrollTop=fr.bottom-vr.bottom;if(fr.top<vr.top)viewport.scrollTop+=fr.top-vr.top}soft(noteText?'Options':'','Save',todoField===4?'Cancel':'Back')"
assert s.count(a)==1;s=s.replace(a,b);Path('/downloads/C2-Reborn-v5.69-todo-form-viewport-candidate.html').write_text(s)
