from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.80-alarm-end-upload-ready.html').read_text().replace('v5.80','v5.81')
def patch(a,b):
 global s
 assert a in s,a
 s=s.replace(a,b,1)
patch("function alarmDraw(s){", "function alarmTimeDisplay(val){if(!alarmEntry)return val;let parts=val.split(':');parts[alarmDigit]=alarmEntry;return parts.join(':')}\nfunction alarmDraw(s){")
patch("timeDigitHtml(val,alarmDigit)","timeDigitHtml(alarmTimeDisplay(val),alarmDigit)")
patch("t[alarmDigit]=v;alarmDraft.time=t.join(':');if(alarmEntry.length===2)","t[alarmDigit]=alarmEntry.length===2?String(Math.min(alarmDigit?59:23,+v)).padStart(2,'0'):v;alarmDraft.time=t.join(':');if(alarmEntry.length===2)")
patch("function alarmSave(){let [h,m]", "function alarmSave(){alarmNumericFinish();let [h,m]")
patch("function alarmTimeDisplay(val){", "function alarmNumericFinish(){if(alarmFields()[alarmFocus]==='snooze')alarmDraft.snooze=String(Math.max(2,Math.min(59,+alarmDraft.snooze))).padStart(2,'0');alarmEntry=''}\nfunction alarmTimeDisplay(val){")
patch("if(k==='UP'||k==='DOWN'){alarmFocus=Math.max(0,Math.min(fields.length-1", "if(k==='UP'||k==='DOWN'){alarmNumericFinish();alarmFocus=Math.max(0,Math.min(fields.length-1")
Path('/downloads/C2-Reborn-v5.81-alarm-numeric-candidate.html').write_text(s)
