# C2 Reborn v5.72: bounded Stopwatch correction

Frozen source and evidence, no index deployment. SDK-grounded parent menu, Split/Lap timing, Stop/Start/Reset, Show last, blank/named snapshot saves, persistent saved-time list and detail, Delete Yes/No, and One by one deletion. Active marks newest first; saved marks chronological. Lap Stop records final partial and total; Split Stop adds no mark. End leaves timer running in background, consistent with SDK home stopwatch indicator.

29 focused checks plus 213 carried checks pass. Saved times survive reload; empty saved list is safe; extra 12-entry scroll check passes. JavaScript syntax passes. Mobile 390x844 pixels inspected for parent menu, running split, stopped lap, Name, saved list/detail, scrolling and Delete? prompt. Prior loan arithmetic tests pass, not financial advice or device parity evidence.

Limitations: real-handset stopwatch footage is pending and will outrank SDK. Name editor Options actions remain a plain evidence-needed notice. SDK Delete all select did not advance across bounded slow replays, so no outcome is invented: Delete all is an explicit evidence-needed notice. Interval timer model not changed pending handset editor footage. Overall handset parity remains open. No removal inferred from SDK limitations.
