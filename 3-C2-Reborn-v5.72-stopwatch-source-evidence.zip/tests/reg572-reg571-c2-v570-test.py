exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.72-stopwatch-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
checks=[
('Starts timer and selects its parent row',"phoneState=migrateState(null);page='timernote';open=false;notice='';timerParts=['00','01','23'];timerNote='Test';draw();let now=Date.now();press('OK');return page==='organiser'&&screens[page][sel]==='Countd. timer'&&phoneState.timerValue==='00:01:23'&&phoneState.timerEndsAt>=now+82990&&phoneState.timerEndsAt<=now+83100"),
('Highlight text is Countd. timer',"return document.querySelector('.sel').textContent.includes('Countd. timer')"),
('OK reopens countdown menu',"press('OK');return page==='countdown'"),
('Zero time does not start countdown',"page='timernote';timerParts=['00','00','00'];draw();press('OK');return !phoneState.timerEndsAt&&screens[page][sel]==='Countd. timer'"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
ev("page='timernote';timerParts=['00','01','23'];timerNote='Test';draw();press('OK')")
z=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});open('/downloads/c2-v570-timer-return.png','wb').write(base64.b64decode(z['result']['data']))
print('PASS',len(checks))
