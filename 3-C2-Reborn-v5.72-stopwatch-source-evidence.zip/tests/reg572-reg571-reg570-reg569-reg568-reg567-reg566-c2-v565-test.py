exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.72-stopwatch-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
checks=[
('12 notes render only first window',"phoneState=migrateState(null);phoneState.notes=Array.from({length:12},(_,n)=>'Note '+(n+1));phoneState.noteStamps=phoneState.notes.map((_,n)=>'stamp '+n);page='notes';sel=0;open=false;notice='';history=[];draw();return document.querySelectorAll('#screen .row').length===5&&document.querySelector('#screen .row.sel').textContent==='Note 1'"),
('Down reaches 12 with visible selected row',"for(let n=0;n<11;n++)press('DOWN');let s=document.querySelector('#screen').getBoundingClientRect(),r=document.querySelector('#screen .row.sel').getBoundingClientRect();return sel===11&&document.querySelector('#screen .row.sel').textContent==='Note 12'&&r.top>=s.top&&r.bottom<=s.bottom"),
('View selects 12 not viewport coordinate',"press('OK');return page==='noteview'&&noteIndex===11&&document.querySelector('#screen').textContent==='NoteNote 12'"),
('Back restores last window and selected record',"press('RSK');return page==='notes'&&sel===11&&document.querySelector('#screen .row.sel').textContent==='Note 12'"),
('Down wrap returns first window',"press('DOWN');return sel===0&&document.querySelector('#screen .row.sel').textContent==='Note 1'"),
('Up wrap returns last window',"press('UP');return sel===11&&document.querySelector('#screen .row.sel').textContent==='Note 12'"),
('Middle window includes same selected index',"sel=6;draw();return document.querySelector('#screen .row.sel').textContent==='Note 7'&&document.querySelectorAll('#screen .row').length===5"),
('Delete last removes exact note and stamp',"sel=11;open=true;os=currentOptions().indexOf('Delete');draw();press('OK');press('OK');return phoneState.notes.length===11&&!phoneState.notes.includes('Note 12')&&!phoneState.noteStamps.includes('stamp 11')&&sel===10&&document.querySelector('#screen .row.sel').textContent==='Note 11'"),
('Short list keeps all rows',"phoneState.notes=['Only','Other'];page='notes';sel=1;open=false;notice='';draw();return document.querySelectorAll('#screen .row').length===2&&document.querySelector('#screen .row.sel').textContent==='Other'"),
('Stale selection clamps safely',"sel=99;draw();return sel===1&&document.querySelector('#screen .row.sel').textContent==='Other'"),
('Mutable markup remains escaped',"phoneState.notes=['<img src=x onerror=alert(1)>'];sel=0;draw();return !document.querySelector('#screen img')&&document.querySelector('#screen .row').textContent.startsWith('<img')"),
('Empty preserves Add affordance',"phoneState.notes=[];sel=0;draw();return sm.textContent==='Add'&&document.querySelectorAll('#screen .row').length===0"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
