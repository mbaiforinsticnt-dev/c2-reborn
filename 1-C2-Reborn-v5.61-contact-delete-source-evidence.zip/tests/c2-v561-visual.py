exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.61-contact-delete-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
f="phoneState=migrateState(null);phoneState.contacts=[{name:'Jane Doe',number:'123',store:'SIM',email:'source@example.invalid'},{name:'Jane Doe',number:'123',store:'Phone',email:'copy@example.invalid'},{name:'John Doe',number:'456',store:'Phone'}];page='names';sel=1;open=true;os=currentOptions().indexOf('Delete contact');namesSubmenu=null;optParent=null;notice='';draw();press('OK')"
for n,e in [('question',f),('no',"press('RSK')"),('remaining',"press('OK');press('OK')")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v561-delete-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
