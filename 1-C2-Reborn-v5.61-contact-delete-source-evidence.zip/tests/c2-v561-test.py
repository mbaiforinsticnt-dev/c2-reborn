exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.61-contact-delete-candidate.html'))
checks=[
('seed duplicate memory rows',"phoneState=migrateState(null);phoneState.contacts=[{name:'Jane Doe',number:'123',store:'SIM',email:'source@example.invalid'},{name:'Jane Doe',number:'123',store:'Phone',email:'copy@example.invalid'},{name:'John Doe',number:'456',store:'Phone'}];page='names';sel=1;open=true;os=currentOptions().indexOf('Delete contact');namesSubmenu=null;optParent=null;notice='';draw();press('OK');return contactDeleteConfirm.record===phoneState.contacts[1]&&phoneState.contacts.length===3"),
('No preserves both duplicate records',"press('RSK');return phoneState.contacts.length===3&&sel===1&&!contactDeleteConfirm"),
('Yes deletes selected duplicate not source',"open=true;os=currentOptions().indexOf('Delete contact');press('OK');press('OK');return phoneState.contacts.length===2&&phoneState.contacts[0].store==='SIM'&&phoneState.contacts[0].email==='source@example.invalid'&&phoneState.contacts[1].name==='John Doe'"),
('persist exact remaining record',"let a=migrateState(JSON.parse(localStorage.getItem('c2state'))).contacts;return a.length===2&&a[0].store==='SIM'&&a[0].email==='source@example.invalid'"),
('details delete uses its selected identity',"phoneState.contacts.splice(1,0,{name:'Jane Doe',number:'123',store:'Phone',email:'copy@example.invalid'});page='contact';contactIndex=1;open=true;os=currentOptions().indexOf('Delete');notice='';draw();press('OK');return contactDeleteConfirm.record===phoneState.contacts[1]"),
('details Yes deletes only copy',"press('OK');return phoneState.contacts.length===2&&phoneState.contacts[0].store==='SIM'&&page==='names'"),
('missing record cannot delete another match',"page='names';sel=0;open=true;os=currentOptions().indexOf('Delete contact');draw();press('OK');phoneState.contacts[0]={name:'Jane Doe',number:'123',store:'Phone'};press('OK');return phoneState.contacts.length===2&&phoneState.contacts[0].store==='Phone'"),
('No exact options context',"page='names';sel=0;open=true;os=currentOptions().indexOf('Delete contact');notice='';draw();press('OK');let cp=contactDeleteConfirm;press('RSK');return open&&os===cp.choice&&currentOptions()[os]==='Delete contact'"),
('prompt exact words and centre Yes',"press('OK');return sm.textContent==='Yes'&&sr.textContent==='No'&&sl.textContent===''&&document.querySelector('#screen').textContent.includes('Delete all details?')"),
('other keys leave confirmation intact',"press('UP');press('CALL');press('LSK');return !!contactDeleteConfirm&&phoneState.contacts.length===2"),
('END cancels without deletion',"press('END');return !contactDeleteConfirm&&page==='home'&&phoneState.contacts.length===2"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
