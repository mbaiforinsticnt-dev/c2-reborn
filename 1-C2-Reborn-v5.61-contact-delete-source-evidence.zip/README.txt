C2 Reborn v5.61: selected-contact deletion

Based on byte-exact v5.60. No index.html deployment.
Fix: pending deletion holds exact local record identity and row index; confirmation never deletes another same-name/number record. Missing pending record does not delete a replacement.
SDK Names evidence: Delete all details? plus name, centre Yes/right No. No restores Delete contact Options selection. Yes returns to remaining Names list. Other keys leave question open; End cancels. Mobile pixels inspected.
11 focused behavior checks and 95 carried regression checks pass; syntax checked.
Limits: details route exact-record deletion tested locally, full SDK details context not certified. Deleted toast timing not implemented in this pass. Bulk deletion and separate legacy SIM array outside scope. SDK evidence does not override handset evidence.
Tests use a development CDP harness; do not run against user data.
