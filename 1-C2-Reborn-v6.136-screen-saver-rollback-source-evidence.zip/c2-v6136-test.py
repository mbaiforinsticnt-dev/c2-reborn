exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.136-screen-saver-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for row,val in [(5,'Analogue clock'),(6,'Digital clock'),(10,'Off')]:
 for absent in [False,True]:
  ev("phoneState=migrateState(null);"+("delete phoneState.dispVals;" if absent else "phoneState.dispVals=pickerDefaults('display');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.dispVals;stored=localStorage.getItem('c2state');page='screensaver';sel="+str(row)+";history=['display'];notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=f'{row} {absent}'
  t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.dispVals===beforeVals&&localStorage.getItem('c2state')===stored")
  t(label+' context',"return page==='screensaver'&&sel==="+str(row)+"&&history.length===1&&notice==='Unable to save screen saver'&&document.getElementById('screen').innerText.includes(notice)")
  if row==6 and not absent:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6136-saver-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return phoneState.dispVals[5]==="+json.dumps(val)+"&&page==='display'")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState.dispVals[5]==="+json.dumps(val))
print('PASS',len(checks))
