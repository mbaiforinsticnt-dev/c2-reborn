exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.63-contact-filter-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
start="phoneState=migrateState(null);phoneState.contacts=[{name:'SIM Person',number:'111',store:'SIM'},{name:'Phone Person',number:'222',store:'Phone'},{name:'Phone Two',number:'333',store:'Phone'}];pickerCommit('contactsettings',0,'SIM');page='names';sel=0;open=false;notice='';draw()"
for n,e in [('sim',start),('details',"press('OK')"),('phone',"press('RSK');pickerCommit('contactsettings',0,'Phone');draw()"),('empty',"phoneState.contacts=phoneState.contacts.filter(c=>c.store==='SIM');draw()")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v563-filter-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
