exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.62-bulk-contact-upload-ready.html'))
for store in ['Phone','SIM','Phone and SIM']:
 print(ev("(()=>{phoneState=migrateState(null);phoneState.contacts=[{name:'Phone only',number:'111',store:'Phone'},{name:'SIM only',number:'222',store:'SIM'}];pickerCommit('contactsettings',0,"+repr(store)+");page='names';sel=0;open=false;notice='';draw();return {memory:pickerCommittedVal('contactsettings',0),rows:selectableRows('names'),text:document.querySelector('#screen').textContent}})()"))
print(ev("(()=>{page='contactsettings';sel=4;draw();press('OK');return {page,text:document.querySelector('#screen').textContent}})()"))
