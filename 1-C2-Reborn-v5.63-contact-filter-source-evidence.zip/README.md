# C2 Reborn v5.63: contact memory filter

No index deployment. Source snapshot, test recipe, patch and inspected mobile pixels.

Memory in use now filters Names. Details, Edit, Delete, individual Move/Copy, send-message recipients and marking use the visible record identity. Legacy records without a store count as Phone. Phone and SIM retains backing order and duplicates.

Fixed existing Details fall-through: Names OK used to call go(contact), then fall through into the static contact route and open itemdetail.

15 focused checks plus 118 carried checks pass. JavaScript syntax checked. Inspectable pixels show SIM Names, correct Details number, Phone Names and empty memory with no Details label.

Grounding: Nokia C2-01 Contacts guide: https://nokia-c2-01.helpdoc.net/en/nokia-c2-01-user-guide/contacts/ . Describes separate Phone/SIM contact memories and contact settings. This is a guide-backed functional fix, not a fresh SDK pixel-parity certificate. SDK navigation became unreliable after the v5.62 replay.

Limits: memory status still incorrectly routes to general storage; Delete all contacts still inert; Contacts view/name display, SIM-specific icons/capacity/field loss, Add new storage selection, search and recipient-pickers are not certified or changed here. No names sorting or rich-field trimming.
