from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.29-demo-file-identity-candidate.html').read_text().replace('v6.29 handset parity','v6.30 handset parity').replace('C2 Reborn v6.29 |','C2 Reborn v6.30 |')
a='contacts:phoneState.contacts,calendar:phoneState.calendar,todos:phoneState.todos'
b='contacts:phoneState.contacts,groups:phoneState.groups,calendar:phoneState.calendar,todos:phoneState.todos'
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.30-group-settings-preservation-candidate.html').write_text(s)
