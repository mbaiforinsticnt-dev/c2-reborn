from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.63-backup-runtime-sync-candidate.html').read_text().replace('v6.63 handset parity','v6.64 handset parity').replace('C2 Reborn v6.63 |','C2 Reborn v6.64 |')
a="DEMO_THREAD=messageStore.threads.alex;screens.goto=phoneState.gotoOrder;return true}function seedMessageStore()"
b="DEMO_THREAD=messageStore.threads.alex;screens.goto=phoneState.gotoOrder;callTimerSecs=phoneState.callTimerSecs;return true}function seedMessageStore()"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.64-backup-call-timer-sync-candidate.html').write_text(s)
