exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.64-backup-call-timer-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for pg in ['names','contact']:
 ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page="+json.dumps(pg)+";sel=1;contactIndex=1;record=phoneState.contacts[1];contactDeleteConfirm={record,index:1,choice:3};notice='';open=false;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(pg+' quota exact contact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&phoneState.contacts[1]===record")
 t(pg+' confirmation and indices retained',"return contactDeleteConfirm.record===record&&sel===1&&contactIndex===1&&page==="+json.dumps(pg)+"&&notice==='Unable to delete contact'")
 if pg=='names':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v634-contact-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(pg+' retry deletes selected once',"return phoneState.contacts.length===2&&!phoneState.contacts.includes(record)&&!contactDeleteConfirm&&page==='names'")
 call('Page.reload');time.sleep(.3)
 t(pg+' reload keeps deletion',"return phoneState.contacts.length===2&&!phoneState.contacts.some(c=>c.name==='Home')")
print('PASS',len(checks))
