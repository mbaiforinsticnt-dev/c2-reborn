exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.63-backup-runtime-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.callTimerSecs=[1,2,3,4];makeLocalBackup();phoneState.callTimerSecs=[11,12,13,14];callTimerSecs=phoneState.callTimerSecs;persist();restoreLocalBackup()")
print(ev("JSON.stringify({stored:phoneState.callTimerSecs,runtime:callTimerSecs})"))
