from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.85-player-mute-rollback-candidate.html').read_text().replace('v6.85 handset parity','v6.86 handset parity').replace('C2 Reborn v6.85 |','C2 Reborn v6.86 |')
a="else if(page==='player'){if(phoneState.player.playing){phoneState.player.elapsed=playerSeconds();phoneState.player.playing=false}else{playerTickBase=Date.now();phoneState.player.playing=true}persist();draw()}"
b="else if(page==='player'){let beforePlayer=phoneState.player,beforeTick=playerTickBase;phoneState.player={...beforePlayer};if(phoneState.player.playing){let elapsed=Math.min(90,(Number(phoneState.player.elapsed)||0)+(Date.now()-playerTickBase)/1000);phoneState.player.elapsed=elapsed>=90?0:elapsed;phoneState.player.playing=false}else{playerTickBase=Date.now();phoneState.player.playing=true}try{persist()}catch(err){phoneState.player=beforePlayer;playerTickBase=beforeTick;notice='Unable to save player';draw();return}draw()}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.86-player-toggle-rollback-candidate.html').write_text(s)
