exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.86-player-toggle-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for store in ['Phone','SIM']:
 ev("phoneState=migrateState(null);phoneState.contacts[0].store="+json.dumps(store)+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');galUseFile={id:'Photo0001.jpg'};galUseFileSel=0;galFolderName='Images';page='names';galUseContactPick=true;galUseContactPending="+('{index:0}' if store=='SIM' else 'null')+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+("galUsePress('OK')" if store=='SIM' else 'galUseApplyContactImage(0)'))
 t(store+' quota exact contact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&notice==='Unable to save contact image'&&page==='names'&&galUseContactPick")
 if store=='SIM':t('SIM confirmation retained',"return galUseContactPending.index===0&&phoneState.contacts[0].store==='SIM'")
 if store=='Phone':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v626-contact-image-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+("galUsePress('OK')" if store=='SIM' else 'galUseApplyContactImage(0)'))
 t(store+' retry commits one contact image',"return page==='contact'&&phoneState.contacts[0].image==='Photo0001.jpg'&&!galUseContactPick&&!galUseContactPending&&phoneState.contacts[0].store==='Phone'")
 call('Page.reload');time.sleep(.3)
 t(store+' reload persists assignment',"return phoneState.contacts[0].image==='Photo0001.jpg'&&phoneState.contacts[0].store==='Phone'")
print('PASS',len(checks))
