exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.144-timer-repeat-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for before in ['absent',True,False]:
 ev("phoneState=migrateState(null);"+("delete phoneState.countdownAutoRepeat;" if before=='absent' else "phoneState.countdownAutoRepeat="+json.dumps(before)+";")+"persist();before=JSON.stringify(phoneState);had=Object.prototype.hasOwnProperty.call(phoneState,'countdownAutoRepeat');stored=localStorage.getItem('c2state');page='countdownsettings';sel=1;history=['settings'];notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(before)+' rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'countdownAutoRepeat')===had&&localStorage.getItem('c2state')===stored")
 t(str(before)+' context',"return page==='countdownsettings'&&notice==='Unable to save timer'")
 if before=='absent':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6144-repeat-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(str(before)+' repeat',"return Object.prototype.hasOwnProperty.call(phoneState,'countdownAutoRepeat')===had")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(str(before)+' retry',"return phoneState.countdownAutoRepeat==="+json.dumps(not before if before!='absent' else True))
 call('Page.reload');time.sleep(.15)
 t(str(before)+' reload',"return phoneState.countdownAutoRepeat==="+json.dumps(not before if before!='absent' else True))
print('PASS',len(checks))
