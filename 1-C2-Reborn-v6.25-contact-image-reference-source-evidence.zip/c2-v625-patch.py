from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.24-demo-capture-integrity-candidate.html').read_text().replace('v6.24 handset parity','v6.25 handset parity').replace('C2 Reborn v6.24 |','C2 Reborn v6.25 |')
a="function namesImage(c){let f=Object.values(GAL_FILES).flat().find(f=>f.n===c.image&&f.n.match(/\.(jpg|png)$/i));return f?.src||ICONNAMESPERSON}"
b="function namesImage(c){let f=Object.values(GAL_FILES).flat().concat(phoneState.galEditedImages||[],phoneState.galFolderItems||[]).find(f=>f.n===c.image);if(!f)return ICONNAMESPERSON;let r=galResolveFileSource(f);return r.big?r.src||r.big:ICONNAMESPERSON}"
assert s.count(a)==1;s=s.replace(a,b)
a='inet:160,image:100,web:300';b='inet:160,image:164,web:300';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.25-contact-image-reference-candidate.html').write_text(s)
