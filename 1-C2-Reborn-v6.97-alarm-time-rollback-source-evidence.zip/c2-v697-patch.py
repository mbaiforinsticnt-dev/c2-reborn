from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.96-menu-view-rollback-candidate.html').read_text().replace('v6.96 handset parity','v6.97 handset parity').replace('C2 Reborn v6.96 |','C2 Reborn v6.97 |')
a="phoneState.alarm.time=alarmDigits.slice(0,2)+':'+alarmDigits.slice(2);phoneState.alarm.on=true;persist();go('alarmclock')"
b="let beforeAlarm=phoneState.alarm;phoneState.alarm={...beforeAlarm,time:alarmDigits.slice(0,2)+':'+alarmDigits.slice(2),on:true};try{persist()}catch(err){phoneState.alarm=beforeAlarm;notice='Unable to save alarm time';draw();return}go('alarmclock')"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save menu view|Folder memory full','Unable to save menu view|Unable to save alarm time|Folder memory full')
Path('/downloads/C2-Reborn-v6.97-alarm-time-rollback-candidate.html').write_text(s)
