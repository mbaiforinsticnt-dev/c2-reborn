from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.55-message-copy-rollback-candidate.html').read_text().replace('v6.55 handset parity','v6.56 handset parity').replace('C2 Reborn v6.55 |','C2 Reborn v6.56 |')
a="let m=currentMessage();if(!m)return;m.marked=c==='Mark';persist();draw();return"
b="let m=currentMessage();if(!m)return;let beforeMarked=m.marked,hadMarked=Object.prototype.hasOwnProperty.call(m,'marked');m.marked=c==='Mark';try{persist()}catch(err){if(hadMarked)m.marked=beforeMarked;else delete m.marked;notice='Unable to save message status'}draw();return"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to copy message|Folder memory full|';b='Unable to copy message|Unable to save message status|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.56-message-status-rollback-candidate.html').write_text(s)
