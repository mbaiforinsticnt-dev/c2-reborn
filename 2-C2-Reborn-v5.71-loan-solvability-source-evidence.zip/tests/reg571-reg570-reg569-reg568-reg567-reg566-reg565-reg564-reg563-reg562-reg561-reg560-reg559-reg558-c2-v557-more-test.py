exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.71-loan-solvability-candidate.html'))
import base64
checks=[
('empty item actions disabled',"phoneState=migrateState(null);phoneState.galleryFolders=['E'];page='galfolder';galFolderName='E';sel=0;open=false;return ['Open folder','Delete folder','Move folder','Copy folder','Rename folder','Details','Mark','Mark all'].every(optionDisabled)&&!optionDisabled('Add folder')"),
('Move source disappears destination gains same key',"phoneState=migrateState(null);phoneState.galleryFolders=['Move me'];page='gallery';sel=9;history=[];galFolderMoveStart();sel=1;press('OK');return page==='gallery'&&!galChildFolders('Memory card').includes('Move me')&&galChildFolders('Images').includes('Move me')&&notice==='Moved to Images'"),
('Move clamps source selection',"return sel<galOrder().length&&sel===8"),
('Move survives reload',"phoneState=migrateState(JSON.parse(localStorage.getItem('c2state')));return galChildFolders('Images').includes('Move me')"),
('Move cancel leaves original',"phoneState=migrateState(null);phoneState.galleryFolders=['Keep'];page='gallery';sel=9;history=[];notice='';galFolderMoveStart();press('BACK');return galChildFolders('Memory card').includes('Keep')&&!phoneState.galFolderParents.Keep"),
('Move populated accepted',"phoneState.galCopied={'Photo0001.jpg':'Keep'};page='gallery';sel=9;galFolderMoveStart();return page==='galfoldertarget'&&galActualFiles('Keep').length===1"),
('nested Open folder route',"phoneState=migrateState(null);phoneState.galleryFolders=['Child'];phoneState.galFolderParents.Child='Images';page='galfolder';galFolderName='Images';sel=0;history=[];notice='';open=true;os=0;press('OK');return page==='galfolder'&&galFolderName==='Child'"),
('nested Rename route key',"back();open=true;os=currentOptions().indexOf('Rename folder');press('OK');return page==='foldername'&&galRenameIdx===screens.gallery.length&&folderName==='Child'"),
('nested Delete route key',"back();open=true;os=currentOptions().indexOf('Delete folder');press('OK');return galDialog==='delfolder'&&galText==='Child'"),
]
for label,expr in checks:
 z=ev('(()=>{'+expr+'})()');print(label,z);assert z is True,(label,z)
ev("galDialog=null;phoneState=migrateState(null);phoneState.galleryFolders=['Move me'];page='gallery';sel=9;open=false;history=[];notice='';galFolderMoveStart()")
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for label,expr in [('move-picker','draw()'),('move-result',"sel=1;press('OK')"),('move-destination',"notice='';galFolderName='Images';go('galfolder');draw()")]:
 ev(expr);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path='/downloads/c2-v558-'+label+'.png';open(path,'wb').write(base64.b64decode(r['result']['data']));print(path)
print('PASS',len(checks))
