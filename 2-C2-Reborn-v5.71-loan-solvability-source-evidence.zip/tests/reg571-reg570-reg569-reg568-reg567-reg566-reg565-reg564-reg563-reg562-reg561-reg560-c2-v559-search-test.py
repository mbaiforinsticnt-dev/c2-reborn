exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.71-loan-solvability-candidate.html'))
checks=[
('fixture',"phoneState=migrateState(null);phoneState.galleryFolders=['P','ad'];phoneState.galFolderParents.P='Graphics';phoneState.galFolderParents.ad='Images';phoneState.galFolderItems=[{n:'Audit3.jpg',folder:'Images',s:'12 B'},{n:'Audit2.jpg',folder:'Images',s:'12 B'}];page='galfolder';galFolderName='Graphics';sel=0;open=false;notice='';history=[];galFolderMoveStart();sel=1;press('LSK');press('OK');return galTarget.browse==='Images'"),
('search enter same selected item',"sel=1;press('LSK');os=currentOptions().indexOf('Search');press('OK');return galTarget.search&&galTarget.query===''&&sel===1"),
('type A filters folders/files',"press('2');return galTargetRows().map(x=>x.n).join('|')==='ad|Audit2.jpg|Audit3.jpg'"),
('folder softkey Move',"return sm.textContent==='Move'&&sr.textContent==='Clear'"),
('multitap same key B then C',"press('2');let b=galTarget.query==='B';press('2');return b&&galTarget.query==='C'"),
('no matches softkey View all',"return galTargetRows().length===0&&sm.textContent==='View all'&&document.querySelector('#screen').innerText.includes('(no matches)')"),
('clear one character search remains',"press('RSK');return galTarget.query===''&&galTarget.search&&sr.textContent==='Back'"),
('query AU photos only',"press('2');press('8');press('8');return galTarget.query==='AU'&&galTargetRows().length===2&&galTargetRows().every(x=>!x.folderRow)&&sm.textContent==='Open'"),
('search exact Options',"return currentOptions().join('|')==='Add folder|Details|Type of view ▸|Sort ▸|View all'"),
('View all retains file closes search',"let key=galTargetRows()[sel].key;press('LSK');os=4;press('OK');return !galTarget.search&&galTarget.query===''&&galTargetRows()[sel].key===key"),
('no-match centre View all',"press('LSK');os=currentOptions().indexOf('Search');press('OK');press('9');press('9');press('9');press('9');let ok=galTarget.query==='Z'&&!galTargetRows().length;press('OK');return ok&&!galTarget.search&&galTargetRows().length>0"),
('Search Clear keeps scope',"press('LSK');os=currentOptions().indexOf('Search');press('OK');press('2');press('8');press('RSK');return galTarget.query==='A'&&galTarget.browse==='Images'"),
('search no mutation',"return phoneState.galFolderParents.P==='Graphics'&&galActualFiles('P').length===0"),
]
checks += [('empty-query Back closes Search in place',"galTarget.query='';galTarget.search=true;let b=galTarget.browse;let n=sel;press('RSK');return !galTarget.search&&galTarget.browse===b&&sel===n")]
for label,x in checks:
 z=ev('(()=>{'+x+'})()');print(label,z);assert z is True,(label,z)
print('PASS',len(checks))
