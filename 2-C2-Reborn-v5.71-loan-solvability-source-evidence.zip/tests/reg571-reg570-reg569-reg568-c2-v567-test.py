exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.71-loan-solvability-candidate.html'))
checks=[
('Cross year and month chronological sort',"phoneState=migrateState(null);phoneState.todos=[{s:'January next year',d:'01-01-2027',t:'08:00'},{s:'October',d:'01-10-2026',t:'08:00'},{s:'September',d:'30-09-2026',t:'09:00'}];page='todolist';sel=1;open=true;os=currentOptions().indexOf('Sort by deadline');notice='';draw();press('OK');return phoneState.todos.map(t=>t.s).join('|')==='September|October|January next year'&&sel===0"),
('Sort persisted same order',"let p=migrateState(JSON.parse(localStorage.getItem('c2state')));return p.todos.map(t=>t.s).join('|')==='September|October|January next year'"),
('Same day time and stable ties',"let a={s:'late',d:'30-09-2026',t:'18:00',done:true,al:'With tone'},b={s:'first tie',d:'30-09-2026',t:'08:00'},c={s:'second tie',d:'30-09-2026',t:'08:00'};phoneState.todos=[a,b,c];sortTodoDeadlines();return phoneState.todos[0]===b&&phoneState.todos[1]===c&&phoneState.todos[2]===a&&a.done&&a.al==='With tone'"),
('Leap day accepted valid year',"return todoDeadlineKey({d:'29-02-2028',t:'00:00'})==='202802290000'&&todoDeadlineKey({d:'29-02-2027',t:'00:00'})===null"),
('Invalid rollover date not guessed',"return todoDeadlineKey({d:'31-04-2026',t:'08:00'})===null&&todoDeadlineKey({d:'00-01-2026',t:'08:00'})===null"),
('Invalid time rejected',"return todoDeadlineKey({d:'30-09-2026',t:'24:00'})===null&&todoDeadlineKey({d:'30-09-2026',t:'08:60'})===null"),
('Missing time uses start of due day',"return todoDeadlineKey({d:'30-09-2026'})==='202609300000'"),
('Invalid legacy list not partially sorted',"phoneState.todos=[{s:'late',d:'01-01-2027',t:'08:00'},{s:'bad',d:'31-02-2026',t:'08:00'},{s:'early',d:'30-09-2026',t:'08:00'}];sel=2;notice='';sortTodoDeadlines();return phoneState.todos.map(t=>t.s).join('|')==='late|bad|early'&&sel===2&&notice==='Invalid deadline; list not sorted'"),
('Sorted View correct record',"phoneState.todos=[{s:'later',d:'01-01-2027',t:'08:00'},{s:'earlier',d:'30-09-2026',t:'08:00'}];page='todolist';open=false;notice='';sortTodoDeadlines();notice='';press('OK');return page==='todoview'&&todoViewIdx===0&&document.querySelector('#screen').textContent.includes('earlier')"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
