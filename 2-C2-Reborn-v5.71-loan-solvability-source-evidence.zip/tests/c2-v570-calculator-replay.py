exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.70-timer-return-upload-ready.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for name,e in [
 ('standard 12+3',"page='calculator';open=false;notice='';calc='';calcStored=null;calcOp='';calcActive=false;press('1');press('2');press('UP');press('3');press('OK');return calc"),
 ('scientific percent',"page='scientific';calc='50';calcSel=9;draw();press('OK');return calc"),
 ('loan interest below zero impossible',"page='loancalc';loanField=1;loanFields=['1200','','12','50'];loanResult='';notice='';draw();press('OK');return {fields:loanFields,result:loanResult,notice}"),
 ('loan payment cannot cover interest',"page='loancalc';loanField=2;loanFields=['1200','12','','10'];loanResult='';notice='';draw();press('OK');return {fields:loanFields,result:loanResult,notice}"),
]:print(name,ev('(()=>{'+e+'})()'))
z=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});open('/downloads/c2-v570-loan-unpayable.png','wb').write(base64.b64decode(z['result']['data']))
