exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.71-loan-solvability-candidate.html'))
checks=[
('Edit hydrates saved tone alarm',"phoneState=migrateState(null);phoneState.todos=[{s:'Existing alarm',p:'High',d:'01-10-2099',t:'09:00',done:true,al:'With tone',ad:'01-10-2099',at:'08:30'}];page='todoview';todoViewIdx=0;sel=0;open=false;notice='';draw();press('OK');return page==='todoedit'&&todoAlarm===2&&todoAlarmDate==='01102099'&&todoAlarmTime==='0830'"),
('Subject-only Save retains alarm and done',"noteText='Edited subject';press('OK');let t=phoneState.todos[0];return t.s==='Edited subject'&&t.al==='With tone'&&t.ad==='01-10-2099'&&t.at==='08:30'&&t.done"),
('Alarm persists reload',"let t=migrateState(JSON.parse(localStorage.getItem('c2state'))).todos[0];return t.al==='With tone'&&t.at==='08:30'&&t.done"),
('Silent alarm hydrates',"phoneState.todos[0].al='Silent';page='todoview';todoViewIdx=0;open=false;notice='';draw();press('OK');return todoAlarm===1"),
('Explicit No alarm removes alarm fields',"todoAlarm=0;press('OK');return !phoneState.todos[0].al&&!phoneState.todos[0].ad&&!phoneState.todos[0].at&&phoneState.todos[0].done"),
('Impossible due date stops write',"page='todoedit';open=false;noteText='Bad date';todoPri=1;todoDate='31022026';todoTime='0900';todoAlarm=0;todoEditIdx=-1;notice='';draw();let n=phoneState.todos.length;press('OK');return page==='todoedit'&&notice==='Invalid due date/time'&&phoneState.todos.length===n"),
('Impossible due time stops write',"notice='';todoDate='30092026';todoTime='2560';press('OK');return page==='todoedit'&&notice==='Invalid due date/time'&&phoneState.todos.length===1"),
('Invalid alarm does not overwrite existing',"notice='';todoDate='01102099';todoTime='0900';todoAlarm=2;todoAlarmDate='31022099';todoAlarmTime='0830';todoEditIdx=0;press('OK');return page==='todoedit'&&notice==='Invalid alarm date/time'&&phoneState.todos[0].s==='Edited subject'"),
('Leap valid due date saves',"notice='';todoDate='29022028';todoTime='1200';todoAlarm=0;todoEditIdx=-1;noteText='Leap note';press('OK');return phoneState.todos[0].d==='29-02-2028'&&phoneState.todos[0].t==='12:00'"),
('List date is escaped not markup',"phoneState.todos=[{s:'Date markup',d:'<b id=todoInjected>X</b>',t:'<i id=todoTimeInjected>Y</i>',p:'Medium'}];page='todolist';sel=0;open=false;notice='';draw();return !document.getElementById('todoInjected')&&document.querySelector('#screen').textContent.includes('<b id=todoInjected>X</b>')"),
('View date and time escaped',"press('OK');return !document.getElementById('todoInjected')&&!document.getElementById('todoTimeInjected')&&document.querySelector('#screen').textContent.includes('<i id=todoTimeInjected>Y</i>')"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
