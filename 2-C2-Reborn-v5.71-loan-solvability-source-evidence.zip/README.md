# C2 Reborn v5.71: bounded loan solvability

Frozen source, no index deployment. Adds mathematical bounds before interest/period bisection: reject values outside existing 0-1000% annual rate or 1-1200 month ranges rather than silently clamping and declaring done. Reject malformed nonfinite/negative supplied values. Preserve input on rejection and use existing Check the three values notice. Zero-rate result accepted. Existing amortisation formula, rounding, fields and ranges unchanged.

12 focused plus 201 carried checks pass. Syntax pass; byte-exact patch rebuild. Actual mobile rejection and valid-result pixels inspected. Before £1200/12%/£10 returned 1200 months, though payment cannot reduce principal; before £1200/12mo/£50 claimed zero interest, though even zero interest needs £100. After both reject without writing target.

Internal mathematical correctness only, not handset/SDK parity certification. Scientific % remains inert and unclaimed; timer/stopwatch gaps documented in v5.70 remain. No external financial action or advice.
