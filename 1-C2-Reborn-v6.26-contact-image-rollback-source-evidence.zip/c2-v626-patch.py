from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.25-contact-image-reference-candidate.html').read_text().replace('v6.25 handset parity','v6.26 handset parity').replace('C2 Reborn v6.25 |','C2 Reborn v6.26 |')
a="function galUseApplyContactImage(i){let c=phoneState.contacts[i];if(!c)return;c.image=galUseFile?galUseFile.id:c.image;persist();"
b="function galUseApplyContactImage(i,toPhone=false){let c=phoneState.contacts[i];if(!c)return false;let before={...c};c.image=galUseFile?galUseFile.id:c.image;if(toPhone)c.store='Phone';try{persist()}catch(err){for(let key of Object.keys(c))delete c[key];Object.assign(c,before);notice='Unable to save contact image';draw();return false}"
assert s.count(a)==1;s=s.replace(a,b)
a="galUseContactPick=false;draw()}\nfunction galUsePress"
b="galUseContactPick=false;galUseContactPending=null;draw();return true}\nfunction galUsePress"
assert s.count(a)==1;s=s.replace(a,b)
a="let _p=galUseContactPending;galUseContactPending=null;if(phoneState.contacts[_p.index])phoneState.contacts[_p.index].store='Phone';galUseApplyContactImage(_p.index)"
b="let _p=galUseContactPending;galUseApplyContactImage(_p.index,true)"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save demo file|Folder memory full|';b='Unable to save demo file|Unable to save contact image|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.26-contact-image-rollback-candidate.html').write_text(s)
