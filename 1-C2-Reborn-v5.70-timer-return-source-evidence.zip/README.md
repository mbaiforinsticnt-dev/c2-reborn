# C2 Reborn v5.70: timer parent-row identity

Frozen source, no index deployment. Starting Normal timer returns to its Countd. timer row by label identity rather than stale index 5 (Calculator). Timer values and running state unchanged. 4 focused plus 197 carried checks pass, syntax and patch byte rebuild pass. Mobile pixels inspected: Countd. timer highlighted with 00:01:23 remaining; OK reopens countdown menu.

Other Organiser gaps are evidence, not fixes: Split/Lap timing explicitly unimplemented; Interval/Rest Change inert; typed expiry note ignored; no Normal timer stop/change path. No C2-specific replacement behavior was invented. Current SDK unavailable for these paths; generic other-model user guides are not C2 parity proof. Exact firmware landing behavior still unproven; this fixes wrong-row identity only.
