exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.70-timer-return-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
setup="phoneState=migrateState(null);page='todoedit';noteText='Test';todoDate='01102099';todoTime='0900';todoAlarm=2;todoAlarmDate='01102099';todoAlarmTime='0830';todoField=0;open=false;notice='';draw()"
print('setup',ev(setup))
for fld in range(7):
 e="(()=>{todoField="+str(fld)+";draw();let s=document.querySelector('#screen').getBoundingClientRect(),r=document.querySelector('[data-todo-field=\""+str(fld)+"\"] > div').getBoundingClientRect();return r.top>=s.top&&r.bottom<=s.bottom+1})()"
 z=ev(e);print('focused field visible',fld,z);assert z is True
checks=[
('Focused last field shows actual alarm time',"return todoField===6&&document.querySelector('[data-todo-field=\"6\"]').textContent.includes('08:30')&&document.querySelector('.todoFormViewport').scrollTop>0"),
('Up brings focus field 5 into viewport',"press('UP');let s=document.querySelector('#screen').getBoundingClientRect(),r=document.querySelector('[data-todo-field=\"5\"] > div').getBoundingClientRect();return todoField===5&&r.top>=s.top&&r.bottom<=s.bottom+1"),
('Return Subject resets viewport',"todoField=0;draw();return document.querySelector('.todoFormViewport').scrollTop===0"),
('No alarm removes fields 5 and 6',"todoAlarm=0;todoField=4;draw();return !document.querySelector('[data-todo-field=\"5\"]')&&!document.querySelector('[data-todo-field=\"6\"]')"),
('Save keeps actual values after field scrolling',"todoAlarm=2;todoField=6;todoEditIdx=-1;draw();press('OK');let t=phoneState.todos[0];return t.s==='Test'&&t.t==='09:00'&&t.al==='With tone'&&t.ad==='01-10-2099'&&t.at==='08:30'"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',12)
