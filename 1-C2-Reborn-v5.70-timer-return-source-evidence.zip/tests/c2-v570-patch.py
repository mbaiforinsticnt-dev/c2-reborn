from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.69-todo-form-viewport-upload-ready.html').read_text()
a="persist();history=[];page='organiser';sel=5;draw();return}"
b="persist();history=[];page='organiser';sel=Math.max(0,screens.organiser.indexOf('Countd. timer'));draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('v5.69','v5.70')
Path('/downloads/C2-Reborn-v5.70-timer-return-candidate.html').write_text(s)
