exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.48-draft-save-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');page='compose';draft='New template';recipientText='Alex';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};saveAsTemplate()")
print(ev("JSON.stringify({templates:phoneState.templates,page,draft,diskSame:localStorage.getItem('c2state')===stored})"))
