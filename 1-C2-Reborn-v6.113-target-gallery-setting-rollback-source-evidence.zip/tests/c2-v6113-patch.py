from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.112-alarm-snooze-rollback-candidate.html').read_text().replace('v6.112 handset parity','v6.113 handset parity').replace('C2 Reborn v6.112 |','C2 Reborn v6.113 |')
a="if(t.pane==='view')phoneState.galView=a[t.menuSel];else{phoneState.galSort=['By name','By date','By format','By size'][t.sortBy]+' '+a[t.menuSel];notice='Sorted'}persist();t.pane=null;open=false;sel=Math.min(sel,Math.max(0,galTargetRows().length-1))"
b="let key=t.pane==='view'?'galView':'galSort',had=Object.prototype.hasOwnProperty.call(phoneState,key),before=phoneState[key];phoneState[key]=t.pane==='view'?a[t.menuSel]:['By name','By date','By format','By size'][t.sortBy]+' '+a[t.menuSel];try{persist()}catch(err){if(had)phoneState[key]=before;else delete phoneState[key];notice='Unable to save gallery setting';draw();return}if(t.pane!=='view')notice='Sorted';t.pane=null;open=false;sel=Math.min(sel,Math.max(0,galTargetRows().length-1))"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to snooze alarm|Folder memory full','Unable to snooze alarm|Unable to save gallery setting|Folder memory full')
Path('/downloads/C2-Reborn-v6.113-target-gallery-setting-rollback-candidate.html').write_text(s)
