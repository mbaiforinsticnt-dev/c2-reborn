exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.133-packet-connection-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices={0:['When needed','Always online']}
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in [0]:
  for choice in range(len(choices[row])):
   for absent in [False,True]:
    if route=='radio' and absent and choice==0:continue
    val=choices[row][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.pdConn;" if absent else "phoneState.pdConn="+json.dumps(choices[row][1-choice])+";")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.pdConn;stored=localStorage.getItem('c2state');history=['packetdata'];notice='';noticeBack=false;open=false;"+("page='packetdata';sel="+str(row)+";pickerDraft={page:'packetdata',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'packetdata',row:"+str(row)+",title:'Call setting',opts:"+json.dumps(choices[row])+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.pdConn===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='packetdata'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save packet connection'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and choice==1 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6133-packet-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.pdConn==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.pdConn==="+json.dumps(val))
print('PASS',len(checks))
