from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.08-folder-rename-identity-candidate.html').read_text().replace('v6.08 handset parity','v6.09 handset parity').replace('C2 Reborn v6.08 |','C2 Reborn v6.09 |')
a="let folderRollback=galFolderEditSnapshot();let key=name;"
b="if(phoneState.galleryFolders.length>=30){notice='Folder memory full';draw();return}let folderRollback=galFolderEditSnapshot();let key=name;"
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.galleryFolders.push(key);phoneState.galFolderParents[key]=galAddParent;"
b="if(phoneState.galleryFolders.length>=30){notice='Folder memory full';draw();return}phoneState.galleryFolders.push(key);phoneState.galFolderParents[key]=galAddParent;"
assert s.count(a)==1;s=s.replace(a,b).replace('Fax not activated|Unable to save folder name','Fax not activated|Folder memory full|Unable to save folder name',1)
Path('/downloads/C2-Reborn-v6.09-folder-capacity-guard-candidate.html').write_text(s)
