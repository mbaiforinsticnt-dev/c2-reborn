exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.22-copy-file-identity-candidate.html'))
ev("phoneState=migrateState(null);phoneState.galDeleted=['New.gif'];galFolderName='Images';page='galphoto';sel=0;galEditor={stage:'saveName',saveName:'New',src:GAL_FILES.Images[0].big};galEditorSaveCopy()")
time.sleep(.5)
print(ev("JSON.stringify({stage:galEditor.stage,saved:phoneState.galEditedImages.map(f=>f.n),visible:galFolderFiles().some(f=>f.n==='New.gif')})"))
