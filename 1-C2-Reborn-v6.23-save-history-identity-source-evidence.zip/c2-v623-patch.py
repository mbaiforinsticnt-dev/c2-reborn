from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.22-copy-file-identity-candidate.html').read_text().replace('v6.22 handset parity','v6.23 handset parity').replace('C2 Reborn v6.22 |','C2 Reborn v6.23 |')
a='if(!e.saveName||Object.values(GAL_FILES).flat().concat(phoneState.galEditedImages||[],phoneState.galCaptures||[],phoneState.galFolderItems||[]).some(f=>f.n.toLowerCase()===name.toLowerCase()||(galOwnText(phoneState.galFileNames,f.n)||f.display||f.n).toLowerCase()===name.toLowerCase()))'
b="if(!e.saveName||(phoneState.galDeleted||[]).some(id=>id.toLowerCase()===name.toLowerCase())||['galMoved','galCopied','galFileNames'].some(k=>Object.keys(phoneState[k]||{}).some(id=>id.toLowerCase()===name.toLowerCase()))||Object.values(GAL_FILES).flat().concat(phoneState.galEditedImages||[],phoneState.galCaptures||[],phoneState.galFolderItems||[]).some(f=>f.n.toLowerCase()===name.toLowerCase()||(galOwnText(phoneState.galFileNames,f.n)||f.display||f.n).toLowerCase()===name.toLowerCase()))"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.23-save-history-identity-candidate.html').write_text(s)
