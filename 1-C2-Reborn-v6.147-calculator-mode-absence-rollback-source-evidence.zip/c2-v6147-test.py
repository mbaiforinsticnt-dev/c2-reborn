exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.147-calculator-mode-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for source in ['calculator','scientific','loancalc']:
 for option,mode,target in [('Scientific calculator','scientific','scientific'),('Standard calculator','standard','calculator'),('Loan calculator','loan','loanintro')]:
  if (source=='calculator' and mode=='standard') or (source=='scientific' and mode=='scientific') or (source=='loancalc' and mode=='loan'):continue
  for absent in [False,True]:
   ev("phoneState=migrateState(null);"+("delete phoneState.calcMode;" if absent else "phoneState.calcMode='standard';")+"persist();before=JSON.stringify(phoneState);had=Object.prototype.hasOwnProperty.call(phoneState,'calcMode');stored=localStorage.getItem('c2state');page="+json.dumps(source)+";sel=0;history=['organiser'];notice='';noticeBack=false;open=true;os=currentOptions().indexOf("+json.dumps(option)+");calcSel=7;loanFields=['1','2','3','4'];loanResult='Keep';loanField=2;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
   label=f'{source} {option} {absent}'
   t(label+' rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'calcMode')===had&&localStorage.getItem('c2state')===stored")
   t(label+' context',"return page==="+json.dumps(source)+"&&calcSel===7&&loanField===2&&loanResult==='Keep'&&notice==='Unable to save calculator mode'")
   if source=='calculator' and mode=='scientific' and absent:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6147-calculator-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=currentOptions().indexOf("+json.dumps(option)+");press('OK')")
   t(label+' retry',"return phoneState.calcMode==="+json.dumps(mode)+"&&page==="+json.dumps(target))
   call('Page.reload');time.sleep(.15)
   t(label+' reload',"return phoneState.calcMode==="+json.dumps(mode))
print('PASS',len(checks))
