from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.54-conversation-move-rollback-candidate.html').read_text().replace('v6.54 handset parity','v6.55 handset parity').replace('C2 Reborn v6.54 |','C2 Reborn v6.55 |')
a="(phoneState.templates=phoneState.templates||[]).push(m.body||m.text||m.preview||'');persist();notice='Saved to Templates'"
b="let beforeTemplates=phoneState.templates?.slice();(phoneState.templates=phoneState.templates||[]).push(m.body||m.text||m.preview||'');try{persist()}catch(err){phoneState.templates=beforeTemplates;notice='Unable to copy message';draw();return}notice='Saved to Templates'"
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.calendar.unshift({type:'Reminder',text:m.text,date:fmtCalDate(new Date()),repeat:'Never',alarm:false,time:''});persist();notice='Copied to calendar'"
b="let beforeCalendar=phoneState.calendar.slice();phoneState.calendar.unshift({type:'Reminder',text:m.text,date:fmtCalDate(new Date()),repeat:'Never',alarm:false,time:''});try{persist()}catch(err){phoneState.calendar=beforeCalendar;notice='Unable to copy message';draw();return}notice='Copied to calendar'"
assert s.count(a)==1;s=s.replace(a,b)
a="(phoneState.templates=phoneState.templates||['Please call me.','I will be late.','Meeting at']).push(m.text);persist();notice='Saved to Templates'"
b="let beforeTemplates=phoneState.templates?.slice();(phoneState.templates=phoneState.templates||['Please call me.','I will be late.','Meeting at']).push(m.text);try{persist()}catch(err){phoneState.templates=beforeTemplates;notice='Unable to copy message';draw();return}notice='Saved to Templates'"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to move message|Folder memory full|';b='Unable to move message|Unable to copy message|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.55-message-copy-rollback-candidate.html').write_text(s)
