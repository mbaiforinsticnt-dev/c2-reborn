from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.120-home-screen-mode-rollback-candidate.html').read_text().replace('v6.120 handset parity','v6.121 handset parity').replace('C2 Reborn v6.120 |','C2 Reborn v6.121 |')
a="if(p==='datetime'){phoneState.dtAuto=v;persist();return}"
b="if(p==='datetime'){let had=Object.prototype.hasOwnProperty.call(phoneState,'dtAuto'),before=phoneState.dtAuto;phoneState.dtAuto=v;try{persist()}catch(err){if(had)phoneState.dtAuto=before;else delete phoneState.dtAuto;notice='Unable to save time update setting';return false}return true}"
assert s.count(a)==1;s=s.replace(a,b).replace('["intphone","homescr"].includes(_rp)','["intphone","homescr","datetime"].includes(_rp)').replace('Unable to save home screen setting|Folder memory full','Unable to save home screen setting|Unable to save time update setting|Folder memory full');Path('/downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html').write_text(s)
