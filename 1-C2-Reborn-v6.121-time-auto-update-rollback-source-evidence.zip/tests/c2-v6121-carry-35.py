exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for days,label in [(1,'After 1 day'),(7,'After 1 week'),(30,'After 1 month')]:
 ev("phoneState=migrateState(null);let now=handsetNow();now.setHours(0,0,0,0);let bound=new Date(now);bound.setDate(bound.getDate()-"+str(days)+");let old=new Date(bound);old.setDate(old.getDate()-1);phoneState.calendar=[{type:'Reminder',text:'Old',date:fmtCalDate(old),repeat:'Never',alarm:false,time:''},{type:'Reminder',text:'Boundary',date:fmtCalDate(bound),repeat:'Never',alarm:false,time:''},{type:'Reminder',text:'Current',date:fmtCalDate(now),repeat:'Never',alarm:false,time:''}];phoneState.calPrefs.autoDelete="+json.dumps(label)+";persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};page='calendar';notice='';calDate=now;draw()")
 t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(label+' visible warning',"return notice==='Unable to auto-delete calendar notes'&&document.getElementById('screen').innerText.includes(notice)")
 if days==1:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v647-calendar-auto-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';draw()")
 t(label+' retry exact boundary',"return phoneState.calendar.length===2&&phoneState.calendar[0].text==='Boundary'&&phoneState.calendar[1].text==='Current'")
 call('Page.reload');time.sleep(.15)
 t(label+' reload exact',"return phoneState.calendar.length===2&&phoneState.calendar[0].text==='Boundary'&&phoneState.calendar[1].text==='Current'")
print('PASS',len(checks))
