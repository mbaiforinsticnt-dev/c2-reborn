exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for style in ['absent','false','mixed']:
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();phoneState.messageStore=messageStore;conversationKey='alex';threadMessages().forEach((m,i)=>{"+("delete m.marked" if style=='absent' else "m.marked=false" if style=='false' else "if(i%2)m.marked=true;else delete m.marked")+"});persist();before=JSON.stringify(messageStore);threadAlias=threadMessages();refs=threadAlias.slice();stored=localStorage.getItem('c2state');page='conversation';conversationMarkMenu=true;sel=0;history=['conversations'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('LSK')")
 t(style+' rollback',"return JSON.stringify(messageStore)===before&&threadMessages()===threadAlias&&refs.every((m,i)=>threadMessages()[i]===m)&&localStorage.getItem('c2state')===stored")
 t(style+' warning/context',"return conversationMarkMenu&&page==='conversation'&&notice==='Unable to mark messages'&&document.getElementById('screen').innerText.includes(notice)")
 if style=='absent':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6116-mark-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('LSK')")
 t(style+' repeat failure',"return JSON.stringify(messageStore)===before&&conversationMarkMenu")
 ev("Storage.prototype.setItem=oldStore;notice='';press('LSK')")
 t(style+' retry',"return threadMessages().every(m=>m.marked===true)&&!conversationMarkMenu")
 call('Page.reload');time.sleep(.15)
 t(style+' reload',"return messageStore.threads.alex.every(m=>m.marked===true)")
print('PASS',len(checks))
