exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for name in ['constructor','toString','__proto__']:
 ev("phoneState=migrateState(JSON.parse("+json.dumps(json.dumps({'galleryFolders':[name],'galFolderParents':{name:'Images'},'galFolderNames':{name:'Recovered folder'},'galFolderItems':[{'folder':name,'n':'constructor','s':'100 B'}]}))+"));page='galfolder';galFolderName='Images';sel=0;draw();persist()")
 t(name+' saved own parent/name recovered',"return galChildFolders('Images').length===1&&galDisplayName("+json.dumps(name)+")==='Recovered folder'")
 t(name+' records preserved no inherited hides',"return galActualFiles("+json.dumps(name)+").length===1&&galFolderBytes("+json.dumps(name)+")===100")
 t(name+' Gallery opens old folder',"press('OK');return galFolderName==="+json.dumps(name)+"&&galFolderFiles().length===1")
 call('Page.reload');time.sleep(.3)
 t(name+' reload exact parent/key/contents',"return phoneState.galleryFolders[0]==="+json.dumps(name)+"&&galOwnText(phoneState.galFolderParents,"+json.dumps(name)+")==='Images'&&phoneState.galFolderItems[0].n==='constructor'")
ev("phoneState=migrateState({galleryFolders:['constructor','__proto__']});page='gallery';sel=galOrder().findIndex(x=>x.n==='constructor');draw()")
t('Missing old maps default to root without inherited data',"return galChildFolders('Memory card').length===2&&galDisplayName('constructor')==='constructor'&&galDisplayName('__proto__')==='__proto__'")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v612-recovered-folders.png','wb').write(base64.b64decode(d['result']['data']))
t('New reserved names remain guarded',"page='foldername';open=false;notice='';galRenameIdx=-1;galTarget=null;folderName='constructor';draw();press('OK');return notice==='This folder name is not supported'")
print('PASS',len(checks))
