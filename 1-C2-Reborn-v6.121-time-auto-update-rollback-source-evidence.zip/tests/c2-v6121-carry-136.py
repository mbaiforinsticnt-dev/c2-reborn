exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for repeat in [False,True]:
 ev("phoneState=migrateState(null);phoneState.alarm.on=true;phoneState.alarm.repeat="+str(repeat).lower()+";phoneState.alarm.days=[1,3];persist();before=JSON.stringify(phoneState);beforeAlarm=phoneState.alarm;lastAlarmKey='test-key';stored=localStorage.getItem('c2state');page='alarmring';history=['organiser'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('RSK')")
 label=str(repeat)
 t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.alarm===beforeAlarm&&localStorage.getItem('c2state')===stored")
 t(label+' warning/context',"return notice==='Unable to snooze alarm'&&document.getElementById('screen').innerText.includes(notice)&&page==='alarmring'&&history.length===1&&lastAlarmKey==='test-key'")
 if not repeat:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6112-alarm-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('RSK')")
 t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('RSK')")
 t(label+' retry',"return phoneState.alarm.on===true&&phoneState.alarm.days===beforeAlarm.days&&page==='home'&&notice==='Snoozed for '+phoneState.alarm.snooze+' min'")
 saved=ev('JSON.stringify(phoneState.alarm)');call('Page.reload');time.sleep(.15)
 t(label+' reload',"return JSON.stringify(phoneState.alarm)==="+json.dumps(saved))
print('PASS',len(checks))
