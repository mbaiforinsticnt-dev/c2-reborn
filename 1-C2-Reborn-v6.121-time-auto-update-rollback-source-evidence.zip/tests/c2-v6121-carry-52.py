exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['normal','target']:
 ev("phoneState=migrateState(null);phoneState.galleryFolders=Array.from({length:30},(_,i)=>'F'+i);phoneState.galFolderParents=Object.fromEntries(phoneState.galleryFolders.map(k=>[k,'Memory card']));page='foldername';open=false;notice='';folderName='Overflow';galRenameIdx=-1;galAddParent='Memory card';galTarget="+('null' if route=='normal' else "{op:'Copy',folder:'F0',adding:true,browse:'',trail:[]}")+";persist();baseline=JSON.stringify(phoneState);draw();press('OK')")
 t(route+' full no phantom folder',"return JSON.stringify(phoneState)===baseline&&page==='foldername'&&folderName==='Overflow'&&notice==='Folder memory full'")
 if route=='normal':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v609-capacity-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("phoneState.galleryFolders.pop();delete phoneState.galFolderParents.F29;notice='';draw();press('OK')")
 t(route+' freed slot succeeds',"return phoneState.galleryFolders.length===30&&phoneState.galleryFolders.includes('Overflow')&&folderName===''")
 call('Page.reload');time.sleep(.3)
 t(route+' reload retains added thirtieth',"return phoneState.galleryFolders.length===30&&phoneState.galleryFolders.includes('Overflow')")
ev("page='foldername';galTarget=null;open=false;notice='';galRenameIdx=screens.gallery.length;galRenameOs=0;folderName='Renamed';draw();press('OK')")
t('Full capacity still permits Rename',"return phoneState.galleryFolders.length===30&&phoneState.galleryFolders.includes('Renamed')&&!phoneState.galleryFolders.includes('F0')")
print('PASS',len(checks))
