exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['picker','selected']:
 for existing in [False,True]:
  ev("phoneState=migrateState(null);phoneState.speedDial="+('{2:"Keep"}' if existing else '{}')+";persist();before=JSON.stringify(phoneState);beforeSpeed=phoneState.speedDial;stored=localStorage.getItem('c2state');page='"+('speedpick' if mode=='picker' else 'speeddials')+"';sel=0;speedPickKey='2';speedContactIndex="+('-1' if mode=='picker' else '0')+";history=['contacts'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  t(mode+str(existing)+' exact rollback alias',"return JSON.stringify(phoneState)===before&&phoneState.speedDial===beforeSpeed&&localStorage.getItem('c2state')===stored")
  t(mode+str(existing)+' warning/context',"return notice==='Unable to save speed dial'&&document.getElementById('screen').innerText.includes(notice)&&page==='"+('speedpick' if mode=='picker' else 'speeddials')+"'&&history.length===1")
  if mode=='picker' and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v693-speed-dial-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(mode+str(existing)+' repeat failure exact',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(mode+str(existing)+' retry exact',"return phoneState.speedDial['2']===phoneState.contacts[0].number&&notice==='Speed dial 2 assigned'")
  call('Page.reload');time.sleep(.15)
  t(mode+str(existing)+' reload exact',"return phoneState.speedDial['2']===phoneState.contacts[0].number")
print('PASS',len(checks))
