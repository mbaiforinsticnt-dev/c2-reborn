exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['new','edit']:
 ev("phoneState=migrateState(null);phoneState.notes=['Keep','Old'];phoneState.noteStamps=['A','B'];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='textnote';noteIndex=1;noteText='New note';noteEditingExisting="+('true' if mode=='edit' else 'false')+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(mode+' exact text and stamps rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' draft edit identity retained',"return page==='textnote'&&noteText==='New note'&&noteIndex===1&&noteEditingExisting==="+('true' if mode=='edit' else 'false'))
 t(mode+' visible warning',"return notice==='Unable to save note'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='new':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v644-note-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect="JSON.stringify(phoneState.notes)==='[\"Keep\",\"New note\"]'&&JSON.stringify(phoneState.noteStamps)==='[\"A\",\"B\"]'" if mode=='edit' else "JSON.stringify(phoneState.notes)==='[\"New note\",\"Keep\",\"Old\"]'&&phoneState.noteStamps.length===3&&phoneState.noteStamps[1]==='A'&&phoneState.noteStamps[2]==='B'"
 t(mode+' retry commits once',"return "+expect+"&&page==='noteview'&&noteText===''")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
