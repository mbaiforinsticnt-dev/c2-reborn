exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.137-slide-wallpaper-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for row,val in [(2,'Slide set')]:
 for absent in [False,True]:
  ev("phoneState=migrateState(null);"+("delete phoneState.dispVals;" if absent else "phoneState.dispVals=pickerDefaults('display');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.dispVals;stored=localStorage.getItem('c2state');page='wallpaperlist';sel="+str(row)+";history=['display'];notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=f'{row} {absent}'
  t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.dispVals===beforeVals&&localStorage.getItem('c2state')===stored")
  t(label+' context',"return page==='wallpaperlist'&&sel==="+str(row)+"&&history.length===1&&notice==='Unable to save wallpaper setting'&&document.getElementById('screen').innerText.includes(notice)")
  if row==2 and not absent:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6137-wallpaper-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return phoneState.dispVals[0]==="+json.dumps(val)+"&&page==='display'")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState.dispVals[0]==="+json.dumps(val))
print('PASS',len(checks))
