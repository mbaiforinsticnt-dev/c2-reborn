exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.142-profile-activation-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
choices=ev('screens.profiles')
for row,val in enumerate(choices):
 for absent in [False,True]:
  ev("phoneState=migrateState(null);"+("delete phoneState.profile;" if absent else "phoneState.profile='General';")+"persist();before=JSON.stringify(phoneState);had=Object.prototype.hasOwnProperty.call(phoneState,'profile');stored=localStorage.getItem('c2state');page='profiles';sel="+str(row)+";history=['settings'];notice='';noticeBack=false;open=true;os=0;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  t(str(row)+str(absent)+' rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'profile')===had&&localStorage.getItem('c2state')===stored")
  t(str(row)+str(absent)+' context',"return page==='profiles'&&sel==="+str(row)+"&&notice==='Unable to activate profile'")
  if row==1 and not absent:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6142-profile-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=0;press('OK')")
  t(str(row)+str(absent)+' retry',"return phoneState.profile==="+json.dumps(val))
  call('Page.reload');time.sleep(.15)
  t(str(row)+str(absent)+' reload',"return phoneState.profile==="+json.dumps(val))
print('PASS',len(checks))
