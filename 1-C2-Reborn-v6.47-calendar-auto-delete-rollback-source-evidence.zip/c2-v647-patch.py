from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.46-todo-status-sort-rollback-candidate.html').read_text().replace('v6.46 handset parity','v6.47 handset parity').replace('C2 Reborn v6.46 |','C2 Reborn v6.47 |')
a="let before=phoneState.calendar.length;phoneState.calendar=phoneState.calendar.filter(n=>{let d=parseCalDate(n.date);return !d||d>=boundary});if(phoneState.calendar.length!==before)persist()"
b="let beforeCalendar=phoneState.calendar;phoneState.calendar=phoneState.calendar.filter(n=>{let d=parseCalDate(n.date);return !d||d>=boundary});if(phoneState.calendar.length!==beforeCalendar.length){try{persist()}catch(err){phoneState.calendar=beforeCalendar;notice='Unable to auto-delete calendar notes'}}"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to sort to-do notes|Folder memory full|';b='Unable to sort to-do notes|Unable to auto-delete calendar notes|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.47-calendar-auto-delete-rollback-candidate.html').write_text(s)
