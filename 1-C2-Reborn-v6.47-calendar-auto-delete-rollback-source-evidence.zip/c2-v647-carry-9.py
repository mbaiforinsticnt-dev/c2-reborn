exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.47-calendar-auto-delete-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for n,b in [(0,0),(100,100),(1023,1023),(1024,1024),(1048576,1048576),(1073741824,1073741824)]:
 t('Byte formatter/parser '+str(n),'return galSizeBytes(galFmt('+str(n)+'))==='+str(b))
t('Legacy unitless remains kB',"return galSizeBytes('2.5')===2560")
t('Case tolerant explicit bytes',"return galSizeBytes('100 b')===100&&galSizeBytes('1 kb')===1024")
ev("phoneState=migrateState(null);phoneState.galleryFolders=['Tiny'];phoneState.galFolderItems=[{folder:'Tiny',n:'tiny.gif',s:'100 B'}];phoneState.galFolderParents={Tiny:'Memory card'}")
t('Tiny folder exact100 bytes',"return galFolderBytes('Tiny')===100&&galFolderSize('Tiny')==='100 B'")
ev("page='gallery';sel=galOrder().findIndex(x=>x.n==='Tiny');draw()")
time.sleep(.1);d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v597-tiny-folder.png','wb').write(base64.b64decode(d['result']['data']))
t('Moved file updates byte totals',"phoneState.galMoved={'tiny.gif':'Images'};return galFolderBytes('Tiny')===0&&galActualFiles('Images').some(x=>x.n==='tiny.gif')")
t('Copied file uses correct bytes',"phoneState.galMoved={};phoneState.galCopied={'tiny.gif':'Graphics'};return galFolderBytes('Tiny')===100&&galFolderBytes('Graphics')>=100")
t('Deleted file excluded',"phoneState.galDeleted=['tiny.gif'];return galFolderBytes('Tiny')===0")
ev("phoneState=migrateState(null);galEditor={src:GAL_PHOTOS[0],saveName:'TinySaved',stage:'saveName'};page='galphoto';draw();press('OK')")
for x in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('Real GIF save remains success',"return galEditor.stage==='saved'&&phoneState.galEditedImages.length===1")
print('PASS',len(checks))
