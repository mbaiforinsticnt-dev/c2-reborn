exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.46-todo-status-sort-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.calendar=[{type:'Reminder',text:'Old',date:'01-01-2020',repeat:'Never',alarm:false,time:''}];phoneState.calPrefs.autoDelete='After 1 day';persist();stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};calInit()")
print(ev("JSON.stringify({calendar:phoneState.calendar,diskSame:localStorage.getItem('c2state')===stored})"))
