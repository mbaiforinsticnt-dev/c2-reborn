from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.04-file-transfer-rollback-candidate.html').read_text().replace('v6.04 handset parity','v6.05 handset parity').replace('C2 Reborn v6.04 |','C2 Reborn v6.05 |')
a="phoneState.galFileNames=phoneState.galFileNames||{};phoneState.galFileNames[galFileRenameFrom]=n;persist();back();notice='File renamed'"
b="let previousNames={...phoneState.galFileNames};phoneState.galFileNames=phoneState.galFileNames||{};phoneState.galFileNames[galFileRenameFrom]=n;try{persist()}catch(err){phoneState.galFileNames=previousNames;notice='Unable to save file name';draw();return}back();notice='File renamed'"
assert s.count(a)==1;s=s.replace(a,b).replace('Fax not activated|Unable to save file (move|copy)','Fax not activated|Unable to save file name|Unable to save file (move|copy)',1)
Path('/downloads/C2-Reborn-v6.05-file-rename-rollback-candidate.html').write_text(s)
