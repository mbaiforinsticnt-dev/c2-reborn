from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.69-countdown-time-save-rollback-candidate.html').read_text().replace('v6.69 handset parity','v6.70 handset parity').replace('C2 Reborn v6.69 |','C2 Reborn v6.70 |')
a="if(page==='timernote'&&k==='OK'){let seconds=normalTimerSeconds();phoneState.timerValue=timerParts.join(':');phoneState.timerEndsAt=seconds?Date.now()+seconds*1000:0;persist();history=[];"
b="if(page==='timernote'&&k==='OK'){let seconds=normalTimerSeconds(),beforeValue=phoneState.timerValue,beforeEnds=phoneState.timerEndsAt;phoneState.timerValue=timerParts.join(':');phoneState.timerEndsAt=seconds?Date.now()+seconds*1000:0;try{persist()}catch(err){phoneState.timerValue=beforeValue;phoneState.timerEndsAt=beforeEnds;normalTimerSay('Unable to save timer');return true}history=[];"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.70-countdown-start-rollback-candidate.html').write_text(s)
