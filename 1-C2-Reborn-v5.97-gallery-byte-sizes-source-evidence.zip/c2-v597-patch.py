from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.96-editor-save-identity-candidate.html').read_text().replace('v5.96 handset parity','v5.97 handset parity').replace('C2 Reborn v5.96 |','C2 Reborn v5.97 |')
a='if(/MB/i.test(s))return m*1048576;return m*1024'
b='if(/MB/i.test(s))return m*1048576;if(/kB/i.test(s))return m*1024;if(/\\bB\\s*$/i.test(s))return m;return m*1024'
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v5.97-gallery-byte-sizes-candidate.html').write_text(s)
