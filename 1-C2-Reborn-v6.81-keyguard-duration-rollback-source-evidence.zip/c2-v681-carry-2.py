exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.81-keyguard-duration-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);phoneState.favourites.push({name:'Keep',number:'456'});persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='favourites';sel=0;open=false;favDelIdx=0;favDelName=phoneState.favourites[0].name;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
t('Quota exact favourites rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
t('Confirmation selection retained',"return favDelName==='Alex Morgan'&&favDelIdx===0&&sel===0&&notice==='Unable to delete favourite'")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v638-favourite-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
t('Retry removes intended entry once',"return phoneState.favourites.length===1&&phoneState.favourites[0].name==='Keep'&&!favDelName")
call('Page.reload');time.sleep(.3)
t('Reload keeps intended deletion',"return phoneState.favourites.length===1&&phoneState.favourites[0].name==='Keep'")
print('PASS',len(checks))
