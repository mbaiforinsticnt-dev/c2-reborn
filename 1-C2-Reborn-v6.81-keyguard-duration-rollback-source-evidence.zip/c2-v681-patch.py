from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.80-profile-activation-rollback-candidate.html').read_text().replace('v6.80 handset parity','v6.81 handset parity').replace('C2 Reborn v6.80 |','C2 Reborn v6.81 |')
a="phoneState.keyguardDelay=sec;pickerCommit('phonesettings',2,'On');persist();back();notice='Automatic keyguard '+sec+' seconds';draw();return"
b="let beforeDelay=phoneState.keyguardDelay,beforeVals=phoneState.phoneVals,hadVals=Object.prototype.hasOwnProperty.call(phoneState,'phoneVals'),beforeInput=lastInputAt;phoneState.keyguardDelay=sec;phoneState.phoneVals=(beforeVals||pickerDefaults('phonesettings')).slice();phoneState.phoneVals[2]='On';try{persist()}catch(err){phoneState.keyguardDelay=beforeDelay;if(hadVals)phoneState.phoneVals=beforeVals;else delete phoneState.phoneVals;lastInputAt=beforeInput;notice='Unable to save keyguard';draw();return}lastInputAt=Date.now();back();notice='Automatic keyguard '+sec+' seconds';draw();return"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save profile|Folder memory full','Unable to save profile|Unable to save keyguard|Folder memory full')
Path('/downloads/C2-Reborn-v6.81-keyguard-duration-rollback-candidate.html').write_text(s)
