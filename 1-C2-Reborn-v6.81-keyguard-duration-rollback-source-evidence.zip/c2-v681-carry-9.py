exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.81-keyguard-duration-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for existing in [False,True]:
 ev("phoneState=migrateState(null);"+("phoneState.homeWallpaper={n:'Old',src:GAL_FILES.Images[1].big,mode:'Centre'};" if existing else '')+"persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');galUseFile={id:'Photo0001.jpg',src:GAL_FILES.Images[0].src,big:GAL_FILES.Images[0].big};galUseFileSel=0;galFolderName='Images';page='galusewall';sel=1;history=['galfolder','galuse'];trail=JSON.stringify(history);notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};galUsePress('OK')")
 t(str(existing)+' exact wallpaper rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&notice==='Unable to save wallpaper'")
 t(str(existing)+' choice and trail retained',"return page==='galusewall'&&sel===1&&JSON.stringify(history)===trail")
 ev("Storage.prototype.setItem=oldStore;notice='';galUsePress('OK')")
 t(str(existing)+' retry commits wallpaper',"return page==='galfolder'&&phoneState.homeWallpaper.n==='Photo0001.jpg'&&phoneState.homeWallpaper.mode==='Fit to display'&&notice==='Wallpaper applied'")
 call('Page.reload');time.sleep(.3)
 t(str(existing)+' reload exact wallpaper bytes',"return phoneState.homeWallpaper.src===GAL_FILES.Images[0].big&&phoneState.homeWallpaper.mode==='Fit to display'")
ev("page='home';notice='';draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v627-wallpaper.png','wb').write(base64.b64decode(d['result']['data']))
print('PASS',len(checks))
