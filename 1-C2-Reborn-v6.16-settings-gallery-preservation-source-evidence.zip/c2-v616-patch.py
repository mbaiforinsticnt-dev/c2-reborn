from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.15-demo-recording-reload-candidate.html').read_text().replace('v6.15 handset parity','v6.16 handset parity').replace('C2 Reborn v6.15 |','C2 Reborn v6.16 |')
a='galleryFolders:phoneState.galleryFolders,galDeleted:phoneState.galDeleted'
b='galleryFolders:phoneState.galleryFolders,galFolderParents:phoneState.galFolderParents,galFolderNames:phoneState.galFolderNames,galFolderAliases:phoneState.galFolderAliases,galFolderItems:phoneState.galFolderItems,galFolderSerial:phoneState.galFolderSerial,galEditedImages:phoneState.galEditedImages,galDeleted:phoneState.galDeleted'
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.16-settings-gallery-preservation-candidate.html').write_text(s)
