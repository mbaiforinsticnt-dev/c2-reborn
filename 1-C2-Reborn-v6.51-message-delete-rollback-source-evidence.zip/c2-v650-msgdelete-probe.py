exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.50-demo-send-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);messageStore=seedMessageStore();messageStore.inbox=[{id:'delete',body:'Delete',name:'Demo',unread:false}];phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');page='inbox';sel=0;askMessageDelete();oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({inbox:messageStore.inbox,pending:messageDeletePending,sel,diskSame:localStorage.getItem('c2state')===stored})"))
