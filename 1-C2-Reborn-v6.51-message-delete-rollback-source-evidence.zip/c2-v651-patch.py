from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.50-demo-send-rollback-candidate.html').read_text().replace('v6.50 handset parity','v6.51 handset parity').replace('C2 Reborn v6.50 |','C2 Reborn v6.51 |')
a="if(messageDeletePending||conversationDeletePending){let pending=messageDeletePending,conv=conversationDeletePending;messageDeletePending=null;"
b="if(messageDeletePending||conversationDeletePending){let pending=messageDeletePending,conv=conversationDeletePending,beforeStore={...messageStore,threads:Object.fromEntries(Object.entries(messageStore.threads).map(([key,list])=>[key,list.slice()])),inbox:messageStore.inbox.slice(),saved:messageStore.saved.slice(),hidden:messageStore.hidden.slice(),marked:messageStore.marked.slice(),numberedKeys:messageStore.numberedKeys.slice()},beforeDrafts=phoneState.drafts.slice(),beforeDemo=draftDemo.slice(),beforeThread=DEMO_THREAD,beforePage=page,beforeSel=sel;try{messageDeletePending=null;"
assert s.count(a)==1;s=s.replace(a,b)
a="}}}}else draw();return}if(callDeletePending)"
b="}}}}else draw()}catch(err){messageStore=beforeStore;phoneState.messageStore=messageStore;phoneState.drafts=beforeDrafts;draftDemo.splice(0,draftDemo.length,...beforeDemo);DEMO_THREAD=beforeThread;page=beforePage;sel=beforeSel;messageDeletePending=pending;conversationDeletePending=conv;notice='Unable to delete message';draw()}return}if(callDeletePending)"
assert s.count(a)==1;s=s.replace(a,b)
a="if(messageDeletePending||conversationDeletePending){s.insertAdjacentHTML";b="if((messageDeletePending||conversationDeletePending)&&!notice){s.insertAdjacentHTML";assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save sent message|Folder memory full|';b='Unable to save sent message|Unable to delete message|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.51-message-delete-rollback-candidate.html').write_text(s)
s=Path('/downloads/C2-Reborn-v6.51-message-delete-rollback-candidate.html').read_text()
s=s.replace('DEMO_THREAD=beforeThread;page=beforePage;sel=beforeSel;messageDeletePending=pending;', 'DEMO_THREAD=messageStore.threads.alex;page=beforePage;sel=beforeSel;messageDeletePending=pending;')
Path('/downloads/C2-Reborn-v6.51-message-delete-rollback-candidate.html').write_text(s)
