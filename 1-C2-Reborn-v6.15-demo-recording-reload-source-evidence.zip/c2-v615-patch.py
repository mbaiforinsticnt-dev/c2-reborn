from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.14-copied-source-preview-candidate.html').read_text().replace('v6.14 handset parity','v6.15 handset parity').replace('C2 Reborn v6.14 |','C2 Reborn v6.15 |')
a="['Images','Video clips'].includes(v.folder)&&typeof v.n==='string').map(v=>({folder:v.folder,n:cleanText(v.n,80),d:cleanText(v.d,30),s:cleanText(v.s,20)}))"
b="['Images','Video clips','Recordings'].includes(v.folder)&&typeof v.n==='string').map(v=>({folder:v.folder,n:cleanText(v.n,80),d:cleanText(v.d,30),s:cleanText(v.s,20),...(v.folder==='Recordings'?{demo:true}:{})}))"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.15-demo-recording-reload-candidate.html').write_text(s)
