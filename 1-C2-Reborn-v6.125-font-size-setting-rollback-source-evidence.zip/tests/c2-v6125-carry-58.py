exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.125-font-size-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['galDeleted','galMoved','galCopied','galFileNames']:
 ev("phoneState=migrateState(null);phoneState["+json.dumps(key)+"]="+ ('["NEW.GIF"]' if key=='galDeleted' else '{"NEW.GIF":"Other"}')+";before=JSON.stringify(phoneState);galFolderName='Images';page='galphoto';sel=0;galEditor={stage:'saveName',saveName:'New',src:GAL_FILES.Images[0].big};galEditorSaveCopy()")
 t(key+' historical identity rejected without mutation',"return galEditor.stage==='unsupported'&&galEditor.returnStage==='saveName'&&JSON.stringify(phoneState)===before")
ev("phoneState=migrateState(null);galEditor={stage:'saveName',saveName:'Fresh',src:GAL_FILES.Images[0].big};galEditorSaveCopy()")
time.sleep(.5)
t('Fresh name still saves visible GIF',"return galEditor.stage==='saved'&&galFolderFiles().some(f=>f.n==='Fresh.gif')")
call('Page.reload');time.sleep(.3)
t('Fresh GIF persists visible after reload',"galFolderName='Images';return galFolderFiles().some(f=>f.n==='Fresh.gif'&&/^data:image\/gif;base64,/.test(f.big))")
ev("phoneState.galDeleted=['Conflict.gif'];page='galphoto';galEditor={stage:'saveName',saveName:'Conflict',src:GAL_FILES.Images[0].big};galEditorSaveCopy();draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v623-save-collision.png','wb').write(base64.b64decode(d['result']['data']))
print('PASS',len(checks))
