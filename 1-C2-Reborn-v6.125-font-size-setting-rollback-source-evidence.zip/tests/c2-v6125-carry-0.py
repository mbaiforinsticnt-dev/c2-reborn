exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.125-font-size-setting-rollback-candidate.html'))
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';sel=0;galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'Probe'};draw();press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('Deleted existing identity guarded',"phoneState.galDeleted=['Probe.gif'];galEditor.stage='saveName';press('OK');return galEditor.stage==='unsupported'&&phoneState.galEditedImages.length===1")
t('Moved existing identity guarded',"phoneState.galDeleted=[];phoneState.galMoved={'Probe.gif':'Graphics'};galEditor.stage='saveName';press('OK');return galEditor.stage==='unsupported'&&phoneState.galEditedImages.length===1")
t('Copied existing identity guarded',"phoneState.galMoved={};phoneState.galCopied={'Probe.gif':'Graphics'};galEditor.stage='saveName';press('OK');return galEditor.stage==='unsupported'&&phoneState.galEditedImages.length===1")
t('Renamed raw identity remains reserved',"phoneState.galCopied={};phoneState.galFileNames={'Probe.gif':'Renamed.gif'};galEditor.stage='saveName';press('OK');return galEditor.stage==='unsupported'&&phoneState.galEditedImages.length===1")
t('Renamed visible identity collision',"galEditor.stage='saveName';galEditor.saveName='Renamed';press('OK');return galEditor.stage==='unsupported'")
t('Case insensitive identity',"galEditor.stage='saveName';galEditor.saveName='pRoBe';press('OK');return galEditor.stage==='unsupported'")
t('Custom item raw identity guarded',"phoneState.galFolderItems=[{folder:'Custom',n:'Custom.gif'}];galEditor.stage='saveName';galEditor.saveName='Custom';press('OK');return galEditor.stage==='unsupported'")
t('Source untouched and no false success',"return phoneState.galEditedImages.length===1&&phoneState.galEditedImages[0].n==='Probe.gif'&&galEditor.src===GAL_PHOTOS[0]")
ev("phoneState.galFileNames={};phoneState.galMoved={};galEditor.stage='saveName';galEditor.saveName='Fresh';press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('Fresh identity saved and visible',"return galEditor.stage==='saved'&&phoneState.galEditedImages.length===2&&galActualFiles('Images').some(f=>f.n==='Fresh.gif')")
print('PASS',len(checks))
