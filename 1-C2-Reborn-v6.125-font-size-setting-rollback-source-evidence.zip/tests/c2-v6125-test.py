exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.125-font-size-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in range(3):
  for choice in range(3):
   for absent in [False,True]:
    val=['Small font','Normal font','Large font'][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.fontVals;" if absent else "phoneState.fontVals=pickerDefaults('fontsize');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.fontVals;stored=localStorage.getItem('c2state');history=['fontsize'];notice='';noticeBack=false;open=false;"+("page='fontsize';sel="+str(row)+";pickerDraft={page:'fontsize',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'fontsize',row:"+str(row)+",title:'Font size',opts:['Small font','Normal font','Large font']};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.fontVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='fontsize'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save font size setting'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and row==0 and choice==2 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6125-font-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.fontVals["+str(row)+"]==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.fontVals["+str(row)+"]==="+json.dumps(val))
print('PASS',len(checks))
