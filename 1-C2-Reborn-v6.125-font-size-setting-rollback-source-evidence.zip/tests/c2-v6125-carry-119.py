exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.125-font-size-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for context in ['left','right','nav-0','nav-1','nav-2','nav-3','home-0','home-1','home-2']:
 home=context.startswith('home-');idx=int(context[-1]) if home else 0
 ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);beforeShortcuts=phoneState.myShortcuts;beforeNav=phoneState.myShortcuts.nav;stored=localStorage.getItem('c2state');page='"+('homescreenkey' if home else 'shortcutpicker')+"';sel="+str(idx)+";shortcutContext="+json.dumps(context)+";history=['settings'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(context+' exact rollback alias',"return JSON.stringify(phoneState)===before&&phoneState.myShortcuts===beforeShortcuts&&phoneState.myShortcuts.nav===beforeNav&&localStorage.getItem('c2state')===stored")
 t(context+' warning/context',"return notice==='Unable to save shortcut'&&document.getElementById('screen').innerText.includes(notice)&&page==='"+('homescreenkey' if home else 'shortcutpicker')+"'&&sel==="+str(idx)+"&&history.length===1")
 if context=='left':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v695-shortcut-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(context+' repeat failure',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';expected="+('JSON.stringify({...beforeShortcuts,home:["Navigation key up","Navig. key down","Nav. key up/down"][sel]})' if home else "JSON.stringify((()=>{let m={...beforeShortcuts,nav:beforeNav.slice()},v=shortcutChoices()[sel];if(shortcutContext==='left')m.left=v;else if(shortcutContext==='right')m.right=v;else m.nav[parseInt(shortcutContext.slice(4),10)]=v;return m})())")+";press('OK')")
 t(context+' retry',"return JSON.stringify(phoneState.myShortcuts)===expected&&page==='"+('navigationkey' if context.startswith('nav-') else 'myshortcuts')+"'")
 saved=ev('expected');call('Page.reload');time.sleep(.15)
 t(context+' reload',"return JSON.stringify(phoneState.myShortcuts)==="+json.dumps(saved))
print('PASS',len(checks))
