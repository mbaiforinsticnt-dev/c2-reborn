exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.125-font-size-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for name in ['If busy','If not answered','If not available']:
 for existing in [False,True]:
  ev("phoneState=migrateState(null);divertName="+json.dumps(name)+";divertScope='All voice calls';phoneState.callDiverts="+('{}' if not existing else "{[divertScope+':'+divertName]:{active:false,number:'Prior'},Other:{active:true,number:'901'}}")+";persist();before=JSON.stringify(phoneState);beforeDiverts=phoneState.callDiverts;stored=localStorage.getItem('c2state');page='divertdest';sel=0;history=['divertaction'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=name+str(existing)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.callDiverts===beforeDiverts&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save call divert'&&document.getElementById('screen').innerText.includes(notice)&&page==='divertdest'&&sel===0&&history.length===1")
  if name=='If busy' and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6108-divert-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return phoneState.callDiverts[divertScope+':'+divertName].active&&phoneState.callDiverts[divertScope+':'+divertName].number==='901'&&notice==='Divert to voice mailbox active (901)'")
  saved=ev('JSON.stringify(phoneState.callDiverts)');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(phoneState.callDiverts)==="+json.dumps(saved))
print('PASS',len(checks))
