exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.122-hs-packet-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for idx,view in enumerate(['List','Grid','Grid with labels','Tab']):
 ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='menu';menuViewChoosing=true;sel="+str(idx)+";lastMenuSel=2;open=true;os=1;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(view+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(view+' warning/context',"return notice==='Unable to save menu view'&&document.getElementById('screen').innerText.includes(notice)&&page==='menu'&&menuViewChoosing&&sel==="+str(idx)+"&&open&&os===1")
 if idx==0:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v696-menu-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(view+' repeat failure',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(view+' retry',"return phoneState.menuView==="+json.dumps(view)+"&&!menuViewChoosing&&sel===2&&!open&&os===0")
 call('Page.reload');time.sleep(.15)
 t(view+' reload',"return phoneState.menuView==="+json.dumps(view))
print('PASS',len(checks))
