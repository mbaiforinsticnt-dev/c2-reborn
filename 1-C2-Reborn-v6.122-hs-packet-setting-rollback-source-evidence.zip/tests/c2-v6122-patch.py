from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.121-time-auto-update-rollback-candidate.html').read_text().replace('v6.121 handset parity','v6.122 handset parity').replace('C2 Reborn v6.121 |','C2 Reborn v6.122 |')
a="if(p==='packetdata'){if(i===2)phoneState.hsPacket=v;else phoneState.pdConn=v;persist();return}"
b="if(p==='packetdata'){if(i===2){let had=Object.prototype.hasOwnProperty.call(phoneState,'hsPacket'),before=phoneState.hsPacket;phoneState.hsPacket=v;try{persist()}catch(err){if(had)phoneState.hsPacket=before;else delete phoneState.hsPacket;notice='Unable to save packet access setting';return false}return true}else phoneState.pdConn=v;persist();return}"
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('if(!["intphone","homescr","datetime"].includes(_rp))persist();','if(!["intphone","homescr","datetime"].includes(_rp)&&!(_rp===\'packetdata\'&&radioCtx.row===2))persist();').replace('Unable to save time update setting|Folder memory full','Unable to save time update setting|Unable to save packet access setting|Folder memory full');Path('/downloads/C2-Reborn-v6.122-hs-packet-setting-rollback-candidate.html').write_text(s)
