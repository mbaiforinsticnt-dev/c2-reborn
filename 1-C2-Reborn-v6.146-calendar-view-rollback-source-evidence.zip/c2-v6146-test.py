exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.146-calendar-view-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for source in ['calendar','calview']:
 for current in ['Month view','Week view','Day view']:
  for absent in [False,True]:
   ev("phoneState=migrateState(null);phoneState.calPrefs.view="+json.dumps(current)+";"+("delete phoneState.calPrefs.view;" if absent else "")+"persist();before=JSON.stringify(phoneState);alias=phoneState.calPrefs;stored=localStorage.getItem('c2state');page="+json.dumps(source)+";sel=0;history=['organiser'];notice='';noticeBack=false;open=true;os=1;pickerDraft=null;radioCtx=null;choice=currentOptions()[1];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
   label=f'{source} {current} {absent}'
   t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.calPrefs===alias&&localStorage.getItem('c2state')===stored")
   t(label+' context',"return page==="+json.dumps(source)+"&&notice==='Unable to save calendar view'")
   if source=='calendar' and current=='Month view' and not absent:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6146-calendar-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=1;press('OK')")
   t(label+' retry',"return phoneState.calPrefs.view===choice&&page==='calendar'")
   call('Page.reload');time.sleep(.15)
   t(label+' reload',"return ['Month view','Week view'].includes(phoneState.calPrefs.view)")
print('PASS',len(checks))
