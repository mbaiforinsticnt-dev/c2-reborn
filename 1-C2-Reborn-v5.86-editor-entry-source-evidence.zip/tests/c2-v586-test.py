exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.86-editor-entry-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(label,expr):
 v=ev('(()=>{'+expr+'})()');checks.append((label,v));print(label,v);assert v is True,(label,v)
def setup(p='galphoto'):
 ev("phoneState=migrateState(null);galEditor=null;galPrint=null;galContrast=null;galZoom=0;notice='';helpText=null;galFullScreen=false;galSequence=null;pageSub=null;history=[{page:'galfolder',sel:0}];galFolderName='Images';page='"+p+"';sel=0;open=true;os=currentOptions().indexOf('Edit image');draw()")
setup()
t('Image editor entry',"press('OK');return galEditor.stage==='view'&&document.querySelector('.title').textContent==='Image editor'&&notice===''&&!open")
t('Editor shows selected pixels',"return document.querySelector('.galEditorImage img').getAttribute('src')===galFolderFiles()[sel].big")
t('Editor status and softkeys',"return !document.querySelector('.lcd').classList.contains('photoMode')&&sl.textContent==='Options'&&sm.textContent==='Save'&&sr.textContent==='Back'")
import base64,time
for name,cmd in [('entry',''),('options',"press('LSK')"),('limit',"press('OK')")]:
 ev(cmd);time.sleep(.2);d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v586-editor-'+name+'.png','wb').write(base64.b64decode(d['result']['data']))
t('Honest operation boundary',"return galEditor.stage==='unsupported'&&document.querySelector('.alarmDialog').textContent==='Not implemented in this prototype'&&sm.textContent===''&&sr.textContent==='Back'")
t('Limit ignores keys',"press('OK');press('2');press('DOWN');return galEditor.stage==='unsupported'")
t('Back restores menu choice',"press('RSK');return galEditor.stage==='options'&&galEditor.choice===0")
t('Five SDK menu entries',"return Array.from(document.querySelectorAll('.galEditorMenu .opt')).map(x=>x.textContent).join('|')==='Insert text|Insert frame|Insert clip-art|Insert image|Crop image'")
t('Options arrows wrap',"press('UP');let a=galEditor.choice===4;press('DOWN');return a&&galEditor.choice===0")
for j in range(5):
 ev('galEditor.choice='+str(j)+';draw()')
 t('Operation '+str(j)+' stops honestly',"let before=JSON.stringify(phoneState);press('OK');let a=galEditor.stage==='unsupported';press('RSK');return a&&galEditor.stage==='options'&&galEditor.choice==="+str(j)+"&&before===JSON.stringify(phoneState)")
t('Menu Back restores editor',"press('RSK');return galEditor.stage==='view'&&sm.textContent==='Save'")
t('Save has no fake mutation',"let b=JSON.stringify(phoneState);press('OK');return galEditor.stage==='unsupported'&&JSON.stringify(phoneState)===b")
t('Save Back restores editor',"press('BACK');return galEditor.stage==='view'")
t('Editor Back restores image',"press('RSK');return !galEditor&&page==='galphoto'&&!open&&document.querySelector('.lcd').classList.contains('photoMode')")
setup('galfolder');t('Folder entry and return',"press('OK');let a=galEditor.stage==='view';press('RSK');return a&&!galEditor&&page==='galfolder'&&sel===0&&!open")
setup();t('End clears editor and history',"press('OK');press('LSK');press('OK');press('END');return !galEditor&&page==='home'&&!open&&history.length===0")
setup();t('Escapes image source',"press('OK');galEditor.src='\" onerror=bad';draw();return document.querySelector('.galEditorImage img').getAttribute('src')==='\" onerror=bad'&&!document.querySelector('.galEditorImage img').hasAttribute('onerror')")
print('PASS',len(checks))
