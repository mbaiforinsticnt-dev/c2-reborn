from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.12-stored-folder-recovery-candidate.html').read_text().replace('v6.12 handset parity','v6.13 handset parity').replace('C2 Reborn v6.12 |','C2 Reborn v6.13 |')
a='let map={},snap=sourceKeys.map';b='let map=Object.create(null),snap=sourceKeys.map';assert s.count(a)==1;s=s.replace(a,b)
a='(phoneState.galFileNames||{})[f.n]';b='galOwnText(phoneState.galFileNames,f.n)';print('file-name read replacements',s.count(a));s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.13-recovered-file-names-candidate.html').write_text(s)
