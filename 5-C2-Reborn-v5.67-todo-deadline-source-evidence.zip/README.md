# C2 Reborn v5.67: chronological To-do deadline sort

No index deployment. Includes v5.64-v5.66 changes, all delivered but pending-bank after browser submission failures. Banking remains parked.

Sort by deadline now uses validated DD-MM-YYYY and HH:MM components in year/month/day/hour/minute order. Cross-month/year sorting no longer treats the day number as the leading key. Equal deadlines preserve input order. Objects, done/alarm fields and text are unchanged. Missing times sort at start of due day without writing a time back. Malformed/rollover dates or times stop the entire sort with a plain notice and no partial reorder.

Grounding is the actual todo editor and save handler, which label/render/write DD-MM-YYYY and HH:MM. UTC date calculation validates leap dates without local DST effects. No new SDK behavior claimed.

9 focused plus 165 carried checks and syntax pass. Sorted September/October/January and View of the first sorted record mobile pixels inspected. Persistence, stable ties, leap day, invalid dates/times, missing time and selected record tested. Patch rebuild byte-exact.

Remaining: broader todo alarm/priority/deletion/calendar-copy behavior, Notes Send routes and earlier Contacts gaps are not certified by this pass.
