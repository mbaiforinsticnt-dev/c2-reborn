exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.67-todo-deadline-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
start="phoneState=migrateState(null);phoneState.todos=[{s:'January next year',d:'01-01-2027',t:'08:00'},{s:'October',d:'01-10-2026',t:'08:00'},{s:'September',d:'30-09-2026',t:'09:00'}];page='todolist';sel=0;open=false;notice='';sortTodoDeadlines();notice='';draw()"
for n,e in [('sorted',start),('view',"press('OK')")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v567-deadline-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
