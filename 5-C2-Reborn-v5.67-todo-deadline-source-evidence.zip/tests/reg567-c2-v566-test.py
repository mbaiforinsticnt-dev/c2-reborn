exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.67-todo-deadline-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
checks=[
('First window and selected item',"phoneState=migrateState(null);phoneState.todos=Array.from({length:12},(_,n)=>({s:'Todo '+(n+1),p:'Medium',d:'30-09-2026',t:'09:00',done:false}));page='todolist';sel=0;open=false;notice='';history=[];draw();return document.querySelectorAll('#screen .row').length===5&&document.querySelector('#screen .row.sel').textContent.includes('Todo 1')"),
('Down reaches last visible item',"for(let n=0;n<11;n++)press('DOWN');let s=document.querySelector('#screen').getBoundingClientRect(),r=document.querySelector('#screen .row.sel').getBoundingClientRect();return sel===11&&document.querySelector('#screen .row.sel').textContent.includes('Todo 12')&&r.top>=s.top&&r.bottom<=s.bottom"),
('View selected actual record',"press('OK');return page==='todoview'&&todoViewIdx===11&&document.querySelector('#screen').textContent.includes('Todo 12')"),
('Back preserves last selection',"press('RSK');return page==='todolist'&&sel===11&&document.querySelector('#screen .row.sel').textContent.includes('Todo 12')"),
('Down wraps to first window',"press('DOWN');return sel===0&&document.querySelector('#screen .row.sel').textContent.includes('Todo 1')"),
('Up wraps to last window',"press('UP');return sel===11&&document.querySelector('#screen .row.sel').textContent.includes('Todo 12')"),
('Middle selected row visible',"sel=6;draw();return document.querySelector('#screen .row.sel').textContent.includes('Todo 7')&&document.querySelectorAll('#screen .row').length===5"),
('Delete selected last item not window position',"sel=11;open=true;os=currentOptions().indexOf('Delete');draw();press('OK');press('OK');return phoneState.todos.length===11&&!phoneState.todos.some(t=>t.s==='Todo 12')&&sel===10&&document.querySelector('#screen .row.sel').textContent.includes('Todo 11')"),
('Stale selection clamps',"phoneState.todos=phoneState.todos.slice(0,2);sel=90;draw();return sel===1&&document.querySelectorAll('#screen .row').length===2"),
('Empty remains Add',"phoneState.todos=[];sel=0;draw();return sm.textContent==='Add'&&document.querySelector('#screen').textContent.includes('(no notes)')"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
