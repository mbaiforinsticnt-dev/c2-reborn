from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.66-todo-viewport-upload-ready.html').read_text().replace('v5.66','v5.67')
a='function normTodos(){'
b="""function todoDeadlineKey(x){let d=String(x.d||'').match(/^(\\d{2})-(\\d{2})-(\\d{4})$/),t=String(x.t||'00:00').match(/^(\\d{2}):(\\d{2})$/);if(!d||!t)return null;let day=+d[1],month=+d[2],year=+d[3],hour=+t[1],minute=+t[2],dt=new Date(0);dt.setUTCFullYear(year,month-1,day);dt.setUTCHours(hour,minute,0,0);if(month<1||month>12||day<1||hour>23||minute>59||dt.getUTCFullYear()!==year||dt.getUTCMonth()!==month-1||dt.getUTCDate()!==day)return null;return d[3]+d[2]+d[1]+t[1]+t[2]}
function sortTodoDeadlines(){let list=normTodos();if(list.some(x=>todoDeadlineKey(x)===null)){notice='Invalid deadline; list not sorted';draw();return}list.sort((a,b)=>todoDeadlineKey(a).localeCompare(todoDeadlineKey(b)));sel=0;persist();notice='Sorted by deadline';draw()}
function normTodos(){"""
assert s.count(a)==1;s=s.replace(a,b)
a="normTodos().sort((a,b)=>((a.d||'')+(a.t||'')).localeCompare((b.d||'')+(b.t||'')));sel=0;persist();notice='Sorted by deadline';draw()"
assert s.count(a)==1;s=s.replace(a,'sortTodoDeadlines()');Path('/downloads/C2-Reborn-v5.67-todo-deadline-candidate.html').write_text(s)
