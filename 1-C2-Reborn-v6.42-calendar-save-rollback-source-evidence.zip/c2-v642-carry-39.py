from pathlib import Path
s=Path('/tmp/c2-v587-test.py').read_text().replace('C2-Reborn-v5.87-editor-text-entry-candidate.html','C2-Reborn-v6.42-calendar-save-rollback-candidate.html')
s=s.replace("t('Layer explicit boundary',\"let b=JSON.stringify(phoneState);press('OK');return galEditor.stage==='unsupported'&&galEditor.returnStage==='text'&&JSON.stringify(phoneState)===b\")", "t('Layer creation with full allowance draft',\"let b=JSON.stringify(phoneState);press('OK');return galEditor.stage==='layer'&&galEditor.layer.text.length===12&&JSON.stringify(phoneState)===b\")")
s=s.replace("t('Layer limit back restores draft',\"press('RSK');return galEditor.stage==='text'&&galEditor.text.length===12\")", "t('Layer retains draft text',\"return galEditor.text.length===12\");ev(\"galEditor.stage='text';galEditor.layer=null\")")
s=s.replace("t('Remaining image action limit',\"press('DOWN');press('OK');return galEditor.stage==='unsupported'&&galEditor.returnStage==='options'\")", "t('Remaining frame entry',\"press('DOWN');press('OK');return galEditor.stage==='resource'&&galEditor.resource==='frame'\")")
exec(s)
