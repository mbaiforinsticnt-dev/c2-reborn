from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.41-todo-delete-rollback-candidate.html').read_text().replace('v6.41 handset parity','v6.42 handset parity').replace('C2 Reborn v6.41 |','C2 Reborn v6.42 |')
a="if(calNoteEdit>=0&&phoneState.calendar[calNoteEdit])phoneState.calendar[calNoteEdit]=n;else phoneState.calendar.unshift(n);persist();let pd="
b="let beforeCalendar=phoneState.calendar.slice();if(calNoteEdit>=0&&phoneState.calendar[calNoteEdit])phoneState.calendar[calNoteEdit]=n;else phoneState.calendar.unshift(n);try{persist()}catch(err){phoneState.calendar=beforeCalendar;notice='Unable to save calendar note';draw();return}let pd="
assert s.count(a)==1;s=s.replace(a,b)
a="Unable to delete to-do notes?|Folder memory full|";b="Unable to delete to-do notes?|Unable to save calendar note|Folder memory full|";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.42-calendar-save-rollback-candidate.html').write_text(s)
