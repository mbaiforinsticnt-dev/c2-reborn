from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.38-favourite-delete-rollback-candidate.html').read_text().replace('v6.38 handset parity','v6.39 handset parity').replace('C2 Reborn v6.38 |','C2 Reborn v6.39 |')
a='phoneState.alarm={on:alarmDraft.on,time:alarmDraft.time,repeat:alarmDraft.repeat,tone:alarmDraft.tone,snooze:+alarmDraft.snooze,days:alarmDraft.days.slice()};persist();alarmBase='
b="let previousAlarm=phoneState.alarm;phoneState.alarm={on:alarmDraft.on,time:alarmDraft.time,repeat:alarmDraft.repeat,tone:alarmDraft.tone,snooze:+alarmDraft.snooze,days:alarmDraft.days.slice()};try{persist()}catch(err){phoneState.alarm=previousAlarm;alarmMode='saveerror';draw();return}alarmBase="
assert s.count(a)==1;s=s.replace(a,b)
a="saved:'Alarm saved',unimplemented:";b="saved:'Alarm saved',saveerror:'Unable to save alarm',unimplemented:";assert s.count(a)==1;s=s.replace(a,b)
a="if(['unimplemented','invalid'].includes(alarmMode))";b="if(['unimplemented','invalid','saveerror'].includes(alarmMode))";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.39-alarm-save-rollback-candidate.html').write_text(s)
