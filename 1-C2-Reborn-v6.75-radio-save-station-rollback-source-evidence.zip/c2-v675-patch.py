from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.74-radio-station-selection-rollback-candidate.html').read_text().replace('v6.74 handset parity','v6.75 handset parity').replace('C2 Reborn v6.74 |','C2 Reborn v6.75 |')
a="else{phoneState.radioSaved.push({frequency:freq,name:'Station '+freq});phoneState.radioStationIndex=phoneState.radioSaved.length-1;persist();notice='Station '+freq+' saved'}draw();return}"
b="else{let beforeSaved=phoneState.radioSaved,beforeIndex=phoneState.radioStationIndex;phoneState.radioSaved=[...beforeSaved,{frequency:freq,name:'Station '+freq}];phoneState.radioStationIndex=phoneState.radioSaved.length-1;try{persist()}catch(err){phoneState.radioSaved=beforeSaved;phoneState.radioStationIndex=beforeIndex;notice='Unable to save radio station';draw();return}notice='Station '+freq+' saved'}draw();return}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.75-radio-save-station-rollback-candidate.html').write_text(s)
