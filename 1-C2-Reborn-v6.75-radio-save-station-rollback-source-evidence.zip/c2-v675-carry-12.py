exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.75-radio-save-station-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['new','edit','exit','demo']:
 act="press('OK')" if mode=='exit' else 'saveDraft()'
 ev("phoneState=migrateState(null);phoneState.drafts=[{kind:'sms',to:'Old',body:'Old',subject:''}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);demoBefore=JSON.stringify(draftDemo);page='compose';draft='New draft';recipientText='Alex';composeSubject='Subject';mmsMode=true;draftOpenIdx="+('0' if mode=='edit' else '-1')+";draftOpenDemo="+('0' if mode=='demo' else '-1')+";composeExitConfirm="+('true' if mode=='exit' else 'false')+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact drafts rollback',"return JSON.stringify(phoneState)===before&&JSON.stringify(draftDemo)===demoBefore&&localStorage.getItem('c2state')===stored")
 t(mode+' composer identity retained',"return page==='compose'&&draft==='New draft'&&recipientText==='Alex'&&composeSubject==='Subject'&&draftOpenIdx==="+('0' if mode=='edit' else '-1')+"&&draftOpenDemo==="+('0' if mode=='demo' else '-1')+"&&composeExitConfirm==="+('true' if mode=='exit' else 'false'))
 t(mode+' visible warning',"return notice==='Unable to save draft'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='exit':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v648-draft-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="draftDemo[0].body==='New draft'&&draftDemo[0].to==='Alex'&&draftDemo[0].subject==='Subject'" if mode=='demo' else "phoneState.drafts.length==="+('1' if mode=='edit' else '2')+"&&phoneState.drafts[0].body==='New draft'&&phoneState.drafts[0].to==='Alex'&&phoneState.drafts[0].subject==='Subject'"
 t(mode+' retry commits once',"return "+expect+"&&draft===''&&recipientText===''")
 if mode!='demo':
  call('Page.reload');time.sleep(.15)
  t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
