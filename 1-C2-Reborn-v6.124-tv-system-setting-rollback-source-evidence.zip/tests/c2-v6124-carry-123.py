exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.124-tv-system-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for existing in [False,True]:
 for slot in range(4):
  for item in [0,1]:
   ev("phoneState=migrateState(null);"+("phoneState.homeSlots=['Prior0','Prior1','Prior2','Prior3'];" if existing else "delete phoneState.homeSlots;")+"persist();before=JSON.stringify(phoneState);beforeSlots=phoneState.homeSlots;stored=localStorage.getItem('c2state');page='assignpicker';assignSlot="+str(slot)+";sel="+str(item)+";history=['persview'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
   label=str(existing)+str(slot)+str(item)
   t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.homeSlots===beforeSlots&&localStorage.getItem('c2state')===stored")
   t(label+' warning/context',"return notice==='Unable to save home content'&&document.getElementById('screen').innerText.includes(notice)&&page==='assignpicker'&&history.length===1&&sel==="+str(item)+"&&assignSlot==="+str(slot))
   if not existing and slot==0 and item==1:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v699-homecontent-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("notice='';press('OK')")
   t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
   ev("Storage.prototype.setItem=oldStore;notice='';expectedSlots=(beforeSlots||['','','','Shortcut bar']).slice();expectedSlots[assignSlot]=CONTENT_OPTS[sel]==='(empty)'?'':CONTENT_OPTS[sel];expected=JSON.stringify(expectedSlots);press('OK')")
   t(label+' retry',"return JSON.stringify(phoneState.homeSlots)===expected&&page==='persview'")
   saved=ev('expected');call('Page.reload');time.sleep(.15)
   t(label+' reload',"return JSON.stringify(phoneState.homeSlots)==="+json.dumps(saved))
print('PASS',len(checks))
