exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.124-tv-system-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
import base64,time
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
def shot(n):
 time.sleep(.1);d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v589-'+n+'.png','wb').write(base64.b64decode(d['result']['data']))
ev("phoneState=migrateState(null);galEditor=null;notice='';helpText=null;pageSub=null;page='galphoto';galFolderName='Images';sel=0;open=true;os=currentOptions().indexOf('Edit image');draw();press('OK');press('LSK');press('DOWN');press('OK')")
t('Frames empty title softkeys',"return galEditor.stage==='resource'&&document.querySelector('.title').textContent==='Frames'&&document.querySelector('.galEditorResourceEmpty').textContent==='(empty)'&&sl.textContent===''&&sm.textContent===''&&sr.textContent==='Back'")
shot('frames')
t('No fake frame choices',"let b=JSON.stringify(phoneState);for(let k of ['OK','LSK','UP','DOWN','LEFT','RIGHT','2'])press(k);return galEditor.stage==='resource'&&JSON.stringify(phoneState)===b")
t('Back restores selected frame row',"press('RSK');return galEditor.stage==='options'&&galEditor.choice===1")
t('Clip picker',"press('DOWN');press('OK');return galEditor.stage==='resource'&&document.querySelector('.title').textContent==='Clip-art'&&sm.textContent===''")
shot('clip')
t('Clip Back selection',"press('BACK');return galEditor.stage==='options'&&galEditor.choice===2")
t('Existing layer retained',"galEditor.layer={text:'A',bold:true,rotation:90};press('OK');press('BACK');return galEditor.stage==='options'&&galEditor.layer.text==='A'&&galEditor.layer.bold&&galEditor.layer.rotation===90")
t('Empty picker End cleanup',"press('OK');press('END');return !galEditor&&page==='home'&&history.length===0")
print('PASS',len(checks))
