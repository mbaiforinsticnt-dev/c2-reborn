exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.124-tv-system-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['create','targetCreate','rename','builtinRename']:
 ev("phoneState=migrateState(null);phoneState.galleryFolders=['Source','Child'];phoneState.galFolderParents={Source:'Memory card',Child:'Source'};phoneState.galFolderNames={Source:'Source',Child:'Child'};phoneState.galFolderItems=[{folder:'Source',n:'Probe',s:'100 B'}];phoneState.galMoved={'Photo0001.jpg':'Source'};phoneState.galCopied={'Photo0002.jpg':'Source'};page='foldername';notice='';open=false;folderName='NewName';galAddParent='Images';galRenameIdx=-1;galTarget=null;")
 if mode=='rename':ev("galRenameIdx=screens.gallery.length;galRenameOriginal='Source'")
 if mode=='builtinRename':ev("galRenameIdx=1;galRenameOriginal='Images'")
 if mode=='targetCreate':ev("galTarget={op:'Copy',folder:'Source',adding:true,browse:'Images',trail:[]};history=['galfoldertarget']")
 ev("persist();baseline=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};draw();press('OK')")
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===baseline&&localStorage.getItem('c2state')===stored")
 t(mode+' editor draft remains',"return page==='foldername'&&folderName==='NewName'&&notice==='Unable to save folder name'")
 if mode=='rename':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v607-folder-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';draw();press('OK')")
 t(mode+' retry persisted',"return page!=='foldername'&&folderName===''&&JSON.parse(localStorage.getItem('c2state'))."+('galFolderAliases.Images===\'NewName\'' if mode=='builtinRename' else 'galleryFolders.includes(\'NewName\')'))
 if mode=='rename':t('Rename retargets children and files',"return phoneState.galFolderParents.Child==='NewName'&&phoneState.galFolderItems[0].folder==='NewName'&&phoneState.galMoved['Photo0001.jpg']==='NewName'&&phoneState.galCopied['Photo0002.jpg']==='NewName'")
print('PASS',len(checks))
