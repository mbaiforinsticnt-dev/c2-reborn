exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.124-tv-system-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for repeat in ['true','false']:
 ev("phoneState=migrateState(null);phoneState.countdownAutoRepeat="+repeat+";persist();stored=localStorage.getItem('c2state');page='countdownsettings';sel=1;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(repeat+' exact rollback',"return phoneState.countdownAutoRepeat==="+repeat+"&&localStorage.getItem('c2state')===stored")
 t(repeat+' visible warning',"return notice==='Unable to save timer'&&document.getElementById('screen').innerText.includes(notice)&&page==='countdownsettings'")
 if repeat=='true':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v672-countdown-repeat-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(repeat+' repeat failure exact',"return phoneState.countdownAutoRepeat==="+repeat)
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(repeat+' retry toggles once',"return phoneState.countdownAutoRepeat!=="+repeat+"&&JSON.parse(localStorage.getItem('c2state')).countdownAutoRepeat===phoneState.countdownAutoRepeat")
 call('Page.reload');time.sleep(.15)
 t(repeat+' reload toggled',"return phoneState.countdownAutoRepeat!=="+repeat)
print('PASS',len(checks))
