exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.89-allsongs-start-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for source in ['calculator','scientific','loancalc']:
 for choice,target,mode in [('Scientific calculator','scientific','scientific'),('Standard calculator','calculator','standard'),('Loan calculator','loanintro','loan')]:
  if (source=='calculator' and mode=='standard') or (source=='scientific' and mode=='scientific') or (source=='loancalc' and mode=='loan'):continue
  ev("phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='"+source+"';calcSel=4;loanField=2;loanFields=['1','2','3','4'];loanResult='Keep';open=true;os=currentOptions().indexOf('"+choice+"');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  t(source+choice+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&page==='"+source+"'&&calcSel===4&&loanField===2&&loanResult==='Keep'")
  t(source+choice+' warning visible',"return notice==='Unable to save calculator mode'&&document.getElementById('screen').innerText.includes(notice)")
  if source=='calculator' and mode=='scientific':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v683-calculator-mode-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';open=true;os=currentOptions().indexOf('"+choice+"');press('OK')")
  t(source+choice+' repeat failure exact',"return JSON.stringify(phoneState)===before&&page==='"+source+"'")
  ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=currentOptions().indexOf('"+choice+"');press('OK')")
  t(source+choice+' retry exact',"return phoneState.calcMode==='"+mode+"'&&page==='"+target+"'")
  call('Page.reload');time.sleep(.15)
  t(source+choice+' reload exact',"return phoneState.calcMode==='"+mode+"'")
print('PASS',len(checks))
