from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.88-player-completion-rollback-candidate.html').read_text().replace('v6.88 handset parity','v6.89 handset parity').replace('C2 Reborn v6.88 |','C2 Reborn v6.89 |')
a="else if(page==='allsongs'){phoneState.player.track=0;phoneState.player.playing=true;playerTickBase=Date.now();persist();go('player')}"
b="else if(page==='allsongs'){let beforePlayer=phoneState.player,beforeTick=playerTickBase;phoneState.player={...beforePlayer,track:0,playing:true};playerTickBase=Date.now();try{persist()}catch(err){phoneState.player=beforePlayer;playerTickBase=beforeTick;notice='Unable to save player';draw();return}go('player')}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.89-allsongs-start-rollback-candidate.html').write_text(s)
