exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.89-allsongs-start-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['UP','DOWN','LEFT','RIGHT']:
 for playing in ['true','false']:
  ev("phoneState=migrateState(null);phoneState.player={track:0,playing:"+playing+",elapsed:15,volume:6,shuffle:false,repeat:false};playerTickBase=Date.now();playerLeftAt=0;persist();before=JSON.stringify(phoneState);beforePlayer=phoneState.player;beforeTick=playerTickBase;beforeLeft=playerLeftAt;stored=localStorage.getItem('c2state');page='player';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
  t(key+playing+' exact rollback aliases',"return JSON.stringify(phoneState)===before&&phoneState.player===beforePlayer&&playerTickBase===beforeTick&&playerLeftAt===beforeLeft&&localStorage.getItem('c2state')===stored")
  t(key+playing+' warning visible',"return notice==='Unable to save player'&&document.getElementById('screen').innerText.includes(notice)")
  if key=='UP' and playing=='false':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v684-player-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('"+key+"')")
  t(key+playing+' repeat failure exact',"return phoneState.player===beforePlayer&&JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
  expect="phoneState.player.volume==="+('7' if key=='UP' else '5') if key in ['UP','DOWN'] else "phoneState.player.elapsed===0&&phoneState.player.track==="+('(1%tracks.length)' if key=='RIGHT' else '0')
  t(key+playing+' retry once',"return "+expect+"&&phoneState.player.playing==="+playing)
  ev("phoneState.player.playing=false;persist()")
  call('Page.reload');time.sleep(.15)
  t(key+playing+' reload exact',"return "+expect)
print('PASS',len(checks))
