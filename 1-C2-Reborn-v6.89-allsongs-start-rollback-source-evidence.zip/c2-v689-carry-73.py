exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.89-allsongs-start-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['inboxopen','msgopen','right','optionsopen']:
 act="draw()" if mode=='msgopen' else "press('OK')" if mode=='inboxopen' else "press('RIGHT')" if mode=='right' else "open=true;os=currentOptions().indexOf('Open');press('OK')"
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();let m={id:'read',body:'Read',text:'Read',name:'Demo',dir:'in',unread:true,icon:'unread'};messageStore.inbox=[{...m}];messageStore.threads={alex:[{...m}]};phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps('inbox' if mode=='inboxopen' else 'msgopen' if mode=='msgopen' else 'conversation')+";sel=0;readMessageIndex=0;openMsgIdx=0;conversationKey='alex';notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' message opened not crashed',"return page==="+json.dumps('messageread' if mode=='inboxopen' else 'msgopen')+"&&document.getElementById('screen').innerText.includes('Read')")
 t(mode+' warning visible',"return notice==='Unable to save read status'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='inboxopen':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v658-open-read-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';draw()")
 expect="messageStore.inbox[0].unread===false" if mode=='inboxopen' else "messageStore.threads.alex[0].unread===false&&messageStore.threads.alex[0].icon==='read'"
 t(mode+' retry exact',"return "+expect)
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
