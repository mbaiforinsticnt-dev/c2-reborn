exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.109-call-divert-cancel-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
def reset():ev("phoneState=migrateState(null);phoneState.galleryFolders=['A','B','Child'];phoneState.galFolderParents={A:'Memory card',B:'Memory card',Child:'A'};phoneState.galFolderNames={A:'A',B:'VisibleB',Child:'Child'};phoneState.galFolderItems=[{folder:'A',n:'a.txt',s:'100 B'},{folder:'B',n:'b.txt',s:'200 B'}];page='foldername';open=false;notice='';galRenameIdx=screens.gallery.length;galRenameOs=0;galRenameOriginal='A';folderName='';persist();baseline=JSON.stringify(phoneState)")
for n in ['B','b','Images','VisibleB']:
 reset();ev('folderName='+json.dumps(n)+';press("OK")')
 t('Collision '+n+' guarded without merge',"return page==='foldername'&&notice==='Folder name already exists'&&JSON.stringify(phoneState)===baseline")
 if n=='B':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v608-rename-collision.png','wb').write(base64.b64decode(d['result']['data']))
reset();ev("folderName='A';press('OK')")
t('Unchanged name cannot delete own parent/name mapping',"return phoneState.galFolderParents.A==='Memory card'&&phoneState.galFolderNames.A==='A'&&phoneState.galFolderParents.Child==='A'&&phoneState.galleryFolders.length===3")
reset();ev("folderName='C';press('OK')")
t('Unique rename retargets without data loss',"return phoneState.galleryFolders.includes('C')&&!phoneState.galleryFolders.includes('A')&&phoneState.galFolderItems[0].folder==='C'&&phoneState.galFolderParents.Child==='C'&&phoneState.galFolderItems[1].folder==='B'")
call('Page.reload');time.sleep(.3)
t('Reload unique identities intact',"return new Set(phoneState.galleryFolders).size===3&&phoneState.galFolderParents.Child==='C'")
print('PASS',len(checks))
