exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.109-call-divert-cancel-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for had in [False,True]:
 ev("phoneState=migrateState(null);phoneState.contacts=[{name:'Demo'"+(",number:'123'" if had else '')+"}];persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='names';sel=0;pendingAddNumber='456';notice='';open=false;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(had)+' quota exact contact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&notice==='Unable to save contact number'")
 t(str(had)+' picker and pending number retained',"return page==='names'&&pendingAddNumber==='456'&&sel===0")
 if had:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v632-contact-number-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(str(had)+' retry appends once',"return phoneState.contacts[0].number==="+json.dumps('123 / 456' if had else '456')+"&&pendingAddNumber===null&&page==='contact'&&notice==='Number added'")
 call('Page.reload');time.sleep(.3)
 t(str(had)+' reload number preserved',"return phoneState.contacts[0].number==="+json.dumps('123 / 456' if had else '456'))
print('PASS',len(checks))
