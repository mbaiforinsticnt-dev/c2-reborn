exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.109-call-divert-cancel-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for kind in ['all','one']:
 for idx in [0,1]:
  ev("phoneState=migrateState(null);phoneState.stopwatchSaves=[{name:'First',mode:'lap',total:1000,marks:[100]},{name:'Second',mode:'split',total:2000,marks:[200]}];persist();before=JSON.stringify(phoneState);beforeSaves=phoneState.stopwatchSaves;stored=localStorage.getItem('c2state');page='"+('swdelete' if kind=='all' else 'swsaved')+"';swConfirm="+json.dumps(kind)+";swSaveIndex="+str(idx)+";history=['swview'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=kind+str(idx)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.stopwatchSaves===beforeSaves&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return swFlash==="+json.dumps('Unable to delete times' if kind=='all' else 'Unable to delete time')+"&&document.getElementById('screen').innerText.includes(swFlash)&&swConfirm==="+json.dumps(kind)+"&&swSaveIndex==="+str(idx)+"&&history.length===1")
  if kind=='one' and idx==0:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6102-stopwatch-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("swFlash='';clearTimeout(swFlashTimer);press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;swFlash='';clearTimeout(swFlashTimer);expectedSaves=beforeSaves.slice();"+("expectedSaves=[];" if kind=='all' else "expectedSaves.splice(swSaveIndex,1);")+"expected=JSON.stringify(expectedSaves);press('OK')")
  t(label+' retry',"return JSON.stringify(phoneState.stopwatchSaves)===expected&&swConfirm===null")
  saved=ev('expected');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(phoneState.stopwatchSaves)==="+json.dumps(saved))
print('PASS',len(checks))
