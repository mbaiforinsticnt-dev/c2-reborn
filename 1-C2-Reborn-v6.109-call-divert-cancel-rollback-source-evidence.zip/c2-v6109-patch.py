from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.108-call-divert-mailbox-rollback-candidate.html').read_text().replace('v6.108 handset parity','v6.109 handset parity').replace('C2 Reborn v6.108 |','C2 Reborn v6.109 |')
a="if(sel===1){if(v){v.active=false;persist()}notice='Call divert cancelled';"
b="if(sel===1){if(v){let beforeDiverts=phoneState.callDiverts;phoneState.callDiverts={...beforeDiverts,[key]:{...v,active:false}};try{persist()}catch(err){phoneState.callDiverts=beforeDiverts;notice='Unable to cancel call divert';draw();return}}notice='Call divert cancelled';"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save call divert|Folder memory full','Unable to save call divert|Unable to cancel call divert|Folder memory full')
Path('/downloads/C2-Reborn-v6.109-call-divert-cancel-rollback-candidate.html').write_text(s)
