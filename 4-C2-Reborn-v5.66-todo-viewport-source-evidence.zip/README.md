# C2 Reborn v5.66: To-do list viewport and highlight

No index deployment. v5.64/v5.65 baselines were delivered but remain pending remote banking. This snapshot includes their fixes.

To-do list now paints a five-row window following selected index, using the existing generic list policy. Selection clamps after a list shrinks. Replaces unused on class with the existing sel class so the selected item is actually highlighted. Keeps date/priority/content layout and backing indices.

10 focused checks and 155 carried checks pass. JavaScript syntax checked. Corrected first/middle/last/wrap mobile pixels inspected. Last item is on-LCD and highlighted; View/Back, exact last-row Delete, short/empty lists and wrap tested.

Build visibility/selection repair, not fresh handset/SDK parity. Deadline sorting, date format, priority icons, alarm semantics, Notes Send workflows and all earlier Contacts gaps remain unclaimed. Banking parked after v5.64 retry failed; no new submission attempted.
