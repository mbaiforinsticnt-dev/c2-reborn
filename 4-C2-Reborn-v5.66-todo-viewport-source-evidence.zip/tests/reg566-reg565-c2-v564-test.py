exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.66-todo-viewport-candidate.html'))
checks=[
('Send captures selected note before go resets sel',"phoneState=migrateState(null);phoneState.notes=['First note','Second note'];phoneState.noteStamps=['first stamp','second stamp'];page='notes';sel=1;noteIndex=0;open=true;deleteNoteConfirm=false;deleteNotesConfirm=0;namesSubmenu=null;pageSub=null;os=currentOptions().indexOf('Send note >');notice='';draw();press('OK');return page==='sendnote'&&noteIndex===1&&sel===0"),
('Back from existing number page retains selected note',"press('OK');press('RSK');return page==='noteview'&&noteIndex===1&&document.querySelector('#screen').textContent==='NoteSecond note'"),
('Send from noteview does not reset its identity',"open=true;os=currentOptions().indexOf('Send note >');press('OK');press('RSK');return noteIndex===1&&page==='noteview'"),
('Delete all first question no mutation',"page='notes';sel=1;open=true;os=currentOptions().indexOf('Delete all notes');draw();press('OK');return deleteNotesConfirm===1&&phoneState.notes.length===2&&phoneState.noteStamps.length===2"),
('No keeps text and stamps',"press('RSK');return !deleteNotesConfirm&&phoneState.notes.length===2&&phoneState.noteStamps[1]==='second stamp'"),
('Second question still no mutation',"open=true;os=currentOptions().indexOf('Delete all notes');press('OK');press('OK');return deleteNotesConfirm===2&&phoneState.notes.length===2&&phoneState.noteStamps.length===2"),
('Final Yes atomically clears stamps and text',"press('OK');return !deleteNotesConfirm&&phoneState.notes.length===0&&phoneState.noteStamps.length===0&&noteIndex===0"),
('Cleared arrays survive migration/reload',"let p=migrateState(JSON.parse(localStorage.getItem('c2state')));return p.notes.length===0&&p.noteStamps.length===0"),
('New note after Delete all gets only its new stamp',"page='textnote';open=false;noteText='Fresh note';noteEditingExisting=false;notice='';draw();press('OK');return phoneState.notes.length===1&&phoneState.notes[0]==='Fresh note'&&phoneState.noteStamps.length===1&&!phoneState.noteStamps.includes('first stamp')"),
('Empty Notes Send does not open stale note',"phoneState.notes=[];phoneState.noteStamps=[];page='notes';sel=0;open=true;os=currentOptions().indexOf('Send note >');draw();press('OK');return page==='notes'&&phoneState.notes.length===0"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
