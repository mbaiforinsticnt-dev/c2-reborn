from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.65-notes-viewport-upload-ready.html').read_text().replace('v5.65','v5.66')
a="else{let rh='';for(let ti=0;ti<tl.length;ti++){let t=tl[ti];"
b="else{sel=Math.max(0,Math.min(sel,tl.length-1));let start=Math.max(0,Math.min(sel-3,tl.length-5)),rh='';for(let ti=start;ti<Math.min(start+5,tl.length);ti++){let t=tl[ti];"
assert s.count(a)==1;s=s.replace(a,b);a="(ti===sel?' on':'')";assert s.count(a)==1;s=s.replace(a,"(ti===sel?' sel':'')");Path('/downloads/C2-Reborn-v5.66-todo-viewport-candidate.html').write_text(s)
