exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.66-todo-viewport-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
start="phoneState=migrateState(null);phoneState.todos=Array.from({length:12},(_,n)=>({s:'Todo '+(n+1),p:'Medium',d:'30-09-2026',t:'09:00',done:false}));page='todolist';sel=0;open=false;notice='';draw()"
for n,e in [('first',start),('middle',"sel=6;draw()"),('last',"sel=11;draw()"),('wrap',"press('DOWN')")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v566-todo-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
