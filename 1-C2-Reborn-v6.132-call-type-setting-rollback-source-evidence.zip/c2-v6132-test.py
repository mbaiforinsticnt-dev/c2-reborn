exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.132-call-type-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices=['Internet call only','Prefer internet call','Voice call only','Prefer voice call']
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for choice,val in enumerate(choices):
  for absent in [False,True]:
   for key in ['OK','LSK']:
    gated=choice<2
    ev("phoneState=migrateState(null);"+("delete phoneState.callVals;" if absent else "phoneState.callVals=pickerDefaults('callsettings');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.callVals;stored=localStorage.getItem('c2state');history=['callsettings'];notice='';noticeBack=false;open=false;inetGate='';"+("page='callsettings';sel=0;pickerDraft={page:'callsettings',row:0,value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'callsettings',row:0,title:'Call type setting',opts:"+json.dumps(choices)+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
    if gated:ev("press('"+key+"')")
    label=f'{route} {choice} {absent} {key}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.callVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("inetGate==="+json.dumps(val) if gated else ("pickerDraft===draftAlias&&page==='callsettings'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'"))+"&&notice==='Unable to save call setting'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and choice==0 and not absent and key=='OK':
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6132-call-type-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('"+key+"')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
    t(label+' retry',"return phoneState.callVals[0]==="+json.dumps(val)+"&&inetGate===''&&pickerDraft===null&&radioCtx===null")
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.callVals[0]==="+json.dumps(val))
print('PASS',len(checks))
