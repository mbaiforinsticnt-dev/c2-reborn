exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.111-alarm-firmware-icon-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode,key,expected in [('numeric','2',1),('next','RIGHT',1),('previous','LEFT',2),('list','OK',1)]:
 ev("phoneState=migrateState(null);phoneState.radioSaved=[{frequency:'98.8',name:'One'},{frequency:'99.9',name:'Two'},{frequency:'101.0',name:'Three'}];phoneState.radioStationIndex=0;phoneState.radioFrequency='98.8';persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='radio';radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')}")
 if mode=='list':ev("radioCtx={title:'Stations',opts:['One','Two','Three'],row:-1,page:'radioStations'};page='radiolist';sel=1;history=['radio']")
 ev("press('"+key+"')")
 t(mode+' rollback exact',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' warning visible',"return notice==='Unable to save radio station'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='list':
  t(mode+' picker context retained',"return page==='radiolist'&&radioCtx.page==='radioStations'&&sel===1&&history.length===1")
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v674-radio-station-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('"+key+"')")
 t(mode+' repeated failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
 t(mode+' retry once',"return phoneState.radioStationIndex==="+str(expected)+"&&phoneState.radioFrequency===phoneState.radioSaved["+str(expected)+"].frequency&&page==='radio'")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return phoneState.radioStationIndex==="+str(expected)+"&&phoneState.radioFrequency===phoneState.radioSaved["+str(expected)+"].frequency")
print('PASS',len(checks))
