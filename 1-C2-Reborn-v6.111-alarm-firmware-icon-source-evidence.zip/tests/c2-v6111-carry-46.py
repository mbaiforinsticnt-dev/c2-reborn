exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.111-alarm-firmware-icon-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(label,expr):
 v=ev('(()=>{'+expr+'})()');checks.append((label,v));print(label,v);assert v is True,(label,v)
def setup(p='galphoto'):
 ev("phoneState=migrateState(null);galPrint=null;galContrast=null;galZoom=0;notice='';helpText=null;galFullScreen=false;galSequence=null;pageSub=null;history=[{page:'galfolder',sel:0}];galFolderName='Images';page='"+p+"';sel=0;open=true;os=currentOptions().indexOf('Print');draw()")
setup()
t('Print named confirmation',"press('OK');return galPrint.stage==='confirm'&&document.querySelector('.alarmDialog').textContent==='Print? Photo0001.jpg'&&notice===''&&open")
t('Yes No softkeys',"return Array.from(document.querySelectorAll('.galPhotoSoft')).at(-1).textContent==='YesNo'")
t('thumbnail',"return document.querySelector('.alarmDialog img').getAttribute('src').length>0")
t('Arrows do not escape modal',"press('DOWN');press('LEFT');return galPrint.stage==='confirm'&&os===currentOptions().indexOf('Print')")
t('No returns image not Options',"press('RSK');return !galPrint&&!open&&page==='galphoto'&&Array.from(document.querySelectorAll('.galPhotoSoft')).at(-1).textContent==='OptionsSendBack'")
setup();t('Yes stops honestly',"press('OK');press('OK');return galPrint.stage==='unsupported'&&!open&&document.querySelector('.alarmDialog').textContent==='Not implemented in this prototype'&&Array.from(document.querySelectorAll('.galPhotoSoft')).at(-1).textContent==='Back'")
t('Unsupported ignores OK',"press('OK');return galPrint.stage==='unsupported'")
t('Back closes unsupported',"press('RSK');return galPrint===null&&page==='galphoto'")
setup();t('End clears confirmation',"press('OK');press('END');return galPrint===null&&page==='home'&&history.length===0")
setup('galfolder');t('Folder opens same named confirmation',"press('OK');return galPrint.name==='Photo0001.jpg'&&sm.textContent==='Yes'&&sr.textContent==='No'")
t('Folder No returns image',"press('RSK');return page==='galphoto'&&galPrint===null&&!open")
setup();t('Escaped filename',"press('OK');galPrint.name='<img onerror=bad>';draw();return document.querySelector('.alarmDialog').textContent==='Print? <img onerror=bad>'&&document.querySelectorAll('.alarmDialog img').length===1")
import base64,time
setup();ev("press('OK')");time.sleep(.2);d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v584-print.png','wb').write(base64.b64decode(d['result']['data']))
ev("press('OK')");time.sleep(.2);d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v584-print-limit.png','wb').write(base64.b64decode(d['result']['data']))
print('PASS',len(checks))
