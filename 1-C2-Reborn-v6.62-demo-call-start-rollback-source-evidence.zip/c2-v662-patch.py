from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.61-backup-rollback-candidate.html').read_text().replace('v6.61 handset parity','v6.62 handset parity').replace('C2 Reborn v6.61 |','C2 Reborn v6.62 |')
a="activeCall=number;callStarted=Date.now();callLoudspeaker=false;callMuted=false;callHeld=false;callHeldAt=0;phoneState.calls.dialled.unshift({number,time:'Just now'});persist();page='incall';"
b="let beforeDialled=phoneState.calls.dialled.slice(),beforeCall={active:activeCall,started:callStarted,loudspeaker:callLoudspeaker,muted:callMuted,held:callHeld,heldAt:callHeldAt};activeCall=number;callStarted=Date.now();callLoudspeaker=false;callMuted=false;callHeld=false;callHeldAt=0;phoneState.calls.dialled.unshift({number,time:'Just now'});try{persist()}catch(err){phoneState.calls.dialled=beforeDialled;activeCall=beforeCall.active;callStarted=beforeCall.started;callLoudspeaker=beforeCall.loudspeaker;callMuted=beforeCall.muted;callHeld=beforeCall.held;callHeldAt=beforeCall.heldAt;notice='Unable to save demo call';draw();return}page='incall';"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to restore backup|Folder memory full|';b='Unable to restore backup|Unable to save demo call|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.62-demo-call-start-rollback-candidate.html').write_text(s)
