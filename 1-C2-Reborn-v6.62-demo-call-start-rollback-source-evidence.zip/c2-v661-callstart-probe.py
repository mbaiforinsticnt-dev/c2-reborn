exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.61-backup-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');page='dial';activeCall=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};startCall('+44 7700 900888')")
print(ev("JSON.stringify({activeCall,page,dialled:phoneState.calls.dialled,diskSame:localStorage.getItem('c2state')===stored})"))
