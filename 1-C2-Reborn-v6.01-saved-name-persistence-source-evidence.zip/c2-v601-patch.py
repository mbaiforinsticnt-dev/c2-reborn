from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.00-target-image-details-candidate.html').read_text().replace('v6.00 handset parity','v6.01 handset parity').replace('C2 Reborn v6.00 |','C2 Reborn v6.01 |')
a="n:cleanText(v.n,160),src:v.src,big:v.src,s:cleanText(v.s,20),d:cleanText(v.d,30)"
b="n:cleanText(v.n,164),src:v.src,big:v.src,s:cleanText(v.s,20),d:cleanText(v.d,30)"
assert s.count(a)==1;s=s.replace(a,b)
a="display:cleanText(v.display||v.n,100),d:cleanText(v.d,30),s:cleanText(v.s,20),source:cleanText(v.source,100)"
b="display:cleanText(v.display||v.n,164),d:cleanText(v.d,30),s:cleanText(v.s,20),source:cleanText(v.source,164)"
assert s.count(a)==1;s=s.replace(a,b)
a="d[key][cleanText(a,100)]=cleanText(b,100)"
b="d[key][cleanText(a,164)]=cleanText(b,164)"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.01-saved-name-persistence-candidate.html').write_text(s)
