exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.00-target-image-details-candidate.html'))
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'a'.repeat(160)};draw();press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
print('before',ev("JSON.stringify({stage:galEditor.stage,len:phoneState.galEditedImages[0].n.length,end:phoneState.galEditedImages[0].n.slice(-8)})"))
call('Page.reload');time.sleep(.3)
print('reload',ev("JSON.stringify({len:phoneState.galEditedImages[0].n.length,end:phoneState.galEditedImages[0].n.slice(-8)})"))
