# S40 6th Edition SDK asset carve - inventory
Source: package_c.ppm from the Nokia S40 6th Edition SDK emulator
(prefix drive_c .../bin/Resources/Packages/package_c.ppm).
Carved 2026-09-15. All filenames carry the byte offset in package_c.ppm.

## icons/ (1433 PNGs + icons_manifest.csv)
Every raster image in the package, name = png_<offset>_<WxH>.png.
RESOURCE ID SCHEME (matches the builder's IDs): 0-based index over these
files sorted by ascending offset. icons_manifest.csv maps id -> offset/dims/file.
Size profile: 491x 30x30, 258x 56x56, 40x 24x24, 36x 94x94, 33x 66x66,
32x 296x296, plus assorted toolbar/status/indicator sizes.
Known verified IDs (pixel-matched against the live emulator LCD):
  0570 = Create message (yellow envelope + diagonal blue pencil)
  0578 = Web menu "Go to address" (globe + blue pencil)
  0581 = Web menu "Home" (globe + house)
  0586 = Web menu "Last web addr." (globe + blue square + white arrow)
  0590 = Web menu "Nokia.com" (globe + NOKIA banner)
  1093 = Web menu "Bookmarks" (globe + white square + dark-blue arrow;
         note: visually an arrow glyph, not a checkmark)
  0487 / 0639 = main-menu Web plain globe (two pixel-identical carves)

## wallpaper/ (154 files)
  - 98x jpg_<offset>.jpg: Nokia logo screens + ornamental photo wallpapers
  - 56x large background PNGs (copies; also in icons/ under their IDs):
    32x 296x296 theme tiles, 3x 320x480 idle backgrounds (analog clock face,
    radial glow), 1x 240x320 full-LCD background, misc 320x186/218x152/etc
    popup and idle graphics.

## fonts/ (5 TTFs)
font_package_c_ppm_<offset>.ttf - TrueType fonts embedded in the resource
package (the device UI fonts).

## animations/ (76 files)
gif_<offset>.gif animated assets + gif_<offset>_f.png first-frame renders.
Not part of the builder's 0-based PNG ID scheme (separate carve).

## Extras
Full 1433-PNG flat zip with the same manifest was previously delivered as
sdkassets_png_full.zip (2.2MB). The emulator rebuild recipe ships separately
as REBUILD_RECIPE.md.
