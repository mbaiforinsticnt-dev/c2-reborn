from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.113-target-gallery-setting-rollback-candidate.html').read_text().replace('v6.113 handset parity','v6.114 handset parity').replace('C2 Reborn v6.113 |','C2 Reborn v6.114 |')
a="if(k==='OK'&&page==='photosgrid'){if(!phoneState.dispVals)phoneState.dispVals=pickerDefaults('display');phoneState.dispVals[0]='Photos';persist();go('display');return}"
b="if(k==='OK'&&page==='photosgrid'){let had=Object.prototype.hasOwnProperty.call(phoneState,'dispVals'),before=phoneState.dispVals;phoneState.dispVals=(before||pickerDefaults('display')).slice();phoneState.dispVals[0]='Photos';try{persist()}catch(err){if(had)phoneState.dispVals=before;else delete phoneState.dispVals;notice='Unable to save wallpaper setting';draw();return}go('display');return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save gallery setting|Folder memory full','Unable to save gallery setting|Unable to save wallpaper setting|Folder memory full')
Path('/downloads/C2-Reborn-v6.114-photo-wallpaper-setting-rollback-candidate.html').write_text(s)
