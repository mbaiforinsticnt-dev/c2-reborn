exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.114-photo-wallpaper-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for active in [False,True]:
 ev("phoneState=migrateState(null);phoneState.callDiverts={'voice:If busy':{active:"+str(active).lower()+",number:'901'},Other:{active:true,number:'123'}};persist();before=JSON.stringify(phoneState);beforeDiverts=phoneState.callDiverts;beforeRecord=beforeDiverts['voice:If busy'];stored=localStorage.getItem('c2state');page='divertopt';sel=1;divertScope='voice';divertName='If busy';history=['divertvoice'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 label=str(active)
 t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.callDiverts===beforeDiverts&&phoneState.callDiverts['voice:If busy']===beforeRecord&&localStorage.getItem('c2state')===stored")
 t(label+' warning/context',"return notice==='Unable to cancel call divert'&&document.getElementById('screen').innerText.includes(notice)&&page==='divertopt'&&sel===1&&history.length===1")
 if active:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6109-divert-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(label+' retry',"return !phoneState.callDiverts['voice:If busy'].active&&phoneState.callDiverts['voice:If busy'].number==='901'&&phoneState.callDiverts.Other===beforeDiverts.Other&&notice==='Call divert cancelled'")
 saved=ev('JSON.stringify(phoneState.callDiverts)');call('Page.reload');time.sleep(.15)
 t(label+' reload',"return JSON.stringify(phoneState.callDiverts)==="+json.dumps(saved))
print('PASS',len(checks))
