exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.114-photo-wallpaper-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for existing in [False,True]:
 ev("phoneState=migrateState(null);"+("phoneState.btName='Prior name';" if existing else "delete phoneState.btName;")+"persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='btnameedit';btNameBuf='New name';history=['bluetooth'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(existing)+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(str(existing)+' warning/context',"return notice==='Unable to save Bluetooth name'&&document.getElementById('screen').innerText.includes(notice)&&page==='btnameedit'&&history.length===1&&btNameBuf==='New name'")
 if not existing:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v698-btname-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(str(existing)+' repeat failure',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(str(existing)+' retry',"return phoneState.btName==='New name'&&notice==='Name saved'")
 call('Page.reload');time.sleep(.15)
 t(str(existing)+' reload',"return phoneState.btName==='New name'")
print('PASS',len(checks))
