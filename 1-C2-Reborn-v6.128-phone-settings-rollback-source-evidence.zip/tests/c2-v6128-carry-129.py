exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.128-phone-settings-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for idx in [4,5]:
 for active in [False,True]:
  ev("phoneState=migrateState(null);phoneState.profile="+json.dumps('My style '+str(idx-3) if active else 'General')+";persist();before=JSON.stringify(phoneState);beforeNames=screens.profiles;beforeTones=phoneState.profileTones;stored=localStorage.getItem('c2state');page='profiles';nameEditing=true;profileTonesFor="+str(idx)+";nameDraft='New profile';history=['profiles'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=str(idx)+str(active)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&screens.profiles===beforeNames&&phoneState.profileTones===beforeTones&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save profile name'&&document.getElementById('screen').innerText.includes(notice)&&nameEditing&&nameDraft==='New profile'&&history.length===1")
  if idx==4 and not active:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6105-profile-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before&&screens.profiles===beforeNames")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return screens.profiles["+str(idx)+"]==='New profile'&&!!phoneState.profileTones['New profile']&&!nameEditing")
  saved=ev("JSON.stringify(phoneState.profileTones['New profile'])");call('Page.reload');time.sleep(.15)
  t(label+' renamed tones reload',"return JSON.stringify(phoneState.profileTones['New profile'])==="+json.dumps(saved))
print('PASS',len(checks))
