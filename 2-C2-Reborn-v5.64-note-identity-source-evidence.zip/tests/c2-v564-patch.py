from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.63-contact-filter-upload-ready.html').read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
s=s.replace('v5.63','v5.64')
rep("if((page==='notes'||page==='noteview')&&(c==='Send note'||c==='Send note >')){go('sendnote');return}","if((page==='notes'||page==='noteview')&&(c==='Send note'||c==='Send note >')){if(page==='notes'){if(!phoneState.notes[sel])return;noteIndex=sel}go('sendnote');return}")
rep("else{phoneState.notes=[];persist();deleteNotesConfirm=0;", "else{phoneState.notes=[];phoneState.noteStamps=[];noteIndex=0;persist();deleteNotesConfirm=0;")
Path('/downloads/C2-Reborn-v5.64-note-identity-candidate.html').write_text(s)
