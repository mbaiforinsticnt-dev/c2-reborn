# C2 Reborn v5.64: Notes identity and metadata

No index deployment. Narrow internal-consistency repair, not new handset/SDK parity.

Notes list Send note captures the selected note before go resets the list selection. Back from the existing number page therefore returns the same note, not an older noteIndex. Send note from Note view preserves its existing index. Empty lists do not open a stale Send flow.

Delete all notes final Yes now clears notes and noteStamps together and resets noteIndex. Both question stages and No keep both arrays unchanged. No change to wording, number of confirmations or timing.

10 focused checks and 133 carried checks pass. JavaScript syntax checked. Mobile pixels inspected: return to Second note, second Delete-all question, empty Notes after deletion.

Limits: Send as message still incorrectly enters a calendar-style number page. Via calendar/Bluetooth, fake transmission notices, wider Notes UI and timing are not fixed/certified here. All v5.63 caveats remain: contacts memory status/delete-all/search/views/icons/capacity/field-loss/Add new storage and recipient pickers.

Basis is exact selected-row identity and atomic cleanup of paired arrays already used by note creation and single-note deletion. No new external behavior invented.
