exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.91-display-restore-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['add','replace']:
 ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');favMode="+json.dumps(mode)+";favReplaceIdx=0;page='favpick';sel=1;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};result=favApply({name:'Demo',number:'123'})")
 t(mode+' quota exact favourite rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&result===false&&notice==='Unable to save favourite'")
 t(mode+' choice retained',"return page==='favpick'&&sel===1&&favMode==="+json.dumps(mode)+"&&favReplaceIdx===0")
 if mode=='add':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v637-favourite-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';result=favApply({name:'Demo',number:'123'})")
 t(mode+' retry commits once',"return result===true&&page==='favourites'&&phoneState.favourites.filter(f=>f.name==='Demo'&&f.number==='123').length===1&&phoneState.favourites.length==="+('2' if mode=='add' else '1'))
 call('Page.reload');time.sleep(.3)
 t(mode+' reload keeps favourite',"return phoneState.favourites.filter(f=>f.name==='Demo'&&f.number==='123').length===1")
print('PASS',len(checks))
