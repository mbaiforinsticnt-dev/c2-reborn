from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.90-theme-selection-rollback-candidate.html').read_text().replace('v6.90 handset parity','v6.91 handset parity').replace('C2 Reborn v6.90 |','C2 Reborn v6.91 |')
a="if(page==='display'&&c==='Restore default'){phoneState.dispVals=pickerDefaults('display');phoneState.homeColor='';phoneState.homeScreenMode='Off';phoneState.fontVals=pickerDefaults('fontsize');persist();notice='Display settings restored';draw();return}"
b="if(page==='display'&&c==='Restore default'){let keys=['dispVals','homeColor','homeScreenMode','fontVals'],beforeValues=keys.map(k=>phoneState[k]),hadValues=keys.map(k=>Object.prototype.hasOwnProperty.call(phoneState,k));phoneState.dispVals=pickerDefaults('display');phoneState.homeColor='';phoneState.homeScreenMode='Off';phoneState.fontVals=pickerDefaults('fontsize');try{persist()}catch(err){keys.forEach((k,i)=>{if(hadValues[i])phoneState[k]=beforeValues[i];else delete phoneState[k]});notice='Unable to restore display settings';draw();return}notice='Display settings restored';draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save theme|Folder memory full','Unable to save theme|Unable to restore display settings|Folder memory full')
Path('/downloads/C2-Reborn-v6.91-display-restore-rollback-candidate.html').write_text(s)
