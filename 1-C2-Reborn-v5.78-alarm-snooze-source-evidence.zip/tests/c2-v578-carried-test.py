exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.78-alarm-snooze-candidate.html'))
checks=[
('populated all confirmation',"phoneState=migrateState(null);phoneState.stopwatchSaves=[{name:'One',mode:'split',total:1250,marks:[500]},{name:'Two',mode:'lap',total:2200,marks:[1000,1200]}];page='swdelete';sel=1;open=false;notice='';swConfirm=null;swFlash='';draw();press('OK');return swConfirm==='all'&&swSaves().length===2&&document.querySelector('.swQuestion').textContent==='Are you sure?'&&sm.textContent==='Yes'&&sr.textContent==='No'"),
('No unchanged',"press('RSK');return !swConfirm&&swSaves().length===2&&page==='swdelete'&&sel===1"),
('Back cancels',"press('OK');press('BACK');return !swConfirm&&swSaves().length===2"),
('Yes clears all with empty notice',"press('OK');press('OK');return swSaves().length===0&&swFlash==='Stopwatch memory empty'&&document.querySelector('.swInfo')&&page==='swdelete'&&sel===1"),
('notice dismissed preserves delete row',"press('OK');return !swFlash&&sel===1&&page==='swdelete'"),
('empty all still asks',"press('OK');return swConfirm==='all'&&swSaves().length===0"),
('empty all result',"press('OK');return swFlash==='Stopwatch memory empty'"),
('one delete still isolated',"swFlash='';phoneState.stopwatchSaves=[{name:'One',mode:'split',total:1250,marks:[]},{name:'Two',mode:'lap',total:2200,marks:[]}];page='swview';sel=0;swDeletePick=true;swSaveIndex=0;draw();press('OK');let a=swConfirm==='one'&&document.querySelector('.swQuestion').textContent==='Delete?';press('OK');return a&&swSaves().length===1&&swSaves()[0].name==='Two'"),
('scientific operand full text escaped',"swFlash='';page='scientific';calc='0.0000017874618872706983';calcStored=200;calcOp='+';draw();return document.querySelector('.operand').textContent===calc&&document.querySelector('.operand').classList.contains('long')"),
('scientific long value inside display',"let a=document.querySelector('.operand');let r=document.createRange();r.selectNodeContents(a);let b=r.getBoundingClientRect(),c=a.getBoundingClientRect();return b.width<=c.width&&b.bottom<=c.bottom&&b.top>=c.top"),
('scientific grid above softkeys',"return document.querySelector('.calcGrid').getBoundingClientRect().bottom<=document.querySelector('.soft').getBoundingClientRect().top"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
ev("phoneState.stopwatchSaves=[{name:'Persist',mode:'split',total:900,marks:[500]}];persist();page='swdelete';sel=1;swFlash='';swConfirm=null;draw();press('OK');press('OK');")
call('Page.reload');time.sleep(.5)
z=ev('swSaves().length===0');print('Delete all survives reload',z);assert z
print('PASS',len(checks)+1)
import base64
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for tag,e in [('scientific-long',"page='scientific';calc='0.0000017874618872706983';calcStored=200;calcOp='+';draw()"),('delete-all',"page='swdelete';sel=1;swFlash='';swConfirm='all';draw()"),('memory-empty',"press('OK')")]:
 ev(e);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});open('/downloads/c2-v576-'+tag+'.png','wb').write(base64.b64decode(r['result']['data']))
