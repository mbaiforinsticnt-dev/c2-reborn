from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.39-alarm-save-rollback-candidate.html').read_text().replace('v6.39 handset parity','v6.40 handset parity').replace('C2 Reborn v6.39 |','C2 Reborn v6.40 |')
a="let i=noteDeleteFromView?noteIndex:sel;phoneState.notes.splice(i,1);phoneState.noteStamps.splice(i,1);sel=Math.max(0,Math.min(i,phoneState.notes.length-1));persist();deleteNoteConfirm=false;"
b="let i=noteDeleteFromView?noteIndex:sel,beforeNotes=phoneState.notes.slice(),beforeStamps=phoneState.noteStamps.slice(),beforeSel=sel;phoneState.notes.splice(i,1);phoneState.noteStamps.splice(i,1);sel=Math.max(0,Math.min(i,phoneState.notes.length-1));try{persist()}catch(err){phoneState.notes=beforeNotes;phoneState.noteStamps=beforeStamps;sel=beforeSel;notice='Unable to delete note';draw();return}deleteNoteConfirm=false;"
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.notes=[];phoneState.noteStamps=[];noteIndex=0;persist();deleteNotesConfirm=0;"
b="let beforeNotes=phoneState.notes,beforeStamps=phoneState.noteStamps,beforeIndex=noteIndex;phoneState.notes=[];phoneState.noteStamps=[];noteIndex=0;try{persist()}catch(err){phoneState.notes=beforeNotes;phoneState.noteStamps=beforeStamps;noteIndex=beforeIndex;notice='Unable to delete notes';draw();return}deleteNotesConfirm=0;"
assert s.count(a)==1;s=s.replace(a,b)
for a,b in [("if(deleteNoteConfirm){s.insertAdjacentHTML","if(deleteNoteConfirm&&!notice){s.insertAdjacentHTML"),("if(deleteNotesConfirm){s.insertAdjacentHTML","if(deleteNotesConfirm&&!notice){s.insertAdjacentHTML"),("Unable to delete favourite|Folder memory full|","Unable to delete favourite|Unable to delete notes?|Folder memory full|")]:
 assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.40-note-delete-rollback-candidate.html').write_text(s)
