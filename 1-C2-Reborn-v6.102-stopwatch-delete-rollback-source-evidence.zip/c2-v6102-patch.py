from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.101-stopwatch-save-rollback-candidate.html').read_text().replace('v6.101 handset parity','v6.102 handset parity').replace('C2 Reborn v6.101 |','C2 Reborn v6.102 |')
repls=[("if(swConfirm==='all'){phoneState.stopwatchSaves=[];persist();swConfirm=null;", "if(swConfirm==='all'){let beforeSaves=phoneState.stopwatchSaves;phoneState.stopwatchSaves=[];try{persist()}catch(err){phoneState.stopwatchSaves=beforeSaves;swSay('Unable to delete times');return true}swConfirm=null;"), ('swSaves().splice(swSaveIndex,1);persist();swConfirm=null;', "let beforeSaves=phoneState.stopwatchSaves;phoneState.stopwatchSaves=swSaves().slice();phoneState.stopwatchSaves.splice(swSaveIndex,1);try{persist()}catch(err){phoneState.stopwatchSaves=beforeSaves;swSay('Unable to delete time');return true}swConfirm=null;")]
for a,b in repls:
 assert s.count(a)==1,a
 s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.102-stopwatch-delete-rollback-candidate.html').write_text(s)
