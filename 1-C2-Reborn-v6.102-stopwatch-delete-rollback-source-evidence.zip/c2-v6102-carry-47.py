exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.102-stopwatch-delete-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(label,expr):
 v=ev(expr);checks.append((label,v));print(label,v);assert v is True,(label,v)
def keys(*ks):
 for k in ks:ev('press('+json.dumps(k)+')')
def snap(name):
 d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v580-'+name+'.png','wb').write(base64.b64decode(d['result']['data']))
ev("phoneState.alarm={on:false,time:'07:00',repeat:false,tone:'Standard',snooze:10,days:[]};persist();go('alarmclock')")
keys('END');t('clean End immediate home',"page==='home'&&alarmDraft===null")
ev("go('alarmclock')");keys('RIGHT','END');t('dirty End asks distinct Yes No',"alarmMode==='endcancel'&&alarmExitHome&&sl.textContent===''&&sm.textContent==='Yes'&&sr.textContent==='No'&&phoneState.alarm.on===false");snap('end-question')
keys('LSK');t('blank left no discard',"alarmMode==='endcancel'&&alarmDraft.on===true")
keys('RSK');t('End No discards and home',"page==='home'&&phoneState.alarm.on===false&&alarmDraft===null&&!alarmExitHome")
ev("go('alarmclock')");keys('RIGHT','END','OK');t('End Yes saves before home',"alarmMode==='saved'&&phoneState.alarm.on===true&&alarmExitHome");snap('end-saved');time.sleep(1.6);t('saved timeout home',"page==='home'&&alarmDraft===null&&!alarmExitHome")
ev("go('alarmclock')");keys('RIGHT','RSK');t('normal Cancel unchanged',"alarmMode==='cancel'&&!alarmExitHome&&sl.textContent==='No'&&sr.textContent==='Back'");keys('RSK');t('normal Back keeps draft',"alarmMode===''&&alarmDraft.on===false");keys('RSK','LSK');t('normal No organiser',"page==='organiser'&&phoneState.alarm.on===true")
print('PASS',len(checks))
