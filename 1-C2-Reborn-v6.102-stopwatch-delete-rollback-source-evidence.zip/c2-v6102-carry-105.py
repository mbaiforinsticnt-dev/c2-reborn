exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.102-stopwatch-delete-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['OK','LSK']:
 for existing in [False,True]:
  ev("phoneState=migrateState(null);"+("phoneState.phoneVals=pickerDefaults('phonesettings');phoneState.phoneVals[2]='Off'" if existing else "delete phoneState.phoneVals")+";persist();before=JSON.stringify(phoneState);beforeVals=phoneState.phoneVals;stored=localStorage.getItem('c2state');page='keyguardduration';keyguardDraft='120';history=['phonesettings'];lastInputAt=Date.now();oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
  t(key+str(existing)+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.phoneVals===beforeVals&&localStorage.getItem('c2state')===stored")
  t(key+str(existing)+' input/context retained',"return page==='keyguardduration'&&keyguardDraft==='120'&&history.length===1&&notice==='Unable to save keyguard'&&document.getElementById('screen').innerText.includes(notice)")
  if key=='OK' and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v681-keyguard-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('"+key+"')")
  t(key+str(existing)+' repeat failure exact',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';writes=0;Storage.prototype.setItem=function(k,v){writes++;return oldStore.call(this,k,v)};press('"+key+"');Storage.prototype.setItem=oldStore")
  t(key+str(existing)+' retry one persist',"return writes===1&&phoneState.keyguardDelay===120&&phoneState.phoneVals[2]==='On'&&page==='phonesettings'&&notice==='Automatic keyguard 120 seconds'")
  call('Page.reload');time.sleep(.15)
  t(key+str(existing)+' reload exact',"return phoneState.keyguardDelay===120&&phoneState.phoneVals[2]==='On'")
print('PASS',len(checks))
