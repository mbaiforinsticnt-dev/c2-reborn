exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.90-theme-selection-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['list','view','all','until']:
 ev("phoneState=migrateState(null);let d=new Date();let future=new Date(d.getFullYear(),d.getMonth(),d.getDate()+1);let past=new Date(d.getFullYear(),d.getMonth(),d.getDate()-1);phoneState.todos=[{s:'Past',p:'Medium',d:fmtCalDate(past),t:'09:00',done:false},{s:'Today',p:'Medium',d:todoToday(),t:'09:00',done:true},{s:'Future',p:'High',d:fmtCalDate(future),t:'11:30',done:false}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps('todoview' if mode=='view' else 'todolist')+";sel=1;todoViewIdx=1;todoDeleteConfirm="+('true' if mode in ['list','view'] else 'false')+";todoDelNotesConfirm="+json.dumps(mode if mode in ['all','until'] else '')+";todoDeleteFromView="+('true' if mode=='view' else 'false')+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(mode+' exact todo rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' selection confirmation retained',"return sel===1&&todoViewIdx===1&&"+('todoDeleteConfirm' if mode in ['list','view'] else 'todoDelNotesConfirm==='+json.dumps(mode))+"&&todoDeleteFromView==="+('true' if mode=='view' else 'false'))
 t(mode+' warning visible',"return notice==="+json.dumps('Unable to delete to-do note' if mode in ['list','view'] else 'Unable to delete to-do notes')+"&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='list':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v641-todo-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect="phoneState.todos.length===0" if mode=='all' else ("phoneState.todos.length===1&&phoneState.todos[0].s==='Future'" if mode=='until' else "phoneState.todos.length===2&&phoneState.todos[0].s==='Past'&&phoneState.todos[1].s==='Future'")
 t(mode+' retry intended deletion once',"return "+expect+"&&!todoDeleteConfirm&&!todoDelNotesConfirm")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
