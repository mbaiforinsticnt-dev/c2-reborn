exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.90-theme-selection-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['inbox','messageread','conversation','msgopen','sent','drafts','demo','conversations']:
 ev("clearTimeout(window._simT);window._simT=0;phoneState=migrateState(null);messageStore=seedMessageStore();messageStore.threads={alex:[{id:'delete',text:'Delete',dir:'out',number:'+44 7700 900123',date:todayDate(),time:'09:00',unread:false},{id:'keep',text:'Keep',dir:'in',number:'+44 7700 900123',date:todayDate(),time:'09:00',unread:false}]};DEMO_THREAD=messageStore.threads.alex;messageStore.inbox=[{id:'delete',body:'Delete',name:'Demo',unread:false},{id:'keep',body:'Keep',name:'Demo',unread:false}];phoneState.messageStore=messageStore;phoneState.drafts="+('[{kind:"sms",body:"Delete",to:"Alex",subject:""}]' if mode!='demo' else '[]')+";persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);demoBefore=JSON.stringify(draftDemo);page="+json.dumps('drafts' if mode=='demo' else mode)+";sel=0;readMessageIndex=0;openMsgIdx=0;conversationKey='alex';conversationNumber='+44 7700 900123';notice='';"+("conversationDeletePending={index:0,key:'alex'};draw()" if mode=='conversations' else 'askMessageDelete()')+";pendingBefore=messageDeletePending;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(mode+' exact rollback',"return DEMO_THREAD===messageStore.threads.alex&&JSON.stringify(phoneState)===before&&JSON.stringify(draftDemo)===demoBefore&&localStorage.getItem('c2state')===stored")
 t(mode+' selection and pending retained',"return page==="+json.dumps('drafts' if mode=='demo' else mode)+"&&sel===0&&"+('conversationDeletePending?.key===\'alex\'' if mode=='conversations' else 'messageDeletePending===pendingBefore'))
 t(mode+' visible warning',"return notice==='Unable to delete message'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='inbox':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v651-message-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect="messageStore.inbox.length===1&&messageStore.inbox[0].body==='Keep'" if mode in ['inbox','messageread'] else "phoneState.drafts.length===0" if mode=='drafts' else "draftDemo.length===JSON.parse(demoBefore).length-1" if mode=='demo' else "messageStore.threads.alex.length===0&&messageStore.hidden.includes(0)" if mode=='conversations' else "messageStore.threads.alex.length===1&&messageStore.threads.alex[0].text==='Keep'"
 t(mode+' retry intended deletion once',"return "+expect+"&&!messageDeletePending&&!conversationDeletePending")
 if mode!='demo':
  call('Page.reload');time.sleep(.15)
  t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
