from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.89-allsongs-start-rollback-candidate.html').read_text().replace('v6.89 handset parity','v6.90 handset parity').replace('C2 Reborn v6.89 |','C2 Reborn v6.90 |')
a="else if(page==='themeselect'){phoneState.theme=themeChoices[sel]?.[4]||phoneState.theme;persist();document.body.dataset.theme=phoneState.theme;notice=phoneState.theme+' selected';draw()}"
b="else if(page==='themeselect'){let beforeTheme=phoneState.theme;phoneState.theme=themeChoices[sel]?.[4]||phoneState.theme;try{persist()}catch(err){phoneState.theme=beforeTheme;notice='Unable to save theme';draw();return}document.body.dataset.theme=phoneState.theme;notice=phoneState.theme+' selected';draw()}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save player|Folder memory full','Unable to save player|Unable to save theme|Folder memory full')
Path('/downloads/C2-Reborn-v6.90-theme-selection-rollback-candidate.html').write_text(s)
