exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.110-alarm-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for pick in range(7):
 ev("phoneState=migrateState(null);phoneState.equaliser='Normal';persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='equaliser';eqEdit=false;sel="+str(pick)+";oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(pick)+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(str(pick)+' visible warning no activation',"return notice==='Unable to save equaliser'&&document.getElementById('screen').innerText.includes(notice)&&page==='equaliser'&&sel==="+str(pick))
 if pick==1:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v678-equaliser-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(str(pick)+' repeat failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(str(pick)+' retry activates',"return phoneState.equaliser===EQ_PRESETS["+str(pick)+"]&&notice===phoneState.equaliser+' activated'")
 call('Page.reload');time.sleep(.15)
 t(str(pick)+' reload exact',"return phoneState.equaliser===EQ_PRESETS["+str(pick)+"]")
print('PASS',len(checks))
