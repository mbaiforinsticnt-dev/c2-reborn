exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.110-alarm-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for repeat in ['true','false']:
 ev("phoneState=migrateState(null);phoneState.timerValue='00:02:00';phoneState.countdownAutoRepeat="+repeat+";phoneState.timerEndsAt=Date.now()+120000;persist();stored=localStorage.getItem('c2state');beforeEnd=phoneState.timerEndsAt;page='countdown';sel=1;normalTimerFlash='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(repeat+' exact timer retained',"return phoneState.timerEndsAt===beforeEnd&&normalTimerActive()&&localStorage.getItem('c2state')===stored")
 t(repeat+' error visible without success',"return normalTimerFlash==='Unable to save timer'&&document.getElementById('screen').innerText.includes(notice)&&page==='countdown'")
 if repeat=='true':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v668-countdown-stop-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("press('OK');press('OK')")
 t(repeat+' repeated failure retains timer',"return phoneState.timerEndsAt===beforeEnd&&normalTimerFlash==='Unable to save timer'")
 ev("Storage.prototype.setItem=oldStore;press('OK');press('OK')")
 t(repeat+' retry stops and persists',"return phoneState.timerEndsAt===0&&JSON.parse(localStorage.getItem('c2state')).timerEndsAt===0&&normalTimerFlash==='Timer stopped'")
 call('Page.reload');time.sleep(.15)
 t(repeat+' reload remains stopped',"return phoneState.timerEndsAt===0&&phoneState.timerValue==='00:02:00'")
print('PASS',len(checks))
