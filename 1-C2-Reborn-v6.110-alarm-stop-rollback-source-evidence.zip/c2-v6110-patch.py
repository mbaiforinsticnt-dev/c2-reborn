from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.109-call-divert-cancel-rollback-candidate.html').read_text().replace('v6.109 handset parity','v6.110 handset parity').replace('C2 Reborn v6.109 |','C2 Reborn v6.110 |')
a="if(k==='OK'&&page==='alarmring'){phoneState.alarm.on=phoneState.alarm.repeat;persist();history=[];page='home';notice='Alarm stopped';draw();return}"
b="if(k==='OK'&&page==='alarmring'){let beforeAlarm=phoneState.alarm;phoneState.alarm={...beforeAlarm,on:beforeAlarm.repeat};try{persist()}catch(err){phoneState.alarm=beforeAlarm;notice='Unable to stop alarm';draw();return}history=[];page='home';notice='Alarm stopped';draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to cancel call divert|Folder memory full','Unable to cancel call divert|Unable to stop alarm|Folder memory full')
Path('/downloads/C2-Reborn-v6.110-alarm-stop-rollback-candidate.html').write_text(s)
