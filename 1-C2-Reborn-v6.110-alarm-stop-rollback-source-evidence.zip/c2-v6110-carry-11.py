exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.110-alarm-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState({galleryFolders:['Custom'],galFolderItems:[{folder:'Custom',n:'constructor',s:'100 B'},{folder:'Custom',n:'toString',s:'200 B'}]});galFolderName='Custom';page='galfolder';sel=0;draw()")
t('File rows use string identity not inherited function',"return galFolderFiles().every(f=>typeof f.n==='string')&&galFolderFiles().map(f=>f.n).join(',')==='constructor,toString'")
t('Target picker names safe',"galTarget={browse:'Custom'};return galTargetAllRows().every(f=>typeof f.n==='string')")
t('Editor picker names safe',"galEditor={pickerBrowse:'Custom'};return galEditorPickerRows().every(f=>typeof f.n==='string')")
ev("galEditor=null;galTarget=null;page='galfolder';draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v613-recovered-files.png','wb').write(base64.b64decode(d['result']['data']))
t('Copy folder preserved visible file identity',"phoneState.galleryFolders.push('Dest');let r=galCopyFolderTo('Custom','Dest');galFolderName=r.key;return galFolderFiles().map(f=>f.n).join(',')==='constructor,toString'")
print('PASS',len(checks))
