exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.110-alarm-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for existing in [False,True]:
 for item in range(11):
  ev("phoneState=migrateState(null);"+("phoneState.homeContentMarks=CONTENT_OPTS.map((_,i)=>i%2===0);" if existing else "delete phoneState.homeContentMarks;")+"persist();before=JSON.stringify(phoneState);beforeMarks=phoneState.homeContentMarks;stored=localStorage.getItem('c2state');page='contentoptions';sel="+str(item)+";oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=str(existing)+str(item)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.homeContentMarks===beforeMarks&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save content options'&&document.getElementById('screen').innerText.includes(notice)&&page==='contentoptions'&&sel==="+str(item))
  if not existing and item==0:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6100-content-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';expectedMarks=(beforeMarks||CONTENT_OPTS.map((_,i)=>i!==10)).slice();expectedMarks[sel]=!expectedMarks[sel];expected=JSON.stringify(expectedMarks);press('OK')")
  t(label+' retry',"return JSON.stringify(phoneState.homeContentMarks)===expected")
  saved=ev('expected');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(phoneState.homeContentMarks)==="+json.dumps(saved))
print('PASS',len(checks))
