from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.98-bluetooth-name-rollback-candidate.html').read_text().replace('v6.98 handset parity','v6.99 handset parity').replace('C2 Reborn v6.98 |','C2 Reborn v6.99 |')
a="else if(page==='assignpicker'){if(!phoneState.homeSlots)phoneState.homeSlots=['','','','Shortcut bar'];phoneState.homeSlots[assignSlot]=CONTENT_OPTS[sel]==='(empty)'?'':CONTENT_OPTS[sel];persist();back();return}"
b="else if(page==='assignpicker'){let hadSlots=Object.prototype.hasOwnProperty.call(phoneState,'homeSlots'),beforeSlots=phoneState.homeSlots;phoneState.homeSlots=(beforeSlots||['','','','Shortcut bar']).slice();phoneState.homeSlots[assignSlot]=CONTENT_OPTS[sel]==='(empty)'?'':CONTENT_OPTS[sel];try{persist()}catch(err){if(hadSlots)phoneState.homeSlots=beforeSlots;else delete phoneState.homeSlots;notice='Unable to save home content';draw();return}back();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save Bluetooth name|Folder memory full','Unable to save Bluetooth name|Unable to save home content|Folder memory full')
Path('/downloads/C2-Reborn-v6.99-home-content-assignment-rollback-candidate.html').write_text(s)
