exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.99-home-content-assignment-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for existing in [False,True]:
 ev("phoneState=migrateState(null);"+("phoneState.homeColor='#112233';phoneState.homeScreenMode='On';phoneState.fontVals=['Large font','Large font','Large font'];phoneState.dispVals=pickerDefaults('display');phoneState.dispVals[0]='Custom'" if existing else "for(let k of ['homeColor','homeScreenMode','fontVals','dispVals'])delete phoneState[k]")+";persist();before=JSON.stringify(phoneState);keys=['dispVals','homeColor','homeScreenMode','fontVals'];beforeValues=keys.map(k=>phoneState[k]);stored=localStorage.getItem('c2state');page='display';open=true;os=currentOptions().indexOf('Restore default');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(existing)+' exact state/aliases',"return JSON.stringify(phoneState)===before&&keys.every((k,i)=>phoneState[k]===beforeValues[i])&&localStorage.getItem('c2state')===stored")
 t(str(existing)+' warning visible no success',"return notice==='Unable to restore display settings'&&document.getElementById('screen').innerText.includes(notice)")
 if existing:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v691-display-restore-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';open=true;os=currentOptions().indexOf('Restore default');press('OK')")
 t(str(existing)+' repeat failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=currentOptions().indexOf('Restore default');press('OK')")
 t(str(existing)+' retry restores',"return phoneState.homeColor===''&&phoneState.homeScreenMode==='Off'&&JSON.stringify(phoneState.fontVals)===JSON.stringify(pickerDefaults('fontsize'))&&JSON.stringify(phoneState.dispVals)===JSON.stringify(pickerDefaults('display'))&&notice==='Display settings restored'")
 call('Page.reload');time.sleep(.15)
 t(str(existing)+' reload restored',"return phoneState.homeColor===''&&phoneState.homeScreenMode==='Off'&&JSON.stringify(phoneState.fontVals)===JSON.stringify(pickerDefaults('fontsize'))")
print('PASS',len(checks))
