exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.99-home-content-assignment-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for action in ['Copy','Move']:
 for dir in [0,1]:
  ev("phoneState=migrateState(null);phoneState.contacts[0].store="+json.dumps('Phone' if dir==0 else 'SIM')+";phoneState.contacts[1].store="+json.dumps('Phone' if dir==0 else 'SIM')+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page="+json.dumps('copycontacts' if action=='Copy' else 'movecontacts')+";bulkContactPending={stage:'question',action:"+json.dumps(action)+",records:phoneState.contacts.slice(0,2),destination:"+json.dumps('SIM' if dir==0 else 'Phone')+",dir:"+str(dir)+",origin:page};notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  t(action+str(dir)+' quota exact row rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&bulkContactPending.records.every(c=>phoneState.contacts.includes(c))")
  t(action+str(dir)+' confirmation retained',"return bulkContactPending.stage==='question'&&bulkContactPending.records.length===2&&notice==='Unable to save contact transfer'")
  if action=='Copy' and dir==0:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v636-bulk-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(action+str(dir)+' retry commits both once',"return bulkContactPending.stage==='result'&&phoneState.contacts.length==="+('5' if action=='Copy' else '3')+"&&phoneState.contacts.filter(c=>['Alex Morgan','Home'].includes(c.name)&&c.store==="+json.dumps('SIM' if dir==0 else 'Phone')+").length===2")
  call('Page.reload');time.sleep(.3)
  t(action+str(dir)+' reload transfers retained',"return phoneState.contacts.length==="+('5' if action=='Copy' else '3')+"&&phoneState.contacts.filter(c=>['Alex Morgan','Home'].includes(c.name)&&c.store==="+json.dumps('SIM' if dir==0 else 'Phone')+").length===2")
print('PASS',len(checks))
