exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.58-open-read-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.calls.dialled=[{number:'+44 7700 900888',time:'Today'}];persist();stored=localStorage.getItem('c2state');page='clearloglists';sel=0;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({calls:phoneState.calls,notice,diskSame:localStorage.getItem('c2state')===stored})"))
