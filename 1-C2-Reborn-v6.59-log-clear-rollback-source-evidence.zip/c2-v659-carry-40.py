exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.59-log-clear-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(label,expr):
 v=ev('(()=>{'+expr+'})()');checks.append((label,v));print(label,v);assert v is True,(label,v)
def setup(state=""):
 ev("phoneState=migrateState(null);galUseFile=null;galUseContactPick=false;galUseContactPending=null;notice='';helpText=null;open=false;history=[];"+state)
# 1 Use image opens submenu
setup("galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw()")
t('Use image opens submenu',"press('OK');return page==='galuse'&&document.querySelector('.title').textContent==='Photo0001.jpg'&&document.querySelectorAll('.row').length===4&&sr.textContent==='Back'&&sm.textContent==='Select'")
t('submenu rows ordered',"return [...document.querySelectorAll('.row')].map(r=>r.textContent).join('|')==='Set as wallpaper|Set as contact image|Set to new contact|Set as group image'")
t('submenu wraps down',"press('DOWN');press('DOWN');press('DOWN');press('DOWN');return sel===0")
t('Back returns folder',"press('RSK');return page==='galfolder'&&sel===0")
# wallpaper
setup("galFolderName='Images';page='galfolder';sel=1;open=true;os=1;draw();press('OK')")
t('wallpaper page',"press('OK');return page==='galusewall'&&document.querySelectorAll('.row').length===4&&document.querySelectorAll('.galWallThumb').length===4&&document.querySelector('.title').textContent==='Photo0002.jpg'")
t('wallpaper rows',"return [...document.querySelectorAll('.row')].map(r=>r.textContent.trim()).join('|')==='Centre|Fit to display|Rotate left|Rotate right'")
t('wallpaper back to submenu',"press('RSK');return page==='galuse'")
t('Centre applies and returns',"press('OK');press('OK');return page==='galfolder'&&sel===1&&notice==='Wallpaper applied'&&phoneState.homeWallpaper.mode==='Centre'&&phoneState.homeWallpaper.n==='Photo0002.jpg'&&/^data:image\\//.test(phoneState.homeWallpaper.src)")
t('history cleaned',"return history.every(h=>(typeof h==='string'?h:h.page)!=='galuse'&&(typeof h==='string'?h:h.page)!=='galusewall')")
t('home renders wallpaper',"notice='';page='home';draw();return !!document.querySelector('.homeTheme.hasWallpaper img')")
t('Fit mode',"phoneState.homeWallpaper=null;page='galusewall';sel=1;draw();press('OK');return phoneState.homeWallpaper.mode==='Fit to display'")
t('Rotate left mode',"page='galusewall';sel=2;draw();press('OK');return phoneState.homeWallpaper.mode==='Rotate left'")
t('Rotate right mode',"page='galusewall';sel=3;draw();press('OK');return phoneState.homeWallpaper.mode==='Rotate right'")
# contact image phone contact
setup("phoneState.contacts=[{name:'Phone Person',number:'111',store:'Phone'},{name:'Sim Person',number:'222',store:'SIM'}];pickerCommit('contactsettings',0,'Phone and SIM');galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw();press('OK');press('DOWN');press('OK')")
t('names pick mode',"return page==='names'&&galUseContactPick===true&&sm.textContent==='Add'&&sl.textContent===''&&sr.textContent==='Back'")
t('phone contact applies direct',"press('OK');return page==='contact'&&contactIndex===0&&phoneState.contacts[0].image==='Photo0001.jpg'")
t('contact details shows image',"return document.querySelector('#screen img').src===namesImage(phoneState.contacts[0])&&sr.textContent==='Done'")
t('Done reopens gallery options',"press('RSK');return page==='galfolder'&&open===true&&os===currentOptions().indexOf('Use image')")
t('names pick flag cleared',"return galUseContactPick===false")
# SIM confirm
setup("phoneState.contacts=[{name:'Phone Person',number:'111',store:'Phone'},{name:'Sim Person',number:'222',store:'SIM'}];pickerCommit('contactsettings',0,'Phone and SIM');galFolderName='Images';page='galfolder';sel=2;open=true;os=1;draw();press('OK');press('DOWN');press('OK');press('DOWN');press('OK')")
t('SIM confirm dialog',"return galUseContactPending&&document.querySelector('.alarmDialog').textContent==='Move contact to phone memory?'&&sm.textContent==='Yes'&&sr.textContent==='No'")
t('No cancels',"press('RSK');return galUseContactPending===null&&page==='names'&&phoneState.contacts[1].image===undefined")
t('Yes moves and applies',"press('OK');press('OK');return page==='contact'&&phoneState.contacts[1].store==='Phone'&&phoneState.contacts[1].image==='Photo0003.jpg'")
# new contact
setup("galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw();press('OK');press('DOWN');press('DOWN');press('OK')")
t('new contact form image preset',"return page==='addcontact'&&contactImage==='Photo0001.jpg'&&cfAdded.image===true&&editingContact===false")
t('form Back returns submenu',"press('RSK');return page==='galuse'&&sel===2")
# group image empty
setup("galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw();press('OK');press('DOWN');press('DOWN');press('DOWN');press('OK')")
t('empty groups notice',"return page==='galuse'&&notice==='Selected memory empty'")
t('groups picker when present',"notice='';phoneState.groups=[{name:'Family',number:''}];press('OK');return page==='galusegroups'&&document.querySelector('.row').textContent==='Family'")
t('group image assign',"press('OK');return phoneState.groups[0].image==='Photo0001.jpg'&&notice==='Image applied'")
# zoom still honest
setup("galFolderName='Images';page='galfolder';sel=0;open=true;os=currentOptions().indexOf('Edit image');draw()")
t('Edit image opens editor',"press('OK');return galEditor?.stage==='view'&&notice===''")
# migration
t('wallpaper survives migration',"return migrateState({homeWallpaper:{n:'Photo0001.jpg',src:'data:image/png;base64,AAAA',mode:'Centre'}}).homeWallpaper.mode==='Centre'")
t('external wallpaper dropped',"return migrateState({homeWallpaper:{n:'x',src:'https://evil.invalid/x.png',mode:'Centre'}}).homeWallpaper===undefined")
t('bad mode dropped',"return migrateState({homeWallpaper:{n:'x',src:'data:image/png;base64,AAAA',mode:'Sideways'}}).homeWallpaper===undefined")
print('PASS',len(checks))
import base64
for tag,state in [('submenu',"galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw();press('OK')"),('wallpaper',"press('OK')"),('sim-confirm',"phoneState=migrateState(null);phoneState.contacts=[{name:'Sim Person',number:'222',store:'SIM'}];pickerCommit('contactsettings',0,'Phone and SIM');galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw();press('OK');press('DOWN');press('OK');press('OK')"),('home-wallpaper',"phoneState=migrateState(null);galFolderName='Images';page='galfolder';sel=0;open=true;os=1;draw();press('OK');press('OK');press('OK');notice='';page='home';draw()")]:
 ev("phoneState=migrateState(null);galUseFile=null;galUseContactPick=false;galUseContactPending=null;notice='';open=false;history=[];"+state)
 import time;time.sleep(0.3)
 d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v582-'+tag+'.png','wb').write(base64.b64decode(d['result']['data']));print('/downloads/c2-v582-'+tag+'.png')
