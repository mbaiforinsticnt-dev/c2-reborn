from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.58-open-read-rollback-candidate.html').read_text().replace('v6.58 handset parity','v6.59 handset parity').replace('C2 Reborn v6.58 |','C2 Reborn v6.59 |')
a="if(page==='clearloglists'){if(sel===0)";b="if(page==='clearloglists'){let beforeCalls={...phoneState.calls},beforeRecipients=phoneState.messageRecipients;if(sel===0)";assert s.count(a)==1;s=s.replace(a,b)
a="notice='Message recipients list cleared'}else return;persist();draw();return}"
b="notice='Message recipients list cleared'}else return;try{persist()}catch(err){phoneState.calls=beforeCalls;phoneState.messageRecipients=beforeRecipients;notice='Unable to clear log list'}draw();return}"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save read status|Folder memory full|';b='Unable to save read status|Unable to clear log list|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.59-log-clear-rollback-candidate.html').write_text(s)
