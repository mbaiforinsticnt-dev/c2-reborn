exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.69-countdown-time-save-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for operation in ['create','restore']:
 for key in ['OK']:
  label=operation+key
  ev("phoneState=migrateState(null);messageStore=seedMessageStore();phoneState.messageStore=messageStore;phoneState.notes=['Backup'];makeLocalBackup();backup=localStorage.getItem('c2-local-backup');phoneState.notes=['Current'];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);beforeState=phoneState;beforeStore=messageStore;page="+json.dumps('createbackup' if operation=='create' else 'restorebackup')+";sel=0;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press("+json.dumps(key)+")")
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState===beforeState&&messageStore===beforeStore&&localStorage.getItem('c2state')===stored&&localStorage.getItem('c2-local-backup')===backup")
  t(label+' correct visible error',"return notice==="+json.dumps('Unable to save backup' if operation=='create' else 'Unable to restore backup')+"&&document.getElementById('screen').innerText.includes(notice)")
  if operation=='restore' and key=='OK':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v661-backup-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("Storage.prototype.setItem=oldStore;notice='';press("+json.dumps(key)+")")
  expect="JSON.parse(localStorage.getItem('c2-local-backup')).data.notes[0]==='Current'&&phoneState.notes[0]==='Current'" if operation=='create' else "phoneState.notes[0]==='Backup'&&phoneState.messageStore===messageStore"
  t(label+' retry exact result',"return "+expect)
  call('Page.reload');time.sleep(.15)
  t(label+' reload exact',"return "+expect)
for bad in ['absent','malformed','no data']:
 ev("page='restorebackup';notice='';"+("localStorage.removeItem('c2-local-backup')" if bad=='absent' else "localStorage.setItem('c2-local-backup',"+json.dumps('{bad' if bad=='malformed' else '{}')+")")+";press('OK')")
 t(bad+' no false restore',"return notice==='No local backup found'")
print('PASS',len(checks))
