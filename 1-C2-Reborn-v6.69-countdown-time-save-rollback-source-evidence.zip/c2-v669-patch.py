from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.68-countdown-stop-rollback-candidate.html').read_text().replace('v6.68 handset parity','v6.69 handset parity').replace('C2 Reborn v6.68 |','C2 Reborn v6.69 |')
a="phoneState.timerValue=timerParts.join(':');persist();if(normalTimerChange){phoneState.timerEndsAt=Date.now()+secs*1000;persist();normalTimerSay('Timer running','organiser')}"
b="let beforeValue=phoneState.timerValue,beforeEnds=phoneState.timerEndsAt;phoneState.timerValue=timerParts.join(':');if(normalTimerChange)phoneState.timerEndsAt=Date.now()+secs*1000;try{persist()}catch(err){phoneState.timerValue=beforeValue;phoneState.timerEndsAt=beforeEnds;normalTimerSay('Unable to save timer');return true}if(normalTimerChange){normalTimerSay('Timer running','organiser')}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.69-countdown-time-save-rollback-candidate.html').write_text(s)
