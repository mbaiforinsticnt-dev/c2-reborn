exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.108-call-divert-mailbox-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
from pathlib import Path
src=Path('/downloads/C2-Reborn-v6.108-call-divert-mailbox-rollback-candidate.html').read_text();a=src.index('setInterval(()=>{let now=new Date()')+len('setInterval(');b=src.index('},1000);',a)+1;cb=src[a:b]
ev('window.expiryTick='+cb)
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for repeat in ['true','false']:
 ev('window.expiryTick='+cb)
 ev("phoneState=migrateState(null);phoneState.alarm.on=false;phoneState.timerValue='00:01:00';phoneState.countdownAutoRepeat="+repeat+";phoneState.timerEndsAt=Date.now()-100;page='organiser';persist();beforeEnd=phoneState.timerEndsAt;stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};notice='';expiryTick()")
 t(repeat+' exact deadline rollback',"return phoneState.timerEndsAt===beforeEnd&&localStorage.getItem('c2state')===stored")
 t(repeat+' no false finished/repeated',"return notice==='Unable to save timer'&&document.getElementById('screen').innerText.includes(notice)")
 if repeat=='true':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v671-countdown-expiry-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("expiryTick()")
 t(repeat+' repeated failure exact',"return phoneState.timerEndsAt===beforeEnd&&notice==='Unable to save timer'")
 ev("Storage.prototype.setItem=oldStore;expiryTick()")
 t(repeat+' retry succeeds',"return "+("phoneState.timerEndsAt>Date.now()&&notice==='Timer repeated'" if repeat=='true' else "phoneState.timerEndsAt===0&&notice==='Countdown finished'"))
 t(repeat+' persisted deadline matches',"return JSON.parse(localStorage.getItem('c2state')).timerEndsAt===phoneState.timerEndsAt")
 ev("savedEnd=phoneState.timerEndsAt;expiryTick()")
 t(repeat+' second tick no duplicate',"return phoneState.timerEndsAt===savedEnd")
 expectedEnd=ev('phoneState.timerEndsAt');call('Page.reload');time.sleep(.15)
 t(repeat+' reload exact',"return phoneState.timerEndsAt==="+str(expectedEnd))
print('PASS',len(checks))
