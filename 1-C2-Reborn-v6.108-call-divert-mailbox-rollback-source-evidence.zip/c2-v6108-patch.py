from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.107-call-divert-number-rollback-candidate.html').read_text().replace('v6.107 handset parity','v6.108 handset parity').replace('C2 Reborn v6.107 |','C2 Reborn v6.108 |')
a="phoneState.callDiverts[key]={active:true,number:'901'};persist();notice='Divert to voice mailbox active (901)';"
b="let beforeDiverts=phoneState.callDiverts;phoneState.callDiverts={...beforeDiverts,[key]:{active:true,number:'901'}};try{persist()}catch(err){phoneState.callDiverts=beforeDiverts;notice='Unable to save call divert';draw();return}notice='Divert to voice mailbox active (901)';"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.108-call-divert-mailbox-rollback-candidate.html').write_text(s)
