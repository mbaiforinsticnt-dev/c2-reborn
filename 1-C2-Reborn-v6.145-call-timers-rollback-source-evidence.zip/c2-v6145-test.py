exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.145-call-timers-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for absent in [False,True]:
 for key in ['OK','LSK']:
  ev("phoneState=migrateState(null);"+("delete phoneState.callTimerSecs;" if absent else "phoneState.callTimerSecs=[1,22,333,4444];")+"callTimerSecs=[1,22,333,4444];persist();before=JSON.stringify(phoneState);alias=callTimerSecs;storedAlias=phoneState.callTimerSecs;stored=localStorage.getItem('c2state');page='securitycode';sel=0;history=['callduration'];secReturn='callduration';secCode='12345';notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx=null;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
  label=f'{absent} {key}'
  t(label+' rollback',"return JSON.stringify(phoneState)===before&&callTimerSecs===alias&&phoneState.callTimerSecs===storedAlias&&localStorage.getItem('c2state')===stored")
  t(label+' context',"return page==='securitycode'&&secCode==='12345'&&notice==='Unable to clear call timers'")
  if absent and key=='OK':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6145-timers-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
  t(label+' retry',"return callTimerSecs.every(x=>x===0)&&phoneState.callTimerSecs.every(x=>x===0)&&page==='callduration'&&secCode===''")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState.callTimerSecs.every(x=>x===0)")
print('PASS',len(checks))
