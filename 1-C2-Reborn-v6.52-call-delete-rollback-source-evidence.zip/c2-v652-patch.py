from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.51-message-delete-rollback-candidate.html').read_text().replace('v6.51 handset parity','v6.52 handset parity').replace('C2 Reborn v6.51 |','C2 Reborn v6.52 |')
a="if(callDeletePending){let p=callDeletePending;callDeletePending=null;if(k==='LSK'||k==='OK'){let a=phoneState.calls[p.list],i=a.indexOf(p.record);if(i>=0){a.splice(i,1);sel=Math.max(0,Math.min(sel,selectableRows(page).length-1));persist();notice='Call deleted'}}draw();return}"
b="if(callDeletePending){let p=callDeletePending;callDeletePending=null;if(k==='LSK'||k==='OK'){let a=phoneState.calls[p.list],i=a.indexOf(p.record);if(i>=0){let beforeCalls=a.slice(),beforeSel=sel;a.splice(i,1);sel=Math.max(0,Math.min(sel,selectableRows(page).length-1));try{persist()}catch(err){phoneState.calls[p.list]=beforeCalls;sel=beforeSel;callDeletePending=p;notice='Unable to delete call';draw();return}notice='Call deleted'}}draw();return}"
assert s.count(a)==1;s=s.replace(a,b)
a='if(callDeletePending){s.insertAdjacentHTML';b='if(callDeletePending&&!notice){s.insertAdjacentHTML';assert s.count(a)==1;s=s.replace(a,b)
a='Unable to delete message|Folder memory full|';b='Unable to delete message|Unable to delete call|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.52-call-delete-rollback-candidate.html').write_text(s)
