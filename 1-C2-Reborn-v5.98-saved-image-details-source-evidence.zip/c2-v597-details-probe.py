exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.97-gallery-byte-sizes-candidate.html'))
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'DetailProbe'};draw();press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
ev("galEditor=null;page='galfolder';galFolderName='Images';sel=galFolderFiles().findIndex(f=>f.n==='DetailProbe.gif');open=true;os=currentOptions().indexOf('Details');draw();press('OK')")
print(ev("JSON.stringify({page,text:document.getElementById('screen').innerText})"))
