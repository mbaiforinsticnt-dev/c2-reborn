from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.97-gallery-byte-sizes-candidate.html').read_text().replace('v5.97 handset parity','v5.98 handset parity').replace('C2 Reborn v5.97 |','C2 Reborn v5.98 |')
s=s.replace("galDetailName='',galDetailSize='',", "galDetailName='',galDetailSize='',galDetailEdited=null,")
s=s.replace("galDetailFile=!!_f.n&&!_f.folderRow;", "galDetailFile=!!_f.n&&!_f.folderRow;galDetailEdited=galEditedDetail(_f);")
s=s.replace("galDetailFile=!f.folderRow;", "galDetailFile=!f.folderRow;galDetailEdited=galEditedDetail(f);")
s=s.replace("galDetailFile=false;galDetailSize=", "galDetailFile=false;galDetailEdited=null;galDetailSize=")
a="(galDetailFile?'<b>Format:</b><b>JPG</b><b>Resolution:</b><b>1600 x 1200</b><b>Copyright:</b><b>None</b>':'')"
b="(galDetailFile?(galDetailEdited?'<b>Format:</b><b>GIF</b>'+(galDetailEdited.resolution?'<b>Resolution:</b><b>'+esc(galDetailEdited.resolution)+'</b>':''):'<b>Format:</b><b>JPG</b><b>Resolution:</b><b>1600 x 1200</b><b>Copyright:</b><b>None</b>'):'')"
assert s.count(a)==1;s=s.replace(a,b)
a="function galSizeBytes(s)"
b="""function galEditedDetail(f){if(!/^data:image\\/gif;base64,/.test(f?.big||f?.src||''))return null;let detail={resolution:''},im=new Image();im.onload=()=>{if(galDetailEdited===detail&&page==='galfolderdetails'&&im.naturalWidth&&im.naturalHeight){detail.resolution=im.naturalWidth+' x '+im.naturalHeight;draw()}};im.src=f.big||f.src;return detail}
function galSizeBytes(s)"""
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v5.98-saved-image-details-candidate.html').write_text(s)
