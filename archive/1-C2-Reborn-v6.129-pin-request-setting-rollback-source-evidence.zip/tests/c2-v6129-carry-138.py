exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.129-pin-request-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for absent in [False,True]:
 for idx in range(12):
  ev("phoneState=migrateState(null);"+("delete phoneState.dispVals;" if absent else "phoneState.dispVals=pickerDefaults('display');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.dispVals;stored=localStorage.getItem('c2state');page='photosgrid';sel="+str(idx)+";open=false;history=['wallpaperlist'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=f'{absent} {idx}'
  t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.dispVals===beforeVals&&localStorage.getItem('c2state')===stored")
  t(label+' context',"return page==='photosgrid'&&sel==="+str(idx)+"&&notice==='Unable to save wallpaper setting'&&document.getElementById('screen').innerText.includes(notice)&&history.length===1")
  if not absent and idx==3:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6114-photo-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("press('OK');press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before&&notice==='Unable to save wallpaper setting'")
  ev("Storage.prototype.setItem=oldStore;press('OK');press('OK')")
  t(label+' retry',"return phoneState.dispVals[0]==='Photos'&&page==='display'")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState.dispVals[0]==='Photos'")
print('PASS',len(checks))
