exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.129-pin-request-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for filt in ['', 'marked','unmarked']:
 for hidden in [False,True]:
  ev("phoneState=migrateState(null);messageStore=seedMessageStore();phoneState.messageStore=messageStore;messageStore.marked=['alex'];messageStore.markFilter="+json.dumps(filt)+";messageStore.hidden="+('[1,3]' if hidden else '[]')+";persist();before=JSON.stringify(messageStore);beforeMarks=messageStore.marked;stored=localStorage.getItem('c2state');wanted=visibleRows().map(rowKey);page='conversations';sel=visibleRows()[0];open=true;os=currentOptions().indexOf('Mark all');idx=os;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=filt+str(hidden)
  t(label+' rollback',"return JSON.stringify(messageStore)===before&&messageStore.marked===beforeMarks&&localStorage.getItem('c2state')===stored")
  t(label+' context',"return page==='conversations'&&open&&os===idx&&notice==='Unable to save conversation marks'&&document.getElementById('screen').innerText.includes(notice)")
  if not filt and not hidden:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6118-directmark-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("press('OK');press('OK')")
  t(label+' repeat failure',"return JSON.stringify(messageStore)===before&&open")
  ev("Storage.prototype.setItem=oldStore;press('OK');press('OK')")
  t(label+' retry',"return JSON.stringify(messageStore.marked)===JSON.stringify(wanted)&&!open")
  saved=ev('JSON.stringify(messageStore.marked)');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(messageStore.marked)==="+json.dumps(saved))
print('PASS',len(checks))
