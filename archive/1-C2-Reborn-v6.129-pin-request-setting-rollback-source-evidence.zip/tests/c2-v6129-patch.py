from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.128-phone-settings-rollback-candidate.html').read_text().replace('v6.128 handset parity','v6.129 handset parity').replace('C2 Reborn v6.128 |','C2 Reborn v6.129 |')
repls=[("if(p==='security'){if(!phoneState.secVals)phoneState.secVals=pickerDefaults(p);phoneState.secVals[i]=v;persist();return}", "if(p==='security'){let had=Object.prototype.hasOwnProperty.call(phoneState,'secVals'),before=phoneState.secVals;phoneState.secVals=(before||pickerDefaults(p)).slice();phoneState.secVals[i]=v;try{persist()}catch(err){if(had)phoneState.secVals=before;else delete phoneState.secVals;notice='Unable to save PIN request setting';return false}return true}"), ("if(_rp==='security'&&radioCtx.row===0){let _cv=_rv;pickerCommit('security',0,_cv);persist();radioCtx=null;back();notice='PIN code request<br>'+_cv.toLowerCase();draw();return}", "if(_rp==='security'&&radioCtx.row===0){let _cv=_rv;if(pickerCommit('security',0,_cv)===false){draw();return}radioCtx=null;back();notice='PIN code request<br>'+_cv.toLowerCase();draw();return}")]
for a,b in repls:
 assert s.count(a)==1
 s=s.replace(a,b)
s=s.replace('Unable to save phone setting|Folder memory full','Unable to save phone setting|Unable to save PIN request setting|Folder memory full');Path('/downloads/C2-Reborn-v6.129-pin-request-setting-rollback-candidate.html').write_text(s)
