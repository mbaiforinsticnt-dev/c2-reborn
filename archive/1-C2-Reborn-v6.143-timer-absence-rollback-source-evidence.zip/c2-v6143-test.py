exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.143-timer-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['new','change','start']:
 for absentValue in [False,True]:
  for absentEnds in [False,True]:
   ev("phoneState=migrateState(null);"+("delete phoneState.timerValue;" if absentValue else "phoneState.timerValue='00:05:00';")+("delete phoneState.timerEndsAt;" if absentEnds else "phoneState.timerEndsAt=0;")+"persist();before=JSON.stringify(phoneState);hadV=Object.prototype.hasOwnProperty.call(phoneState,'timerValue');hadE=Object.prototype.hasOwnProperty.call(phoneState,'timerEndsAt');stored=localStorage.getItem('c2state');page="+json.dumps('timernote' if route=='start' else 'normaltimer')+";sel=0;history=['countdown'];notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx=null;normalTimerFlash='';normalTimerChange="+json.dumps(route=='change')+";timerParts=['01','02','03'];timerField=1;timerNote='Keep';timerCursor=2;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
   label=f'{route} {absentValue} {absentEnds}'
   t(label+' rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'timerValue')===hadV&&Object.prototype.hasOwnProperty.call(phoneState,'timerEndsAt')===hadE&&localStorage.getItem('c2state')===stored")
   t(label+' context',"return page==="+json.dumps('timernote' if route=='start' else 'normaltimer')+"&&normalTimerFlash==='Unable to save timer'&&timerNote==='Keep'&&timerCursor===2")
   if route=='new' and absentValue and absentEnds:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6143-timer-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("Storage.prototype.setItem=oldStore;normalTimerFlash='';if(normalTimerFlashTimer)clearTimeout(normalTimerFlashTimer);press('OK')")
   t(label+' retry',"return phoneState.timerValue==='01:02:03'"+("&&phoneState.timerEndsAt>Date.now()" if route!='new' else ""))
   call('Page.reload');time.sleep(.15)
   t(label+' reload',"return phoneState.timerValue==='01:02:03'")
print('PASS',len(checks))
