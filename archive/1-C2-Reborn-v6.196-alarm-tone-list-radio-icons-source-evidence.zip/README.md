C2 Reborn v6.196 (base v6.195). Focused script r117: python3 r117.py index.html.
From Moti's handset photo of Alarm clock > Alarm tone (4 Oct 22:48): title "Alarm tone" with a counter at the top right, rows Standard and Radio with radio buttons (chosen one filled), Open Gallery and Tone downloads with row icons, softkeys Select | Back.
- The emulator list now has the counter, radio buttons and the two icons. Choosing Standard/Radio still saves the tone; Open Gallery and Tone downloads still say not implemented.
- Caveat: Open Gallery uses the yellow folder icon already used in the profile tone chooser; the handset photo's icon looks like a grey striped gallery icon (no clean file).
Not changed (no evidence): alarm popup layout, which tone file "Standard" plays, calendar day-list order, Clear log confirm, hold timer, Missed/Received/All calls option lists.
