exec(open("/tmp/hdr.py").read())
import base64
fresh2();ev("go('alarmclock')");S('DOWN','DOWN','DOWN','DOWN') if False else None
print(ev("typeof alarmInit"),ev("page"))
ev("alarmInit();alarmMode='tones';alarmPick=0;draw()")
print(ev(T))
print('rows',ev("document.querySelectorAll('.shortcutRow').length"),'radio imgs',ev("[...document.querySelectorAll('.shortcutRow img')].map(i=>i.src.slice(0,30)).join(' ')"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/alarmtone.png','wb').write(base64.b64decode(r['result']['data']))
S('DOWN');print('sel',ev('alarmPick'),ev("document.querySelector('.shortcutRow.sel').innerText"))
S('DOWN');S('DOWN');print('3',ev('alarmPick'));S('DOWN');print('wrap',ev('alarmPick'))
ev("alarmPick=1");S('OK');print('after pick Radio',ev("alarmDraft.tone"),ev("alarmMode"))
