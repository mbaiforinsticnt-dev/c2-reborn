exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.79-alarm-days-candidate.html'))
checks=[
('six plain rows without icons',"phoneState=migrateState(null);phoneState.contacts=Array.from({length:9},(_,i)=>({name:'Alpha '+i,number:String(i),store:'Phone'}));namesClearSearch();page='names';sel=0;open=false;notice='';helpText=null;history=[{page:'home',sel:0}];pickerCommit('contactsettings',1,'Name list');draw();return document.querySelectorAll('.namesRow').length===6&&!document.querySelector('.namesRow img')&&sr.textContent==='Exit'"),
('four name-number rows',"pickerCommit('contactsettings',1,'Name and number');draw();return document.querySelectorAll('.namesRow').length===4&&document.querySelectorAll('.namesNumber').length===4&&document.querySelector('.namesNumber').textContent==='0'"),
('four image rows firmware placeholder',"pickerCommit('contactsettings',1,'Name and image');draw();return document.querySelectorAll('.namesImage').length===4&&document.querySelector('.namesImage').src===ICONNAMESPERSON"),
('known gallery image and arbitrary URL ignored',"phoneState.contacts[0].image='Photo0001.jpg';phoneState.contacts[1].image='https://bad.invalid/photo';draw();return document.querySelectorAll('.namesImage')[0].src===GAL_FILES.Images[0].src&&document.querySelectorAll('.namesImage')[1].src===ICONNAMESPERSON"),
('contact-menu Back label',"history=[{page:'contacts',sel:0}];draw();return sr.textContent==='Back'"),
('Search same Names and no history push',"press('LSK');os=currentOptions().indexOf('Search');let n=history.length;press('OK');return page==='names'&&namesSearchVisible&&history.length===n&&document.querySelector('.namesSearch')&&document.querySelector('#statusMode').textContent==='ABC'"),
('search no match View all',"namesQuery='ZZ';draw();return document.querySelector('.namesNoMatch').textContent==='(no matches)'&&sl.textContent===''&&sm.textContent==='View all'&&sr.textContent==='Clear'"),
('View all restores records',"press('OK');return !namesQuery&&!namesSearchVisible&&namesContacts().length===9"),
('direct letter from no visible field',"press('2');return namesQuery==='A'&&namesSearchVisible&&namesContacts().length===9"),
('multitap cycle B no matches',"press('2');return namesQuery==='B'&&namesContacts().length===0&&sm.textContent==='View all'"),
('Clear letter then close empty field',"press('RSK');let empty=namesQuery===''&&namesSearchVisible;press('RSK');return empty&&page==='names'&&!namesSearchVisible"),
('starts-with only and selected identity',"phoneState.contacts=[{name:'Not Alpha',number:'1'},{name:'Alpha SIM',number:'2',store:'SIM'},{name:'Alpha Phone',number:'3',store:'Phone'}];pickerCommit('contactsettings',0,'Phone');press('2');return namesContacts().length===1&&namesRecord()===phoneState.contacts[2]"),
('Details correct filtered identity',"press('OK');return page==='contact'&&contactIndex===2"),
('Details Back retains query',"press('RSK');return page==='names'&&namesQuery==='A'&&namesRecord()===phoneState.contacts[2]"),
('search text escaped',"namesQuery='<script>';draw();return !document.querySelector('#screen script')&&document.querySelector('.namesSearch').textContent.includes('<script>')"),
('contact memory route',"namesClearSearch();page='contactsettings';sel=4;open=false;notice='';pickerDraft=null;draw();press('OK');return page==='contactmemory'&&document.querySelector('#screen').textContent.includes('SIM card')"),
('Phone contact usage synthetic values',"press('OK');return page==='contactphoneusage'&&document.querySelector('.cmBar')&&document.querySelector('#screen').textContent.includes('63% free')&&sr.textContent==='Back'&&sm.textContent===''"),
('SIM selection and synthetic 250 sum',"press('RSK');press('DOWN');press('OK');return page==='contactsimusage'&&document.querySelector('#screen').textContent.includes('238')&&document.querySelector('#screen').textContent.includes('12')&&CONTACT_MEMORY_DEMO.simSlots===250"),
('SIM Back preserves picker row',"press('RSK');return page==='contactmemory'&&sel===1"),
('memory picker Back returns settings row4',"press('RSK');return page==='contactsettings'&&sel===4"),
('unrelated storage untouched',"page='memorystatus';sel=0;draw();return document.querySelector('#screen').textContent.includes('43.5 MB')&&document.querySelector('#screen').textContent.includes('28.0 GB')"),
('empty contacts no-match absent until query',"phoneState.contacts=[];page='names';sel=0;namesClearSearch();draw();return !document.querySelector('.namesNoMatch')&&sm.textContent===''"),
('no shared recipient query mutation',"rcptQuery='recipient';press('2');return rcptQuery==='recipient'&&namesQuery==='A'"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
import base64
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for tag,e in [('name-list',"phoneState=migrateState(null);phoneState.contacts=Array.from({length:9},(_,i)=>({name:['Alex Morgan','Baker','Charlie','David','Emma','Frank','George','Henry','Iris'][i],number:'020 7946 00'+i,store:'Phone'}));namesClearSearch();page='names';sel=0;open=false;notice='';history=[{page:'home',sel:0}];pickerCommit('contactsettings',0,'Phone');pickerCommit('contactsettings',1,'Name list');draw()"),('name-number',"pickerCommit('contactsettings',1,'Name and number');draw()"),('name-image',"pickerCommit('contactsettings',1,'Name and image');draw()"),('search-no-match',"namesQuery='ZZ';namesShowSearch();draw()"),('phone-memory',"page='contactphoneusage';draw()"),('sim-memory',"page='contactsimusage';draw()")]:
 ev(e);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v575-contacts-'+tag+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
