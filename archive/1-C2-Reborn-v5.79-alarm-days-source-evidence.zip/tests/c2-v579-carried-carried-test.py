exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.79-alarm-days-candidate.html'))
checks=[
('idle menu',"phoneState=migrateState(null);page='countdown';sel=0;open=false;notice='';helpText=null;history=[{page:'organiser',sel:6}];draw();return document.querySelector('#screen').textContent.includes('Normal timer')&&normalTimerMenu().length===3"),
('popup over menu zero hours selected',"press('OK');return page==='normaltimer'&&timerParts.join(':')==='00:00:00'&&timerField===0&&document.querySelector('.ntTimePopup')&&document.querySelector('.ntMenu').textContent.includes('Interval timer')&&document.querySelector('#statusMode').textContent==='123'"),
('minimum one second remains editor',"press('OK');return page==='normaltimer'&&normalTimerFlash==='Minimum time is 1 second'&&phoneState.timerEndsAt===0"),
('dismiss minimum preserves editing',"press('OK');return page==='normaltimer'&&!normalTimerFlash&&timerParts.join(':')==='00:00:00'"),
('two hours keypad entry',"press('2');return timerParts[0]==='02'"),
('note separate layout Abc',"press('OK');return page==='timernote'&&document.querySelector('.normalTimerNote').textContent.includes('Note for timer:')&&document.querySelector('#statusMode').textContent==='Abc'&&sm.textContent==='Start'&&sr.textContent==='Back'"),
('note letters and Clear',"press('2');return timerNote==='a'&&sr.textContent==='Clear'"),
('note options overlay reachable',"press('LSK');return open&&!!document.querySelector('.optionsPanel')"),
('close options and start notice',"press('RSK');let now=Date.now();press('OK');return normalTimerFlash==='Timer running'&&phoneState.timerEndsAt>=now+7199900&&phoneState.timerEndsAt<=now+7200100"),
('return selects Organiser timer row',"press('OK');return page==='organiser'&&screens[page][sel]==='Countd. timer'&&document.querySelector('.sel').textContent.includes('02:00')"),
('active menu Change Stop only',"press('OK');return page==='countdown'&&normalTimerMenu().join('|')==='Change time|Stop timer'&&document.querySelector('.ntMenu').textContent.includes('Change time')"),
('change remaining time',"phoneState.timerEndsAt=Date.now()+7194000;press('OK');return page==='normaltimer'&&normalTimerChange&&timerParts.join(':')==='01:59:54'"),
('cancel change leaves timer running',"let end=phoneState.timerEndsAt;press('RSK');return page==='countdown'&&phoneState.timerEndsAt===end"),
('change commits only on OK',"press('OK');timerParts=['00','00','10'];press('OK');return normalTimerFlash==='Timer running'&&phoneState.timerValue==='00:00:10'"),
('stop notice and Off',"press('OK');press('OK');press('DOWN');press('OK');let stopped=phoneState.timerEndsAt===0&&normalTimerFlash==='Timer stopped';press('OK');return stopped&&page==='organiser'&&document.querySelector('.sel').textContent.includes('Off')"),
('idle menu restores interval settings',"press('OK');return normalTimerMenu().length===3"),
('minimum one second valid',"press('OK');timerParts=['00','00','01'];press('OK');return page==='timernote'&&!normalTimerFlash"),
('zero bypass never starts',"timerParts=['00','00','00'];press('OK');return !phoneState.timerEndsAt&&page==='organiser'"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert bool(z) is True,(n,z)
print('PASS',len(checks))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
import base64
for tag,e in [('set-time',"page='countdown';sel=0;open=false;notice='';phoneState.timerEndsAt=0;normalTimerOpen()"),('minimum',"press('OK')"),('note',"press('OK');timerParts=['02','00','00'];press('OK')"),('running',"press('OK')"),('active-menu',"press('OK');press('OK')"),('stop',"sel=1;press('OK')")]:
 ev(e);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v575-'+tag+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
