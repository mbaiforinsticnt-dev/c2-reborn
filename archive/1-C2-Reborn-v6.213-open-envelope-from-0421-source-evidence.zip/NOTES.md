# Working notes (saved in repo after a workspace reset on 5 Oct 09:36)
Live builds: v6.201 blob c08432ac5b0de5a32bbfa919586f7d474b3dcc1a (run #46, archive 5a77f244). v6.202 follows this note.
Test harness: tests/hdr.py (CDP over websocket, run `bash chrome.sh` first, then `python3 rNN.py <file.html>`), crawlers a3-a7. The old 178-test regression sweep (cf-N.py) was lost in the reset and has NOT been rebuilt.
Open items: arrows on list-opening rows (Moti: follow the emulator; emulator install lost too, needs re-supplying), Black/Dark contrast: Black done (no list-row faults), Dark not crawled; Tab leads unchecked: Calendar day selection contrast Black/Dark, Keypad tones silent, unsorted new contacts, editor submenu Back collapses levels, Equaliser outline-only focus, Calendar editor last field clipped; Tab leads not reproduced: Call on highlighted contact opens empty dialler, Writing language popup off screen.
Rules: Moti's 4 rules (full-row focus, list wrap, Options sized to whole rows, expandable-row arrow). Arrow art: Moti's Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead), author not recorded.
Publishing: atomic Actions workflow 4-publish-index.yml (zip_path archive/1-<name>.zip, member index.html, new_blob, base_blob). Banked zip must byte-match a raw download pinned to the commit.

## v6.203 (2026-10-05)
- Saved-notice tick (listIcons.CHECK) replaced by a CROP of Moti's emulator screenshot (image-4fd8f09f), 56x56. Crop, not an original firmware file (Moti permission 10:15). Unicode check glyphs replaced by the same image.
- Go to profile icons and plain Settings > Profiles already match his screenshots (no change).
Base blob: c531b2156eba4434e3c2463fa0772a9edc0816b7

## v6.204 (2026-10-05)
- Memory card Options per handset video (frames in source-evidence/sheet0-5.png). Seen in footage: Set password -> Enter new password (numeric, masked, last digit shown, max 8, Options/OK/Clear) -> Verify new password -> "Password set" note; Delete password -> "Memory card will be unlocked. Continue?" Yes/No -> "Enter memory card password:" -> "Password deleted" note.
- NOT in footage (inferred): Change password flow (old, new, verify), wrong-password and mismatch messages, Rename/Format dialogs, minimum password length.
- Hold # popup: from emulator screenshot only; hold time is the existing 700 ms (Moti guessed about 0.5 s); Number mode sets 123, Writing language opens the existing page, Paste always dim (inferred).
- Paste is enabled only when the clipboard has content (Moti 10:31); selecting it in the Gallery list does nothing (no target; inferred).

## v6.205 (2026-10-05)
- Memory card row icon replaced by crop from Moti C2 photo (new listIcons.MEMCARD, 30x30, white background removed). Used in Gallery list, Gallery search, move/copy target and editor picker. 0534 (Gallery app icon) untouched.

## v6.206 (2026-10-05)
- Inbox (single messages) rows: Unicode envelope glyphs replaced by images. Unread = made closed envelope (Moti 10:46 instruction), read = VIEW_ICON_READ. CSS filter none so the Nokia selected-row invert does not recolour it.
- Conversation bubbles and Conversations list unchanged (they already use image icons).
- Memory card icon (Gallery list) REPLACED: v6.205 used a zoom of the HTML own old icon by mistake; now a 30x30 crop of Moti emulator screenshot (notch top-left, contacts left), image-821ba14f (10:53). Crop, not a firmware file. Original-file extraction from SDK package_c.bin attempted separately.

## v6.207 (2026-10-05)
- Conversation view: selected bubble scrolls fully above the softkeys (keepConvSelVisible, 34px end spacer). Tested 4 viewports x 2 themes.
- Open message view and Inbox read view: UP/DOWN scroll long text (did not scroll before).
- Sent bubble icon = crop of Moti emulator zoom (envelope + green tick bottom-right), image-e18b983a. Old one came from the HTML own VIEW_ICON_SENT (green square overlay), not a firmware file. Crop, not firmware file.
- Received bubbles in conversation view: unread/received = made closed envelope (same as Inbox), read = firmware open envelope. Nokia invert filter off for these icons.

## v6.208
- Closed (0421), open (0758), sent (0603), memory card (0533) are ORIGINAL firmware files now (from package_c.ppm). Made envelope and the two crops kept in source-evidence as rollback.
- Open envelope variant 0758 is my pick (0760/0995/0960 look the same at 30px); Moti has not picked.

## v6.209
- Contact Back-after-save fix (history dropped the add-contact form; cfVal guard). Reproduced from the external c2-audit-harness (untrusted, verify.py re-implemented), banked in source-evidence/c2-audit-harness.
- ?calc= URL param restricted to digits/operators.
- Calculator 7/0: note "Cannot divide by zero" with firmware 1053 info icon (Moti handset photo 11:28). Display keeps 7.
- Tick = firmware 1062 (replaces crop).
- Not done: Add detail empty list, 7/0 only, dark crawl, emulator.

## v6.210
- Contact details > Options > Add detail now opens the Add detail tree (Number/Internet/Multimedia/Personal info) from Moti's 11:33 handset photos; leaves reuse the Edit-contact add-field flow (opens Edit contact with the new field). Number list from contact details = General, Mobile, Home, Work, Fax (5, per photo); the Edit-contact form keeps its own 7-item list.
- Notes (.alarmDialog) are dark with white bold text in Black, Dark and Legacy Black themes.
- Inferred, not footage: after choosing a leaf the field opens in the Edit contact form; Back from the submenu root returns to the form (handset behaviour unknown).

## v6.211
- Memory card icon: Moti's emulator icon (11:40) = firmware 0533 (diff 2.2 only from JPEG artefacts). Already used as MEMCARD. The Gallery picker row "32" used GPcard = firmware 0720 (a SIM card with yellow contacts); now 0533. No other SD-card uses found (sync icons 0908/0909, 1080 are different pictures).

## v6.212
- Messaging menu Conversations row: firmware 0955 unchanged but drawn 22% larger (CSS scale) and 12% brighter (CSS filter) per Moti 11:46. Adjustment only: the PNG is the untouched firmware file. Rollback = remove the style attribute (v6.211).

## v6.213
- Open envelope (VIEW_ICON_READ) is MADE, not firmware: Moti rejected the 30x30 firmware open envelopes (0758/0760/0995/0960: dark flap, black pixel outline). Built from firmware closed envelope 0421 (V cut for the front pocket, 0421's own triangle flipped as the raised flap). Script: source-evidence/open-envelope/mkopen.py. Rollback: firmware 0758 (v6.212).
