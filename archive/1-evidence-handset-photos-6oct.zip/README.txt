Handset photos supplied by Moti (6 Oct 2026, 13:38-14:19) for the missed-call and new-message popups and Options screens.
Source for layout. Not part of the site. The photo showing the handset's real phone number is deliberately left out.
