from pathlib import Path
import re,subprocess
logs=[];total=0;fail=[]
fs=list(Path('/tmp').glob('reg573*test.py'))+[Path('/tmp/c2-v572-test.py'),Path('/tmp/c2-v573-test.py')]
for i,p in enumerate(fs):
 t=p.read_text();t=re.sub(r'file:///downloads/[^\x27\x22]+\.html','file:///downloads/C2-Reborn-v5.75-normal-timer-candidate.html',t)
 q=Path('/tmp/reg575-'+str(i)+'.py');q.write_text(t);r=subprocess.run(['python3',str(q)],capture_output=True,text=True);logs.append(p.name+'\n'+r.stdout+r.stderr)
 if r.returncode:fail.append(p.name)
 else:total+=sum(int(n) for n in re.findall(r'PASS (\d+)',r.stdout))
Path('/tmp/c2-v575-regression.log').write_text('\n'.join(logs));print('FILES',len(fs),'PASS CHECKS',total,'FAILED',fail)
