from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.02-folder-copy-rollback-candidate.html').read_text().replace('v6.02 handset parity','v6.03 handset parity').replace('C2 Reborn v6.02 |','C2 Reborn v6.03 |')
a="phoneState.galFolderParents[source]=dest;persist();return {key:source}"
b="let hadParent=Object.prototype.hasOwnProperty.call(phoneState.galFolderParents,source),oldParent=phoneState.galFolderParents[source];phoneState.galFolderParents[source]=dest;try{persist()}catch(err){if(hadParent)phoneState.galFolderParents[source]=oldParent;else delete phoneState.galFolderParents[source];return {error:'Unable to save moved folder'}}return {key:source}"
assert s.count(a)==1;s=s.replace(a,b).replace('Fax not activated|Unable to save copied folder','Fax not activated|Unable to save copied folder|Unable to save moved folder',1)
Path('/downloads/C2-Reborn-v6.03-folder-move-rollback-candidate.html').write_text(s)
