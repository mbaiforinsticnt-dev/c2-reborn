import os,json
F='c2-v6165-cand.html'
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';draw()})()")
S="(()=>document.querySelector('.lcd').innerText.replace(/\\n/g,'|').slice(-70))()"
tests={'dial':"go('dial');dial='';draw()",'newnumber':"newNum='';go('newnumber');sel=0;draw()",
'addcontact':"cfReset();contactNumber='';contactField=1;editingContact=false;go('addcontact');draw()",
'editnumber':"udDialog='editnumber';udEdit='';udCur=0;page='usedetailnumber';draw()",
'keyguardduration':"keyguardDraft='';go('keyguardduration');draw()"}
for n,js in tests.items():
 fresh()
 try:
  ev("(()=>{"+js+"})()");ev("press('5');0;press('5');0;press('5');0");print(n,ev("page"),ev(S))
 except Exception as e:print(n,'ERR',e)
print('--- hold tests')
holds={'dial':("go('dial');dial='';draw()","dial"),'newnumber':("newNum='';go('newnumber');sel=0;draw()","newNum"),'addcontact':("cfReset();contactNumber='';contactField=1;editingContact=false;go('addcontact');draw()","contactNumber"),'editnumber':("udDialog='editnumber';udEdit='';udCur=0;page='usedetailnumber';draw()","udEdit"),'keyguard':("keyguardDraft='';go('keyguardduration');draw()","keyguardDraft")}
for n,(js,var) in holds.items():
 fresh();ev("(()=>{"+js+"})()");ev("press('5');0;press('7');0;press('2');0")
 ev("press('RSK');0");short=ev(var)
 ev("pressStart('RSK');0");time.sleep(1.6);ev("pressEnd('RSK');0");print(n,'after short:',repr(short),'after hold:',repr(ev(var)),ev("page"))
