import os,datetime
F=os.environ.get('C2F','c2-v6163-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v)
T="(()=>JSON.stringify({page,sel,H:ptH,M:ptM,f:ptField,t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|')}))()"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('profiles');sel=0;draw()})()")
def timed(row=1):
 fresh();ev("press('DOWN');0;" *row+"press('OK');0;press('DOWN');0;press('DOWN');0;press('OK');0")
import json
timed();r=ev(T);print(r);j=json.loads(r)
now=datetime.datetime.now()
t('popup Profile expires + HH:MM',all(x in j['t'] for x in ['Profile expires:','HH:MM','Silent']) and 'OK|Back' in j['t'])
t('prefilled current time, hour focused',abs((j['H']*60+j['M'])-(now.hour*60+now.minute))<=1 and j['f']==0)
ev("press('1');0;press('1');0");j=json.loads(ev(T));t('two digits -> hour 11, minutes focused',j['H']==11 and j['f']==1)
ev("press('2');0;press('8');0");j=json.loads(ev(T));t('minutes 28, focus returns to hour',j['M']==28 and j['H']==11 and j['f']==0)
ev("press('UP');0");j=json.loads(ev(T));t('up steps hour 12',j['H']==12 and j['f']==0)
ev("press('1');0");t('first digit shows single digit',"|1:28|" in ev(T) or "1:28" in ev(T) and "01:28" not in ev(T))
ev("press('0');0");ev("ptH=12;ptM=28;ptField=0;ptTyped=0;draw()")
ev("press('DOWN');0;press('DOWN');0");j=json.loads(ev(T));t('down x2 -> 10',j['H']==10)
ev("press('RIGHT');0;press('UP');0");j=json.loads(ev(T));t('right up minutes 29',j['M']==29 and j['f']==1)
ev("ptH=23;ptField=0;press('UP');0");t('hour wraps 23->0',json.loads(ev(T))['H']==0)
ev("ptField=0;press('9');0;press('9');0");t('hour clamps to 23',json.loads(ev(T))['H']==23)
tt=now+datetime.timedelta(minutes=3)
timed();ev("ptH=%d;ptM=%d;press('OK');0"%(tt.hour,tt.minute));t('OK sets timed and reverts target',ev("phoneState.profile")=='Silent' and ev("phoneState.timedProfilePrev")=='General' and 0<ev("phoneState.timedProfile.until-Date.now()")<=240000)
ev("phoneState.timedProfile.until=Date.now()-1000;draw()");t('expiry rolls back',ev("phoneState.profile")=='General' and ev("phoneState.timedProfile")is None)
timed();ev("press('RSK');0");t('Back returns to profile page',ev("page")=='profileopts')
timed();ev("ptH=%d;ptM=%d;press('OK');0"%(now.hour,now.minute));t('prefilled-as-is OK expires within a minute',0<ev("phoneState.timedProfile.until-Date.now()")<=61000)
timed();p=(now-datetime.timedelta(minutes=10));ev("ptH=%d;ptM=%d;press('OK');0"%(p.hour,p.minute));t('past time = tomorrow',ev("phoneState.timedProfile.until-Date.now()")>20*3600000)
timed();ev("press('OK');0");
# Options>Change>Back must return to a clean form, every row type, every profile
bad=[]
for prof in range(5):
 for row in [0,1,3,4,5,6,7,8,10,11,12]:
  fresh();ev("profileTonesFor=%d;go('profiletones');sel=%d;draw();press('LSK');0;press('OK');0"%(prof,row))
  if ev("page")!='radiolist':bad.append((prof,row,'noradio'));continue
  ev("press('RSK');0");r=json.loads(ev(T))
  if ev("page")!='profiletones' or ev("open") or ev("document.querySelectorAll('.lcd .overlay').length") or 'Change|Play|Save' in r['t']:bad.append((prof,row))
t('Options>Change>Back clean for 5 profiles x 11 rows',not bad);print(bad[:5])
fresh();ev("profileTonesFor=0;go('profiletones');sel=1;draw();press('LSK');0;press('OK');0;press('OK');0");t('OK on chooser keeps working and form clean',ev("page")=='profiletones' and not ev("open"))
bad=[]
n=ev("screens.profiles.length")
for prof in range(n):
 for row in range(15):
  fresh();ev("profileTonesFor=%d;go('profiletones');sel=%d;draw()"%(prof,row))
  before=ev("JSON.stringify(profileToneStore(screens.profiles[profileTonesFor]))");ev("press('OK');0");r=ev(T)
  after=ev("JSON.stringify(profileToneStore(screens.profiles[profileTonesFor]))")
  if not(ev("page")=='profiletones' and 'Saved to profile' in r and before==after and not ev("nameEditing")):bad.append((prof,row,ev("page")))
t('OK = Save on all 15 rows x %d profiles, no chooser, values unchanged'%n,not bad);print(bad[:6])
for row in [0,1,7]:
 fresh();ev("profileTonesFor=0;go('profiletones');sel=%d;draw();press('LSK');0;press('OK');0"%row);t('Options>Change still opens chooser row %d'%row,ev("page")=='radiolist')
for row in [2,9]:
 fresh();ev("profileTonesFor=0;go('profiletones');sel=%d;draw()"%row);b=ev("profileToneStore(screens.profiles[profileTonesFor]).%s"%PROFILE_ROWS_KEY[row]) if False else None
fresh();ev("profileTonesFor=0;go('profiletones');sel=14;draw();press('LSK');0;press('OK');0");t('Options>Change on Profile name starts editing',ev("nameEditing")is True)
fresh();ev("go('tones');sel=1;draw();press('OK');0");t('Settings>Tones OK saves too',ev("page")=='tones' and 'Saved' in ev(T))
print('checks',len(res),'pass',sum(1 for v in res if v is True))
