import os,json
F=os.environ.get('C2F','c2-v6164-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v)
T="(()=>JSON.stringify({page,sel,t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|')}))()"
STUB="window.__p=[];window.Audio=function(u){this.src=u;this.pause=()=>{window.__stopped=(window.__stopped||0)+1};this.play=()=>{window.__p.push(decodeURIComponent(u.split('/').pop()));return Promise.resolve()}};0"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('profiles');sel=0;draw()})()");ev(STUB)
def form(prof=0,row=1):
 fresh();ev("profileTonesFor=%d;go('profiletones');sel=%d;draw()"%(prof,row))
def chooser(prof=0,row=1):
 form(prof,row);ev("press('LSK');0;press('OK');0")
chooser();r=ev(T);print(r)
t('chooser plays current tone on open',ev("__p")==['Nokia tune.mp3'])
ev("press('UP');0");t('moving to Open Gallery stops audio',ev("toneCur")=='' )
ev("press('OK');0");r=ev(T);print(r);t('Open Gallery -> Gallery list, cursor Tones, 57 files',ev("page")=='galpicker' and ev("sel")==2 and '57 files' in r)
ev("press('OK');0");r=ev(T);print(r);t('Tones -> Ringing 38 / Alert 19',ev("page")=='tonefolders' and '38 files' in r and '19 files' in r)
ev("press('OK');0");r=ev(T);print(r);t('Ringing tones list: files, date, size, counter',ev("page")=='tonefiles' and 'Alablaster.aac' in r and '01-01-12' in r and '148 kB' in r and 'Select|Back' in r)
t('auto-plays highlighted file',ev("__p")[-1]=='Alablaster.mp3')
ev("press('DOWN');0");t('Down plays next (Bespoke), size 20.0',ev("__p")[-1]=='Bespoke.mp3' and '20.0 kB' in ev(T))
ev("press('RSK');0");t('Back -> Tones folder, audio stopped',ev("page")=='tonefolders' and ev("toneCur")=='')
ev("press('DOWN');0;press('OK');0");r=ev(T);print(r);t('Alert tones list 19 w/ Calendar alert 1',ev("page")=='tonefiles' and 'Calendar alert 1.aac' in r)
ev("press('RSK');0;press('RSK');0");t('Back -> Gallery list',ev("page")=='galpicker')
ev("press('RSK');0");r=ev(T);print(r);t('Back -> chooser',ev("page")=='radiolist' and 'Open Gallery' in r)
# pick
ev("press('OK');0;press('OK');0;press('OK');0");ev("press('DOWN');0;press('DOWN');0;press('DOWN');0;press('OK');0")
r=ev(T);print(r,ev("profileToneStore(screens.profiles[profileTonesFor]).tone"))
t('Select stores Breeze/ 4th file and returns to form',ev("profileToneStore(screens.profiles[profileTonesFor]).tone")=='Breeze' and ev("page")=='profiletones' and ev("toneCur")=='')
# Options > Play
ev("sel=1;draw();press('LSK');0;press('DOWN');0;press('OK');0");t('Options>Play plays Breeze',ev("__p")[-1]=='Breeze.mp3')
# e-mail alert tone too
chooser(0,7);ev("press('UP');0;press('OK');0;press('OK');0;press('OK');0;press('OK');0");t('E-mail alert tone uses same gallery pick',ev("profileToneStore(screens.profiles[profileTonesFor]).emailtone")=='Alablaster')
# Settings tones
fresh();ev("go('tones');sel=1;draw();press('LSK');0;press('OK');0;press('UP');0;press('OK');0;press('OK');0;press('OK');0;press('OK');0");t('Settings>Tones pick works',ev("page")=='tones' and ev("phoneState.tones.tone")=='Alablaster')
# real decode of firmware aac in Chrome
fresh();ev("window.__d=null;(()=>{let a=new Audio('ground-up/assets/tones/Bespoke.aac');a.onloadedmetadata=()=>{window.__d=a.duration};a.onerror=()=>{window.__d='err'}})()") if False else None
print('checks',len(res),'pass',sum(1 for v in res if v is True))
