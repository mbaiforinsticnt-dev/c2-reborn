F='c2-v6165-cand.html'
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;cfReset();contactNumber='';contactField=1;editingContact=false;go('addcontact');draw()})()")
print(ev("typeof CF_KEYS!=='undefined'?JSON.stringify(CF_KEYS):''"))
for f in (0,1,2):
  ev("contactField=%d;draw();cfSet(contactField,'');0"%f);ev("press('5');0;press('7');0")
  a=ev("cfVal(contactField)");ev("press('RSK');0");b=ev("cfVal(contactField)")
  ev("pressStart('RSK');0");time.sleep(1.6);ev("pressEnd('RSK');0");c=ev("cfVal(contactField)")
  print(f,repr(a),repr(b),repr(c),ev("page"))
