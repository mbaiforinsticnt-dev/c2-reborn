import os,json
F=os.environ.get('C2F','c2-v6165-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(bool(v))
T="(()=>JSON.stringify({page,sel,v:typeof divertNumVal!=='undefined'?divertNumVal:'',t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|')}))()"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';divertScope='voice';divertName='All voice calls';go('divertdest');sel=1;draw()})()")
def num():
 fresh();ev("press('OK');0");
fresh();ev("press('OK');0");r=ev(T);print(r)
t('To other number -> Number entry, softkeys Options/Search/Back',ev("page")=='divertnum' and 'Options|Search|Back' in r)
ev("press('2');0;press('6');0;press('9');0;press('5');0");r=ev(T);print(r)
t('typed 2695: right softkey is Clear',ev("page")=='divertnum' and 'Options|Search|Clear' in r)
ev("press('RSK');0");t('Clear short press deletes one digit',ev("divertNumVal")=='269' and ev("page")=='divertnum')
ev("press('LEFT');0;press('RSK');0");t('Clear deletes digit before cursor',ev("divertNumVal")=='29')
ev("pressStart('RSK');0");time.sleep(1.6);ev("pressEnd('RSK');0");r=ev(T);print(r);t('Clear hold clears all, stays on page, Back label returns',ev("divertNumVal")=='' and ev("page")=='divertnum' and 'Options|Search|Back' in r)
ev("press('RSK');0");t('Back on empty leaves screen',ev("page")=='divertdest')
fresh();ev("press('OK');0;press('2');0;press('6');0;press('9');0;press('5');0;press('LSK');0");r=ev(T);print(r)
t('Options opens real list (not activate)',ev("open")==True and 'OK' in r and 'Search' in r and 'activated' not in r)
ev("press('OK');0");r=ev(T);print(r)
t('Options>OK with fake 2695 does not activate, says invalid',('activated' not in r) and 'Invalid' in r and ev("JSON.stringify(phoneState.callDiverts||{})")in('{}',) )
fresh();ev("press('OK');0;press('2');0;press('6');0;press('9');0;press('5');0;press('OK');0");r=ev(T);print(r)
t('Search (middle OK) opens Contacts, not activated',ev("page")=='divertpick' and 'activated' not in r and 'Contacts' in r)
ev("press('DOWN');0");nm=ev("divertPickList()[sel].number");ev("press('OK');0");r=ev(T);print(r)
t('Pick contact fills number, back at entry, still not activated',ev("page")=='divertnum' and ev("divertNumVal")==nm and 'activated' not in r)
ev("press('LSK');0;press('OK');0");r=ev(T);print(r);d=ev("JSON.stringify(phoneState.callDiverts)");print(d)
t('Options>OK with valid contact number activates',('activated' in r) and nm in d)
fresh();ev("press('OK');0;press('LSK');0;press('DOWN');0;press('OK');0");t('Options>Search opens Contacts',ev("page")=='divertpick')
ev("press('RSK');0");t('Back from Contacts returns to entry',ev("page")=='divertnum')
fresh();ev("press('OK');0;press('1');0;press('2');0;press('3');0;press('4');0;press('5');0;press('LSK');0;press('OK');0");t('5-digit number activates',ev("JSON.stringify(phoneState.callDiverts)").find('12345')>0)
fresh();ev("go('divertdest');sel=0;draw();press('OK');0");r=ev("JSON.stringify(phoneState.callDiverts)");t('To voice mailbox path unchanged (901)','901' in r if False else '901' in r)
print('checks',len(res),'pass',sum(res))
