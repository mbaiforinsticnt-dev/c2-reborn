from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.76-radio-search-stations-rollback-candidate.html').read_text().replace('v6.76 handset parity','v6.77 handset parity').replace('C2 Reborn v6.76 |','C2 Reborn v6.77 |')
a="if(page==='incall'&&!open&&(k==='UP'||k==='DOWN')){phoneState.callVolume=Math.max(0,Math.min(10,(phoneState.callVolume??6)+(k==='UP'?1:-1)));persist();notice='Volume '+phoneState.callVolume;draw();return}"
b="if(page==='incall'&&!open&&(k==='UP'||k==='DOWN')){let hadVolume=Object.prototype.hasOwnProperty.call(phoneState,'callVolume'),beforeVolume=phoneState.callVolume;phoneState.callVolume=Math.max(0,Math.min(10,(phoneState.callVolume??6)+(k==='UP'?1:-1)));try{persist()}catch(err){if(hadVolume)phoneState.callVolume=beforeVolume;else delete phoneState.callVolume;notice='Unable to save call volume';draw();return}notice='Volume '+phoneState.callVolume;draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save radio station|Folder memory full','Unable to save radio station|Unable to save call volume|Folder memory full')
Path('/downloads/C2-Reborn-v6.77-demo-call-volume-rollback-candidate.html').write_text(s)
