exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.77-demo-call-volume-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['held','running']:
 ev("phoneState=migrateState(null);callTimerSecs=[3,4,5,6];phoneState.callTimerSecs=callTimerSecs.slice();activeCall='+44 7700 900888';callHeld="+('true' if mode=='held' else 'false')+";callHeldAt=12;callStarted=Date.now()-12000;page='incall';callLoudspeaker=true;callMuted=true;persist();beforeTimer=callTimerSecs;beforeSaved=phoneState.callTimerSecs;stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('END')")
 t(mode+' rollback exact timer aliases',"return callTimerSecs===beforeTimer&&phoneState.callTimerSecs===beforeSaved&&JSON.stringify(callTimerSecs)==='[3,4,5,6]'&&localStorage.getItem('c2state')===stored")
 t(mode+' active call retained',"return activeCall==='+44 7700 900888'&&page==='incall'&&callLoudspeaker&&callMuted")
 t(mode+' warning visible',"return notice==='Unable to save demo call'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='held':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v667-demo-call-end-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("endCall()")
 t(mode+' repeat failure no double count',"return callTimerSecs===beforeTimer&&phoneState.callTimerSecs===beforeSaved&&JSON.stringify(callTimerSecs)==='[3,4,5,6]'")
 ev("Storage.prototype.setItem=oldStore;callHeld=true;callHeldAt=12;notice='';press('END')")
 t(mode+' retry applies once',"return activeCall===null&&page==='home'&&notice==='Call ended'&&JSON.stringify(callTimerSecs)==='[12,4,17,18]'")
 ev("endCall()")
 t(mode+' idle does not count twice',"return JSON.stringify(callTimerSecs)==='[12,4,17,18]'")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact totals',"return JSON.stringify(callTimerSecs)==='[12,4,17,18]'&&JSON.stringify(phoneState.callTimerSecs)==='[12,4,17,18]'")
print('PASS',len(checks))
