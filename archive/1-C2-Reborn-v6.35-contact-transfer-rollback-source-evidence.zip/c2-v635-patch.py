from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.34-contact-delete-rollback-candidate.html').read_text().replace('v6.34 handset parity','v6.35 handset parity').replace('C2 Reborn v6.34 |','C2 Reborn v6.35 |')
a="if(cp.action==='Copy'){let copied=JSON.parse(JSON.stringify(cp.source));copied.store=cp.destination;copied.marked=false;phoneState.contacts.splice(i+1,0,copied);i++}else{cp.source.store=cp.destination}persist();namesSubmenu=null;"
b="let previousContacts=phoneState.contacts.slice(),hadStore=Object.prototype.hasOwnProperty.call(cp.source,'store'),previousStore=cp.source.store;if(cp.action==='Copy'){let copied=JSON.parse(JSON.stringify(cp.source));copied.store=cp.destination;copied.marked=false;phoneState.contacts.splice(i+1,0,copied);i++}else{cp.source.store=cp.destination}try{persist()}catch(err){phoneState.contacts=previousContacts;if(hadStore)cp.source.store=previousStore;else delete cp.source.store;contactMemoryPending=cp;notice='Unable to save contact transfer';draw();return}namesSubmenu=null;"
assert s.count(a)==1;s=s.replace(a,b)
a="if(contactMemoryPending){let cp=contactMemoryPending;s.insertAdjacentHTML"
b="if(contactMemoryPending&&!notice){let cp=contactMemoryPending;s.insertAdjacentHTML"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to delete contact|Folder memory full|';b='Unable to delete contact|Unable to save contact transfer|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.35-contact-transfer-rollback-candidate.html').write_text(s)
