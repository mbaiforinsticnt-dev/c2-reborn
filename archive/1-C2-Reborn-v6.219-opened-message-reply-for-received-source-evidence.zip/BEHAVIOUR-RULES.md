# C2 Reborn behaviour rules (Moti)
Source: Moti's messages, kept in the repo (non-site folder). Add new rules at the bottom.

1. Centre key = the most common action on that screen.
2. Conversation view: selected message truncated in the list (cut at 3 lines with "...") => centre key "Open" (opens full message, marks it read: closed envelope -> open envelope). Fully visible received message => "Reply". Outgoing => "Open" (unchanged).
3. Opened message view: received => centre key "Reply"; sent/outgoing => "Send" (forward / resend to someone else). OK key follows the label. (v6.219)
4. The hardware OK key must always do what the centre label says (v6.218 fixed Conversation view; v6.219 opened message view).
5. Icons: original firmware files or sources Moti chose; never drawn, never Unicode glyphs; disclose crop/made/firmware.
6. Handset footage outranks emulator evidence, except list-opening arrows (follow emulator). Additions ship; removals need Moti's word or footage.
