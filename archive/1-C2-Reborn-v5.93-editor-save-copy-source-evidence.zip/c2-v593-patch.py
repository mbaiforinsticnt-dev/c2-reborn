from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.92-editor-crop-entry-candidate.html').read_text().replace('v5.92 handset parity','v5.93 handset parity').replace('C2 Reborn v5.92 |','C2 Reborn v5.93 |')
s=s.replace("galEditor={src:f.big||f.src||'',stage:'view',choice:0}","galEditor={src:f.big||f.src||'',sourceName:f.n,stage:'view',choice:0}",1)
s=s.replace('galCaptures:[],galFolderAliases:', 'galCaptures:[],galEditedImages:[],galFolderAliases:',1)
a=s.index('d.galCaptures=')
s=s[:a]+"d.galEditedImages=Array.isArray(x.galEditedImages)?x.galEditedImages.slice(0,30).filter(v=>v&&v.folder==='Images'&&typeof v.n==='string'&&typeof v.src==='string'&&/^data:image\\/gif;base64,/.test(v.src)&&v.src.length<1000000).map(v=>({folder:'Images',n:cleanText(v.n,160),src:v.src,big:v.src,s:cleanText(v.s,20),d:cleanText(v.d,30)})):[];"+s[a:]
s=s.replace("concat((phoneState.galCaptures||[]).filter(v=>v.folder===n)","concat((phoneState.galEditedImages||[]).filter(v=>v.folder===n),(phoneState.galCaptures||[]).filter(v=>v.folder===n)",1)
s=s.replace("flat().concat(phoneState.galCaptures||[]", "flat().concat(phoneState.galEditedImages||[],phoneState.galCaptures||[]",1)
s=s.replace('function galEditorDraw(s)',Path('/tmp/c2-v593-helper.js').read_text()+'\nfunction galEditorDraw(s)',1)
s=s.replace("let e=galEditor;if(['imagePicker'", "let e=galEditor;if(galEditorSaveDraw(s))return true;if(['imagePicker'",1)
s=s.replace("if(['imagePicker','imageOptions'].includes(e.stage)){if(e.stage", "if(galEditorSavePress(k))return true;if(['imagePicker','imageOptions'].includes(e.stage)){if(e.stage",1)
s=s.replace("if(e.pickerMode==='save'){e.returnStage='imagePicker';e.stage='unsupported'}", "if(e.pickerMode==='save'){if(!e.pickerBrowse&&rows[e.pickerChoice]?.key==='Images')galEditorSaveForm();else{e.returnStage='imagePicker';e.stage='unsupported'}}",1)
s=s.replace("else if(k==='OK'){e.stage='imagePicker';e.pickerMode='save';", "else if(k==='OK'){let im=document.querySelector('.galEditorImage img'),l=document.querySelector('.galEditorLayer');e.saveImageHeight=im?.getBoundingClientRect().height||0;e.saveFontSize=l?parseFloat(getComputedStyle(l).fontSize):14;e.stage='imagePicker';e.pickerMode='save';",1)
Path('/downloads/C2-Reborn-v5.93-editor-save-copy-candidate.html').write_text(s)
