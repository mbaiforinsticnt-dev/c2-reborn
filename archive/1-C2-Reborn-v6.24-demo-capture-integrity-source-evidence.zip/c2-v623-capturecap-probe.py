exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.23-save-history-identity-candidate.html'))
print(ev("phoneState=migrateState(null);phoneState.galCaptures=Array.from({length:100},(_,i)=>({folder:'Images',n:'DemoPhoto'+String(i+6).padStart(4,'0')+'.jpg',s:'1.2 MB'}));page='camera';notice='';press('OK');JSON.stringify({notice,count:phoneState.galCaptures.length})"))
call('Page.reload');time.sleep(.3)
print(ev("phoneState.galCaptures.length"))
