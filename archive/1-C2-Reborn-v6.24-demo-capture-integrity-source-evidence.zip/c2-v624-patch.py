from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.23-save-history-identity-candidate.html').read_text().replace('v6.23 handset parity','v6.24 handset parity').replace('C2 Reborn v6.23 |','C2 Reborn v6.24 |')
a='function recordDemoCapture(folder){'
b="function galStoreDemoCapture(row){let old=phoneState.galCaptures||[];if(old.length>=100){notice='Demo file memory full';return false}phoneState.galCaptures=old.concat(row);try{persist()}catch(err){phoneState.galCaptures=old;notice='Unable to save demo file';return false}return true}\nfunction recordDemoCapture(folder){"
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.galCaptures.push({folder,n,d:String(d.getDate()).padStart(2,'0')+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getFullYear()).slice(-2),s:folder==='Images'?'1.2 MB':'0 B'});persist();return n"
b="return galStoreDemoCapture({folder,n,d:String(d.getDate()).padStart(2,'0')+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getFullYear()).slice(-2),s:folder==='Images'?'1.2 MB':'0 B'})?n:null"
assert s.count(a)==1;s=s.replace(a,b)
a="cameraShot=true;notice='Demo photo '+name+' saved';"
b="if(name){cameraShot=true;notice='Demo photo '+name+' saved';}"
assert s.count(a)==1;s=s.replace(a,b)
a="notice='Demo photo '+name+' saved';cameraShot=true;"
b="if(name){notice='Demo photo '+name+' saved';cameraShot=true;}"
assert s.count(a)==1;s=s.replace(a,b)
a="else if(page==='videorecorder')notice='Demo clip '+recordDemoCapture('Video clips')+' saved';"
b="else if(page==='videorecorder'){let name=recordDemoCapture('Video clips');if(name)notice='Demo clip '+name+' saved';}"
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.galCaptures.push({folder:'Recordings',n:name,d:String(d.getDate()).padStart(2,'0')+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getFullYear()).slice(-2),s:'0 B',demo:true});persist();notice=name+' saved (silent demo - no audio file)'"
b="if(galStoreDemoCapture({folder:'Recordings',n:name,d:String(d.getDate()).padStart(2,'0')+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getFullYear()).slice(-2),s:'0 B',demo:true}))notice=name+' saved (silent demo - no audio file)'"
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('Fax not activated|Folder memory full|','Fax not activated|Demo file memory full|Unable to save demo file|Folder memory full|')
Path('/downloads/C2-Reborn-v6.24-demo-capture-integrity-candidate.html').write_text(s)
