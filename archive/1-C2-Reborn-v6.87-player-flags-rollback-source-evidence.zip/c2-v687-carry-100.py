exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.87-player-flags-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for freq,expected in [('88.0',1),('100.0',2),('107.9',1)]:
 ev("phoneState=migrateState(null);phoneState.radioSaved=[{frequency:'101.0',name:'One'},{frequency:'98.8',name:'Two'},{frequency:'100.5',name:'Three'}];phoneState.radioFrequency='"+freq+"';phoneState.radioStationIndex=0;persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='radio';open=true;os=currentOptions().indexOf('Search stations');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(freq+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(freq+' warning no false station',"return notice==='Unable to save radio station'&&document.getElementById('screen').innerText.includes(notice)")
 if freq=='88.0':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v676-radio-search-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';open=true;os=currentOptions().indexOf('Search stations');press('OK')")
 t(freq+' repeat failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=currentOptions().indexOf('Search stations');press('OK')")
 t(freq+' retry once',"return phoneState.radioStationIndex==="+str(expected)+"&&phoneState.radioFrequency===phoneState.radioSaved["+str(expected)+"].frequency&&notice==='Demo station '+phoneState.radioFrequency+' MHz'")
 call('Page.reload');time.sleep(.15)
 t(freq+' reload exact',"return phoneState.radioStationIndex==="+str(expected)+"&&phoneState.radioFrequency===phoneState.radioSaved["+str(expected)+"].frequency")
ev("phoneState=migrateState(null);phoneState.radioSaved=[];phoneState.radioFrequency='99.9';before=JSON.stringify(phoneState);page='radio';notice='';open=true;os=currentOptions().indexOf('Search stations');press('OK')")
t('Empty guard exact',"return JSON.stringify(phoneState)===before&&notice==='No demo stations to find'")
print('PASS',len(checks))
