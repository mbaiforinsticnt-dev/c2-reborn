exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.87-player-flags-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for seconds in ['00:02:00','00:00:00']:
 ev("phoneState=migrateState(null);phoneState.timerValue='00:01:00';phoneState.timerEndsAt=0;persist();stored=localStorage.getItem('c2state');page='timernote';timerParts='"+seconds+"'.split(':');timerNote='Demo note';normalTimerFlash='';history=['home','countdown'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(seconds+' exact rollback',"return phoneState.timerEndsAt===0&&phoneState.timerValue==='00:01:00'&&localStorage.getItem('c2state')===stored")
 t(seconds+' note/history retained',"return page==='timernote'&&timerNote==='Demo note'&&history.length===2&&normalTimerFlash==='Unable to save timer'&&document.getElementById('screen').innerText.includes(normalTimerFlash)")
 if seconds=='00:02:00':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v670-countdown-start-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("press('OK');press('OK')")
 t(seconds+' repeat failure exact',"return phoneState.timerEndsAt===0&&phoneState.timerValue==='00:01:00'")
 ev("Storage.prototype.setItem=oldStore;press('OK');press('OK')")
 t(seconds+' retry saved',"return phoneState.timerValue==='"+seconds+"'&&history.length===0&&JSON.parse(localStorage.getItem('c2state')).timerValue==='"+seconds+"'")
 t(seconds+' success state',"return "+("phoneState.timerEndsAt>Date.now()&&normalTimerFlash==='Timer running'&&page==='timernote'" if seconds=='00:02:00' else "phoneState.timerEndsAt===0&&normalTimerFlash===''&&page==='organiser'"))
 call('Page.reload');time.sleep(.15)
 t(seconds+' reload value',"return phoneState.timerValue==='"+seconds+"'")
print('PASS',len(checks))
