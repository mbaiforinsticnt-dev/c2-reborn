from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.28-group-image-integrity-candidate.html').read_text().replace('v6.28 handset parity','v6.29 handset parity').replace('C2 Reborn v6.28 |','C2 Reborn v6.29 |')
a='function galStoreDemoCapture(row){'
b="function galNextDemoName(folder,prefix,ext,start){let ids=Object.values(GAL_FILES).flat().concat(phoneState.galEditedImages||[],phoneState.galCaptures||[],phoneState.galFolderItems||[]).map(f=>f.n).concat(phoneState.galDeleted||[],...['galMoved','galCopied','galFileNames'].map(k=>Object.keys(phoneState[k]||{}))),seen=new Set(ids.map(n=>n.toLowerCase())),max=start-1;for(let n of ids){let match=n.match(new RegExp('^'+prefix+'([0-9]+)\\\\.'+ext+'$','i'));if(match&&Number.isSafeInteger(Number(match[1]))&&Number(match[1])<1000000000)max=Math.max(max,Number(match[1]))}let n;do{n=prefix+String(++max).padStart(4,'0')+'.'+ext}while(seen.has(n.toLowerCase()));return n}\nfunction galStoreDemoCapture(row){"
assert s.count(a)==1;s=s.replace(a,b)
a="let v=(phoneState.galCaptures||[]).reduce((n,x)=>x.folder===folder?Math.max(n,Number((x.n||'').match(/(\d+)\./)?.[1]||0)-5):n,0)+1,n=(folder==='Images'?'DemoPhoto':'DemoClip')+String(5+v).padStart(4,'0')+(folder==='Images'?'.jpg':'.mp4'),d=new Date();"
b="let n=galNextDemoName(folder,folder==='Images'?'DemoPhoto':'DemoClip',folder==='Images'?'jpg':'mp4',6),d=new Date();"
assert s.count(a)==1;s=s.replace(a,b)
a="let count=phoneState.galCaptures.filter(x=>x.folder==='Recordings').length+1,name='DemoRecording'+String(count).padStart(4,'0')+'.amr',d=new Date();"
b="let name=galNextDemoName('Recordings','DemoRecording','amr',1),d=new Date();"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.29-demo-file-identity-candidate.html').write_text(s)
