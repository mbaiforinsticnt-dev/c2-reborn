exec(open("/tmp/hdr.py").read())
import time as tm
fresh2();ev("go('home')")
for k in '5551234':S(k)
S('CALL');tm.sleep(8);S('END')
ev("go('allcalls')");S('DOWN');S('DOWN');S('LSK');print(ev(T)[:300])
for q in range(6):
    S('DOWN');print(ev('os'),ev(T)[-90:])
