exec(open("/tmp/hdr.py").read())
import time as tm
def start():
    fresh2();ev("go('home')")
    for k in '5551234':S(k)
    S('CALL')
for name,n in (('Loudspeaker',0),('Mute',1),('Hold',2)):
    start();S('LSK')
    for q in range(n):S('DOWN')
    S('OK');print(name,ev('page'),repr(ev('notice')),ev(T)[:200])
    S('LSK');print('  reopen',ev(T)[:200])
    for q in range(n):S('DOWN')
    S('OK');print('  second',ev('page'),repr(ev('notice')),ev(T)[:200])
start();tm.sleep(4);S('RSK');print('end?',ev('page'),ev(T)[:200]);S('END');print('END',ev('page'),ev(T)[:200])
print(ev("JSON.stringify((phoneState.calls||phoneState.callLog||[]).slice(0,3))")[:600])
