exec(open("/tmp/hdr.py").read())
import time as tm
fresh2()
ev("""(function(){let n=handsetNow();n=new Date(n.getTime()+60000-n.getSeconds()*1000-n.getMilliseconds()-3000);
let dd=('0'+n.getDate()).slice(-2)+'-'+('0'+(n.getMonth()+1)).slice(-2)+'-'+n.getFullYear(),hm=new Date(n.getTime()+3000).toTimeString().slice(0,5);
phoneState.calPrefs=Object.assign({},phoneState.calPrefs,{clockAt:n.getTime(),clockSavedAt:Date.now()});
phoneState.todos=[{s:'Pay rent',p:'High',d:dd,t:hm,done:false,al:'With tone',ad:dd,at:hm}];
phoneState.calendar=[{type:'Reminder',text:'Dentist',date:dd,repeat:'Never',alarm:true,time:hm}];window.__hm=hm;})()""")
S('DOWN') if False else None
for q9 in range(8):
    tm.sleep(1);p=ev('page')
    print(q9,p)
    if p=='itemalarm':break
print(ev(T))
S('RSK');print(ev('page'),ev(T)[:80])
tm.sleep(1.5);print('no repeat',ev('page'))
