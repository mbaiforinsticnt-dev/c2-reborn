C2 Reborn v6.189 (base v6.188). Source-evidence bundle; Nokia build.
Reproduced on v6.188 and fixed (r93,r94,r97,r98,r99 focused scripts, python3 rNN.py index.html):
- Notes > Send note > "Send as message" went to a number-entry page and OK showed "Search opened", creating nothing. Now opens a new text message with the note text (same as To-do "Send as message").
- To-do editor right softkey said "Back" but deleted a char when the subject has text. Label is now "Clear" in that state.
- Call in progress: Mute and Hold showed a false "Not implemented in this prototype" (branches lacked return). Fixed. Options labels now toggle (Handset/Unmute/Unhold).
- Call in progress: first END after a notice (e.g. "Loudspeaker on") was swallowed. END now always ends the call.
- Dialled call log time was "Just now" forever; now "Today HH:MM" like the other rows.
Added (inferred, no handset evidence): Calendar notes with alarm and To-do items with Silent/With tone alarms now fire a simple screen at their date/time (Stop dismisses). Previously only the Alarm clock rang. Repeats are not scheduled.
Not changed: folder Rename in Gallery returns with Options open - long-standing deliberate behaviour (galRenameOs, since v5.5x); file Rename in Images already returns to Images. Needs handset evidence to change.
Not reproduced: call duration mismatch (no Details option in the log lists on this build).
