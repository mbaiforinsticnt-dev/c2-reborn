exec(open("/tmp/hdr.py").read())
fresh2();ev("phoneState.notes=['Buy milk and eggs'];go('notes')")
S('OK');S('LSK');S('DOWN');S('DOWN');S('OK');print(ev("page"),ev(T)[:120])
S('OK');print('after',ev("page"),ev("notice"),ev(T)[:200])
