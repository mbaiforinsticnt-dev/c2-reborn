# C2 Reborn behaviour rules (Moti)
Source: Moti's messages, kept in the repo (non-site folder). Add new rules at the bottom.

1. Centre key = the most common action on that screen.
2. Conversation view: selected message truncated in the list (cut at 3 lines with "...") => centre key "Open" (opens full message, marks it read: closed envelope -> open envelope). Fully visible received message => "Reply". Outgoing => "Open" (unchanged).
3. Opened message view: received => centre key "Reply"; sent/outgoing => "Send" (forward / resend to someone else). OK key follows the label. (v6.219)
4. The hardware OK key must always do what the centre label says (v6.218 fixed Conversation view; v6.219 opened message view).
5. Icons: original firmware files or sources Moti chose; never drawn, never Unicode glyphs; disclose crop/made/firmware.
6. Handset footage outranks emulator evidence, except list-opening arrows (follow emulator). Additions ship; removals need Moti's word or footage.
7. Key auto-repeat (Moti 12:46, 5 Oct): on every scrolling list/menu/text, holding Up/Down (and Left/Right where they move through items) for more than 0.8 s starts auto-scroll at 4 steps per second until release; stops on release; list end follows the emulator's wrap rule. A short press moves one step. One shared mechanism in pressStart/pressEnd (v6.221). Test: t240.py (short=1, 1.0s=1, 2.0s=5, release stops).
8. Equal row heights (Moti 14:43/14:44, 5 Oct; evidence: emulator Display settings frame): in every list, all rows on a page have the same height whether or not a row has a value line. Rows without a value leave the space empty; label at top, value text at the bottom of the row; selected row shows "‹ value ›" with a dark rounded highlight (Black/Nokia themes). Implemented v6.228 as a generic normaliser (any list with unequal rows gets equal rows) plus crawl check (rowh in a8 output).
9. Row size per page follows the emulator/handset height for that page type; never resize a page just to fill blank space (Moti 16:19). Uniform within a page; Display settings 4 x 57 is the only normalised page so far.
10. List pages: a small extra gap between the title and the first row (Moti 16:36); title centre to row top about 19-22 units, not 13.
11. C2-only features stay even when the SDK emulator lacks them (Moti 17:04): e.g. "View conversations" in Names Options exists because only the C2 has the conversation view of SMS (rather than inbox/sent items). The emulator is not a C2, so such differences are not removals. Find on map: still unconfirmed.

12. Call-log lists: centre key = Call (voice). Options = Call, Video call, View conversations (C2-only), then the rest.

13. Conversations search uses its own index of conversation names and numbers (unsaved numbers included), never the contacts index (Moti 17:18/17:19).

14. Search is "plain": start-of-word for names, start-of-number for digits. Half-name/half-number matching is "enhanced" and shelved until Moti asks for it.

15. Selection (mark) mode follows the Gallery file explorer everywhere (Moti 16:18, 6 Oct, voice note on video-6dd87fb5, transcribed): (a) Options > Select starts selecting with the highlighted item already selected; (b) from that moment the centre key reads Select / Deselect (never Open) and toggles the highlighted item; (c) Back leaves selecting and lets go of every selection, so nothing stays ticked afterwards (also when leaving the list and coming back); (d) it applies to messages inside a conversation too: Select, then Options has View selected etc.; (e) general rule for the whole system wherever anything can be selected. Bugs reported in v6.271: a ticked message stayed ticked after Back in the thread; Conversations kept its selection after leaving; the thread centre key stayed Open in select mode.
   Confirmation 16:26 (video-677c2337, v6.272): Select all in Conversations, then Back, must just cancel the selection (it stayed ticked) - rule 15(c); and the status-bar unread envelope showed with no unread message anywhere in Conversations (cause: inbox-only City Library seed unread, fixed in v6.274). Both covered by v6.274.
16. Checkbox look (Moti 16:25, handset photo of Conversations select mode): white rounded box with grey border, green tick; a selected highlighted row keeps the grey border around the box; on a non-highlighted (dark) row the box is a white box on the dark row; unselected rows show the same white box empty. One shared graphic (.galCheck / chkBox) everywhere. v6.275 candidate.
17. SIGNED OFF (Moti, 19:26 and 19:29): the select box and tick are the drawn graphic (class galCheck / galCheck.on): white fill, thin grey border, green tick, empty and ticked, on dark and highlighted rows (his reference picture checkbox-big). No firmware icon exists for it and none is needed. Do not change it in any later build.
