exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.103-calendar-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for action in ['Copy','Move']:
 for store in ['Phone','SIM']:
  ev("phoneState=migrateState(null);phoneState.contacts[0].store="+json.dumps(store)+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');source=phoneState.contacts[0];page='contact';contactIndex=0;contactMemoryPending={action:"+json.dumps(action)+",source,destination:"+json.dumps('SIM' if store=='Phone' else 'Phone')+",submenu:'Edit',choice:2,parent:null};notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  t(action+store+' quota exact source rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&phoneState.contacts[0]===source")
  t(action+store+' pending confirmation retained',"return contactMemoryPending.source===source&&contactMemoryPending.action==="+json.dumps(action)+"&&notice==='Unable to save contact transfer'&&page==='contact'")
  if action=='Copy' and store=='Phone':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v635-contact-transfer-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(action+store+' retry one transfer',"return !contactMemoryPending&&phoneState.contacts.length==="+('4' if action=='Copy' else '3')+"&&phoneState.contacts[contactIndex].store==="+json.dumps('SIM' if store=='Phone' else 'Phone'))
  call('Page.reload');time.sleep(.3)
  t(action+store+' reload transfer persisted',"return phoneState.contacts.length==="+('4' if action=='Copy' else '3')+"&&phoneState.contacts.some(c=>c.name==='Alex Morgan'&&c.store==="+json.dumps('SIM' if store=='Phone' else 'Phone')+")")
print('PASS',len(checks))
