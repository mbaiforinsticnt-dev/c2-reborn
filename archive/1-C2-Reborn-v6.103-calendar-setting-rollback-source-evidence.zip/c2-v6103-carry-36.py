exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.103-calendar-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for op in ['Move','Copy']:
 ev("phoneState=migrateState(null);page='galtarget';history=['galfolder'];galFolderName='Images';galTarget={op:"+json.dumps(op)+",from:'Images',names:['Photo0001.jpg','Photo0002.jpg']};sel=1;galMarked=new Set(galTarget.names);galMarkMode=true;persist();baseline=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};draw();press('OK')")
 t(op+' quota exact state rollback',"return JSON.stringify(phoneState)===baseline&&localStorage.getItem('c2state')===stored")
 t(op+' failure keeps selection and destination',"return page==='galtarget'&&galTarget.names.length===2&&galMarked.size===2&&galMarkMode&&notice==='Unable to save file "+op.lower()+"'")
 if op=='Move':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v604-file-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';draw();press('OK')")
 t(op+' retry completes once',"return page==='galfolder'&&!galTarget&&!galMarkMode&&galMarked.size===0&&Object.keys(phoneState."+('galMoved' if op=='Move' else 'galCopied')+").length===2")
 call('Page.reload');time.sleep(.3)
 t(op+' reload keeps both transfers',"return phoneState."+('galMoved' if op=='Move' else 'galCopied')+"['Photo0001.jpg']==='Video clips'&&phoneState."+('galMoved' if op=='Move' else 'galCopied')+"['Photo0002.jpg']==='Video clips'")
print('PASS',len(checks))
