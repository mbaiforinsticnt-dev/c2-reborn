from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.102-stopwatch-delete-rollback-candidate.html').read_text().replace('v6.102 handset parity','v6.103 handset parity').replace('C2 Reborn v6.102 |','C2 Reborn v6.103 |')
a="phoneState.calPrefs[calChoice]=v;persist();back();notice=(calChoice==='autoDelete'?'Auto-delete activated':'Setting changed');"
b="let beforePrefs=phoneState.calPrefs;phoneState.calPrefs={...beforePrefs,[calChoice]:v};try{persist()}catch(err){phoneState.calPrefs=beforePrefs;notice='Unable to save calendar setting';draw();return true}back();notice=(calChoice==='autoDelete'?'Auto-delete activated':'Setting changed');"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save content options|Folder memory full','Unable to save content options|Unable to save calendar setting|Folder memory full')
Path('/downloads/C2-Reborn-v6.103-calendar-setting-rollback-candidate.html').write_text(s)
