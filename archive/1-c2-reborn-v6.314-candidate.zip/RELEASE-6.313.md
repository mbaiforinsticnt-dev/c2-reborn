# v6.313 candidate - incoming demo call filtering

Extends312 by wiring settled blacklist/whitelist rules into incoming-call simulation.

- Active blacklist rejects listed numbers; Off allows them; Timed rejects until its stored future deadline and stops immediately on expiry.
- Whitelist mode allows only listed numbers. Empty whitelist blocks all demo numbers.
- Blocked demo calls show an honest blocked result with its reason; no missed/received call event is invented. Dismissing the result restores the underlying page/options.
- If both modes are active and a number is in both lists, simulation pauses with "Not simulated: Blacklist/whitelist overlap needs a decision". No winner is guessed.
- Reject unknown callers remains pending, with no guessed withheld/unsaved interpretation.
- No real calls, no account contact changes, no recording code. Merge remains unimplemented.

13 enforcement checks plus prior60 pass on the exact313 file. Sweep409 content lines, a798bba3, no errors and byte-identical to312 sweep. Local actual screenshots inspected for blocked and pending result. Not publicly banked/published or live-verified yet. Rollback target for an eventual313 publish is the actual live312, blob abcc45c4d9547799481da3a60e353a80a90fb061.
