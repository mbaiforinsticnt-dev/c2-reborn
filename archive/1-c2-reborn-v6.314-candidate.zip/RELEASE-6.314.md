# v6.314 candidate - Gallery Back repair

PDF F4 replayed before this change against actual S40 SDK, not adopted on trust. SDK Menu > Gallery opens Memory card and Back returns to Menu with Gallery highlighted. Exact served v6.313 HTML Menu > Gallery > Back incorrectly went home and discarded history.

The single Gallery RSK branch now uses the existing stored-parent back handler. It preserves Menu selection, folder return paths, Options dismissal and marking-mode exit. Gallery introduction dismisses on first Back without exiting. Red remains home; shortcut/direct entry has a safe home fallback. No assets or layout changed. SDK menu order differs from the owner's HTML menu order; this is a Back/navigation comparison, not an order/layout parity claim.

12 new focused navigation checks + 73 prior checks pass on exact v6.314. Sweep409 content lines a798bba3, zero errors, byte-identical to v6.313. Local screenshots inspected. Candidate pending banking/publish/live verification at freeze. Later deployment facts belong in current README/handover, not a retroactive edit to this frozen bundle.

Rollback for this candidate is verified live v6.313 blob 047c380665053b0cf0823888c134cd53a876f356. Unknown/overlap/Merge decisions remain unresolved; recording absent. No full differential certification, private handset media, real contacts, ground-up change, removal or third-party audit send.
