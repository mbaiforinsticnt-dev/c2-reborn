import sys,json,time
sys.argv=['probe','/tmp/h/w313.html'];exec(open('/tmp/c2hdr.py').read());fresh2();R=[]
def ck(n,e):
 v=ev(e);assert v is True,(n,v);R.append(n)
ev("notice='';rule308Incoming=null;go('names');sel=1;open=true;os=2;window.base313=JSON.stringify({page,sel,open,os,history});window.logs313=JSON.stringify(phoneState.calls);filter312Change(n=>{n.black=['+447700900456'];n.blackMode='On';n.white=[];n.whiteMode=false});simulateIncomingCall('+44 7700 900456')")
ck('blacklisted call blocked',"!rule308Incoming&&filter313Outcome.status==='Incoming demo call blocked'")
ck('blocked does not invent missed event',"JSON.stringify(phoneState.calls)===logs313")
ev("press('END')");ck('blocked acknowledgement preserves page',"!filter313Outcome&&JSON.stringify({page,sel,open,os,history})===base313")
ev("simulateIncomingCall('+44 7700 900888')");ck('other number allowed blacklist only',"!!rule308Incoming&&!filter313Outcome");ev("rule308Incoming=null;filter312Change(n=>n.blackMode='Off');simulateIncomingCall('+44 7700 900456')");ck('Off allows blacklisted',"!!rule308Incoming")
ev("rule308Incoming=null;filter312Change(n=>{n.whiteMode=true;n.white=['+447700900888']});simulateIncomingCall('+44 7700 900888')");ck('whitelisted call allowed',"!!rule308Incoming");ev("rule308Incoming=null;simulateIncomingCall('+44 7700 900456')");ck('non-whitelist blocked',"!!filter313Outcome&&!rule308Incoming");ev("press('OK');filter312Change(n=>{n.white=[]});simulateIncomingCall('+44 7700 900888')");ck('empty whitelist rejects',"!!filter313Outcome&&!rule308Incoming")
ev("press('OK');filter312Change(n=>{n.white=['+447700900456'];n.blackMode='On'});simulateIncomingCall('+44 7700 900456')");ck('overlap honest pending',"filter313Outcome.status==='Not simulated'&&!rule308Incoming&&JSON.stringify(phoneState.calls)===logs313")
ev("press('OK');filter312Change(n=>{n.whiteMode=false;n.blackMode='Timed';n.blackUntil=Date.now()-1});simulateIncomingCall('+44 7700 900456')");ck('expired blacklist allows immediately',"!!rule308Incoming&&filter312.blackMode==='Off'")
ev("rule308Incoming=null;filter312Change(n=>{n.blackMode='Timed';n.blackUntil=Date.now()+3600000});simulateIncomingCall('+44 7700 900456')");ck('active timed blacklist blocks',"!!filter313Outcome&&!rule308Incoming")
shot('/downloads/enforce313-blocked.png');ev("press('OK');filter312Change(n=>{n.blackMode='On';n.whiteMode=true;n.white=['+447700900456']});simulateIncomingCall('+44 7700 900456')");shot('/downloads/enforce313-pending.png')
ev("filter313Outcome=null;filter312Change(n=>{n.blackMode='On';n.whiteMode=false});persist()");call('Page.reload');time.sleep(.8);ev("rule308Incoming=null;simulateIncomingCall('+44 7700 900456')");ck('enforcement persists reload',"!!filter313Outcome&&!rule308Incoming")
ev("filter313Outcome=null;rule308Incoming=null;activeCall='demo';simulateIncomingCall('+44 7700 900456')");ck('active call guard preserves existing call',"activeCall==='demo'&&!filter313Outcome&&!rule308Incoming&&notice==='A call is already active'")
print('\n'.join('PASS '+x for x in R));print('TOTAL',len(R))
