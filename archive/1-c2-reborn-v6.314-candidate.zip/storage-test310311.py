import sys
sys.argv=['probe','/tmp/h/w311.html'];exec(open('/tmp/c2hdr.py').read());fresh2();R=[]
def ck(n,e):
 v=ev(e);assert v is True,(n,v);R.append(n)
ev("phoneState.contacts=[{name:'Demo caller',number:'+44 7700 900888',email:'demo@example.invalid',groups:['Family']}];notice='';go('names');sel=namesContacts().findIndex(x=>x.number==='+44 7700 900888');transfer309Start('Copy contact',phoneState.contacts[0]);press('RSK')");ck('cancel no copy',"phoneState.contacts.length===1")
ev("transfer309Start('Copy contact',phoneState.contacts[0]);press('OK')");ck('copy Phone to SIM preserved source',"phoneState.contacts.length===2&&!phoneState.contacts[0].store&&phoneState.contacts[1].store==='SIM'&&phoneState.contacts[1].email==='demo@example.invalid'")
ev("notice='';transfer309Start('Copy contact',phoneState.contacts[0]);press('OK')");ck('duplicate not added',"phoneState.contacts.length===2")
ev("phoneState.contacts.splice(0,1);notice='';transfer309Start('Move contact',phoneState.contacts[0]);press('OK')");ck('move SIM to Phone preserves fields',"phoneState.contacts.length===1&&phoneState.contacts[0].store==='Phone'&&phoneState.contacts[0].groups[0]==='Family'")
ev('persist()');call('Page.reload');time.sleep(1);ck('storage reload',"phoneState.contacts.length===1&&phoneState.contacts[0].store==='Phone'")
print('\n'.join('PASS '+x for x in R))
