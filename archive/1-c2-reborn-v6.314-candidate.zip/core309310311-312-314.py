import sys,json
sys.argv=['probe','/tmp/h/w314.html'];exec(open('/tmp/c2hdr.py').read());fresh2();res=[]
def test(n,e):
 v=ev(e);assert v is True,(n,v);res.append(n)
ev("notice='';mm=null;go('names');sel=1;open=true;os=2;draw();window.before308=JSON.stringify({page,sel,open,os,history});simulateIncomingCall('+44 7700 900888')")
test('incoming keeps underlying state',"JSON.stringify({page,sel,open,os,history})===before308")
ev("press('CALL')");test('answer returns prior options',"JSON.stringify({page,sel,open,os,history})===before308&&activeCall==='+44 7700 900888'");test('received individual timestamp',"Number.isFinite(phoneState.calls.received[0].at)&&/\\d\\d:\\d\\d/.test(callEventLabel(phoneState.calls.received[0]))")
ev("press('END')");test('red ends only call',"activeCall===null&&JSON.stringify({page,sel,open,os,history})===before308");ev("press('END')");test('next red home',"page==='home'")
ev("notice='';go('missed');sel=0;phoneState.calls.missed=[{number:'+44 7700 900888',time:'Yesterday 10:07'},{number:'+44 7700 900888',time:'Yesterday 09:00'}];let r=phoneState.calls.missed[1];maSnooze(r);window.z308=JSON.parse(localStorage.getItem('c2snooze'));rule308Reminder(r)")
test('snooze exact second event',"z308.event.time==='Yesterday 09:00'&&z308.event.id===phoneState.calls.missed[1].id");test('10 minute due',"z308.due-Date.now()>599000&&z308.due-Date.now()<=600000");test('reminder draft exact event',"page==='calnote'&&noteText==='You have missed a call from +44 7700 900888 at 09:00.'");test('draft not saved',"!phoneState.calendar.some(x=>x.text===noteText)")
ev("notice='';go('missed');rule308Reminder({number:'+44 7700 900888',time:'Yesterday'})");test('legacy unknown not fabricated',"notice==='Event time unavailable'&&page==='missed'")
ev("notice='';go('names');sel=0;open=false;draw()");test('names menus additive',"['Call','Send message','View conversations','Details','Add to group','Add to contact','Edit contact','Delete contact','Copy contact','Move contact','Merge contact'].every(x=>currentOptions().includes(x))")
ev("go('received');sel=0;draw()");test('received menus additive',"['Call duration','View number','Edit number','Delete from call log','Details'].every(x=>currentOptions().includes(x))")
print('\n'.join('PASS '+x for x in res));print('TOTAL',len(res))
