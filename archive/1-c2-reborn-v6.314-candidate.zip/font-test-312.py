import sys,json
sys.argv=['probe','/tmp/h/w312.html'];exec(open('/tmp/c2hdr.py').read());fresh2();R=[]
def ck(n,e):
 v=ev(e);assert v is True,(n,v);R.append(n)
for route in ['fontsize','contactsettings']:
 for idx,val in enumerate(['Small font','Normal font','Large font']):
  ev("notice='';open=false;pickerDraft=null;radioCtx=null;go(%s);sel=%d;press('OK')"%(json.dumps(route),1 if route=='fontsize' else 3));ev("sel=%d;press('OK')"%idx)
  ck(route+' chooses '+val,"contactFont311()===%s"%json.dumps(val));ev("notice='';radioCtx=null;go('names');draw()")
  ck(val+' actual pixels '+route,"getComputedStyle(document.querySelector('.namesName')).fontSize===%s"%json.dumps(str([18,22,26][idx])+'px'))
  lcdshot('/downloads/font311-'+val.split()[0]+'.png');ev('persist()');call('Page.reload');time.sleep(.7);ck(val+' persists '+route,"contactFont311()===%s"%json.dumps(val))
ev("notice='';pickerDraft=null;go('fontsize');sel=1;press('LEFT');press('RSK')");ck('cancel retains committed size',"contactFont311()==='Large font'")
print('\n'.join('PASS '+x for x in R));print('TOTAL',len(R))
