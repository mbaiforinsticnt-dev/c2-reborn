# C2 Reborn v6.312 candidate

Builds on v6.311 (font routes unified, Small enabled, ellipsis repairs).

## New: Call filtering (custom feature from the owner's 7 October video)
- Settings > Call settings > Call filtering (new 14th row, additive; existing 13 rows untouched).
- Reject unknown callers: On/Off meaning withheld pending owner confirmation, so the row shows a plain pending note instead of a guessed toggle.
- Reject numbers in blacklist: Off / On / On until expiry. Timed choice opens a Year/Month/Day/Hour/Minute editor, validates a real future date, saves the deadline, and expires to Off even after reload.
- Blacklist numbers: pool list with Options > Remove (review prompt), no numeric editor. Duplicates blocked.
- Whitelist mode On/Off; whitelist numbers pool with the same Remove flow.
- Names/Contact Options gain "Add to blacklist" and "Add to whitelist".
- Demo data only: no real calls, no real handset numbers, nothing outside localStorage.
- Phone/SIM Copy/Move (v6.309) is complete and owner-confirmed; earlier release-note caveat resolved.

## Tests (all pass on this exact file)
- filter: 14 checks (route, empty pool, add/no-duplicate, remove review/cancel/commit, whitelist add, date-time editor, timed save, Off clears deadline, invalid date rejected, expiry after reload, persistence).
- prior suites: core 12, actions 10, storage 5, font 19. 60 total.
- Sweep: 408 lines, no JS errors; only intended diffs vs v6.311 (names/contact options gain the two list actions).

## Not done
- Reject-unknown toggle semantics and black/white overlap rule await owner answers.
- Auto call recording is deferred by the owner; no recording code.
- Merge contact remains an honest "Not implemented in this prototype".
- Not published; v6.307 stays live until this candidate is banked, tested live and approved.
