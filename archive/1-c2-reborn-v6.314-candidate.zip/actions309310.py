import sys,json
sys.argv=['probe','/tmp/h/w310.html'];exec(open('/tmp/c2hdr.py').read());fresh2();R=[]
def ck(n,e):
 v=ev(e);assert v is True,(n,v);R.append(n)
def base(p):ev("notice='';mm=null;open=false;subParent=null;pageSub=null;optParent=null;namesSubmenu=null;rule308Details=null;go(%s);sel=0;draw()"%json.dumps(p))
def action(c):ev("open=true;os=currentOptions().indexOf(%s);draw();press('OK')"%json.dumps(c))
ev("phoneState.contacts=[{name:'Demo caller',number:'+44 7700 900888'}];phoneState.calls.received=[{number:'+44 7700 900888',at:1791348000000},{number:'+44 7700 900777',at:1791344000000}]")
base('received');action('Details');ck('details full saved name and number',"rule308Details.name==='Demo caller'&&rule308Details.number==='+44 7700 900888'");ev("press('RSK')")
base('received');action('Send message');ck('send message exact recipient',"page==='compose'&&recipientText==='+44 7700 900888;'")
base('received');action('View conversations');ck('thread exact recipient',"page==='conversation'&&conversationNumber==='+44 7700 900888'")
base('received');action('Delete from call log');ev("press('RSK')");ck('received delete cancel',"phoneState.calls.received.length===2")
base('received');action('Delete from call log');ev("press('LSK')");ck('received delete only selected',"phoneState.calls.received.length===1&&phoneState.calls.received[0].number==='+44 7700 900777'")
base('received');action('Call duration');ck('unknown duration not invented',"notice==='Call duration unavailable'")
base('received');action('Edit number');ev("maState.text='+44 7700 900666';press('OK')");ck('edit exact received record',"phoneState.calls.received[0].number==='+44 7700 900666'")
base('names');ev("sel=namesContacts().findIndex(x=>x.number==='+44 7700 900888');draw()");action('Add to contact');ck('add to existing contact picker',"page==='names'&&pendingAddNumber==='+44 7700 900888'")
ev("phoneState.calls.missed=[{number:'+44 7700 900888',time:'Yesterday 10:07'},{number:'+44 7700 900888',time:'Yesterday 09:00'}];maSnooze(phoneState.calls.missed[1]);maArm(0)");time.sleep(.05);ck('snooze callback exact older event',"maState.time==='Yesterday, 09:00'&&maState.rec.time==='Yesterday 09:00'")
base('compose');ev("draft='unsent draft';cursor=4;composeFocus=1;open=true;os=2;simulateIncomingCall('+44 7700 900777');press('CALL');press('END')");ck('incoming keeps compose text/cursor/options',"page==='compose'&&draft==='unsent draft'&&cursor===4&&composeFocus===1&&open&&os===2")
print('\n'.join('PASS '+x for x in R));print('TOTAL',len(R))
