/* Owner-authored 7 October screenshot rules: prototype only, additive. */
var rule308Incoming=null,rule308Received=null,rule308Details=null;
function rule308EventID(r){if(!r.id){r.id='call-'+Date.now()+'-'+Math.random().toString(36).slice(2);persist()}return r.id}
function rule308ShowEvent(r,again){maState={name:maName(r.number),number:r.number,mode:'alert',os:0,again:!!again,time:callEventLabel(r),text:'',prev:null,rec:r};notice='';mm=null;go('missedalert');draw();if(again)maBeep()}
maSnooze=function(rec){if(!rec)return;rule308EventID(rec);let due=Date.now()+600000;localStorage.setItem('c2snooze',JSON.stringify({event:{...rec},due:due}));maArm(600000)};
maArm=function(ms){clearTimeout(maTimer);maTimer=setTimeout(function(){let z;try{z=JSON.parse(localStorage.getItem('c2snooze')||'null')}catch(e){}if(!z)return;localStorage.removeItem('c2snooze');let r=z.event||{number:z.number,time:z.time};rule308ShowEvent(r,true)},Math.max(0,ms))};
function rule308Reminder(rec){if(!rec)return;let label=callEventLabel(rec),hm=maHM(label);if(!hm){notice='Event time unavailable';draw();return}let text='You have missed a call from '+maName(rec.number)+' at '+hm+'.';mm=null;open=false;calDate=handsetNow();calNoteStart('Reminder',-1);noteText=text;noteCursor=text.length;calNoteDirty=true;calNoteAlarm=false;draw()}
function simulateIncomingCall(number){if(activeCall||rule308Incoming){notice='A call is already active';draw();return}rule308Incoming={number:number||'+44 7700 900456',at:handsetNow().getTime()};draw()}
function rule308Answer(){let r=rule308Incoming;if(!r)return;r={...r,id:'received-'+Date.now()+'-'+Math.random().toString(36).slice(2),time:callEventLabel(r)};phoneState.calls.received.unshift(r);try{persist()}catch(e){phoneState.calls.received.shift();notice='Unable to save demo call';draw();return}rule308Incoming=null;rule308Received=r;activeCall=r.number;callStarted=Date.now();callHeld=false;callMuted=false;callLoudspeaker=false;draw()}
var rule308OldEnd=endCall;endCall=function(){if(!rule308Received)return rule308OldEnd.apply(this,arguments);let r=rule308Received,sec=Math.max(0,Math.floor((Date.now()-callStarted)/1000)),before=r.duration;r.duration=sec;try{persist()}catch(e){r.duration=before;notice='Unable to save demo call';draw();return}rule308Received=null;activeCall=null;draw()};
function rule308Target(){let r,c,num='';try{
 if(['allcalls','missed','received','dialled'].includes(page))r=selectableRows(page)[sel];
 else if(page==='names'){c=namesRecord();if(c&&c.isGroup)return null;num=c&&c.number}
 else if(page==='contact'){c=phoneState.contacts[contactIndex];num=c&&c.number}
 else if(page==='conversations')num=agNum(rowKey(sel));
 else if(page==='conversation'||page==='msgopen'||page==='messageread')num=convCallNumber();
 else if(page==='inbox'||page==='sent')r=selectableRows(page)[sel];
 else if(page==='dial')num=dial;
 else num=greenNumber();
 num=r?r.number:num;c=c||findContact(num);if(!num||num==='(no number)')return null;return {number:num,contact:c,rec:r}
 }catch(e){return null}}
var rule308General=['Call','Send message','View conversations','Details','Add to group','Add to contact'];
var rule308Co=currentOptions;currentOptions=function(){let old=rule308Co.apply(this,arguments),t=rule308Target();if(!t||!Array.isArray(old)||subParent||pageSub||namesSubmenu||optParent)return old;let a=old.slice();rule308General.forEach(x=>{if(!a.includes(x))a.push(x)});if(page==='names'||page==='contact')['Edit contact','Delete contact','Copy contact','Move contact','Merge contact'].forEach(x=>{if(!a.includes(x))a.push(x)});if(['allcalls','missed','received','dialled'].includes(page))['Call duration','View number','Edit number','Delete from call log'].forEach(x=>{if(!a.includes(x))a.push(x)});if(page==='missed'&&!a.includes('Add to reminder (calendar)'))a.push('Add to reminder (calendar)');return a};
['Details','Add to contact','Call duration','Delete from call log','Add to reminder (calendar)'].forEach(x=>{if(!MM_CALL.includes(x))MM_CALL.push(x)});
var rule308Mm=mmCallAction;mmCallAction=function(c){let ctx=mm&&mm.ctx;if(!ctx)return rule308Mm(c);if(c==='Add to reminder (calendar)'){rule308Reminder(ctx.rec);return}if(c==='Details'){mm=null;rule308Details={number:ctx.number,name:maName(ctx.number)};draw();return}if(c==='Add to contact'){let n=ctx.number;mm=null;go('names');pendingAddNumber=n;draw();return}if(c==='Call duration'){let r=ctx.rec;mm=null;if(r.duration==null){notice='Call duration unavailable';draw();return}callDetailRec=r;callDurMode=true;go('calldetail');return}if(c==='Delete from call log')return rule308Mm('Delete');return rule308Mm(c)};
var rule308Draw=draw;draw=function(){rule308Draw.apply(this,arguments);let s=document.querySelector('#screen');if(rule308Incoming){let r=rule308Incoming;s.insertAdjacentHTML('beforeend','<div class="overlay infoDialog" style="z-index:95"><b>Incoming demo call</b><div>'+esc(maName(r.number))+'</div><div>'+esc(r.number)+'</div></div>');soft('','Answer','Reject')}if(rule308Details){s.insertAdjacentHTML('beforeend','<div class="overlay infoDialog" style="z-index:95"><b>Details</b><div>'+esc(rule308Details.name)+'</div><div>'+esc(rule308Details.number)+'</div></div>');soft('','OK','Back')}};
var rule308Press=press;press=function(k){if(rule308Incoming){if(k==='CALL'||k==='SEND'||k==='OK')rule308Answer();else if(k==='END'||k==='RSK'||k==='BACK'){let r=rule308Incoming;rule308Incoming=null;r={...r,id:'missed-'+Date.now(),time:callEventLabel(r),n:1};phoneState.calls.missed.unshift(r);persist();draw()}return true}if(rule308Received&&k==='END'){endCall();return true}if(rule308Details){if(['OK','RSK','BACK','END'].includes(k)){rule308Details=null;draw()}return true}
 if(page==='log'&&!open&&!notice&&(k==='OK'||k==='LSK')&&sel===screens.log.length-1){simulateIncomingCall();return true}
 if(open&&!notice&&!subParent&&!pageSub&&!namesSubmenu&&!optParent&&(k==='OK'||k==='LSK')){let c=currentOptions()[os],t=rule308Target();if(t){
 if(c==='Add to reminder (calendar)'){rule308Reminder(t.rec);return true}
 if(c==='Details'){open=false;rule308Details={number:t.number,name:t.contact?t.contact.name:t.number};draw();return true}
 if(c==='Send message'){open=false;startMessage('',t.number);return true}
 if(c==='View conversations'){open=false;maThread(t.number);return true}
 if(c==='Add to contact'){open=false;go('names');pendingAddNumber=t.number;draw();return true}
 if(c==='View number'){open=false;maEnter('view',t.number);return true}
 if(c==='Edit number'){open=false;maEnter('edit',t.number);if(t.rec)maState.rec=t.rec;return true}
 if(c==='Delete from call log'){open=false;let list=['missed','received','dialled'].find(x=>phoneState.calls[x].includes(t.rec));if(list)callDeletePending={list:list,record:t.rec};draw();return true}
 if(c==='Call duration'&&t.rec&&t.rec.duration==null){open=false;notice='Call duration unavailable';draw();return true}
 if(c==='Edit contact'&&t.contact){open=false;contactIndex=phoneState.contacts.indexOf(t.contact);loadContactToForm(t.contact);editingContact=true;go('addcontact');return true}
 if(c==='Delete contact'&&t.contact){contactDeleteConfirm={record:t.contact,index:phoneState.contacts.indexOf(t.contact),choice:os};draw();return true}
 if(['Copy contact','Move contact','Merge contact'].includes(c)){open=false;notice='Not implemented in this prototype';draw();return true}
 }}return rule308Press.apply(this,arguments)};
if(!screens.log.includes('Simulate incoming call'))screens.log.push('Simulate incoming call');
try{let z=JSON.parse(localStorage.getItem('c2snooze')||'null');if(z)maArm(z.due-Date.now())}catch(e){}
draw();
