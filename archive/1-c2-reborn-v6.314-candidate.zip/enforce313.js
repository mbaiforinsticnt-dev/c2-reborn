/* Incoming simulation enforcement. No cellular/account side effects. */
var filter313Outcome=null;
function filter313Decision(number){filter312Expire();let key=filter312Key(number),b=filter312.black.includes(key),w=filter312.white.includes(key),blackActive=filter312.blackMode==='On'||(filter312.blackMode==='Timed'&&Date.now()<filter312.blackUntil);
 if(blackActive&&filter312.whiteMode&&b&&w)return {pending:true,reason:'Blacklist/whitelist overlap needs a decision'};
 if(blackActive&&b)return {blocked:true,reason:'Number is in blacklist'};
 if(filter312.whiteMode&&!w)return {blocked:true,reason:'Number is not in whitelist'};
 return {allowed:true};
}
var incoming313=simulateIncomingCall;simulateIncomingCall=function(number){if(activeCall||rule308Incoming)return incoming313.apply(this,arguments);let n=number||'+44 7700 900456',decision=filter313Decision(n);if(decision.pending){filter313Outcome={number:n,status:'Not simulated',reason:decision.reason};draw();return}if(decision.blocked){filter313Outcome={number:n,status:'Incoming demo call blocked',reason:decision.reason};draw();return}return incoming313(n)};
var draw313=draw;draw=function(){draw313.apply(this,arguments);if(filter313Outcome){let r=filter313Outcome;document.querySelector('#screen').insertAdjacentHTML('beforeend','<div class="overlay rule308Card" style="z-index:100"><b>'+esc(r.status)+'</b><div>'+esc(contactLabel(r.number))+'</div><div>'+esc(r.reason)+'</div></div>');soft('','OK','Back')}};
var press313=press;press=function(k){if(filter313Outcome){if(['OK','LSK','RSK','BACK','END'].includes(k)){filter313Outcome=null;draw()}return true}return press313.apply(this,arguments)};draw();
