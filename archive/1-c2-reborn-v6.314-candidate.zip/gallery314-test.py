import sys,json
sys.argv=['probe','/tmp/h/w314.html'];exec(open('/tmp/c2hdr.py').read());fresh2();R=[]
def ck(n,e):
 v=ev(e);assert v is True,(n,v);R.append(n)
def base():ev("notice='';helpText=null;open=false;optParent=null;pageSub=null;galDialog=null;galMarkMode=false;phoneState.galleryHelp=false;page='home';sel=0;history=[];draw()")
base();S('OK');ev('sel=3;draw()');S('OK');ck('actual Menu to Gallery route',"page==='gallery'&&history.at(-1).page==='menu'&&history.at(-1).sel===3");S('RSK');ck('Gallery Back restores Menu row',"page==='menu'&&sel===3&&history.length===1")
ev('go("gallery");sel=2;draw()');S('OK');ck('Gallery folder enters',"page==='galfolder'");S('RSK');ck('folder Back restores Gallery row',"page==='gallery'&&sel===2");S('RSK');ck('next Back restores Menu selection',"page==='menu'&&sel===3")
ev('go("gallery");open=true;os=2;draw()');S('RSK');ck('Options Back keeps Gallery',"page==='gallery'&&!open");ev('galMarkMode=true;galMarked=new Set(["Graphics"]);draw()');S('RSK');ck('mark Back exits marking not Gallery',"page==='gallery'&&!galMarkMode&&galMarked.size===0")
ev('phoneState.galleryHelp=true;draw()');S('RSK');ck('Gallery introduction Back dismisses not exits',"page==='gallery'&&!phoneState.galleryHelp");shot('/downloads/gallery314-before-back.png');S('RSK');ck('Back after introduction returns stored Menu',"page==='menu'&&sel===3");shot('/downloads/gallery314-menu-return.png')
ev('go("gallery")');S('END');ck('red still goes Home',"page==='home'&&history.length===0");base();ev('go("gallery")');S('RSK');ck('home shortcut entry returns Home',"page==='home'&&history.length===0");base();ev('page="gallery";history=[];draw()');S('RSK');ck('direct entry safe Home fallback',"page==='home'")
print('\n'.join('PASS '+x for x in R));print('TOTAL',len(R))
