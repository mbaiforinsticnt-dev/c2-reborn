from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.10-folder-identity-persistence-candidate.html').read_text().replace('v6.10 handset parity','v6.11 handset parity').replace('C2 Reborn v6.10 |','C2 Reborn v6.11 |')
a='function galFolderEditSnapshot()';b="function galFolderReservedName(n){return n==='__proto__'||Object.prototype.hasOwnProperty.call(Object.prototype,n)}\nfunction galFolderEditSnapshot()";assert s.count(a)==1;s=s.replace(a,b)
a="let folderRollback=galFolderEditSnapshot();let key=name;"
b="if(galFolderReservedName(name)){notice='This folder name is not supported';draw();return}let folderRollback=galFolderEditSnapshot();let key=name;";assert s.count(a)==1;s=s.replace(a,b)
a="if(folderName.trim()){let folderRollback=galFolderEditSnapshot();"
b="if(folderName.trim()){if(galFolderReservedName(folderName.trim())){notice='This folder name is not supported';draw();return}let folderRollback=galFolderEditSnapshot();";assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('Folder name already exists|Selected memory empty','Folder name already exists|This folder name is not supported|Selected memory empty',1)
Path('/downloads/C2-Reborn-v6.11-folder-name-safety-candidate.html').write_text(s)
