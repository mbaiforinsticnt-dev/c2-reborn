exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.10-folder-identity-persistence-candidate.html'))
for name in ['constructor','toString','__proto__']:
 r=ev("(()=>{phoneState=migrateState(null);page='foldername';open=false;notice='';galRenameIdx=-1;galTarget=null;galAddParent='Images';folderName="+json.dumps(name)+";draw();press('OK');let key=phoneState.galleryFolders[0];return JSON.stringify({key,parent:phoneState.galFolderParents[key],display:galDisplayName(key),migrated:JSON.stringify(migrateState(phoneState).galFolderParents),child:galChildFolders('Images')})})()")
 print(name,r)
