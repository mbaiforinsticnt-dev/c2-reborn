from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.111-alarm-firmware-icon-candidate.html').read_text().replace('v6.111 handset parity','v6.112 handset parity').replace('C2 Reborn v6.111 |','C2 Reborn v6.112 |')
a="if(k==='RSK'&&page==='alarmring'){phoneState.alarm.on=true;phoneState.alarm.time=new Date(Date.now()+phoneState.alarm.snooze*60000).toTimeString().slice(0,5);persist();lastAlarmKey='';history=[];page='home';notice='Snoozed for '+phoneState.alarm.snooze+' min';draw();return}"
b="if(k==='RSK'&&page==='alarmring'){let beforeAlarm=phoneState.alarm;phoneState.alarm={...beforeAlarm,on:true,time:new Date(Date.now()+beforeAlarm.snooze*60000).toTimeString().slice(0,5)};try{persist()}catch(err){phoneState.alarm=beforeAlarm;notice='Unable to snooze alarm';draw();return}lastAlarmKey='';history=[];page='home';notice='Snoozed for '+phoneState.alarm.snooze+' min';draw();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to stop alarm|Folder memory full','Unable to stop alarm|Unable to snooze alarm|Folder memory full')
Path('/downloads/C2-Reborn-v6.112-alarm-snooze-rollback-candidate.html').write_text(s)
