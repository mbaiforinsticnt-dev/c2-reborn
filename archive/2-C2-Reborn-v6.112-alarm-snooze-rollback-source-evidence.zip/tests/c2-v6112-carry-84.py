exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.112-alarm-snooze-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['idle','prior']:
 ev("phoneState=migrateState(null);phoneState.calls.dialled=[{number:'Keep',time:'Before'}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='dial';dial='+44 7700 900888';activeCall="+('null' if mode=='idle' else "'Prior'")+";callStarted=123;callLoudspeaker=true;callMuted=true;callHeld=true;callHeldAt=8;beforeRuntime=JSON.stringify([activeCall,callStarted,callLoudspeaker,callMuted,callHeld,callHeldAt]);notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};startCall(dial)")
 t(mode+' exact state rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' exact call runtime retained',"return JSON.stringify([activeCall,callStarted,callLoudspeaker,callMuted,callHeld,callHeldAt])===beforeRuntime&&page==='dial'")
 t(mode+' warning visible',"return notice==='Unable to save demo call'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='idle':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v662-demo-call-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';startCall(dial)")
 t(mode+' retry creates one demo call',"return activeCall==='+44 7700 900888'&&page==='incall'&&!callLoudspeaker&&!callMuted&&!callHeld&&callHeldAt===0&&phoneState.calls.dialled.length===2&&phoneState.calls.dialled[0].number===activeCall&&phoneState.calls.dialled[1].number==='Keep'")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload history exact',"return phoneState.calls.dialled.length===2&&phoneState.calls.dialled[0].number==='+44 7700 900888'&&phoneState.calls.dialled[1].number==='Keep'")
ev("phoneState=migrateState(null);phoneState.flight=true;before=JSON.stringify(phoneState);activeCall=null;page='dial';startCall('+44 7700 900888')")
t('Flight guard unchanged',"return JSON.stringify(phoneState)===before&&activeCall===null&&page==='dial'&&notice==='Flight profile active'")
print('PASS',len(checks))
