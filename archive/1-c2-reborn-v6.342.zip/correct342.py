from pathlib import Path
import hashlib,sys
s=Path(sys.argv[1]).read_text();assert hashlib.sha256(s.encode()).hexdigest()=='79d6b5bf9daae2263951a6628e92f004054b2e972b0cb60bdba33d52e5d66633'
a="return [...new Set(old.concat(currentOptions()))]";assert s.count(a)==1;s=s.replace(a,"return [...new Set(old.concat(rule308General))]")
a="function listingExtras341(t){let a=rule308General.slice();if(t.contact)a=a.concat(['Edit contact','Delete contact','Copy contact','Move contact','Merge contact','Add to blacklist','Add to whitelist']);return a}";assert s.count(a)==1;s=s.replace(a,"function listingExtras341(t){return rule308General.slice()}")
s=s.replace('C2 Reborn v6.341 |','C2 Reborn v6.342 |');Path(sys.argv[2]).write_text(s);print(len(s.encode()),hashlib.sha256(s.encode()).hexdigest())
