exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.47-calendar-auto-delete-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');page='compose';draft='New draft';recipientText='Alex';draftOpenIdx=-1;draftOpenDemo=-1;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};saveDraft()")
print(ev("JSON.stringify({drafts:phoneState.drafts,page,draft,diskSame:localStorage.getItem('c2state')===stored})"))
