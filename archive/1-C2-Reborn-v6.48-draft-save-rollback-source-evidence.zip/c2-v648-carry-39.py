exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.48-draft-save-rollback-candidate.html'))
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';sel=0;galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'SavedTest',sourceName:'Photo0001.jpg'};draw();press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('One copy only after repeated OK',"press('OK');press('OK');return galEditor.stage==='saved'&&phoneState.galEditedImages.length===1")
t('Deleted edited image hidden',"phoneState.galDeleted=['SavedTest.gif'];return !galActualFiles('Images').some(f=>f.n==='SavedTest.gif')")
t('Copied edited source retained in destination',"phoneState.galDeleted=[];phoneState.galCopied={'SavedTest.gif':'Graphics'};return galActualFiles('Graphics').find(f=>f.n==='SavedTest.gif').src===phoneState.galEditedImages[0].src")
t('Moved edited source left source folder',"phoneState.galCopied={};phoneState.galMoved={'SavedTest.gif':'Graphics'};return !galActualFiles('Images').some(f=>f.n==='SavedTest.gif')&&galActualFiles('Graphics').find(f=>f.n==='SavedTest.gif').big===phoneState.galEditedImages[0].big")
t('Migrated moved bytes retained',"let d=migrateState(phoneState);return d.galEditedImages[0].src===phoneState.galEditedImages[0].src&&d.galMoved['SavedTest.gif']==='Graphics'")
t('Gallery edited filename alias honored',"phoneState.galMoved={};phoneState.galFileNames={'SavedTest.gif':'Renamed.gif'};return galFolderFiles().some(f=>f.n==='Renamed.gif'&&f.big===phoneState.galEditedImages[0].big)")
t('Renamed collision guarded',"galEditor.stage='saveName';galEditor.saveName='Renamed';press('OK');return galEditor.stage==='unsupported'&&phoneState.galEditedImages.length===1")
t('Old state no edited collection safe',"return migrateState({version:6}).galEditedImages.length===0")
t('Maximum records migration bounded',"let r=phoneState.galEditedImages[0];return migrateState({galEditedImages:Array(50).fill(r)}).galEditedImages.length===30")
t('Invalid folder bytes excluded',"return migrateState({galEditedImages:[{...phoneState.galEditedImages[0],folder:'Graphics'}]}).galEditedImages.length===0")
print('PASS',len(checks))
