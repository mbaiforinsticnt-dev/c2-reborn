from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.47-calendar-auto-delete-rollback-candidate.html').read_text().replace('v6.47 handset parity','v6.48 handset parity').replace('C2 Reborn v6.47 |','C2 Reborn v6.48 |')
a="function storeDraft(){let t=draft.trim();if(!t)return false;if(draftOpenIdx>=0)";b="function storeDraft(){let t=draft.trim();if(!t)return false;let beforeDrafts=JSON.parse(JSON.stringify(phoneState.drafts)),beforeDemo=JSON.parse(JSON.stringify(draftDemo));if(draftOpenIdx>=0)";assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.drafts=phoneState.drafts.slice(0,20)}persist();return true}";b="phoneState.drafts=phoneState.drafts.slice(0,20)}try{persist()}catch(err){phoneState.drafts=beforeDrafts;draftDemo.splice(0,draftDemo.length,...beforeDemo);notice='Unable to save draft';draw();return false}return true}";assert s.count(a)==1;s=s.replace(a,b)
a="if(composeExitConfirm){if(k==='LSK'||k==='OK'){storeDraft();persist();draft='';";b="if(composeExitConfirm){if(k==='LSK'||k==='OK'){if(!storeDraft())return;draft='';";assert s.count(a)==1;s=s.replace(a,b)
a="if(composeExitConfirm){s.insertAdjacentHTML";b="if(composeExitConfirm&&!notice){s.insertAdjacentHTML";assert s.count(a)==1;s=s.replace(a,b)
a='Unable to auto-delete calendar notes|Folder memory full|';b='Unable to auto-delete calendar notes|Unable to save draft|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.48-draft-save-rollback-candidate.html').write_text(s)
