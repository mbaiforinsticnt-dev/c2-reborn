import os
F=os.environ.get('C2F','c2-v6150-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({c:JSON.stringify(phoneState.contacts),stored:localStorage.getItem('c2state'),page,sel,open,os,sub:namesSubmenu,notice}))()"
def setup(which):
 print(ev("(()=>{phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('names');draw();press('LSK');let a=opts[page];os=a.indexOf('Marking options >')>=0?a.indexOf('Marking options >'):a.findIndex(x=>/Marking/.test(x));draw();press('OK');os=%d;draw();return {page,open,os,sub:namesSubmenu,opts:JSON.stringify(opts[page]),lcd:document.getElementById('screen').innerText.replace(/\\n/g,'|')}})()"%which))
for which,name in ((0,'Mark'),(1,'Mark all')):
 setup(which)
 b=ev(SN)
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{try{press('OK')}catch(e){return 'THROW '+e.message}return 'ok'})()")
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(name,'RESULT',r,'contacts same',b['c']==a['c'],'stored same',b['stored']==a['stored'],'notice',repr(a['notice']),'marked',ev("JSON.stringify(phoneState.contacts.map(x=>!!x.marked))"))
