import os
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+os.environ.get('C2F','c2-v6151-cand.html')))
res=[]
def t(n,v):print(n,v);res.append(v);assert v is True,n
def setup(W): ev("(()=>{phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('names');draw();press('LSK');os=opts[page].findIndex(x=>/Marking/.test(x));draw();press('OK');os=%d;draw()})()"%W)
HAS="phoneState.contacts.map(x=>Object.prototype.hasOwnProperty.call(x,'marked'))"
for W_,name,note in ((0,'Mark','Unable to mark contact'),(1,'Mark all','Unable to mark contacts')):
 setup(W_);b=ev("JSON.stringify(["+HAS+",phoneState.contacts])");st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 t(name+' press no throw',ev("(()=>{try{press('OK')}catch(e){return false}return true})()"))
 t(name+' contacts and own-property presence restored',ev("JSON.stringify(["+HAS+",phoneState.contacts])")==b)
 t(name+' notice',note in ev("document.getElementById('screen').innerText"))
 ev('Storage.prototype.setItem=oldStore;0')
 t(name+' storage unchanged',ev("localStorage.getItem('c2state')")==st)
 setup(W_);ev("press('OK')")
 t(name+' success marks',ev("phoneState.contacts.filter(x=>x.marked).length")==(1 if W_==0 else 3))
 t(name+' success persists',ev("JSON.parse(localStorage.getItem('c2state')).contacts.filter(x=>x.marked).length")==(1 if W_==0 else 3))
# pre-marked contact toggles back to unmarked on failure keeps marked true
setup(0);ev("phoneState.contacts[0].marked=true;persist();oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
ev("press('OK')");t('Mark premarked stays marked on failure',ev("phoneState.contacts[0].marked===true"));ev('Storage.prototype.setItem=oldStore;0')
print('checks',len(res))
