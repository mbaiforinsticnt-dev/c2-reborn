exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.88-player-completion-rollback-candidate.html'))
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for name in ['constructor','toString','__proto__']:
 raw=json.dumps({'galleryFolders':[name,'Destination'],'galFolderParents':{name:'Images','Destination':'Memory card'},'galFolderNames':{name:'RecoverMe'},'galFolderItems':[{'folder':name,'n':'record','s':'100 B'}]})
 ev('phoneState=migrateState(JSON.parse('+json.dumps(raw)+'));persist()')
 t(name+' Copy preserves records',"let r=galCopyFolderTo("+json.dumps(name)+",'Destination');return !r.error&&galFolderBytes(r.key)===100&&galDisplayName(r.key)==='RecoverMe'")
 t(name+' Move parent preserved',"phoneState.galFolderNames[phoneState.galleryFolders.find(k=>k.startsWith('foldercopy-'))]='Independent copy';let r=galMoveEmptyFolderTo("+json.dumps(name)+",'Destination');return !r.error&&galOwnText(phoneState.galFolderParents,"+json.dumps(name)+")==='Destination'")
 ev("page='foldername';open=false;notice='';galTarget=null;galRenameIdx=screens.gallery.length;galRenameOs=0;folderName='Recovered';draw();press('OK')")
 t(name+' Rename safe',"return phoneState.galleryFolders.includes('Recovered')&&phoneState.galFolderItems[0].folder==='Recovered'&&phoneState.galFolderParents.Recovered==='Destination'")
 call('Page.reload');time.sleep(.3)
 t(name+' Reload retains recovery',"return galFolderBytes('Recovered')===100&&phoneState.galFolderParents.Recovered==='Destination'")
 ev("page='gallery';open=false;notice='';galDialog='delfolder';galText='Recovered';press('LSK')")
 t(name+' Delete only recovered source',"return !phoneState.galleryFolders.includes('Recovered')&&phoneState.galFolderItems.length===1")
print('PASS',len(checks))
