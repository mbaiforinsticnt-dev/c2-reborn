from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.87-player-flags-rollback-candidate.html').read_text().replace('v6.87 handset parity','v6.88 handset parity').replace('C2 Reborn v6.87 |','C2 Reborn v6.88 |')
a='if(e>=90&&p.playing){p.playing=false;p.elapsed=0;persist();return 0}return e}'
b="if(e>=90&&p.playing){let beforePlaying=p.playing,beforeElapsed=p.elapsed;p.playing=false;p.elapsed=0;try{persist()}catch(err){p.playing=beforePlaying;p.elapsed=beforeElapsed;notice='Unable to save player';return e}return 0}return e}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.88-player-completion-rollback-candidate.html').write_text(s)
