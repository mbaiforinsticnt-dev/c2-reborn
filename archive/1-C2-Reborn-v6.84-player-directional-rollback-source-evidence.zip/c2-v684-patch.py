from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.83-calculator-mode-rollback-candidate.html').read_text().replace('v6.83 handset parity','v6.84 handset parity').replace('C2 Reborn v6.83 |','C2 Reborn v6.84 |')
repls=[("if(page==='player'&&['UP','DOWN','LEFT','RIGHT'].includes(k)){let p=phoneState.player;", "if(page==='player'&&['UP','DOWN','LEFT','RIGHT'].includes(k)){let beforePlayer=phoneState.player,beforeTick=playerTickBase,beforeLeft=playerLeftAt;phoneState.player={...beforePlayer};let p=phoneState.player;"), ("if(k==='DOWN')p.volume=Math.max(0,(Number(p.volume)||0)-1);persist();draw();return}", "if(k==='DOWN')p.volume=Math.max(0,(Number(p.volume)||0)-1);try{persist()}catch(err){phoneState.player=beforePlayer;playerTickBase=beforeTick;playerLeftAt=beforeLeft;notice='Unable to save player';draw();return}draw();return}")]
for a,b in repls:
 assert s.count(a)==1,a
 s=s.replace(a,b)
s=s.replace('Unable to save calculator mode|Folder memory full','Unable to save calculator mode|Unable to save player|Folder memory full')
s=s.replace("<span>'+notice+'</span>","<span style=\"color:inherit\">'+notice+'</span>")
Path('/downloads/C2-Reborn-v6.84-player-directional-rollback-candidate.html').write_text(s)
