from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.06-gallery-delete-rollback-candidate.html').read_text().replace('v6.06 handset parity','v6.07 handset parity').replace('C2 Reborn v6.06 |','C2 Reborn v6.07 |')
a='function galFolderSource()'
b="function galFolderEditSnapshot(){return {galleryFolders:phoneState.galleryFolders.slice(),galFolderItems:phoneState.galFolderItems.map(f=>({...f})),galFolderParents:{...phoneState.galFolderParents},galFolderNames:{...phoneState.galFolderNames},galFolderAliases:{...phoneState.galFolderAliases},galMoved:{...phoneState.galMoved},galCopied:{...phoneState.galCopied},galFolderSerial:phoneState.galFolderSerial}}\nfunction galFolderSource()"
assert s.count(a)==1;s=s.replace(a,b)
a="let key=name;while(screens.gallery.includes(key)"
b="let folderRollback=galFolderEditSnapshot();let key=name;while(screens.gallery.includes(key)"
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.galFolderParents[key]=parent;persist();folderName='';galTarget.adding=false"
b="phoneState.galFolderParents[key]=parent;try{persist()}catch(err){Object.assign(phoneState,folderRollback);notice='Unable to save folder name';draw();return}folderName='';galTarget.adding=false"
assert s.count(a)==1;s=s.replace(a,b)
a="else if(page==='foldername'){if(folderName.trim()){if(galRenameIdx>=0)"
b="else if(page==='foldername'){if(folderName.trim()){let folderRollback=galFolderEditSnapshot();if(galRenameIdx>=0)"
assert s.count(a)==1;s=s.replace(a,b)
p=s.find(b);e=s.find("else if(page==='btnameedit')",p);t=s[p:e];assert t.count('persist()')==3
t=t.replace("persist()","(()=>{try{persist()}catch(err){Object.assign(phoneState,folderRollback);throw err}})()")
# catch within this folder-only branch, preserving editor state on failure
start=t.find('let folderRollback=galFolderEditSnapshot();')+len('let folderRollback=galFolderEditSnapshot();')
stop=t.find("folderName='',urlEntry='';")
t=t[:start]+'try{'+t[start:stop]+"}catch(err){notice='Unable to save folder name';draw();return}"+t[stop:]
s=s[:p]+t+s[e:];s=s.replace('Fax not activated|Unable to save deletion','Fax not activated|Unable to save folder name|Unable to save deletion',1)
Path('/downloads/C2-Reborn-v6.07-folder-edit-rollback-candidate.html').write_text(s)
