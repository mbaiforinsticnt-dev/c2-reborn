C2 Reborn v6.172 (source evidence)
Base: v6.171 (blob 8a2df291). Each lead below was reproduced on v6.171 first (emulator/CDP, not handset). Source: Tab addendum v6.170 (unverified leads).
- D1: middle key labelled "Save" on the dialler now saves the number (opens New contact). It placed a call before. Call key still calls. Label-driven; handset behaviour not footage-proven.
- S1: unlabelled left softkey no longer acts as Select in radio lists. OK still selects.
- GA1: Gallery rename refuses an empty name before the extension (was saved as ".jpg").
- N4 (Log/Dial Options End), N5 (factory explanation End), CD1 (call divert number End): already fixed by v6.171 End rule; tests added.
Not reproduced / not fixed: radio softkeys, interval timer redraw, Media All songs static page, other addendum stub groups.
Focused tests: 20/20.
