import os,sys,json
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+os.environ.get('C2F','c2-v6151-cand.html')))
print('flips',ev("Object.keys(PICKER_FLIPS).join(',')"))
SN="(()=>({ps:JSON.stringify(phoneState),stored:localStorage.getItem('c2state'),page,sel,open,notice}))()"
out=[]
def trial(pg,row,keys):
 call('Page.navigate',{'url':'file:///tmp/'+os.environ.get('C2F','c2-v6151-cand.html')});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('%s');sel=%d;draw()})()"%(pg,row))
 ev("window.__t=[]")
 ev("oldStore=Storage.prototype.setItem;0")
 b=ev(SN)
 ev("Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{let o=[];for(const k of %s){try{press(k)}catch(e){o.push(k+' THROW '+e.message)}}return o})()"%json.dumps(keys))
 import time as T;T.sleep(0.8)
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 same=(a['ps']==b['ps'])
 return (pg,row,keys,r,'stateSame',same,'stored same',a['stored']==b['stored'],'notice',a['notice'])
for pg,row in json.loads(os.environ.get('CASES','[["bluetooth",0],["bluetooth",4]]')):
 print(trial(pg,row,['OK','DOWN','OK']))
