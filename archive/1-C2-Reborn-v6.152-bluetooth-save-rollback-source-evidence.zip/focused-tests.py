import os
F=os.environ.get('C2F','c2-v6152-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v);assert v is True,n
def fresh(pre=""):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);"+pre+"persist();page='home';history=[];open=false;notice='';btBusy='';go('bluetooth');sel=0;draw()})()")
PS="JSON.stringify(phoneState)"
def failon(): ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
def failoff(): ev("Storage.prototype.setItem=oldStore;0")
def press(keys): return ev("(()=>{for(const k of %s){try{press(k)}catch(e){return 'THROW '+e.message}}return 'ok'})()"%str(keys))
def case(name,pre,sel,keys,wait=0,extra_pre=None):
 fresh(pre);ev("sel=%d;draw()"%sel)
 b=ev(PS);st=ev("localStorage.getItem('c2state')");failon()
 r=press(keys)
 if wait:time.sleep(wait)
 a=ev(PS);busy=ev("btBusy");conf=ev("btVisConfirm");note=ev("notice");failoff()
 t(name+' no throw',r=='ok');t(name+' state restored',a==b);t(name+' storage unchanged',ev("localStorage.getItem('c2state')")==st);t(name+' not stuck busy',busy=='');return note
n=case('vis row4',"",4,['OK','DOWN','OK']);t('vis notice',n=='Unable to save Bluetooth setting')
case('bt On after Yes (LSK)',"",0,['OK','UP','OK','LSK'],3.5)
case('bt On after No (RSK)',"",0,['OK','UP','OK','RSK'],3.5)
case('bt Off',"phoneState.bluetooth=true;",0,['OK','DOWN','OK'],3.5)
fresh("");ev("bluetoothPrompt=true");b=ev(PS);failon();r=press(['LSK']);a=ev(PS);n=ev("notice");p=ev("bluetoothPrompt");failoff()
t('prompt no throw',r=='ok');t('prompt state restored',a==b);t('prompt kept open with notice',p is True and n=='Unable to save Bluetooth setting')
# success paths
fresh("");press(['OK','UP','OK','LSK']);time.sleep(3.5);t('success On persisted',ev("JSON.parse(localStorage.getItem('c2state')).bluetooth")is True and ev("JSON.parse(localStorage.getItem('c2state')).btVis")=='Shown to all' and ev("btBusy")=='')
fresh("phoneState.bluetooth=true;");press(['OK','DOWN','OK']);time.sleep(3.5);t('success Off persisted',ev("JSON.parse(localStorage.getItem('c2state')).bluetooth")is False)
fresh("");ev("sel=4;draw()");press(['OK','DOWN','OK']);t('success vis persisted',ev("JSON.parse(localStorage.getItem('c2state')).btVis")!=None)
print('checks',len(res))
