import os
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+os.environ.get('C2F','c2-v6151-cand.html')))
SN="(()=>({v:phoneState.timerValue,e:phoneState.timerEndsAt,stored:localStorage.getItem('c2state'),page,hist:history.length,notice,tp:JSON.stringify(timerParts)}))()"
def fail(on=True): ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0" if on else "Storage.prototype.setItem=oldStore;0")
print(ev("(()=>{phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('organiser');sel=Math.max(0,screens.organiser.indexOf('Countd. timer'));draw();press('OK');return {page,lcd:document.getElementById('screen').innerText.replace(/\\n/g,'|'),tp:JSON.stringify(timerParts)}})()"))
ev("sel=0;draw();press('OK');timerParts=['00','00','10'];draw()");print(ev("[page,document.getElementById('screen').innerText.replace(/\\n/g,'|')]"));
b=ev(SN);fail()
r=ev("(()=>{let o=[];for(const k of ['OK','OK']){try{press(k);o.push(k+':'+page)}catch(e){o.push(k+' THROW '+e.message+' page '+page)}}return o})()")
a=ev(SN);fail(False)
print('RESULT',r);print('before',{k:b[k] for k in b if k!='stored'});print('after',{k:a[k] for k in a if k!='stored'},'stored same',a['stored']==b['stored'])
