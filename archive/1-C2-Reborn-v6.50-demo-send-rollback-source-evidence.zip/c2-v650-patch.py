from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.49-message-folder-save-rollback-candidate.html').read_text().replace('v6.49 handset parity','v6.50 handset parity').replace('C2 Reborn v6.49 |','C2 Reborn v6.50 |')
a="let num=nums[0],key=num.replace(/\D/g,'')===CONV_NUMBER"
b="let beforeStore=JSON.parse(JSON.stringify(messageStore)),beforeRecipients=phoneState.messageRecipients.slice(),beforeConversation={key:conversationKey,number:conversationNumber,name:conversationName};let num=nums[0],key=num.replace(/\D/g,'')===CONV_NUMBER"
assert s.count(a)==1;s=s.replace(a,b)
a="conversationName=contactLabel(num);persist();draft='';"
b="conversationName=contactLabel(num);try{persist()}catch(err){messageStore=beforeStore;phoneState.messageStore=messageStore;phoneState.messageRecipients=beforeRecipients;conversationKey=beforeConversation.key;conversationNumber=beforeConversation.number;conversationName=beforeConversation.name;notice='Unable to save sent message';draw();return}draft='';"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save message|Folder memory full|';b='Unable to save message|Unable to save sent message|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.50-demo-send-rollback-candidate.html').write_text(s)
