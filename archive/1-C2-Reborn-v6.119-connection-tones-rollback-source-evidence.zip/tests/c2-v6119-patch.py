from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.118-direct-mark-all-rollback-candidate.html').read_text().replace('v6.118 handset parity','v6.119 handset parity').replace('C2 Reborn v6.118 |','C2 Reborn v6.119 |')
repls=[("if(p==='intphone'){phoneState.connTones=v;persist();return}", "if(p==='intphone'){let had=Object.prototype.hasOwnProperty.call(phoneState,'connTones'),before=phoneState.connTones;phoneState.connTones=v;try{persist()}catch(err){if(had)phoneState.connTones=before;else delete phoneState.connTones;notice='Unable to save connection tones';return false}return true}"), ('pickerCommit(_rp,radioCtx.row,_rv);persist();', 'if(pickerCommit(_rp,radioCtx.row,_rv)===false){draw();return}if(_rp!=="intphone")persist();'), ("pickerCommit(pickerDraft.page,pickerDraft.row,pickerDraft.value);if(pickerDraft.page==='fontsize')", "if(pickerCommit(pickerDraft.page,pickerDraft.row,pickerDraft.value)===false){draw();return true}if(pickerDraft.page==='fontsize')")]
for a,b in repls:
 assert s.count(a)==1
 s=s.replace(a,b)
s=s.replace('Unable to save conversation marks|Folder memory full','Unable to save conversation marks|Unable to save connection tones|Folder memory full');Path('/downloads/C2-Reborn-v6.119-connection-tones-rollback-candidate.html').write_text(s)
