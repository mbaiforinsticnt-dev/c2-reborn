exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.119-connection-tones-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['OK','LSK']:
 for dirty in [False,True]:
  ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);beforePrefs=phoneState.calPrefs;stored=localStorage.getItem('c2state');page='caldatetime';calSavePrompt=true;calDateDraft='02-10-2026';calTimeDraft='09:15';calZoneDraft='GMT';calDstDraft=1;calDateDirty="+str(dirty).lower()+";history=['calsettings'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press("+json.dumps(key)+")")
  label=key+str(dirty)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.calPrefs===beforePrefs&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save date and time'&&document.getElementById('screen').innerText.includes(notice)&&calSavePrompt&&calDateDirty==="+str(dirty).lower()+"&&page==='caldatetime'&&history.length===1&&calDateDraft==='02-10-2026'&&calTimeDraft==='09:15'")
  if key=='OK' and dirty:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6104-clock-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press("+json.dumps(key)+")")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press("+json.dumps(key)+")")
  t(label+' retry',"return phoneState.calPrefs.dst===1&&phoneState.calPrefs.zone==='GMT'&&phoneState.calPrefs.clockAt===new Date(2026,9,2,9,15).getTime()&&phoneState.calPrefs.clockSavedAt>0&&!calSavePrompt&&!calDateDirty&&page==='calsettings'")
  saved=ev('JSON.stringify(phoneState.calPrefs)');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(phoneState.calPrefs)==="+json.dumps(saved))
print('PASS',len(checks))
