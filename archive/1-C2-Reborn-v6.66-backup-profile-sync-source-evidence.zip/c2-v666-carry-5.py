exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.66-backup-profile-sync-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['template','templatefolder','saved']:
 act='saveAsTemplate()' if mode=='template' else "saveToFolder("+json.dumps('Templates' if mode=='templatefolder' else 'Saved messages')+")"
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='compose';draft='New message';recipientText='Alex';composeSubject='Subject';cursor=4;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact storage rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' composer retained',"return page==='compose'&&draft==='New message'&&recipientText==='Alex'&&composeSubject==='Subject'&&cursor===4")
 t(mode+' visible warning',"return notice==="+json.dumps('Unable to save message' if mode=='saved' else 'Unable to save template')+"&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='saved':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v649-message-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="messageStore.saved.filter(x=>x.body==='New message').length===1&&messageStore.saved[0].to==='Alex'" if mode=='saved' else "phoneState.templates.filter(x=>x==='New message').length===1"
 t(mode+' retry commits once',"return "+expect+"&&draft===''&&recipientText===''")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
