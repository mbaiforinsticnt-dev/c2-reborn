from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.65-backup-theme-sync-candidate.html').read_text().replace('v6.65 handset parity','v6.66 handset parity').replace('C2 Reborn v6.65 |','C2 Reborn v6.66 |')
a="phoneState.messageStore=messageStore;try{persist()}catch(err){phoneState=beforeState;messageStore=beforeStore;notice='Unable to restore backup'"
b="phoneState.messageStore=messageStore;phoneState.tones=profileToneStore(phoneState.profile);phoneState.flight=(phoneState.profile==='Flight');try{persist()}catch(err){phoneState=beforeState;messageStore=beforeStore;notice='Unable to restore backup'"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.66-backup-profile-sync-candidate.html').write_text(s)
