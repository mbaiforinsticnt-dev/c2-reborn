exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.116-thread-mark-all-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['OK','LSK']:
 for existing in [False,True]:
  ev("phoneState=migrateState(null);"+("phoneState.homeColor='#112233'" if existing else "delete phoneState.homeColor")+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='colourpicker';sel=2;history=['display'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
  t(key+str(existing)+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
  t(key+str(existing)+' selection/context retained',"return page==='colourpicker'&&sel===2&&history.length===1&&notice==='Unable to save home colour'&&document.getElementById('screen').innerText.includes(notice)")
  if key=='OK' and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v682-home-colour-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('"+key+"')")
  t(key+str(existing)+' repeat failure exact',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
  t(key+str(existing)+' retry saves and leaves',"return phoneState.homeColor===COLOUR_PALETTE[2]&&page==='display'&&JSON.parse(localStorage.getItem('c2state')).homeColor===COLOUR_PALETTE[2]")
  call('Page.reload');time.sleep(.15)
  t(key+str(existing)+' reload exact',"return phoneState.homeColor===COLOUR_PALETTE[2]")
print('PASS',len(checks))
