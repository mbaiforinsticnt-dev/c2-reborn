exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.116-thread-mark-all-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for profile in ['General','Silent','Meeting','Outdoor','My style 1','My style 2']:
 ev("phoneState=migrateState(null);phoneState.profile="+json.dumps(profile)+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='home';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};pressHold('#')")
 t(profile+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(profile+' warning',"return notice==='Unable to save profile'&&document.getElementById('screen').innerText.includes(notice)&&page==='home'")
 if profile=='General':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v694-profile-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';pressHold('#')")
 t(profile+' repeat failure',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';pressHold('#')")
 t(profile+' retry',"return phoneState.profile==="+json.dumps('General' if profile=='Silent' else 'Silent')+"&&notice===phoneState.profile+' profile activated'")
 call('Page.reload');time.sleep(.15)
 t(profile+' reload',"return phoneState.profile==="+json.dumps('General' if profile=='Silent' else 'Silent'))
print('PASS',len(checks))
