exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.116-thread-mark-all-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for field in ['user','pass']:
 for existing in [False,True]:
  prop='syncUser' if field=='user' else 'syncPass'
  ev("phoneState=migrateState(null);"+("phoneState["+json.dumps(prop)+"]='Prior demo';" if existing else "delete phoneState["+json.dumps(prop)+"];")+"persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='"+('pcsyncname' if field=='user' else 'pcsyncpass')+"';syncEditing=true;syncField="+json.dumps(field)+";syncDraft='New demo';history=['sync'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=field+str(existing)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save sync setting'&&document.getElementById('screen').innerText.includes(notice)&&syncEditing&&syncDraft==='New demo'&&history.length===1")
  if field=='user' and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6106-sync-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return phoneState["+json.dumps(prop)+"]==='New demo'&&!syncEditing")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState["+json.dumps(prop)+"]==='New demo'")
print('PASS',len(checks))
