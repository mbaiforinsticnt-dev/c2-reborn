exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.116-thread-mark-all-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['helper','calopen','all','until']:
 act="calOvPick("+json.dumps('All notes' if mode=='all' else 'All until today')+")" if mode in ['all','until'] else ("calDeleteAt(1);draw()" if mode=='helper' else "open=true;os=currentOptions().indexOf('Delete');press('OK')")
 ev("phoneState=migrateState(null);let d=new Date();let future=new Date(d.getFullYear(),d.getMonth(),d.getDate()+1);let past=new Date(d.getFullYear(),d.getMonth(),d.getDate()-1);phoneState.calendar=[{type:'Reminder',text:'Past',date:fmtCalDate(past),repeat:'Never',alarm:false,time:''},{type:'Reminder',text:'Today',date:fmtCalDate(d),repeat:'Never',alarm:false,time:''},{type:'Reminder',text:'Future',date:fmtCalDate(future),repeat:'Never',alarm:false,time:''}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);calDate=d;page="+json.dumps(mode if mode=='calopen' else 'calendar')+";sel="+('0' if mode=='calview' else '1')+";calNoteView=1;calOv="+json.dumps('delnotes' if mode in ['all','until'] else '')+";open=false;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact calendar rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' page selection retained',"return page==="+json.dumps(mode if mode=='calopen' else 'calendar')+"&&sel==="+('0' if mode=='calview' else '1')+"&&calNoteView===1")
 t(mode+' visible warning',"return notice==="+json.dumps('Unable to delete calendar notes' if mode in ['all','until'] else 'Unable to delete calendar note')+"&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='all':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v643-calendar-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="phoneState.calendar.length===0" if mode=='all' else ("phoneState.calendar.length===1&&phoneState.calendar[0].text==='Future'" if mode=='until' else "phoneState.calendar.length===2&&phoneState.calendar[0].text==='Past'&&phoneState.calendar[1].text==='Future'")
 t(mode+' retry intended deletion once',"return "+expect)
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
