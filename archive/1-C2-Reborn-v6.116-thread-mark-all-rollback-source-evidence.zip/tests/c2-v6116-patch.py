from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.115-conversation-filter-exit-rollback-candidate.html').read_text().replace('v6.115 handset parity','v6.116 handset parity').replace('C2 Reborn v6.115 |','C2 Reborn v6.116 |')
a='conversationMarkMenu=false;threadMessages().forEach(m=>m.marked=true);persist()'
b="let messages=threadMessages(),beforeMarks=messages.map(m=>({m,had:Object.prototype.hasOwnProperty.call(m,'marked'),marked:m.marked}));messages.forEach(m=>m.marked=true);try{persist()}catch(err){beforeMarks.forEach(x=>{if(x.had)x.m.marked=x.marked;else delete x.m.marked});notice='Unable to mark messages';draw();return}conversationMarkMenu=false"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save conversation filter|Folder memory full','Unable to save conversation filter|Unable to mark messages|Folder memory full')
Path('/downloads/C2-Reborn-v6.116-thread-mark-all-rollback-candidate.html').write_text(s)
