import os,json
F=os.environ.get('C2F','c2-v6153-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v);assert v is True,n
GD="['Lock keypad','Profiles','Alarm clock','Camera','Video recorder','Bluetooth menu','Calendar','Calculator','Flight']"
SN="(()=>({ps:JSON.stringify(phoneState),sc:gotoSaveConfirm,cd:gotoCheckDirty,od:gotoOrgDirty,ms:menuSaveConfirm,sd:galSortDir,gs:JSON.stringify(screens.goto),sub:pageSub,ps2}))()"
def fresh(): 
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);phoneState.gotoOrder="+GD+";screens.goto=phoneState.gotoOrder;persist();page='home';history=[];open=false;notice=''})()")
def keys(k): return ev("(()=>{for(const x of %s){try{press(x)}catch(e){return 'THROW '+e.message}}return 'ok'})()"%json.dumps(k))
def case(name,setup,k,note,persisted=None,extra=None):
 fresh();ev("(()=>{"+setup+"})()");b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=keys(k);a=ev(SN);n=ev("notice");ev('Storage.prototype.setItem=oldStore;0')
 t(name+' no throw',r=='ok');t(name+' state unchanged',a==b or (extra and extra(a,b)));t(name+' storage unchanged',ev("localStorage.getItem('c2state')")==st);t(name+' notice',n==note)
 if persisted:
  fresh();ev("(()=>{"+setup+"})()");keys(k);t(name+' success persists',ev(persisted))
case('gotocheck',"page='gotocheck';sel=1;open=false;history=['home'];draw()",['OK'],'Unable to save Go to list',"JSON.stringify(JSON.parse(localStorage.getItem('c2state')).gotoOrder)!=JSON.stringify("+GD+")")
case('gotoapps',"page='gotoapps';sel=0;open=false;history=['home'];draw()",['OK'],'Unable to save Go to list',"JSON.stringify(JSON.parse(localStorage.getItem('c2state')).gotoOrder)!=JSON.stringify("+GD+")")
case('gotoorg drop',"page='gotoorg';sel=0;open=false;history=['home'];gotoGrab=0;gotoGrabFrom=0;draw()",['OK'],'Unable to save Go to order',"gotoGrab==-1")
case('goto discard',"page='gotocheck';sel=0;open=false;history=['home'];gotoCheckBase=phoneState.gotoOrder.slice(0,3).join('||');gotoCheckDirty=true;gotoSaveConfirm=true;draw()",['LSK'],'Unable to save Go to list',"JSON.parse(localStorage.getItem('c2state')).gotoOrder.length==3")
case('menu save',"go('menu');menuOriginalOrder=phoneState.menuOrder.slice();phoneState.menuOrder=[1,0,2,3,4,5,6,7,8];menuSaveConfirm=true;draw()",['OK'],'Unable to save menu order',"JSON.parse(localStorage.getItem('c2state')).menuOrder[0]==1")
def lab(l,p2,two=None): return "go('gallery');draw();press('LSK');os=(opts[page]||opts.gallery).findIndex(x=>x===%s);draw();press('OK');ps2=%d;draw();%s"%(json.dumps(l),p2,("press('OK');ps2=%d;draw()"%two) if two is not None else "")
case('galview',lab('Type of view \u25b8',1),['OK'],'Unable to save view',"JSON.parse(localStorage.getItem('c2state')).galView=='List'")
case('galsortdir',lab('Sort \u25b8',2,1),['OK'],'Unable to save sort order',"JSON.parse(localStorage.getItem('c2state')).galSort=='By format Descending'")
print('checks',len(res))
