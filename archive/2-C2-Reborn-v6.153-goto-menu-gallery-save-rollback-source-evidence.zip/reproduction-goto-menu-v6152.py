import os,json
F=os.environ.get('C2F','c2-v6152-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({ps:JSON.stringify(phoneState),page,sel,notice,gd:gotoGrab,sc:gotoSaveConfirm,cd:gotoCheckDirty,od:gotoOrgDirty,ms:menuSaveConfirm,me:typeof menuEditing!=='undefined'?menuEditing:null,gs:JSON.stringify(screens.goto)}))()"
CASES={
'gotocheck OK':("page='gotocheck';sel=0;open=false;history=['home'];draw()",['OK']),
'gotoapps OK':("page='gotoapps';sel=0;open=false;history=['home'];draw()",['OK']),
'gotoorg drop':("page='gotoorg';sel=0;open=false;history=['home'];gotoGrab=-1;draw()",['OK','OK']),
'goto discard LSK':("page='gotocheck';sel=0;open=false;history=['home'];gotoCheckBase=phoneState.gotoOrder.slice(0,3).join('||');gotoCheckDirty=true;gotoSaveConfirm=true;draw()",['LSK']),
'menu save OK':("go('menu');menuOriginalOrder=phoneState.menuOrder.slice();menuSaveConfirm=true;draw()",['OK']),
'menu discard LSK':("go('menu');menuOriginalOrder=phoneState.menuOrder.slice().reverse();menuEditing=true;menuSaveConfirm=true;draw()",['LSK']),
}
for n,(setup,keys) in CASES.items():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);phoneState.gotoOrder=['Lock keypad','Profiles','Alarm clock','Camera','Video recorder','Bluetooth menu','Calendar','Calculator','Flight'];screens.goto=phoneState.gotoOrder;persist();page='home';history=[];open=false;notice=''})()")
 print(n,'setup',ev("(()=>{"+setup+";return page})()"))
 b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{let o=[];for(const k of %s){try{press(k)}catch(e){o.push(k+' THROW '+e.message)}}return o})()"%json.dumps(keys))
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(n,'->',r,'diff',[k for k in b if b[k]!=a[k]],'storedSame',ev("localStorage.getItem('c2state')")==st)
