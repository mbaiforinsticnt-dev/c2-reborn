import os,json
F=os.environ.get('C2F','c2-v6153-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({ps:JSON.stringify(phoneState),has:[Object.prototype.hasOwnProperty.call(phoneState,'galView'),Object.prototype.hasOwnProperty.call(phoneState,'galSort')],sd:galSortDir,sb:galSortBy,page,open,sub:pageSub,ps2,notice}))()"
def run(name,label,ps2v,second=None):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('gallery');draw();press('LSK');let a=opts[page]||opts.gallery;os=a.findIndex(x=>x===%s);draw();press('OK');ps2=%d;draw()})()"%(json.dumps(label),ps2v))
 if second: ev("press('OK');ps2=%d;draw()"%second)
 print(name,'setup',ev("[page,open,pageSub,ps2]"))
 b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{try{press('OK')}catch(e){return 'THROW '+e.message}return 'ok'})()")
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(name,'->',r,'diff',[k for k in b if b[k]!=a[k]],'storedSame',ev("localStorage.getItem('c2state')")==st,'notice',a['notice'])
 return b,a
run('galview','Type of view \u25b8',1)
run('galsortdir','Sort \u25b8',2,1)
