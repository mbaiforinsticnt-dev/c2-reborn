from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.43-calendar-delete-rollback-candidate.html').read_text().replace('v6.43 handset parity','v6.44 handset parity').replace('C2 Reborn v6.43 |','C2 Reborn v6.44 |')
a="if(noteEditingExisting)phoneState.notes[noteIndex]=noteText.trim();else{phoneState.notes.unshift(noteText.trim());phoneState.noteStamps.unshift(noteStamp());noteIndex=0}persist();noteText='';noteEditingExisting=false;"
b="let beforeNotes=phoneState.notes.slice(),beforeStamps=phoneState.noteStamps.slice(),beforeIndex=noteIndex;if(noteEditingExisting)phoneState.notes[noteIndex]=noteText.trim();else{phoneState.notes.unshift(noteText.trim());phoneState.noteStamps.unshift(noteStamp());noteIndex=0}try{persist()}catch(err){phoneState.notes=beforeNotes;phoneState.noteStamps=beforeStamps;noteIndex=beforeIndex;notice='Unable to save note';draw();return}noteText='';noteEditingExisting=false;"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to delete calendar notes?|Folder memory full|';b='Unable to delete calendar notes?|Unable to save note|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.44-note-save-rollback-candidate.html').write_text(s)
