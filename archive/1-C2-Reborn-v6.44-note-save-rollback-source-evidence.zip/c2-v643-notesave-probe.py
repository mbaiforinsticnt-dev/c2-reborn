exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.43-calendar-delete-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');page='textnote';noteEditingExisting=false;noteText='New note';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({notes:phoneState.notes,stamps:phoneState.noteStamps,page,noteText,diskSame:localStorage.getItem('c2state')===stored})"))
