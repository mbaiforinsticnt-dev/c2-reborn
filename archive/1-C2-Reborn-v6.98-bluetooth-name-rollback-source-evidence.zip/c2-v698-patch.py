from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.97-alarm-time-rollback-candidate.html').read_text().replace('v6.97 handset parity','v6.98 handset parity').replace('C2 Reborn v6.97 |','C2 Reborn v6.98 |')
a="else if(page==='btnameedit'){phoneState.btName=btNameBuf;persist();notice='Name saved';draw();"
b="else if(page==='btnameedit'){let hadName=Object.prototype.hasOwnProperty.call(phoneState,'btName'),beforeName=phoneState.btName;phoneState.btName=btNameBuf;try{persist()}catch(err){if(hadName)phoneState.btName=beforeName;else delete phoneState.btName;notice='Unable to save Bluetooth name';draw();return}notice='Name saved';draw();"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save alarm time|Folder memory full','Unable to save alarm time|Unable to save Bluetooth name|Folder memory full')
Path('/downloads/C2-Reborn-v6.98-bluetooth-name-rollback-candidate.html').write_text(s)
