exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.98-bluetooth-name-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(label,expr):
 v=ev(expr);checks.append((label,v));print(label,v);assert v is True,(label,v)
def keys(*ks):
 for k in ks:ev('press('+json.dumps(k)+')')
def snap(name):
 d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v581-'+name+'.png','wb').write(base64.b64decode(d['result']['data']))
ev("phoneState.alarm={on:true,time:'09:00',repeat:false,tone:'Standard',snooze:10,days:[]};go('alarmclock')")
keys('DOWN','9');t('partial hour',"alarmTimeDisplay(alarmDraft.time)==='9:00'&&alarmDraft.time==='09:00'");snap('partial-hour')
keys('9');t('99 hour clamp and advance',"alarmDraft.time==='23:00'&&alarmDigit===1&&alarmEntry===''")
keys('9');t('partial minute',"alarmTimeDisplay(alarmDraft.time)==='23:9'");snap('partial-minute')
keys('9');t('99 minute clamp and advance',"alarmDraft.time==='23:59'&&alarmDigit===0");snap('clamped')
keys('2','4');t('24 hour clamp',"alarmDraft.time==='23:59'&&alarmDigit===1")
keys('6','0');t('60 minute clamp',"alarmDraft.time==='23:59'&&alarmDigit===0")
keys('0');t('partial zero',"alarmTimeDisplay(alarmDraft.time)==='0:59'")
keys('RIGHT');t('pad on leave',"alarmTimeDisplay(alarmDraft.time)==='00:59'&&alarmEntry===''")
keys('0','0');t('zero minutes',"alarmDraft.time==='00:00'")
keys('2','3','5','8');t('legal time',"alarmDraft.time==='23:58'")
keys('DOWN','DOWN','DOWN','0');t('partial snooze zero allowed',"alarmDraft.snooze==='0'")
keys('UP');t('leaving snooze clamps pads',"alarmDraft.snooze==='02'&&alarmEntry===''")
keys('DOWN','0','OK');t('save finalizes partial snooze',"alarmMode==='saved'&&phoneState.alarm.snooze===2&&phoneState.alarm.time==='23:58'")
print('PASS',len(checks))
