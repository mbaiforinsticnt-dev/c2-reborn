exec(open("/tmp/hdr.py").read())
fresh2();ev("go('addcontact')");S('7');print('first',repr(ev("cfVal(0)")));S('7');print('cycled',repr(ev("cfVal(0)")))
import time;time.sleep(1.8);S('7');print('next char',repr(ev("cfVal(0)")))
fresh2();ev("startMessage('','07700900999')");ev("composeFocus=1");S('4');S('4');print('compose',repr(ev('draft')));time.sleep(1.8);S('4');print(repr(ev('draft')))
