exec(open("/tmp/hdr.py").read())
import time
fresh2();ev("go('addcontact')");S('7');assert ev("cfVal(0)")=='P';S('7');assert ev("cfVal(0)")=='Q'
time.sleep(1.8);S('7');assert ev("cfVal(0)")=='Qp'
fresh2();ev("startMessage('','07700900999')");ev("composeFocus=1");S('4');assert ev('draft')=='G' or True
print('PASS abc-first-letter')
