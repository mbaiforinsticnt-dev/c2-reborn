# C2 Reborn v6.178 (source-evidence)
Change: first letter of a sentence is capitalised in Abc/T9 (lowercase) mode in contact form, notes and message compose; ABC and 123 unchanged. Source: Tab lead 3 (unverified), reproduced on v6.177: typing 7 gave "p".
Evidence class: inferred from standard Nokia S40 behaviour, not C2-01 handset-proven.
Reproduced but NOT fixed: new conversation lands at row 179 under demo fillers (deferred, touches ~7 index sites).
Not tested: held Clear/long-press digits, home number in contact view, End from symbol picker, Drafts Delete (Delete handler exists in code).
Correction: banked v6.177 zip image emu-6260-interval-timers.png is wrong (empty Gallery). Correct 6260 evidence image: shows "Timer name:" form; 6260 profile, not C2-01 proof.
