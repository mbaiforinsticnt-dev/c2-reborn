from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.33-contact-save-rollback-candidate.html').read_text().replace('v6.33 handset parity','v6.34 handset parity').replace('C2 Reborn v6.33 |','C2 Reborn v6.34 |')
a="if(k==='OK'){contactDeleteConfirm=null;open=false;let i=phoneState.contacts.indexOf(pending.record);if(i>=0){phoneState.contacts.splice(i,1);sel=Math.max(0,Math.min(pending.index,namesContacts().length-1));contactIndex=0;persist()}if(page==='contact')go('names');else draw();return}"
b="if(k==='OK'){let previousContacts=phoneState.contacts.slice(),previousSel=sel,previousIndex=contactIndex,previousOpen=open;open=false;let i=phoneState.contacts.indexOf(pending.record);if(i>=0){phoneState.contacts.splice(i,1);sel=Math.max(0,Math.min(pending.index,namesContacts().length-1));contactIndex=0;try{persist()}catch(err){phoneState.contacts=previousContacts;sel=previousSel;contactIndex=previousIndex;open=previousOpen;notice='Unable to delete contact';draw();return}}contactDeleteConfirm=null;if(page==='contact')go('names');else draw();return}"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save contact|Folder memory full|';b='Unable to save contact|Unable to delete contact|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('if(contactDeleteConfirm){s.insertAdjacentHTML','if(contactDeleteConfirm&&!notice){s.insertAdjacentHTML')
Path('/downloads/C2-Reborn-v6.34-contact-delete-rollback-candidate.html').write_text(s)
