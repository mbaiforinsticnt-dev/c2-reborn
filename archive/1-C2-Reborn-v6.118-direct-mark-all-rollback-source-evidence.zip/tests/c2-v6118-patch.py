from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.117-conversation-mark-menu-rollback-candidate.html').read_text().replace('v6.117 handset parity','v6.118 handset parity').replace('C2 Reborn v6.117 |','C2 Reborn v6.118 |')
a="if(c==='Mark all'){messageStore.marked=visibleRows().map(rowKey);persist();draw();return}"
b="if(c==='Mark all'){let beforeMarks=messageStore.marked;messageStore.marked=visibleRows().map(rowKey);try{persist()}catch(err){messageStore.marked=beforeMarks;open=true;notice='Unable to save conversation marks';draw();return}draw();return}"
assert s.count(a)==1;s=s.replace(a,b);Path('/downloads/C2-Reborn-v6.118-direct-mark-all-rollback-candidate.html').write_text(s)
