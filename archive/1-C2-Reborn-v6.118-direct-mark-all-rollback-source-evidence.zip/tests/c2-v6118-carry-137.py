exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.118-direct-mark-all-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for absent in [False,True]:
 for pane in ['view','dir']:
  for choice in range(3 if pane=='view' else 8):
   sort=0 if pane=='view' else choice//2;selchoice=choice if pane=='view' else choice%2
   key='galView' if pane=='view' else 'galSort'
   expected=['List with details','List','Grid'][choice] if pane=='view' else ['By name','By date','By format','By size'][sort]+' '+['Ascending','Descending'][selchoice]
   ev("phoneState=migrateState(null);"+("delete phoneState."+key+";" if absent else "")+"persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='galfoldertarget';galTarget={op:'Copy',folder:'Images',browse:'Memory card',pane:"+json.dumps(pane)+",sortBy:"+str(sort)+",menuSel:"+str(selchoice)+"};targetAlias=galTarget;open=false;sel=0;history=['gallery'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
   label=f'{absent} {pane} {choice}'
   t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&galTarget===targetAlias")
   t(label+' warning/context',"return notice==='Unable to save gallery setting'&&document.getElementById('screen').innerText.includes(notice)&&page==='galfoldertarget'&&galTarget.pane==="+json.dumps(pane)+"&&history.length===1")
   if not absent and pane=='view' and choice==1:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6113-target-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("press('OK');press('OK')")
   t(label+' repeat failure',"return JSON.stringify(phoneState)===before&&notice==='Unable to save gallery setting'")
   ev("Storage.prototype.setItem=oldStore;press('OK');press('OK')")
   t(label+' retry',"return phoneState."+key+"==="+json.dumps(expected)+"&&galTarget.pane===null&&!open")
   call('Page.reload');time.sleep(.15)
   t(label+' reload',"return phoneState."+key+"==="+json.dumps(expected))
print('PASS',len(checks))
