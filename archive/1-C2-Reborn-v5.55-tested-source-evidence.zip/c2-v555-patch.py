from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.54-folder-copy-upload-ready.html').read_text()
def sub(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:100]);s=s.replace(a,b)
# Defaults and optional fields. Stored details are surfaced, never removed.
sub("let nums=['mobile','home'].filter(k=>!cfHidden[k]);","let nums=['mobile','home'].filter(k=>!cfHidden[k]&&(k==='mobile'||cfAdded[k]));")
sub(".filter(k=>k==='email'||k==='inet'||k==='image'?!cfHidden[k]:(cfAdded[k]&&!cfHidden[k]))",".filter(k=>cfAdded[k]&&!cfHidden[k])")
sub("cfNumType={mobile:1,home:2};cfDeleteConfirm", "cfNumType={mobile:0,home:2};cfDeleteConfirm")
sub("cfAdded={web:!!contactWeb,company:","cfAdded={home:!!contactHome,email:!!contactEmail,inet:!!contactInet,image:contactImage!=='No image',web:!!contactWeb,company:")
sub("else{contactField=CF_KEYS.indexOf(ds===1?'mobile':ds===2?'home':'inet')}","else{let key=ds===1?'mobile':ds===2?'home':'inet';cfAdded[key]=true;cfHidden[key]=false;cfRelayout();contactField=CF_KEYS.indexOf(key)}")
sub("else contactField=CF_KEYS.indexOf('email');", "else{cfAdded.email=true;cfHidden.email=false;cfRelayout();contactField=CF_KEYS.indexOf('email')}")
sub("else{contactField=CF_KEYS.indexOf('image');draw()}","else{cfAdded.image=true;cfHidden.image=false;cfRelayout();contactField=CF_KEYS.indexOf('image');draw()}")
sub("if(k==='internet')return cfAdded.web?[0,1]:[1];if(k==='multimedia')return[1];", "if(k==='internet')return [cfAdded.web?0:-1,cfAdded.email?1:-1].filter(v=>v>=0);if(k==='multimedia')return cfAdded.image?[1]:[];")
# Universal explorer menus use the same shared arrays, contextual folder operations retained.
sub("soft('','','Back')}else if(phoneState.galView==='Grid')","soft('Options','Add','Back')}else if(phoneState.galView==='Grid')")
sub("if(page==='galfolder'&&!galMarkMode&&galFolderFiles()[sel]?.folderRow)return ['Open folder','Copy folder','Move folder','Details'];", "if(page==='galfolder'&&!galMarkMode&&(!galFolderFiles().length||galFolderFiles()[sel]?.folderRow))return galExplorerOptions();")
sub("function currentOptions(){", "function galExplorerOptions(){return opts.gallery.slice()}function currentOptions(){")
# Empty Add follows exactly the shared Add folder handler.
sub("function press(k){armActivity();", "function press(k){armActivity();if(galSequence){if(k==='RSK'||k==='BACK'||k==='END')galSequenceStop();return}if(page==='galfolder'&&!open&&!pageSub&&!galFolderFiles().length&&k==='OK'){open=true;os=currentOptions().indexOf('Add folder');press('OK');return}")
# Slideshow session never changes saved data. Selected start, five seconds per image, no wrap.
sub("galFullScreen=false,btPending", "galFullScreen=false,galSequence=null,btPending")
sub("function galFolderSource(){", """function galSequenceStart(){let files=galFolderFiles(),start=sel,indices=files.map((f,i)=>!f.folderRow&&f.big?i:-1).filter(i=>i>=start);if(!indices.length){open=false;notice='No images';draw();return}let folder=galFolderName;if(page==='galfolder'){go('galphoto');sel=start}else open=false;galSequence={folder,start,indices,pos:0,timer:0};galFullScreen=true;sel=indices[0];draw();galSequenceArm()}
function galSequenceArm(){if(galSequence)galSequence.timer=setTimeout(galSequenceAdvance,5000)}
function galSequenceAdvance(){let q=galSequence;if(!q)return;if(page!=='galphoto'){clearTimeout(q.timer);galSequence=null;galFullScreen=false;return}q.pos++;if(q.pos>=q.indices.length){clearTimeout(q.timer);galSequence=null;galFullScreen=false;open=false;back();if(page!=='galfolder'){page='galfolder';galFolderName=q.folder}sel=q.start;draw();return}sel=q.indices[q.pos];draw();galSequenceArm()}
function galSequenceStop(){let q=galSequence;if(!q)return;clearTimeout(q.timer);galSequence=null;galFullScreen=false;open=false;draw()}
function galFolderSource(){""")
sub("if(page==='galphoto')galFullScreen=false;", "if(page==='galphoto'){if(galSequence){clearTimeout(galSequence.timer);galSequence=null}galFullScreen=false;}")
sub("(galFullScreen?'':'<div class=\"galPhotoSoft\">", "(galSequence?'<div class=\"galSequenceStop\">Stop</div>':galFullScreen?'':'<div class=\"galPhotoSoft\">")
sub("else if((page==='galfolder'||page==='galphoto')&&['Use image','Zoom','Set contrast','Edit image','Print','Open in sequence'].includes(c))", "else if((page==='galfolder'||page==='galphoto')&&c==='Open in sequence'){galSequenceStart();return}else if((page==='galfolder'||page==='galphoto')&&['Use image','Zoom','Set contrast','Edit image','Print'].includes(c))")
sub("else if(_f&&_f.big){go('galphoto')}","else if(_f&&_f.big){let index=sel;go('galphoto');sel=index;draw()}")
# Existing folder operations remain honest until recursive/collision behavior grounded.
# Visual fullscreen Stop, oriented like SDK.
s=s.replace('</style>', '.galSequenceStop{position:absolute;bottom:8px;right:4px;writing-mode:vertical-rl;color:#fff;text-shadow:1px 1px #000;font-size:16px;z-index:4}</style>',1)
s=s.replace('v5.54','v5.55')
Path('/downloads/C2-Reborn-v5.55-parity-candidate.html').write_text(s)
a=s.rfind('<script>');b=s.find('</script>',a);Path('/tmp/c2-v555.js').write_text(s[a+8:b]);print('candidate',len(s))
