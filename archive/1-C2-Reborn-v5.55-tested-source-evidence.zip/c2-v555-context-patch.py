from pathlib import Path
p=Path('/downloads/C2-Reborn-v5.55-parity-candidate.html');s=p.read_text()
def sub(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:80]);s=s.replace(a,b)
# No selected item in empty explorer. Options stay present, item operations disabled.
sub("function optionDisabled(label){", "function optionDisabled(label){if(page==='galfolder'&&!galFolderFiles().length&&['Delete folder','Move folder','Copy folder','Rename folder','Details','Mark','Mark all'].includes(label))return true;")
sub("if(page==='gallery'&&c==='Rename folder'){let _e=galOrder()[sel];", "if((page==='gallery'||page==='galfolder')&&c==='Rename folder'){let key=galFolderSource();let _e=page==='gallery'?galOrder()[sel]:{n:key,i:screens.gallery.length+phoneState.galleryFolders.indexOf(key)};")
sub("if(page==='gallery'&&c==='Delete folder'){let _e=galOrder()[sel],name=_e?.n;", "if((page==='gallery'||page==='galfolder')&&c==='Delete folder'){let key=galFolderSource();let _e=page==='gallery'?galOrder()[sel]:{n:key,i:screens.gallery.length+phoneState.galleryFolders.indexOf(key)},name=_e?.n;")
# Implement observed empty-folder Move. Unsupported populated/nested source waits for exact behavior evidence.
sub("if((page==='gallery'||page==='galfolder')&&c==='Move folder'){notice='Folder move needs device evidence';draw();return}","if((page==='gallery'||page==='galfolder')&&c==='Move folder'){galFolderMoveStart();return}")
sub("function galFolderCopyStart(){", """function galFolderMoveStart(){let key=galFolderSource();if(!key||screens.gallery.includes(key)){notice='Built-in folders cannot be moved';draw();return}if(galActualFiles(key).length||galChildFolders(key).length){notice='Moving populated folders is not implemented in this prototype';draw();return}galTarget={op:'Move',folder:key,from:(phoneState.galFolderParents||{})[key]||'Memory card'};go('galfoldertarget');sel=0;draw()}
function galMoveEmptyFolderTo(source,dest){if(source===dest)return {error:'Cannot move a folder into itself'};if(galActualFiles(source).length||galChildFolders(source).length)return {error:'Moving populated folders is not implemented in this prototype'};if(galChildFolders(dest).some(k=>k!==source&&galDisplayName(k).toLowerCase()===galDisplayName(source).toLowerCase()))return {error:'Folder name already exists'};phoneState.galFolderParents[source]=dest;persist();return {key:source}}
function galFolderCopyStart(){""")
sub("soft('Options','Copy to','Back')", "soft('Options',galTarget.op==='Move'?'Move':'Copy to','Back')")
sub("r=galCopyFolderTo(galTarget.folder,dst);", "r=galTarget.op==='Move'?galMoveEmptyFolderTo(galTarget.folder,dst):galCopyFolderTo(galTarget.folder,dst);")
sub("galTarget=null;back();notice='Copied to '+galDisplayName(dst);", "let verb=galTarget.op==='Move'?'Moved':'Copied';galTarget=null;back();notice=verb+' to '+galDisplayName(dst);")
# Shared explorer target Options, with unsupported destinations explicit rather than fake behavior.
sub("if(k==='LSK'){notice='Destination Options need device evidence';draw();return}","if(k==='LSK'){notice='Destination Options are not implemented in this prototype';draw();return}")
# Empty Details must not invent JPG dimensions.
sub("galDetailFile=!_f.folderRow;", "galDetailFile=!!_f.n&&!_f.folderRow;")
p.write_text(s);a=s.rfind('<script>');b=s.find('</script>',a);Path('/tmp/c2-v555.js').write_text(s[a+8:b]);print(len(s))
