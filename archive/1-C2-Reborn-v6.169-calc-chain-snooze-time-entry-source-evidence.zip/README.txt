v6.169: three defects reported by another agent (unverified leads), each reproduced on live v6.168 first, then fixed.
1. Calculator chain: 2 [up] 3 [up] 4 [OK] gave 7 (the pending 2+ was dropped when a second operator was pressed). Now evaluates the running result: 9. Changing the operator before typing the next number just swaps it. Scientific calculator had the same bug, fixed.
2. Alarm snooze overwrote the saved alarm time with now + snooze. Now the saved time stays; a separate one-shot snooze time rings again. Stop clears it. Stop (left soft key) also now works as well as OK.
3. Time field in Date and time settings: typing 0930 gave 03:90 (digits shifted through segments). Now digits fill left to right, hours clamp to 23, minutes to 59. Alarm and Timed-profile time fields already gave 09:30 and are unchanged.
Evidence class: 1 is arithmetic, 2 matches normal Nokia alarm behaviour (no handset footage for snooze), 3 inferred from standard S40 entry (handset footage does not show typing into this field). Flag as not handset-proven: 2 and 3.
Tests: v6169 focused 9/9; v6168 7/7, v6167 27/27, v6166 10/10, v6165 15/15, v6164 15/15 on this build.
