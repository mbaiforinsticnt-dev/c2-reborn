import os,json
F=os.environ.get('C2F','c2-v6155-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';profileTonesFor=0;})()")
S="(()=>({page,sel,notice,open,rc:radioCtx&&radioCtx.title,ne:nameEditing,rows:[...document.querySelectorAll('[data-row]')].map(e=>e.textContent.trim()).slice(0,6)}))()"
fresh()
print(ev("(()=>{profileTonesFor='General';go('profiletones');draw();return JSON.stringify(screens.profiles)})()"))
print('form',ev(S))
for q in range(16):
 ev("press('DOWN');0")
 print(q+1,ev("sel"),ev("document.querySelector('.sel')&&document.querySelector('.sel').textContent.trim().slice(0,40)"))
# OK on ringing tone
fresh();ev("profileTonesFor='General';go('profiletones');sel=1;draw()")
ev("press('OK');0");print('OK on tone ->',ev(S))
fresh();ev("profileTonesFor='General';go('profiletones');sel=1;draw()")
ev("press('LSK');0");print('LSK',ev(S));

