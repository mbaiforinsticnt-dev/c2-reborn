# C2 Reborn v6.201 (built on v6.200, blob 3123f5ea871c0d37c5b6b0378b4f1568e54cf0fc)
Changes
- Names list: focused row is a mid-blue band with white text in the Light, Simple, Abstract and Nokia themes (was pale blue on near-white, ratio about 1.1).
- Alarm form: 6 px gap below the last field so it no longer sits flush against the softkeys.
Sweep: 157 pass, 21 fail on the first run. 4 are the obsolete alarm tests (104, 134, 135, 136). 17 were reload-race fails and all passed solo (3 needed a second solo run).
Contrast crawls: Nokia (340 screens) and Light (357 screens) done. Black and Dark not crawled yet.
Not done: arrows on list-opening rows (waiting on Moti), Equaliser selected-row fill, Notes/To-do Use detail check, Light-theme highlight edge gap, Conversation bubble focus weak in Light, Black and Dark contrast crawls.
Arrow art: Moti's chosen Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead); author not recorded.
