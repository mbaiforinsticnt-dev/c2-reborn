from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.37-favourite-save-rollback-candidate.html').read_text().replace('v6.37 handset parity','v6.38 handset parity').replace('C2 Reborn v6.37 |','C2 Reborn v6.38 |')
a="phoneState.favourites.splice(favDelIdx,1);persist();favDelName=null;"
b="let before=phoneState.favourites.slice();phoneState.favourites.splice(favDelIdx,1);try{persist()}catch(err){phoneState.favourites=before;notice='Unable to delete favourite';draw();return true}favDelName=null;"
assert s.count(a)==1;s=s.replace(a,b)
a="if(favDelName){s.insertAdjacentHTML";b="if(favDelName&&!notice){s.insertAdjacentHTML";assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save favourite|Folder memory full|';b='Unable to save favourite|Unable to delete favourite|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.38-favourite-delete-rollback-candidate.html').write_text(s)
