import os,json
F=os.environ.get('C2F','c2-v6154-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({ps:JSON.stringify(phoneState),page,rp:radioPlaying,rb:radioBackground,pb:playerBackground,notice,hist:history.length,tb:playerTickBase}))()"
CASES={
'radio freq RIGHT':("go('radio');draw()","pressHold('RIGHT')"),
'radio freq LEFT':("go('radio');draw()","pressHold('LEFT')"),
'player seek RIGHT':("go('player');draw()","pressHold('RIGHT')"),
'player END (playing)':("go('player');phoneState.player.playing=true;phoneState.player.elapsed=5;playerBackground=true;draw()","pressHold('END')"),
'radio END':("go('radio');radioPlaying=true;radioBackground=true;draw()","pressHold('END')"),
}
for n,(setup,act) in CASES.items():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice=''})()")
 print(n,'setup',ev("(()=>{"+setup+";return page})()"))
 b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{try{%s}catch(e){return 'THROW '+e.message}return 'ok'})()"%act)
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(n,'->',r,'diff',[k for k in b if b[k]!=a[k]],'storedSame',ev("localStorage.getItem('c2state')")==st,repr(a['notice']))
