import os,json
F=os.environ.get('C2F','c2-v6155-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v);assert v is True,n
SN="(()=>({ps:JSON.stringify(phoneState),page,pb:playerBackground,tb:playerTickBase,hist:history.length}))()"
def fresh(setup):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';"+setup+"})()")
def case(name,setup,act,note,ok):
 fresh(setup);b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{try{%s}catch(e){return 'THROW '+e.message}return 'ok'})()"%act);a=ev(SN);n=ev("notice");ev('Storage.prototype.setItem=oldStore;0')
 t(name+' no throw',r=='ok');t(name+' state unchanged',a==b);t(name+' storage unchanged',ev("localStorage.getItem('c2state')")==st);t(name+' notice',n==note)
 fresh(setup);ev("(()=>{"+act+"})()");t(name+' success',ev(ok))
case('radio RIGHT',"go('radio');draw()","pressHold('RIGHT')",'Unable to save radio frequency',"JSON.parse(localStorage.getItem('c2state')).radioFrequency!='98.8'")
case('radio LEFT',"go('radio');draw()","pressHold('LEFT')",'Unable to save radio frequency',"JSON.parse(localStorage.getItem('c2state')).radioFrequency!='98.8'")
case('player seek',"go('player');draw()","pressHold('RIGHT')",'Unable to save playback position',"JSON.parse(localStorage.getItem('c2state')).player.elapsed>0")
case('player END',"go('player');phoneState.player.playing=true;phoneState.player.elapsed=5;playerBackground=true;persist();draw()","pressHold('END')",'Unable to save player state',"page=='home'&&JSON.parse(localStorage.getItem('c2state')).player.playing===false&&playerBackground===false")
print('checks',len(res))
