exec(open("/tmp/hdr.py").read())
fresh2();ev("go('datetime')");S('OK');
S('Down');S('1');S('2');S('3');S('4')
print(ev("[page,calDateDirty,calSavePrompt,calTimeDraft,calDateDraft]"))
S('BACK');print(ev("[page,calDateDirty,calSavePrompt]"),ev(T)[:120])
S('END');print('END',ev("[page,calDateDirty,calSavePrompt,calTimeDraft]"))
b=ev("JSON.stringify([phoneState.timeOffset,phoneState.dtVals,phoneState.clock])")
S('OK');S('OK');print('after',ev("[page,calDateDirty,calSavePrompt]"),b,ev("JSON.stringify([phoneState.timeOffset,phoneState.dtVals,phoneState.clock])"))
