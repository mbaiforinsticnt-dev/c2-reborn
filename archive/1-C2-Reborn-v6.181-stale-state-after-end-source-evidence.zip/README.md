# C2 Reborn v6.181 (source-evidence)
Change: generic stale-state-after-End. End now clears every pending overlay/prompt flag: previous Organiser list plus Date/time "Save changes?" prompt and dirty flag, picker draft, Gallery dialog, Gallery mark mode and marks. Also cleared at standby if any survive. End returns to standby.
Reproduced on v6.180: Date and time settings, edit date, Back (Save changes? prompt), End: calSavePrompt and calDateDirty stayed True at standby (focused-datetime-prompt-after-end.py). Fixed in v6.181 (both False).
Inferred only (flags cleared by code, not reproduced as surviving): Gallery mark/dialog and picker draft; Settings picker draft abandonment (a PIN/keyguard/font picker abandoned with End did not change phoneState in my test on v6.180).
Evidence class: inferred (End always returns to standby on S40), not C2-01 handset-proven.
Not done: Calls, Calendar confirms/validation/alarms, To-do, Gallery folder/Send, remaining Tab leads (held keys, mode indicator).
