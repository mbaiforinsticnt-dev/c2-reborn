exec(open("/tmp/hdr.py").read())
fl="[page,calDateDirty,calSavePrompt,JSON.stringify(pickerDraft),JSON.stringify(galDialog),galMarkMode,galMarked.size]"
fresh2();ev("go('datetime')");S('OK');S('Down');S('1');S('2');S('BACK');S('END');print('datetime',ev(fl))
fresh2();ev("go('gallery')");ev("galMarkMode=true;galMarked.add('x')");S('END');print('galmark',ev(fl))
fresh2();ev("go('gallery')");ev("galDialog={type:'delete'}");S('END');print('galdialog',ev(fl))
fresh2();ev("go('display')");S('OK');S('Down');ev("pickerDraft={page:'display'}");S('END');print('draft',ev(fl))
