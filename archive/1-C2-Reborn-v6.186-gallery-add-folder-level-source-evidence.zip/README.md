# C2 Reborn v6.186 (source-evidence)
Change (reproduced on v6.185 with Tab's path: Images > Options > Add folder > name > OK): after saving, the phone landed on the top-level Gallery list with Memory card highlighted (so the next Rename acted on Memory card). Now it returns to the Images folder with the new subfolder selected.
Evidence class: inferred (a new folder is shown where it was created), not C2-01 handset-proven. Add folder from the top-level Gallery list and Rename are unchanged.
Not built (no handset evidence, so not invented): Security keyguard code prompt on turning On, Language settings list, Rename folder level/Options leak (not reproduced yet), Calls leftovers.
