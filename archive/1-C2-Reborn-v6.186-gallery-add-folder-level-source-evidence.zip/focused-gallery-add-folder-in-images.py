exec(open("/tmp/hdr.py").read())
st="[page,open,pageSub,sel,galFolderName]"
fresh2();ev("go('gallery')");S('DOWN');S('OK');print('in',ev(st))
S('LSK');
for q in range(5):S('UP')
S('OK');print('after opt',ev(st),ev(T)[:120])
for c in '9736':S(c)
print('typed',ev("folderName"),ev(st))
S('OK');print('after OK',ev(st),ev(T)[:160])
print(ev("JSON.stringify(phoneState.galleryFolders)"))
