exec(open("/tmp/hdr.py").read())
SM="document.getElementById('statusMode').innerHTML.replace(/<img[^>]*>/,'[pen]')"
def chk(label,setup,keys=('4','4')):
    fresh2();ev(setup);print(label,'start',repr(ev(SM)),end=' ')
    for k in keys:
        S(k);print('after',k,repr(ev(SM)),end=' ')
    print()
chk('contact',"go('addcontact')")
chk('note',"go('textnote');noteText=''")
chk('compose',"startMessage('','','new')")
chk('contact space',"go('addcontact')",('4','1','0','4'))
