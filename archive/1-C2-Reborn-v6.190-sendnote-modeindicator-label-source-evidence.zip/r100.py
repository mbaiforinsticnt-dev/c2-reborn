exec(open("/tmp/hdr.py").read())
fresh2();ev("phoneState.notes=['x'];go('notes')");S('OK');S('LSK');S('DOWN');S('DOWN');S('OK')
S('DOWN');S('DOWN');print('sel',ev('sel'));S('OK');print(ev('page'),ev('!!bluetoothPrompt'),repr(ev('notice')),ev(T)[:200])
