exec(open("/tmp/hdr.py").read())
SM="document.getElementById('statusMode').innerHTML.replace(/<img[^>]*>/,'[pen]')"
fresh2();ev("startMessage('','','new')");print(ev('composeFocus'),repr(ev(SM)),ev("typeof draft!=='undefined'?JSON.stringify(draft):null"))
S('DOWN');print('f',ev('composeFocus'),repr(ev(SM)),ev(T)[:120])
for k in ('4','4','4'):
    S(k);print(k,repr(ev(SM)),ev("draft"),ev("inputMode"))
S('0');S('4');print('after space+4',repr(ev(SM)),ev("draft"))
