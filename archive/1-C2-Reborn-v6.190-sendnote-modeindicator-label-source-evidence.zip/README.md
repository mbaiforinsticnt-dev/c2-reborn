C2 Reborn v6.190 (base v6.189). Source-evidence bundle; Nokia build. Focused scripts: python3 rNN.py index.html
Reproduced on v6.189 and fixed:
- Send note list (Notes): cursor wrapped over 2 rows so "Via Bluetooth" was unreachable. Now 3 rows (r100).
- Mode indicator after the first capital (r101, r102): contact form text fields always showed "Abc"; compose body showed "abc" on empty text and "Abc" after typing (inverted). Both now show "Abc" while the next letter would be capitalised and "abc" afterwards. Notes editor had no indicator; it now shows Abc/abc the same way. Uses the same autoCap rule as the capitalisation itself.
Not handset-proven: indicator for the notes editor (inferred).
Not done: held keys (harness cannot hold keys), call duration mismatch (not reproduced), folder-rename Options-open (deliberate, unchanged).
- Page label (debug bar) corrected to v6.190; v6.189 shipped with a stale v6.188 label (my miss).
