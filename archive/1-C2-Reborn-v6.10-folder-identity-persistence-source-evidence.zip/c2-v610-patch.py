from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.09-folder-capacity-guard-candidate.html').read_text().replace('v6.09 handset parity','v6.10 handset parity').replace('C2 Reborn v6.09 |','C2 Reborn v6.10 |')
a='d[key][cleanText(a,100)]=cleanText(b,225)';b='d[key][cleanText(a,225)]=cleanText(b,225)';assert s.count(a)==1;s=s.replace(a,b)
a='folder:cleanText(v.folder,100),n:cleanText(v.n,160)';b='folder:cleanText(v.folder,225),n:cleanText(v.n,160)';assert s.count(a)==1;s=s.replace(a,b)
a='d[key][cleanText(a,164)]=cleanText(b,164)';b="d[key][cleanText(a,164)]=cleanText(b,key==='galFileNames'?164:225)";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.10-folder-identity-persistence-candidate.html').write_text(s)
