# C2 Reborn v6.200 (built on v6.199, blob 745d590f870155d07dee0363b7fd61eb6c2a1305)
Changes
- Nokia theme: focused row in radio lists is a dark band, white text and dot (was white on white).
- Nokia theme: Drafts/message rows readable (dark text unfocused, dark band focused).
- Ringing volume row (Tone settings, profile tones) plays the selected ringtone at that volume on focus; restarts on each change; stops on leaving. Stop-on-leave is inferred.
- Incoming call alert list previews: Ringing at set volume; Ascending 15% to full over 4 s; Ring once cut at 3 s; Beep once 1 kHz 0.25 s; Off silent. Timings and beep are inferred (emulator has no sound).
- Calendar day list: Up/Down move focus and wrap.
- Calendar and Alarm Options panels and Gallery submenu are content-sized (no clipping, Alarm Options is one row).
- Arrow image on the Calendar Options rows.
Sweep: 174 pass, 4 fail (104,134,135,136, obsolete alarm tests). 16 reload-race/real fails re-run solo and pass; one real regression (alert preview firing on Home screen radio lists) fixed before bundling.
Not done: arrows on list-opening rows (waiting on Moti), Notes/To-do Use detail, Equaliser outline, Alarm snooze label, contrast crawl of Light/Black/Dark/Simple/Abstract, alarm popup, screens deeper than 4 levels.
Arrow art: Moti's chosen Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead); Flaticon free licence needs attribution; author not recorded.
