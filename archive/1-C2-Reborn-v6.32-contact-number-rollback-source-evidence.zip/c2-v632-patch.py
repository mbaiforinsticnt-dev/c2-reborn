from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.31-reset-storage-rollback-candidate.html').read_text().replace('v6.31 handset parity','v6.32 handset parity').replace('C2 Reborn v6.31 |','C2 Reborn v6.32 |')
a="if(pendingAddNumber){let _c=selected;if(_c)_c.number=_c.number?_c.number+' / '+pendingAddNumber:pendingAddNumber;pendingAddNumber=null;persist();contactIndex="
b="if(pendingAddNumber){let _c=selected,had=Object.prototype.hasOwnProperty.call(_c,'number'),old=_c.number;_c.number=_c.number?_c.number+' / '+pendingAddNumber:pendingAddNumber;try{persist()}catch(err){if(had)_c.number=old;else delete _c.number;notice='Unable to save contact number';draw();return}pendingAddNumber=null;contactIndex="
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to restore settings|Folder memory full|';b='Unable to restore settings|Unable to save contact number|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.32-contact-number-rollback-candidate.html').write_text(s)
