exec(open("/tmp/hdr.py").read())
import base64
th=sys.argv[2] if len(sys.argv)>2 else 'Light.nth'
fresh2();ev("document.body.setAttribute('data-theme','%s')"%th);S('RSK','LSK');print(ev('page'),ev(T))
print(ev("(()=>{let p=document.querySelector('.optionsPanel');if(!p)return 'nopanel';let r=p.getBoundingClientRect();let c=getComputedStyle(p);let q=p.querySelector('.opt');let cq=getComputedStyle(q);return JSON.stringify({cls:p.className,top:r.top,h:r.height,l:r.left,w:r.width,bg:c.backgroundColor,bgi:c.backgroundImage.slice(0,50),border:c.border,rows:p.querySelectorAll('.opt').length,rowh:q.getBoundingClientRect().height,rowbg:cq.backgroundColor,rowcol:cq.color,padb:c.paddingBottom})})()"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o120-%s.png'%th.split('.')[0].replace(' ','_'),'wb').write(base64.b64decode(r['result']['data']))
