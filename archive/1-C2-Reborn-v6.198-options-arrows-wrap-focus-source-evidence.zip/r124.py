exec(open("/tmp/hdr.py").read())
import base64
fresh2();ev("document.body.setAttribute('data-theme','Nokia.nth')")
n=0
for pg in ["conversations","settings","calllog","contacts","names","messaging","gallery","settingsmenu"]:
    try:
        fresh2();ev("document.body.setAttribute('data-theme','Nokia.nth')");ev("go('%s')"%pg);S('DOWN')
        print(pg,ev('page'),ev(T)[:80], ev("(()=>{let r=document.querySelector('.row.sel,.conversationRow.sel');return r?getComputedStyle(r).backgroundImage.slice(0,30)+'|'+(r.querySelector('.sub')?getComputedStyle(r.querySelector('.sub')).color:'-'):'norow'})()"))
        r=call('Page.captureScreenshot',{'format':'png','clip':{'x':320,'y':40,'width':160,'height':200,'scale':1.5}});open('/tmp/o124-%s.png'%pg,'wb').write(base64.b64decode(r['result']['data']))
    except Exception as e: print(pg,'ERR',e)
