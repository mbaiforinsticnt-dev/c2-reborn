exec(open("/tmp/hdr.py").read())
import base64
th=sys.argv[2] if len(sys.argv)>2 else 'Nokia.nth'
fresh2();ev("document.body.setAttribute('data-theme','%s')"%th)
call('Emulation.setDeviceMetricsOverride',{'width':412,'height':915,'deviceScaleFactor':1.4,'mobile':True})
ev("go('tones')");S('DOWN','LSK');print(ev('page'),ev(T))
print(ev("(()=>{let p=document.querySelector('.optionsPanel');let r=p.getBoundingClientRect();let s=document.querySelector('.lcd').getBoundingClientRect();return JSON.stringify({cls:p.className,top:r.top-s.top,h:r.height,lcdh:s.height,rows:p.querySelectorAll('.opt').length,rowh:p.querySelector('.opt').getBoundingClientRect().height})})()"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o121-%s.png'%th.split('.')[0].replace(' ','_'),'wb').write(base64.b64decode(r['result']['data']))
call('Emulation.clearDeviceMetricsOverride',{})
