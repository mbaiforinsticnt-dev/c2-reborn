exec(open("/tmp/hdr.py").read())
import base64
for th in ['Light.nth','Nokia.nth','Classic light','Abstract.nth']:
    fresh2();ev("go('alarmclock')");ev("document.body.setAttribute('data-theme','%s')"%th);ev("alarmInit();alarmFocus=alarmFields().indexOf('snooze');draw()")
    print(th,ev("(()=>{let e=document.querySelector('.nfBox.fsel');let c=getComputedStyle(e);let d=getComputedStyle(e.querySelector('.dgsel'));return c.backgroundImage.slice(0,40)+'|'+getComputedStyle(e.querySelector('.nfHint')).color+'|dg '+d.backgroundColor})()"))
    if th=='Light.nth':
        r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/snz.png','wb').write(base64.b64decode(r['result']['data']))
