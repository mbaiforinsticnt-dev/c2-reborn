exec(open("/tmp/hdr.py").read())
import base64
for th in ['Nokia.nth','Light.nth','Black.nth','Dark.nth','Abstract.nth']:
    fresh2();ev("document.body.setAttribute('data-theme','%s')"%th);ev("go('conversations')");S('DOWN','DOWN')
    print(th,ev('page'),ev(T)[:90])
    print(ev("(()=>{let r=document.querySelector('.row.sel');if(!r)return 'norow';let c=getComputedStyle(r),sb=r.querySelector('.sub'),t=r.querySelector('.name,.t,b,span');return JSON.stringify({bg:c.backgroundColor,bgi:c.backgroundImage.slice(0,60),col:c.color,sub:sb&&getComputedStyle(sb).color,cls:r.className,html:r.innerHTML.slice(0,160)})})()"))
    r=call('Page.captureScreenshot',{'format':'png','clip':{'x':320,'y':40,'width':160,'height':200,'scale':2}});open('/tmp/o123-%s.png'%th[:-4],'wb').write(base64.b64decode(r['result']['data']))
