# C2 Reborn v6.198 - source evidence

Changes on top of v6.197:
1. Options and sub-menu panels (all themes): light gradient panel, dark focus bar with white text, panel height = its rows (matches emulator and Moti's handset photo; inferred where the photo doesn't show).
2. Sub-menu rows show an arrow image pinned 8 px from the right edge instead of ">" text. Shape: the notched arrowhead Moti chose (arrow-source-moti-notched.jpg, background keyed to transparent), 8x9 px. Dark solid on normal rows; on the focus bar the same shape with a white border and dark inside (matches his zoomed handset photo). The ">" text stays in the DOM, hidden, so key-driven tests still read it.
3. Stray outlined box removed (the Options backdrop element carried a 2px grey border).
4. Alarm clock edit screen: Up on the first field goes to the last, Down on the last goes to the first.
5. Nokia theme focused list rows (Conversations, Settings, Messaging, Contacts, Gallery): dark band with white title and subtitle instead of a pale band with white subtitle.

Icon source/licence: arrow images came from Flaticon (https://www.flaticon.com/free-icons/arrowhead), chosen and downloaded by Moti. Flaticon free licence requires attribution to the author/Flaticon; author name not recorded in this bundle. Attribution belongs here and in release notes, not on the phone screen.

Not changed / no evidence: blank space under Save (could not reproduce; the thin white line above the Nokia softkey bar is that theme's softkey frame), whole-phone wrap/arrow audit (starts in v6.199), focused-row shade on non-Nokia themes (already dark), alarm popup layout, calendar day-list order, Clear-log confirm, Missed/Received/All calls option lists, Dialled View, which file "Standard" alarm tone plays.

Test scripts r116-r125 are the browser checks used for these changes.
