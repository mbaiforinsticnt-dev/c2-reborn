from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.83-zoom-contrast-upload-ready.html').read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a[:90],s.count(a));s=s.replace(a,b)
rep('content="v5.83 handset parity built-2026-09-30"','content="v5.84 handset parity built-2026-09-30"')
rep('<div class="debug">C2 Reborn v5.83 | 2026-09-30</div>','<div class="debug">C2 Reborn v5.84 | 2026-09-30</div>')
rep('galContrastValues={},galSequence=null','galContrastValues={},galPrint=null,galSequence=null')
rep("&&['Edit image','Print'].includes(c)){open=false;notice=c+' is not available in the HTML yet';draw();return}","&&c==='Print'){let f=galFolderFiles()[sel];if(!f||f.folderRow)return; open=true;galPrint={name:f.n,src:f.src||f.big||'',stage:'confirm'};draw();return}else if((page==='galfolder'||page==='galphoto')&&c==='Edit image'){open=false;notice=c+' is not available in the HTML yet';draw();return}")
rep('drawCalOverlays(s);', '''drawCalOverlays(s);if(galPrint){s.insertAdjacentHTML('beforeend','<div class="alarmShade" style="z-index:110"></div><div class="alarmDialog" style="z-index:111;min-height:14vh;bottom:3.5vh">'+(galPrint.stage==='confirm'?'Print? '+esc(galPrint.name)+'<img style="display:block;float:right;width:4vh;height:5vh;object-fit:contain;margin-top:2vh" src="'+esc(galPrint.src)+'">':'Not implemented in this prototype')+'</div>'+(page==='galphoto'?'<div class="galPhotoSoft" style="z-index:112;background:#222"><span></span><span>'+(galPrint.stage==='confirm'?'Yes':'')+'</span><span>'+(galPrint.stage==='confirm'?'No':'Back')+'</span></div>':''));soft('',galPrint.stage==='confirm'?'Yes':'',galPrint.stage==='confirm'?'No':'Back')}''')
rep('function galPhotoToolsPress(k){', '''function galPhotoToolsPress(k){
if(galPrint){if(k==='END'){galPrint=null;open=false;history=[];page='home';sel=0;draw()}else if(k==='RSK'||k==='BACK'){galPrint=null;open=false;if(page==='galfolder')go('galphoto');draw()}else if(k==='OK'&&galPrint.stage==='confirm'){galPrint.stage='unsupported';open=false;draw()}return true}
''')
Path('/downloads/C2-Reborn-v5.84-print-confirmation-candidate.html').write_text(s)
