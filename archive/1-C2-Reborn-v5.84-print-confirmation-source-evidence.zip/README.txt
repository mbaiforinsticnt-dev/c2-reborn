v5.84 frozen Print confirmation repair. No index deployment.
SDK-grounded Print? filename, thumbnail, center Yes/right No. No dismisses
Options and returns to the image. Yes stops at a Back-only honest prototype
limitation; no printer or actual print action is implemented or claimed.
12 Print tests passed, plus 30 Use image, 13 numeric alarm, 29 alarm,
9 End/cancel and 277 carried regression checks.
Visual check: confirmation fully contains thumbnail; footer is not overlapped.
Edit image remains explicitly unavailable pending proper stateful work.
