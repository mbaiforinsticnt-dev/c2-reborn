C2 Reborn v6.176 (source evidence)
Base: v6.175 (blob 300d8016). Tab's v6.175 minor leads, each reproduced on v6.175 first (emulator/CDP, not handset):
- PC sync User name/Password editor: Back on an empty field did nothing; it now leaves the editor.
- Editor right softkey now reads Clear while there is text, Back when empty (label parity with S40 per Tab, not handset-proven).
- A saved empty username reopened as "user"; it now reopens empty (default "user" only when never set).
- Build label reads v6.176.
Not changed: password masking (parity question, no evidence).
Empty Gallery rename .jpg: Tab confirmed his test error.
Focused tests 40/40.
