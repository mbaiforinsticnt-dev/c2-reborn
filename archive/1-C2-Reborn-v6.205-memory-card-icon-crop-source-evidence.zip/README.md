# C2 Reborn v6.205 (built on v6.204, blob b862ac7204c4221bfd82dc66a3c7b4b838d9fdb6)
- Gallery Memory card icon is now a CROP of Moti real C2 zoom (not a firmware file). Gallery app icon in Go to unchanged.
- Gallery > Memory card row Options now match Moti handset video (10:27): Downloads, Mem. card options, Details, Type of view, Sort, Add folder, Memory status, Search, Mark (dim), Mark all. Submenu: Set password or Change/Delete password; Rename mem. card; Format memory card. Set password and Delete password flows follow the footage.
- Hold # (700 ms, inferred) in Gallery list opens Number mode / Writing language / Paste (dim only while the clipboard is empty, Moti 10:31), from Moti emulator screenshot.
- Saved-notice tick is now a crop of Moti emulator screenshot (not an original firmware file); Unicode tick glyphs replaced by it.
- Main menu view radio labels are white in the Black and Dark themes (were dark on dark).
- Submenu panels that run under the softkeys (Conversation > Mark) are moved up to fit.
Tests: 178-test sweep did NOT run (lost). Fresh: r126,r127,r129,r130 identical on v6.202 and v6.203; screenshots of Go to + saved notice.
See NOTES.md.
