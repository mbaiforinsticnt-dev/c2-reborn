C2 Reborn v5.62: actual bulk contact Copy/Move

Based on byte-exact v5.61. No index.html deployment.
Direction counts use store-filtered records. Copy deep-clones records retaining rich data and clearing copy mark flag; Move changes original stores. Both persist. No restores direction. Empty sources are grey and explain Selected memory empty. Legacy simContacts array is folded once into contacts as SIM records, retaining duplicate identities rather than merging. Contact migration no longer truncates records to an invented capacity.
Collision with same-name/number destination stops the whole operation honestly as unsupported. Source changes during confirmation also stop transaction.
SDK Copy question, No and 1 contact copied result captured. SDK later Names shows two John Doe rows. Mobile question/result/empty inspected. 12 focused tests, 106 carried checks and syntax pass.
Limits: full bulk Move SDK context and collision semantics not certified. SIM field-loss, capacity and memory-filter/icon parity not certified; prototype preserves data. Disabled source row retains Select, matching SDK empty-source replay. Source handset evidence wins.
Tests use a development CDP harness; do not run against user data.
