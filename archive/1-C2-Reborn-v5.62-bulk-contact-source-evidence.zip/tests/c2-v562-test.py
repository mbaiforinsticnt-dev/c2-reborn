exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.62-bulk-contact-candidate.html'))
checks=[
('legacy SIM migration preserves duplicates',"let p=migrateState({contacts:[{name:'A',number:'1',store:'SIM'}],simContacts:[{name:'A',number:'1'},{name:'B',number:'2'}]});return p.contacts.length===3&&p.contacts.every(c=>c.store==='SIM')&&p.simContacts.length===0&&migrateState(p).contacts.length===3"),
('bulk Phone count filters SIM',"phoneState=migrateState(null);phoneState.contacts=[{name:'A',number:'1',store:'Phone',email:'a@example.invalid',marked:true},{name:'B',number:'2',store:'SIM'}];page='copycontacts';sel=0;open=false;notice='';draw();press('OK');return bulkContactPending.records.length===1&&sm.textContent==='Yes'&&sr.textContent==='No'"),
('No restores same direction without mutation',"press('RSK');return !bulkContactPending&&page==='copycontacts'&&sel===0&&phoneState.contacts.length===2"),
('Copy mutates only destination preserves rich data',"press('OK');press('OK');return phoneState.contacts.length===3&&phoneState.contacts[0].store==='Phone'&&phoneState.contacts[2].store==='SIM'&&phoneState.contacts[2].email==='a@example.invalid'&&!phoneState.contacts[2].marked&&bulkContactPending.stage==='result'"),
('persisted copy',"return migrateState(JSON.parse(localStorage.getItem('c2state'))).contacts.length===3"),
('result OK returns direction not stale confirm',"press('OK');return !bulkContactPending&&page==='copycontacts'&&sel===0"),
('destination collision honest no mutation',"press('OK');press('OK');return bulkContactPending.stage==='error'&&phoneState.contacts.length===3&&!document.querySelector('#screen').textContent.includes('contact copied')"),
('SIM Move filters direction',"press('OK');phoneState.contacts=[{name:'A',number:'1',store:'Phone'},{name:'B',number:'2',store:'SIM',email:'b@example.invalid'},{name:'C',number:'3',store:'SIM'}];page='movecontacts';sel=1;draw();press('OK');return bulkContactPending.records.length===2"),
('Move updates actual selected records',"press('OK');return phoneState.contacts.length===3&&phoneState.contacts.every(c=>c.store==='Phone')&&phoneState.contacts[1].email==='b@example.invalid'"),
('empty source stays and explains',"press('OK');press('OK');return !bulkContactPending&&page==='movecontacts'&&notice==='Selected memory empty'"),
('changed source stops entire transaction',"notice='';page='copycontacts';sel=0;draw();press('OK');phoneState.contacts.splice(0,1);press('OK');return bulkContactPending.stage==='error'&&phoneState.contacts.length===2"),
('unrelated key and End do not mutate',"press('OK');press('OK');press('DOWN');let n=phoneState.contacts.length;press('END');return page==='home'&&!bulkContactPending&&phoneState.contacts.length===n"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
