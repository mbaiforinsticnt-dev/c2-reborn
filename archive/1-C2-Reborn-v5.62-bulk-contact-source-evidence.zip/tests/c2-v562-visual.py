exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.62-bulk-contact-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
f="phoneState=migrateState(null);phoneState.contacts=[{name:'A',number:'123',store:'Phone',email:'a@example.invalid'},{name:'B',number:'456',store:'SIM'}];page='copycontacts';sel=0;open=false;notice='';draw();press('OK')"
for n,e in [('question',f),('no',"press('RSK')"),('result',"press('OK');press('OK')"),('empty',"press('OK');phoneState.contacts=[];draw()")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});p='/downloads/c2-v562-bulk-'+n+'.png';open(p,'wb').write(base64.b64decode(r['result']['data']));print(p)
