import sys,subprocess,hashlib,re
f=sys.argv[1]
x=open(f).read();x=x.replace('<head>', '<head><script>const RealDate=Date;class FixedDate extends RealDate{constructor(...a){super(...(a.length?a:[1791331920000]))}static now(){return 1791331920000}};window.Date=FixedDate;</script>', 1);j=x.rfind('</body>')
t="""<script>window.__err=[];addEventListener('error',function(e){__err.push(String(e.message))});
setTimeout(function(){var out=[];try{press('RSK')}catch(e){}
var pages=[];try{Object.keys(route).forEach(function(k){pages.push(k);(route[k]||[]).forEach(function(p){if(pages.indexOf(p)<0)pages.push(p)})});Object.keys(opts).forEach(function(k){if(pages.indexOf(k)<0)pages.push(k)})}catch(e){out.push('ERRP '+e)}
pages.forEach(function(p){try{go(p);sel=0;draw();var s=document.querySelector('#screen');var txt=s?s.innerText.replace(/\\s+/g,' ').slice(0,300):'';var o='';try{o=JSON.stringify(currentOptions())}catch(e){o='ERR'}
var sm=['sl','sm','sr'].map(function(i){var e=document.getElementById(i);return e?e.innerText:''}).join('/');
out.push(p+' | '+page+' | '+txt+' | '+o+' | '+sm);
for(var i=0;i<4;i++){press('DOWN')}press('OK');out.push('  >ok '+page+' '+(document.querySelector('#screen')||{innerText:''}).innerText.replace(/\\s+/g,' ').slice(0,120));
}catch(e){out.push(p+' EXC '+e)}});
var pre=document.createElement('pre');pre.id='out';pre.textContent=out.join('\\n')+'\\nERRORS '+__err.join(';');document.body.appendChild(pre)},3500)</script>"""
open('/tmp/h/sw_tmp.html','w').write(x[:j]+t+x[j:])
r=subprocess.run(['google-chrome','--headless=new','--no-sandbox','--disable-gpu','--virtual-time-budget=20000','--dump-dom','file:///tmp/h/sw_tmp.html'],capture_output=True,text=True,timeout=100).stdout
m=re.search(r'<pre id="out">(.*?)</pre>',r,re.S)
o=m.group(1) if m else 'NOOUT'
open(sys.argv[2],'w').write(o)
print(len(o.splitlines()),'lines',hashlib.md5(o.encode()).hexdigest()[:8],o.split('ERRORS')[-1][:200])
