import sys,json
from pathlib import Path
sys.argv=['probe',str(Path(sys.argv[1] if len(sys.argv)>1 else 'index.html').resolve())];exec((Path(__file__).parent/'c2hdr.py').read_text());fresh2();results=[]
def check(name,expr):
 v=ev(expr);assert v is True,(name,v);results.append(name)
def setup(p):ev("notice='';open=false;mm=null;callDeletePending=null;logEmptyModal=false;go(%s);sel=0;draw()"%json.dumps(p))
ev("phoneState.calls={missed:[],received:[],dialled:[]};phoneState.contacts=[]")
for p in ['missed','received','dialled','allcalls']:
 setup(p);check(p+' empty dialog',"logEmptyModal&&document.querySelector('.lcd').innerText.includes('No numbers')")
fresh2();ev("phoneState.calls.missed=[{number:'+44 7700 900888',time:'Yesterday 09:00',n:4},{number:'+44 7700 900888',at:1791331200000,n:1}];phoneState.calls.received=Array.from({length:120},(_,i)=>({number:'+44 7700 900777',at:1791331200000+i,time:'Today 08:00'}));persist()");call('Page.reload');time.sleep(1)
check('reload legacy n retained','phoneState.calls.missed[0].n===4');check('reload event timestamp retained','phoneState.calls.missed[1].at===1791331200000');check('reload >100 records retained','phoneState.calls.received.length===120')
setup('missed');ev("press('LSK');mm.os=6;draw();press('OK');press('RSK')");check('delete cancel retained events','phoneState.calls.missed.length===2&&!callDeletePending')
ev("press('LSK');mm.os=6;draw();press('OK');press('LSK')");check('delete yes one event only','phoneState.calls.missed.length===1&&phoneState.calls.missed[0].at===1791331200000&&!callDeletePending');ev('persist()');call('Page.reload');time.sleep(1);check('delete persisted','phoneState.calls.missed.length===1')
ev("notice='';open=false;mm=null;history=[];page='home';draw();go('log');sel=1;press('OK');press('RSK')");check('Back reaches Log',"page==='log'")
ev("phoneState.calls.missed=[];simulateMissedCall();simulateMissedCall();persist()");call('Page.reload');time.sleep(1);check('two missed reload separate','phoneState.calls.missed.length===2&&phoneState.calls.missed.every(x=>Number.isFinite(x.at))')
ev("phoneState.calls.dialled=[];startCall('+44 7700 900888');startCall('+44 7700 900888');persist()");call('Page.reload');time.sleep(1);check('two outgoing reload separate','phoneState.calls.dialled.length===2&&phoneState.calls.dialled.every(x=>Number.isFinite(x.at))')
print('\n'.join('PASS '+x for x in results));print('TOTAL',len(results))
