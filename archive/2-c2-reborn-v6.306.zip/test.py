import sys,json
from pathlib import Path
sys.argv=['probe',str(Path(sys.argv[1] if len(sys.argv)>1 else 'index.html').resolve())];exec((Path(__file__).parent/'c2hdr.py').read_text());fresh2()
ev("notice='';open=false;phoneState.calls={missed:[],received:[],dialled:[]};phoneState.contacts=[{name:'Demo caller',number:'+44 7700 900888'}]")
for typ in ['missed','received','dialled']:
 ev("phoneState.calls.%s=[{number:'+44 7700 900888',time:'Yesterday 10:07'},{number:'+44 7700 900888',time:'Yesterday 09:00'},{number:'+44 7700 900777',time:'Yesterday 08:00'},{number:'+44 7700 900666',time:'04-10 21:18'},{number:'+44 7700 900555',time:'04-10 20:00'}]"%typ)
for p in ['missed','received','dialled','allcalls']:
 ev("notice='';open=false;mm=null;go('%s');sel=0;draw()"%p)
 print(p,ev("JSON.stringify({text:document.querySelector('#screen').innerText,soft:sr.textContent,rows:document.querySelectorAll('.messageRow').length,clipped:[...document.querySelectorAll('.messageRow')].some(e=>e.offsetTop+e.offsetHeight>e.parentNode.clientHeight+1)})"))
 for _ in range(4):safe('DOWN')
 print('fifth',ev("document.querySelector('#screen').innerText"))
 ev("sel=0;draw()")
 if p=='missed':lcdshot('/downloads/missed306-four.png')
ev("phoneState.calls.missed=[];simulateMissedCall();simulateMissedCall()")
print('missed-two',ev("JSON.stringify(phoneState.calls.missed)"))
ev("phoneState.calls.dialled=[];notice='';open=false;startCall('+44 7700 900888');startCall('+44 7700 900888')")
print('dialled-two',ev("JSON.stringify(phoneState.calls.dialled)"))
