exec(open("/tmp/hdr.py").read())
def run(d):
    fresh2();ev("page='calendar';calDate=new Date(2026,9,3);calGoDate=true;calGoDateDraft='03-10-2026';calGoDateDigit=0;calGoTyped=0")
    for c in d:S(c)
    print(d,ev("[calGoDateDraft,calGoDateDigit]"))
run('15112026');run('3199')
