exec(open("/tmp/hdr.py").read())
def run(d,f):
    fresh2();ev("go('todoedit');todoField=%d;todoSeg=0;todoPos=-1"%f)
    for c in d:S(c)
    print(d,f,ev("[todoDate,todoTime,todoSeg,todoPos]"))
print(ev("page"))
run('16102026',2);run('1030',3)
