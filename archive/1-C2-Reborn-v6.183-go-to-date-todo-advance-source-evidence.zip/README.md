# C2 Reborn v6.183 (source-evidence)
Changes (both reproduced on v6.182 first):
1. Calendar Go to date prompt: same garble as note date. 15112026 gave 12-26-2610, 3199 gave 39-01-0269. Now two digits per segment (four for year), advance, clamp day 1-31, month 1-12: 15-11-2026, 31-12-2026.
2. To-do date/time entry did not advance after a segment filled. 16102026 left the field at "16" with the cursor stuck (time 1030 gave 1000). Now a filled segment advances to the next: 16102026 and 1030 accepted whole.
Evidence class: inferred (standard S40 numeric field behaviour), not C2-01 handset-proven.
Not changed: Calendar note delete confirm (no handset evidence found; Calendar delete currently without prompt), To-do value validation.
