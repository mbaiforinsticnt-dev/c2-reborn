C2 Reborn v5.87 - bounded Insert text entry

Implements the SDK-grounded Insert text field, 12-character allowance, empty/nonempty softkeys, first-letter capitalization, numeric-key multitap, cursor and Clear, Back to the editor Options, and three text-input Options labels. Text remains an unsaved draft. Centre OK with text stops at an explicit Back-only prototype limitation. Text-option operations, layer placement/styling/rotation and Save remain unsupported, not fake saves.

Evidence: SDK F9/F11/F12 replay, first KP_2 creates A, PC 2 creates literal 2 (not handset multitap), Clear/empty Back restores Insert text row. Full SDK save replay produced Audit37.gif with a visibly bold black 2 rotated 90 degrees, same 240x320 size. Saved output included as evidence, not a prototype asset.

22 focused tests and 135 carried checks passed. Portrait 390x844 screenshots inspected. No index deployment.

SHA256: 736d3351b6d91927e675ea7e0b691625975f60a9f07cb7aa1eb4c029021dec63
