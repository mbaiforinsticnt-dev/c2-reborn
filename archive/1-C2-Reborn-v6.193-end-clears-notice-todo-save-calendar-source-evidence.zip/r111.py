exec(open("/tmp/hdr.py").read())
# END after notice
fresh2();ev("go('calendar')");ev("notice='Invalid date';draw()");S('END');print('END notice ->',ev('page'),repr(ev('notice')))
# todo save w/ alarm + dup
fresh2();ev("phoneState.todos=[{s:'Pay rent',p:'High',d:'05-10-2026',t:'09:30',done:false,al:'With tone',ad:'05-10-2026',at:'09:00'},{s:'Plain',p:'Low',d:'06-10-2026',t:'10:15',done:false}];go('todolist')")
for q9 in (0,1):
    ev("sel=%d;draw()"%q9);ev("saveTodoToCal(%d)"%q9)
    print(ev("JSON.stringify(phoneState.calendar[0])"))
n=ev("phoneState.calendar.length");ev("sel=1;draw();saveTodoToCal(1)");print('dup',ev("phoneState.calendar.length")==n,repr(ev('notice')))
