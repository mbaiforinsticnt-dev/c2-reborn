import os
F=os.environ.get('C2F','c2-v6149-base.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({missed:JSON.stringify(phoneState.calls.missed),stored:localStorage.getItem('c2state'),page,sel,open,os,notice}))()"
print(ev("(()=>{phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('missed');draw();press('LSK');let a=opts[page];os=a.indexOf('Clear list');draw();return {page,open,opts:JSON.stringify(a),os,lcd:document.getElementById('screen').innerText}})()"))
b=ev(SN)
ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
r=ev("(()=>{let o=[];for(const k of ['OK','LSK']){try{press(k);o.push(k+':'+document.getElementById('screen').innerText.replace(/\\n/g,'|'))}catch(e){o.push(k+' THROW '+e.message)}}return o})()")
a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
print('RESULT',r);print({k:(b[k]==a[k]) for k in b});print('missed',b['missed'],'->',a['missed'],a['notice'])
