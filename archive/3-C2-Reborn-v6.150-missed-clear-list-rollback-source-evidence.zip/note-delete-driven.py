import os
F=os.environ.get('C2F','c2-v6149-base.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({notes:JSON.stringify(phoneState.notes),stored:localStorage.getItem('c2state'),page,sel,open,os,noteIndex,notice}))()"
print(ev("(()=>{phoneState=migrateState(null);phoneState.notes=['first note','second note'];persist();page='home';history=[];open=false;notice='';go('notes');sel=1;draw();press('OK');return {page,noteIndex,notes:phoneState.notes.length,lcd:document.getElementById('screen').innerText}})()"))
print(ev("(()=>{press('LSK');let o=opts[page]||[];return {page,open,opts:JSON.stringify(opts[page]),os}})()"))
print('idx',ev("(()=>{let a=opts[page];os=a.indexOf('Delete');draw();return {os,sel:a[os]}})()"))
b=ev(SN)
ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
r=ev("(()=>{try{press('OK');let m=document.getElementById('screen').innerText;press('LSK');return 'ok '+m.replace(/\\n/g,'|')}catch(e){return 'THROW '+e.message}})()")
a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
print('RESULT',r);print('diff',{k:(b[k],a[k]) for k in ('notes','page','sel','open','noteIndex','notice') if b[k]!=a[k]});print('stored same',b['stored']==a['stored']);print({k:b[k]==a[k] for k in b})
print(ev("document.getElementById('screen').innerText"))
