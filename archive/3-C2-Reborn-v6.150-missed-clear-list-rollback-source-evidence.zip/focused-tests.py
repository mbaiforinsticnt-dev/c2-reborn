import os
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+os.environ.get('C2F','c2-v6150-cand.html')))
res=[]
def t(n,v):print(n,v);res.append(v);assert v is True,n
def setup(): ev("(()=>{phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('missed');draw();press('LSK');os=opts[page].indexOf('Clear list');draw()})()")
setup()
ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
b=ev("JSON.stringify(phoneState.calls.missed)")
t('press does not throw',ev("(()=>{try{press('OK')}catch(e){return false}return true})()"))
t('missed list kept',ev("JSON.stringify(phoneState.calls.missed)")==b)
t('notice shown',ev("notice")=='Unable to clear list' or 'Unable to clear list' in ev("document.getElementById('screen').innerText"))
t('page still missed',ev("page")=='missed')
ev('Storage.prototype.setItem=oldStore;0')
t('storage unchanged',ev("JSON.parse(localStorage.getItem('c2state')).calls.missed.length")==1)
setup();ev("press('OK')")
t('success clears memory',ev("phoneState.calls.missed.length")==0)
t('success persists',ev("JSON.parse(localStorage.getItem('c2state')).calls.missed.length")==0)
print('checks',len(res))
