exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+__import__('os').environ.get('C2F','c2-v6149-base.html')))
SN="(()=>({ps:JSON.stringify(phoneState),dd:JSON.stringify(draftDemo),alexSame:DEMO_THREAD===messageStore.threads.alex,msSame:phoneState.messageStore===messageStore,page,sel,rm:readMessageIndex,om:openMsgIdx}))()"
setups={
'inbox':"page='inbox';sel=0;history=['home'];askMessageDelete()",
'drafts_demo':"page='drafts';sel=0;history=['home'];askMessageDelete()",
'drafts_user':"phoneState.drafts=[{kind:'sms',to:'1',body:'u'}];persist();page='drafts';sel=0;history=['home'];askMessageDelete()",
'sent':"page='sent';sel=0;history=['home'];askMessageDelete()",
'conversation':"conversationKey='alex';page='conversation';sel=0;history=['home'];askMessageDelete()",
'messageread':"readMessageIndex=0;page='messageread';sel=0;history=['home','inbox'];askMessageDelete()",
'msgopen':"conversationKey='alex';openMsgIdx=0;page='msgopen';sel=0;history=['home','conversation'];askMessageDelete()",
'conv':"page='conversations';sel=1;history=['home'];conversationDeletePending={index:1,key:rowKey(1)};draw()",
}
for n,s in setups.items():
 call('Page.navigate',{'url':'file:///tmp/'+__import__('os').environ.get('C2F','c2-v6149-base.html')});time.sleep(0.6)
 ev("localStorage.clear();0")
 print(n,'setup',ev("(()=>{"+s+";return {page,pend:!!messageDeletePending,cp:!!conversationDeletePending}})()"))
 b=ev(SN)
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{try{press('LSK')}catch(e){return 'THROW '+e.message}return 'ok'})()")
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(n,'press',r,'diff',{k:(b[k]==a[k]) for k in b},'pendAfter',ev("[!!messageDeletePending,!!conversationDeletePending,notice]"))
