import json,base64
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/c2-v6168-cand.html'))
from PIL import Image
call('Emulation.setDeviceMetricsOverride',{'width':360,'height':760,'deviceScaleFactor':2,'mobile':True});call('Page.navigate',{'url':'file:///tmp/c2-v6168-cand.html'});time.sleep(.8)
def lcd(setup,out):
  ev("(()=>{notice='';open=false;history=[];page='home';phoneState.theme='Black.nth';document.body.dataset.theme='Black.nth';"+setup+";draw()})()");time.sleep(.3)
  r=json.loads(ev("(()=>{let b=document.querySelector('.lcd').getBoundingClientRect();return JSON.stringify([b.x,b.y,b.width,b.height])})()"))
  d=call('Page.captureScreenshot',{'format':'png','clip':{'x':r[0],'y':r[1],'width':r[2],'height':r[3],'scale':1}})
  open(out,'wb').write(base64.b64decode(d['result']['data']));print(out,ev("page"))
lcd("go('messaging');sel=1","/tmp/b-messaging.png")
lcd("go('conversations');sel=0","/tmp/b-conversations.png")
lcd("go('names');sel=0","/tmp/b-names.png")
lcd("go('datetimesettings');sel=0","/tmp/b-datetime.png")
lcd("go('log');sel=0","/tmp/b-log.png")
lcd("go('connectivity');sel=0","/tmp/b-conn.png")
lcd("go('bluetooth');sel=0","/tmp/b-bt.png")
