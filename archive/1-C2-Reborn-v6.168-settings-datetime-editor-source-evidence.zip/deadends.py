import json
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/c2-v6168-cand.html'))
pages=json.loads(ev("JSON.stringify(Object.keys(screens))"))
out=[]
for pg in pages:
  n=int(ev("(()=>{let a=screens[%s];return Array.isArray(a)?a.length:0})()"%json.dumps(pg)) or 0)
  for ix in range(n or 0):
    try:
      r=ev("(()=>{localStorage.clear();notice='';open=false;history=[];page='home';go(%s);sel=%d;draw();press('OK');return JSON.stringify([page,notice,document.querySelector('.lcd').innerText.replace(/\\n/g,'|').slice(0,90)])})()"%(json.dumps(pg),ix))
      p,nt,t=json.loads(r)
      if p=='itemdetail' or 'Not implemented' in nt or 'Not implemented' in t:
        row=ev("String(screens[%s][%d])"%(json.dumps(pg),ix));out.append((pg,ix,row,p,nt))
    except Exception as e: pass
for o in out:print(o)
print(len(out))
