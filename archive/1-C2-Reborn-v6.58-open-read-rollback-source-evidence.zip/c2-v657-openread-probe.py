exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.57-demo-reply-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);messageStore=seedMessageStore();messageStore.inbox=[{id:'read',body:'Read',name:'Demo',unread:true,icon:'unread'}];phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');page='messageread';readMessageIndex=0;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};draw()")
print(ev("JSON.stringify({unread:messageStore.inbox[0].unread,diskSame:localStorage.getItem('c2state')===stored})"))
