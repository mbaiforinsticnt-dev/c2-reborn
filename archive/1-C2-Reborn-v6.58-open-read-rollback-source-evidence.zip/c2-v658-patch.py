from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.57-demo-reply-rollback-candidate.html').read_text().replace('v6.57 handset parity','v6.58 handset parity').replace('C2 Reborn v6.57 |','C2 Reborn v6.58 |')
a="function markDemoRead(m){if(m&&m.unread){m.icon='read';m.unread=false;persist()}}"
b="function markDemoRead(m){if(m&&m.unread){let beforeIcon=m.icon,hadIcon=Object.prototype.hasOwnProperty.call(m,'icon'),beforeUnread=m.unread;m.icon='read';m.unread=false;try{persist()}catch(err){if(hadIcon)m.icon=beforeIcon;else delete m.icon;m.unread=beforeUnread;notice='Unable to save read status'}}}"
assert s.count(a)==1;s=s.replace(a,b)
a="messageStore.inbox[readMessageIndex].unread=false;persist()"
b="let row=messageStore.inbox[readMessageIndex],beforeUnread=row.unread;row.unread=false;try{persist()}catch(err){row.unread=beforeUnread;notice='Unable to save read status'}"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save demo reply|Folder memory full|';b='Unable to save demo reply|Unable to save read status|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.58-open-read-rollback-candidate.html').write_text(s)
