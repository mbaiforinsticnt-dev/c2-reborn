# C2 Reborn v5.57: populated-folder Move

Based on v5.56 contact correction, unchanged.

## Changes
- Move now accepts populated folders. Stable folder keys preserve the complete subtree, file identities, display names, metadata, and file state.
- Folder-to-descendant cycle guard prevents corrupting the tree.
- A destination sibling with the same name rejects the move with exactly "Name already exists", using the info notice icon. No replacement or merge.
- Collision returns to the source explorer Options with Move folder selected. No state mutation.

## SDK evidence
Moved Audit1.jpg into card folder 2 through UI, then moved populated folder 2 to Video clips and reopened Audit1.jpg. Attempt to move folder 2 into Images collided with existing folder 2, showed the exact notice, then returned to source Move folder Options.

## Verification
JavaScript syntax passes. 51 action/state tests pass: 15 broad, 9 explorer/Move, 14 existing copy/migration regressions, 7 contact, 6 focused populated-tree/collision tests. Candidate destination and collision screenshots inspected. Handler/state tests are not complete physical-button parity certification.

## Remaining
Destination Options currently remains a stated prototype gap. SDK confirmed six menu items: Open drive/Open folder, Add folder, Details, Type of view, Sort, Search. Open, Details and selecting List view were exercised; remaining branch actions need bounded continuation. No index.html deployment.
