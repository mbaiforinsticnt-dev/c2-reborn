exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.57-move-candidate.html'))
import json
# Independent known-valid state per check; assertions, no invented handset status.
checks=[
('default rename sort',"phoneState=migrateState(null);phoneState.galFileNames={'Photo0002.jpg':'aster.jpg'};galFolderName='Images';return galFolderFiles()[0].n==='aster.jpg'"),
('explicit descending sort',"phoneState.galSort='By name Descending';return galFolderFiles()[0].n==='Photo0005.jpg'"),
('default capture sort',"phoneState.galSort='';recordDemoCapture('Images');return galFolderFiles().map(f=>f.n).slice(0,2).join('|')==='aster.jpg|DemoPhoto0006.jpg'"),
('same folder copy no double count',"phoneState=migrateState(null);phoneState.galCopied={'Photo0001.jpg':'Images'};return galActualFiles('Images').length===5"),
('empty custom no creation date',"phoneState.galleryFolders=['Test'];return galFolderCreated('Test')===''&&galFolderSize('Test')==='0.0 kB'"),
('nested copy independent',"phoneState=migrateState(null);phoneState.galleryFolders=['Parent','Child'];phoneState.galFolderParents.Child='Parent';phoneState.galMoved={'Photo0002.jpg':'Child'};let r=galCopyFolderTo('Parent','Images');let child=galChildFolders(r.key)[0];let clone=galActualFiles(child)[0];phoneState.galDeleted.push(clone.n);return galActualFiles('Child').length===1&&galActualFiles(child).length===0"),
('cycle blocked',"let r=galCopyFolderTo('Parent','Child');return !!r.error"),
('copy cancel',"phoneState=migrateState(null);phoneState.galleryFolders=['Test'];page='gallery';history=[];sel=9;open=false;notice='';galFolderCopyStart();press('BACK');return page==='gallery'&&phoneState.galleryFolders.length===1"),
('empty UI copy persistence',"phoneState=migrateState(null);phoneState.galleryFolders=['Test'];page='gallery';history=[];sel=9;open=false;notice='';galFolderCopyStart();press('DOWN');press('OK');phoneState=migrateState(migrateState(JSON.parse(localStorage.getItem('c2state'))));return galChildFolders('Images').length===1&&galChildFolders('Memory card').includes('Test')"),
('migration messaging/contact/todo',"let raw={drafts:[{kind:'sms',to:'123',body:'Hello'}],todos:[{s:'Task',done:true,p:'High'}],contacts:[{name:'One',number:'123',home:'456',email:'one@test.invalid'}]};let z=migrateState(migrateState(raw));return z.drafts[0].body==='Hello'&&z.todos[0].done&&z.contacts[0].home==='456'&&z.contacts[0].email==='one@test.invalid'"),
('download contexts distinct',"phoneState=migrateState(null);page='gallerygraphicdownloads';sel=0;open=false;draw();return selectableRows(page).length===3&&screens.graphicdownloads.length===5"),
('copy unchanged builtins',"phoneState=migrateState(null);page='gallery';sel=1;open=false;galFolderCopyStart();return page==='gallery'&&phoneState.galleryFolders.length===0"),
('copy renamed file name survives reload',"phoneState=migrateState(null);phoneState.galleryFolders=['Test'];phoneState.galCopied={'Photo0001.jpg':'Test'};phoneState.galFileNames={'Photo0001.jpg':'Renamed.jpg'};let r=galCopyFolderTo('Test','Images');phoneState=migrateState(migrateState(phoneState));galFolderName=r.key;return galFolderFiles()[0].n==='Renamed.jpg'"),
('source delete independent',"phoneState.galDeleted.push('Photo0001.jpg');return galFolderFiles().length===1"),
]
for label,expr in checks:
 z=ev('(()=>{'+expr+'})()');print(label,z);assert z is True,(label,z)
print('PASS',len(checks))
# mobile visual evidence at usable size.
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
ev("phoneState=migrateState(null);phoneState.galleryFolders=['Test folder'];page='gallery';sel=9;open=false;notice='';galFolderCopyStart()")
import base64
for label,expr in [('mobile-picker','draw()'),('mobile-result',"sel=1;press('OK')"),('mobile-destination',"notice='';page='gallery';sel=1;open=false;draw();press('OK')")]:
 ev(expr);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path='/downloads/c2-next-'+label+'.png';open(path,'wb').write(base64.b64decode(r['result']['data']));print(path)
