from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.21-file-reference-reload-candidate.html').read_text().replace('v6.21 handset parity','v6.22 handset parity').replace('C2 Reborn v6.21 |','C2 Reborn v6.22 |')
a="let id='copyfile-'+(++phoneState.galFolderSerial);"
b="let id;do{id='copyfile-'+(++phoneState.galFolderSerial)}while(Object.values(GAL_FILES).flat().concat(phoneState.galEditedImages||[],phoneState.galCaptures||[],phoneState.galFolderItems||[]).some(v=>v.n===id)||(phoneState.galDeleted||[]).includes(id)||['galMoved','galCopied','galFileNames'].some(k=>galOwnText(phoneState[k],id)!==undefined));"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.22-copy-file-identity-candidate.html').write_text(s)
