import os
F=os.environ.get('C2F','c2-v6159-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v)
T="(()=>JSON.stringify({page,sel,t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|')}))()"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('profiles');sel=0;draw()})()")
def toform():
 fresh();ev("press('OK');0;press('DOWN');0;press('OK');0;press('DOWN');0")
def chooser():
 toform();ev("sel=1;draw();profRowChange();0");return ev(T)
r=chooser();print(r)
t('Ringing tone chooser = Tone downloads, Open Gallery, Nokia tune',all(x in r for x in ['Tone downloads','Open Gallery','Nokia tune']) and 'Shimmy' not in r and 'Passe' not in r)
t('Nokia tune selected, counter',ev("sel")==2)
chooser();ev("press('UP');0;press('UP');0;press('OK');0");r=ev(T);print(r);t('Tone downloads opens',"Tone downloads" in r and ('Ringing tones' in r))
ev("press('RSK');0");r=ev(T);print(r);t('Back returns to chooser',"Open Gallery" in r and "Nokia tune" in r and ev("page")=='radiolist')
chooser();ev("sel=1;draw();press('OK');0");r=ev(T);print(r);t('Open Gallery shows tone files',"Ringing tones" in r and ev("radioCtx.opts.length")==38)
ev("sel=24;draw();press('OK');0");print(ev(T));t('picking Shimmy stored',ev("profileToneStore(screens.profiles[profileTonesFor]).tone")=='Shimmy' and ev("page")=='profiletones')
ev("profRowChange();0");r=ev(T);print(r);t('re-open shows Shimmy as current',"Shimmy" in r and "Nokia tune" in r)
ev("press('OK');0");print(ev(T));t('selecting Shimmy row keeps it',ev("profileToneStore(screens.profiles[profileTonesFor]).tone")=='Shimmy')
chooser();ev("sel=1;draw();press('OK');0;press('BACK');0");t('Back from gallery returns to chooser',"Tone downloads" in ev(T))
toform();ev("sel=7;draw();profRowChange();0");print(ev(T))

# Timed
def timedpage():
 fresh();ev("press('DOWN');0;press('OK');0;press('DOWN');0;press('DOWN');0;press('OK');0")
timedpage();r=ev(T);print(r);t('Timed opens time entry for Silent',ev("page")=='profiletimed' and 'Profile expires' in r and 'Silent' in r)
ev("press('1');0;press('2');0");t('digits shown',':' in ev(T) and '12:__' in ev(T))
ev("press('OK');0");t('OK with 2 digits is ignored/invalid',ev("page")=='profiletimed')
import datetime
tt=(datetime.datetime.now()+datetime.timedelta(minutes=3)).strftime('%H%M')
timedpage();ev("".join("press('%s');0;"%c for c in tt)+"press('OK');0");r=ev(T);print(r)
t('timed sets Silent, stores prev General',ev("phoneState.profile")=='Silent' and ev("phoneState.timedProfilePrev")=='General' and ev("phoneState.timedProfile.name")=='Silent')
t('until within 3-4 minutes',0<ev("phoneState.timedProfile.until-Date.now()")<=240000)
ev("phoneState.timedProfile.until=Date.now()-1000;draw()");t('expiry rolls back to General',ev("phoneState.profile")=='General' and ev("phoneState.timedProfile")is None)
timedpage();ev("press('2');0;press('5');0;press('6');0;press('1');0;press('OK');0");t('invalid 25:61 rejected',ev("page")=='profiletimed' and ev("phoneState.profile")=='General')
# past time -> tomorrow
pt=(datetime.datetime.now()-datetime.timedelta(minutes=5)).strftime('%H%M')
timedpage();ev("".join("press('%s');0;"%c for c in pt)+"press('OK');0");t('past time means tomorrow',ev("phoneState.timedProfile.until-Date.now()")>20*3600000)
# second timed keeps original prev
ev("go('profiles');sel=2;draw();press('OK');0;sel=2;draw();press('OK');0");ev("".join("press('%s');0;"%c for c in tt)+"press('OK');0")
t('re-timing keeps original previous profile',ev("phoneState.timedProfilePrev")=='General')
# manual activate cancels timer
ev("notice='';go('profiles');sel=0;draw();press('OK');0;press('OK');0");t('manual Activate cancels timer',ev("phoneState.timedProfile")is None and ev("phoneState.profile")=='General')
print('checks',len(res),'pass',sum(1 for v in res if v is True))
