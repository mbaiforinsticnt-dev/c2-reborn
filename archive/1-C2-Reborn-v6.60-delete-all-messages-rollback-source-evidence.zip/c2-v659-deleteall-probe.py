exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.59-log-clear-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);messageStore=seedMessageStore();phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='confirmdelete';sel=0;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({same:JSON.stringify(phoneState)===before,page,drafts:phoneState.drafts,inbox:messageStore.inbox,diskSame:localStorage.getItem('c2state')===stored})"))
