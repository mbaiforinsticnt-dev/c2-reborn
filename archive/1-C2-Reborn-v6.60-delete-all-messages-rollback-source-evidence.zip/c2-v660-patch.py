from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.59-log-clear-rollback-candidate.html').read_text().replace('v6.59 handset parity','v6.60 handset parity').replace('C2 Reborn v6.59 |','C2 Reborn v6.60 |')
a="if(k==='OK'&&page==='confirmdelete'){phoneState.drafts=[];"
b="if(k==='OK'&&page==='confirmdelete'){let beforeState={drafts:phoneState.drafts,sent:phoneState.sent,thread:phoneState.thread,legacySent:phoneState.legacySent},beforeStore={threads:messageStore.threads,inbox:messageStore.inbox,saved:messageStore.saved,hidden:messageStore.hidden,marked:messageStore.marked,markFilter:messageStore.markFilter,numberedKeys:messageStore.numberedKeys};phoneState.drafts=[];"
assert s.count(a)==1;s=s.replace(a,b)
a="messageStore.numberedKeys=[];persist();history=[];page='messaging';sel=12;notice='Messages deleted';"
b="messageStore.numberedKeys=[];try{persist()}catch(err){Object.assign(phoneState,beforeState);Object.assign(messageStore,beforeStore);DEMO_THREAD=messageStore.threads.alex;notice='Unable to delete messages';draw();return}history=[];page='messaging';sel=12;notice='Messages deleted';"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to clear log list|Folder memory full|';b='Unable to clear log list|Unable to delete messages|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.60-delete-all-messages-rollback-candidate.html').write_text(s)
s=Path('/downloads/C2-Reborn-v6.60-delete-all-messages-rollback-candidate.html').read_text()
a="else if(page==='confirmdelete'){s.innerHTML='<div class=\"title\">Delete messages</div><div class=\"mailboxDialog\">Delete all messages?</div>';soft('Yes','','No')}"
b="else if(page==='confirmdelete'){s.innerHTML='<div class=\"title\">Delete messages</div>'+(!notice?'<div class=\"mailboxDialog\">Delete all messages?</div>':'');soft('Yes','','No')}"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.60-delete-all-messages-rollback-candidate.html').write_text(s)
