exec(open("/tmp/hdr.py").read())
flags="[page,noteTypesOv,calGoDate,calOv,todoDeleteConfirm,deleteNoteConfirm,deleteNotesConfirm]"
for pg,setj in (('calendar',"calOv='delnotes'"),('calendar',"calGoDate=true"),('calendar',"noteTypesOv=true"),('notes',"deleteNotesConfirm=1"),('notes',"deleteNoteConfirm=true"),('todo',"todoDeleteConfirm=true")):
    fresh2();ev("go('%s')"%pg);ev(setj);S('END');print(pg,setj,ev(flags))
print('--- OK after END')
fresh2();ev("go('notes')");ev("deleteNotesConfirm=1");n0=ev("JSON.stringify(typeof notes!=='undefined'?notes.length:null)");S('END');S('OK');S('OK');print(n0,ev("JSON.stringify(typeof notes!=='undefined'?notes.length:null)"),ev(flags))
