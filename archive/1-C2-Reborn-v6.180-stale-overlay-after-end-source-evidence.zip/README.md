# C2 Reborn v6.180 (source-evidence)
Change: End now clears stale Organiser overlay/confirm state (Calendar Delete notes submenu, Go to date, note-type list, To-do delete confirm, Notes delete / delete all confirm) and always returns to standby. Also cleared if any survive at standby.
Source: Tab v6.176 Organiser leads 1-3 (unverified), reproduced on v6.179: after End the flags stayed set (noteTypesOv, calGoDate, calOv='delnotes', todoDeleteConfirm, deleteNoteConfirm, deleteNotesConfirm), calendar remained the page for two of them, so a later OK could run the delete.
Evidence class: inferred (End always returns to standby on Nokia S40), not C2-01 handset-proven.
Focused: focused-stale-overlay-after-end.py (all 6 cases end on home with every flag cleared).
Not done: Calendar delete confirms (lead 6), alarms, date validation, To-do items 7-10, Calls leads.
