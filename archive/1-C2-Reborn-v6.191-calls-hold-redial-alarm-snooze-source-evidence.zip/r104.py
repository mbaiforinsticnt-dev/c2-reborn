exec(open("/tmp/hdr.py").read())
fresh2();ev("phoneState.calls.dialled.unshift({number:'7770001',time:'Today 00:01'});persist();go('allcalls')");S('OK');print('redial',ev('activeCall'))
