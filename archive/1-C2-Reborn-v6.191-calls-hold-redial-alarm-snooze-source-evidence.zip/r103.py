exec(open("/tmp/hdr.py").read())
import time as tm
fresh2();ev("go('home')")
for k in '5551234':S(k)
S('CALL');S('LSK');S('DOWN');S('OK');tm.sleep(3.5);print('muted',ev(T)[:120])
S('LSK');S('DOWN');S('DOWN');S('OK');tm.sleep(3.5);print('held',ev(T)[:120]);S('END')
ev("go('allcalls')");print('all',ev(T)[:200]);S('OK');print('redial',ev('activeCall'))
S('END')
fresh2();ev("phoneState.calls.dialled.unshift({number:'7770001',time:'Today 00:01'});persist();go('allcalls')");print(ev(T)[:140])
# alarm
fresh2()
ev("itemAlarm={kind:'Reminder',text:'Dentist',when:'03-10-2026 17:10'};page='itemalarm';draw()");print(ev(T)[:150])
S('LSK');print(ev('page'),repr(ev('notice')),ev('itemAlarmSnooze!==null'))
ev("itemAlarmSnooze.at=Date.now()+1500");tm.sleep(3);print('resnooze',ev('page'),ev(T)[:80]);S('RSK');print(ev('page'),ev('itemAlarmSnooze'))
