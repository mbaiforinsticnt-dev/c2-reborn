C2 Reborn v6.191 (base v6.190). Focused scripts r103/r104: python3 rNN.py index.html
Fixed (reproduced on v6.190, from Tab's v6.189 retest, each reproduced first):
- In-call "On hold"/"Muted" line never showed: CSS .inCall small{display:none!important} hid it. Removed.
- All calls listed missed, received, dialled in that order, so a fresh call sat below the future-dated demo Alex Morgan 22:41 and Call-Call redialled the wrong row. Records whose time is "Today HH:MM" at or before the handset clock now sort first, newest first; icon mapping and selection use the same list. Inferred ordering, no handset footage.
- Item (Calendar/To-do) alarm screen: added the alarm icon, darker date line, and Snooze (LSK, uses the Alarm clock snooze minutes). Inferred, no handset evidence.
Not changed: call timer during hold (no footage), Gallery folder rename returning with Options open (deliberate older code), Clear log confirm (handset says none), Send note via Calendar OK (intended behaviour unknown).
