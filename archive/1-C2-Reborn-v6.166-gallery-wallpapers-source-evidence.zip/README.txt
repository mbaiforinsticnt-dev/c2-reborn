v6.166: Gallery > Graphics > Wallpapers (5 images, 240x320 JPEG) + Settings wallpaper > Graphic downlds. > Wallpapers.
Images are NOT Nokia firmware originals. They are free-licence photos from Wikimedia Commons (CC BY-SA 3.0/4.0), cropped to 3:4 and resized to 240x320.
Source page, author, licence, source file URL and SHA-256 of each output are in wallpaper-sources-and-licences.json (raw*.jpg = downloaded source thumbnails).
Firmware search result: SDK carve has only 107x160 Chinese-market zodiac thumbnails; SDK predefwallpapers folders are empty.
Tests: v6.166 focused 10/10, v6.165 15/15, v6.164 15/15, v6.163 23/23, v6.158 5/5; carried profile/divert set (68 76 84 86 90 118 129 131 132 133 143 151 171) pass. Full sweep to follow.
