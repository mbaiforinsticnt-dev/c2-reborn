# Working notes (saved in repo after a workspace reset on 5 Oct 09:36)
Live builds: v6.201 blob c08432ac5b0de5a32bbfa919586f7d474b3dcc1a (run #46, archive 5a77f244). v6.202 follows this note.
Test harness: tests/hdr.py (CDP over websocket, run `bash chrome.sh` first, then `python3 rNN.py <file.html>`), crawlers a3-a7. The old 178-test regression sweep (cf-N.py) was lost in the reset and has NOT been rebuilt.
Open items: arrows on list-opening rows (Moti: follow the emulator; emulator install lost too, needs re-supplying), Black/Dark contrast: Black done (no list-row faults), Dark not crawled; Tab leads unchecked: Calendar day selection contrast Black/Dark, Keypad tones silent, unsorted new contacts, editor submenu Back collapses levels, Equaliser outline-only focus, Calendar editor last field clipped; Tab leads not reproduced: Call on highlighted contact opens empty dialler, Writing language popup off screen.
Rules: Moti's 4 rules (full-row focus, list wrap, Options sized to whole rows, expandable-row arrow). Arrow art: Moti's Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead), author not recorded.
Publishing: atomic Actions workflow 4-publish-index.yml (zip_path archive/1-<name>.zip, member index.html, new_blob, base_blob). Banked zip must byte-match a raw download pinned to the commit.

## v6.203 (2026-10-05)
- Saved-notice tick (listIcons.CHECK) replaced by a CROP of Moti's emulator screenshot (image-4fd8f09f), 56x56. Crop, not an original firmware file (Moti permission 10:15). Unicode check glyphs replaced by the same image.
- Go to profile icons and plain Settings > Profiles already match his screenshots (no change).
Base blob: c531b2156eba4434e3c2463fa0772a9edc0816b7

## v6.204 (2026-10-05)
- Memory card Options per handset video (frames in source-evidence/sheet0-5.png). Seen in footage: Set password -> Enter new password (numeric, masked, last digit shown, max 8, Options/OK/Clear) -> Verify new password -> "Password set" note; Delete password -> "Memory card will be unlocked. Continue?" Yes/No -> "Enter memory card password:" -> "Password deleted" note.
- NOT in footage (inferred): Change password flow (old, new, verify), wrong-password and mismatch messages, Rename/Format dialogs, minimum password length.
- Hold # popup: from emulator screenshot only; hold time is the existing 700 ms (Moti guessed about 0.5 s); Number mode sets 123, Writing language opens the existing page, Paste always dim (inferred).
- Paste is enabled only when the clipboard has content (Moti 10:31); selecting it in the Gallery list does nothing (no target; inferred).

## v6.205 (2026-10-05)
- Memory card row icon replaced by crop from Moti C2 photo (new listIcons.MEMCARD, 30x30, white background removed). Used in Gallery list, Gallery search, move/copy target and editor picker. 0534 (Gallery app icon) untouched.

## v6.206 (2026-10-05)
- Inbox (single messages) rows: Unicode envelope glyphs replaced by images. Unread = made closed envelope (Moti 10:46 instruction), read = VIEW_ICON_READ. CSS filter none so the Nokia selected-row invert does not recolour it.
- Conversation bubbles and Conversations list unchanged (they already use image icons).
- Memory card icon (Gallery list) REPLACED: v6.205 used a zoom of the HTML own old icon by mistake; now a 30x30 crop of Moti emulator screenshot (notch top-left, contacts left), image-821ba14f (10:53). Crop, not a firmware file. Original-file extraction from SDK package_c.bin attempted separately.

## v6.207 (2026-10-05)
- Conversation view: selected bubble scrolls fully above the softkeys (keepConvSelVisible, 34px end spacer). Tested 4 viewports x 2 themes.
- Open message view and Inbox read view: UP/DOWN scroll long text (did not scroll before).
- Sent bubble icon = crop of Moti emulator zoom (envelope + green tick bottom-right), image-e18b983a. Old one came from the HTML own VIEW_ICON_SENT (green square overlay), not a firmware file. Crop, not firmware file.
- Received bubbles in conversation view: unread/received = made closed envelope (same as Inbox), read = firmware open envelope. Nokia invert filter off for these icons.

## v6.208
- Closed (0421), open (0758), sent (0603), memory card (0533) are ORIGINAL firmware files now (from package_c.ppm). Made envelope and the two crops kept in source-evidence as rollback.
- Open envelope variant 0758 is my pick (0760/0995/0960 look the same at 30px); Moti has not picked.

## v6.209
- Contact Back-after-save fix (history dropped the add-contact form; cfVal guard). Reproduced from the external c2-audit-harness (untrusted, verify.py re-implemented), banked in source-evidence/c2-audit-harness.
- ?calc= URL param restricted to digits/operators.
- Calculator 7/0: note "Cannot divide by zero" with firmware 1053 info icon (Moti handset photo 11:28). Display keeps 7.
- Tick = firmware 1062 (replaces crop).
- Not done: Add detail empty list, 7/0 only, dark crawl, emulator.

## v6.210
- Contact details > Options > Add detail now opens the Add detail tree (Number/Internet/Multimedia/Personal info) from Moti's 11:33 handset photos; leaves reuse the Edit-contact add-field flow (opens Edit contact with the new field). Number list from contact details = General, Mobile, Home, Work, Fax (5, per photo); the Edit-contact form keeps its own 7-item list.
- Notes (.alarmDialog) are dark with white bold text in Black, Dark and Legacy Black themes.
- Inferred, not footage: after choosing a leaf the field opens in the Edit contact form; Back from the submenu root returns to the form (handset behaviour unknown).

## v6.211
- Memory card icon: Moti's emulator icon (11:40) = firmware 0533 (diff 2.2 only from JPEG artefacts). Already used as MEMCARD. The Gallery picker row "32" used GPcard = firmware 0720 (a SIM card with yellow contacts); now 0533. No other SD-card uses found (sync icons 0908/0909, 1080 are different pictures).

## v6.212
- Messaging menu Conversations row: firmware 0955 unchanged but drawn 22% larger (CSS scale) and 12% brighter (CSS filter) per Moti 11:46. Adjustment only: the PNG is the untouched firmware file. Rollback = remove the style attribute (v6.211).

## v6.213
- Open envelope (VIEW_ICON_READ) is MADE, not firmware: Moti rejected the 30x30 firmware open envelopes (0758/0760/0995/0960: dark flap, black pixel outline). Built from firmware closed envelope 0421 (V cut for the front pocket, 0421's own triangle flipped as the raised flap). Script: source-evidence/open-envelope/mkopen.py. Rollback: firmware 0758 (v6.212).

## v6.214
- Moti's emulator closed envelope = firmware 1056 (= 1057), not 0421. Unread icon = 1056. Read icon (VIEW_ICON_READ) = MADE from 1056 by mk3.py variant C: full 1056 body, straight outlined top, lighter inside, flap folded up behind, same width. Earlier "squashed flap" version rejected by Moti ("Terrible"), never published. Rollback: v6.213 blob c08536d4.

## v6.215
- v6.214 (live briefly) had a made open envelope Moti rejected. v6.215 read icon (VIEW_ICON_READ) = Moti's own open envelope image (his ChatGPT-made file image-5402b817.jpg), black background keyed to transparent, Lanczos-downscaled to 56x56 canvas (content 54x47), no recolouring. Unread = firmware 1056. Rollback: v6.214 blob 1dbb8adf (or v6.213 c08536d4).

## v6.216
- Calculator "Cannot divide by zero" note matched to Moti's handset photo (image-65390d87): info icon 29 px (was 40), 23 px from right edge, vertically centred; panel full-width, 135 px tall, text wraps "Cannot divide / by zero", font 1.25em. Applies to .alarmDialog.calcNote only (the only note using this style). Comparison: source-evidence/cmp231.png.
- Font audit: Nokia faces embedded (Sans, Cn, Title SemiBold, Digi, Title A). Gaps: .key and .brand use Arial (outside LCD); 24 symbol glyphs (arrows/radio/media glyphs) not in any Nokia font and fall back. Rollback: v6.215 blob 04ec06ae.

## v6.217
- Read icon = Moti's ChatGPT open envelope with the horizontal band removed (clean.py steps in source-evidence/open-envelope-final), 56 px. Replaces firmware open-envelope slots 0758/0760/0960/0995 in the icon packs. Originals remain in earlier archive/ zips. Rollback: v6.216 blob 1694839b.

## v6.218
- Conversation view centre key: truncated (3-line clamp, scrollHeight>clientHeight+8) selected message => "Open" (opens full message, marks read: closed -> open envelope); fully shown incoming => "Reply"; outgoing => "Open" (unchanged). The hardware OK key follows the same rule (before it always replied). Tests t232/t233. No handset footage for this view was found; rule is Moti's. Rollback v6.217 blob 763a0e3c.

## v6.219
- Opened message view: received message => centre "Reply" (OK replies to the conversation number), sent => "Send" (unchanged). Options list unchanged (Delete, Send copy, Edit, Move, Use detail, Copy to Calendar, Copy as template, Select). Tests t234. Rules file: BEHAVIOUR-RULES.md. Rollback v6.218 blob 3400ae50.
- a7.py = label-vs-action crawl (first run found compose screens with empty softkey labels that still act - see a7 output when finished).

## v6.220
- Open envelope body now matches the closed 1056 body: body x 4..52 (49 px), bottom y=46; flap rises above (open icon y 4..46). Master: source-evidence/open-envelope-final/open56m3.png. Rollback v6.219 blob b3cca1a3.

## v6.221
- Rule 7 key auto-repeat (shared in pressStart/pressEnd for UP/DOWN/LEFT/RIGHT, 0.8 s delay, 250 ms step). Rollback v6.220 blob 520ad386.

## v6.222
- Keypad (.key) and .brand font: Arial -> Nokia Sans Wide (maisfontes.com, name table "Nokia Sans Wide", 233 glyphs, embedded woff2 base64), fallback Nokia Sans S40, Arial. In-screen fonts unchanged (bundled firmware S40 fonts). Symbols not in Wide (◉ ⌂ ✶ ↻ ▲ ◀ ▶ ▼) still fall back. Rollback v6.221 blob 7be6dacd.
- Full Nokia Sans family (13 files) stored under fonts/ in the repo (non-site folder); URLs in fonts/SOURCES.txt.

## v6.223
- Message editor attachment strip rebuilt from Moti's emulator video (13:11): 11 items in emulator order (Image, Sound clip, Calendar note, Business card, Theme, Streaming link, Gallery file, Text field, Text template, Video clip, Camera), starts on Image, name tooltip ~1 s, Insert centre key, Close right key in multimedia, header "New multimedia 1/1". Business card converts SMS->MMS with note "Message changed to multimedia". Icons are CROPS from Moti's emulator footage (30x30, source-evidence/sms-strip-icons-from-moti-video), not firmware, blurry. Invented "not implemented" notice removed. Other items (image gallery flow, sound, video, camera, theme, stream, gallery file, calendar note, text field/template, attachments preview, remove) still TODO. Rollback v6.222 blob dc3263f7.

## v6.224
- SMS attachment flow, part 2 (Moti video): Business card is an object in composeObjs; Preview -> Attachments list (VCARD.vcf 0.1 kB, Options/Open/Back); Open -> "No data to display" (info); Options Save/Details; Save -> "Business card saved to phone memory"; Options > Remove -> "Remove object? VCARD.vcf" Yes/No; Yes -> note "Message changed to text message", header back to New text message. Missing vs emulator: yellow file icon on the Attachments row, Details content, Image gallery flow, other items, "Save message?" on close. Rollback v6.223 blob d1e82772.

## v6.225 (5 Oct 14:09)
- Confirm prompts (Delete N items?, Delete folder?, Delete?, Format memory card?, Delete favourite?, Remove object?, Save message?) are now a half-height grey box (from 42% down to the softkeys) over a dimmed page, as in Moti's emulator video (S10 t=284, t=196). Was full-screen dark panel (.optionsPanel inset:0).
- Note tick (CHECK) is byte-identical to firmware 1062 (also 1058/1061); no change.
- Icon audit sent to Moti: 123 non-exact icons, sheets A-D.

## v6.226 (5 Oct 14:19)
- SMS attachment strip icons (11) replaced with firmware files downscaled to 18x18 (LANCZOS, no video crops): sound 0513, calendar 0559, bcard 0589, theme 0608, gallery 0697, template 1023, video 0521, camera 0567 (the Media-folder camera). 
- SUBSTITUTES, no firmware match for the emulator art found: image (fw 0716, picture), stream (fw 0532, globe+arrow; emulator shows globe+phone), textfield (fw 0948, plain text doc; emulator shows doc+pencil). Need 100% emulator screenshots from Moti.

## v6.227 (5 Oct 14:31)
- Strip icons now the exact firmware set 0349 image, 0350 textfield, 0351 template, 0352 calendar, 0353 gallery, 0354 sound, 0355 bcard, 0356 theme, 0357 stream, 0358 video (50x66 files, trimmed to the art, LANCZOS to 18px) + 0567 camera (Media folder). Found by matching Moti's emulator reference screenshots. No substitutes left.
- Display settings > Fonts (row 10, last): Default (current firmware look), Regular, Light, Bold, Condensed, Wide. Nokia Sans family from fonts/ zip, subset to Latin, woff2 (+~135 kB). Applies to the screen UI (.lcd). Saved in dispVals[9]; Restore default resets it.
- Display list navigation wraps at 10 rows.
- Keypad symbols (1 voicemail, 0 refresh, # house/star): no firmware icons exist for the printed keypad art; not changed.

## v6.228 (5 Oct 14:48)
- Equal-height list rows rule (BEHAVIOUR-RULES 8). Display settings: 4 rows at equal height, dark rounded highlight, value bottom. Generic normaliser fixes any other list with unequal rows; crawl a8 records rowh per screen. Rollback v6.227 blob f8381e3e.

## v6.229 (5 Oct 15:20)
- Moti 15:17: equal rows must fill the list area down to the softkey bar. Display settings: 4 rows x 57 px fill exactly (no strip above the soft keys). Row count per page type is reported with the crawl (a8 now logs gap per list). Rollback v6.228 blob 594ba545.

## v6.230 (5 Oct 16:15)
- Messaging and Create message: 4 rows x 58 px fill the list area (were 4x62 overflowing 13 px / 4x47 with 47 px blank). Names list (Black theme): dark rounded highlight bar and smaller text as in Moti's 14:52 emulator frame; row count unchanged (3 contacts). Rollback v6.229 blob 2de11714.

## v6.231 (5 Oct 16:22)
- Moti 16:19: Create message / Messaging row sizes were too big vs emulator. Reverted to the original heights (Create message 4 x 47, Messaging 4 x 62) from v6.229. Names highlight change from v6.230 kept. Lesson: fill-to-bottom must not resize pages whose original height matches the emulator; only Display settings was normalised (Moti's frame). Rollback v6.230 blob af0183bd.

## v6.232 (5 Oct 16:32)
- Create message from Moti's handset photo (16:28, real C2): row pitch 34 px (handset 32-34 at 240 wide), icon 22 px (handset about 20), item text 24px (handset text width about 149 units vs ours 115 at 20px; the handset font is wider, 24px gives 138). Highlight left white (handset photo shows theme lavender, theme differs). No emulator frame yet; Messaging root untouched. Rollback v6.231 blob 6a96b447.

## v6.233 (5 Oct 16:40)
- Moti 16:36 gap rule: title centre to first row top was 13 units on rows pages (handset 17.8, emulator Names/Display/Options 23.6). Now 19 (rows pages) / 22 (Display, Names). Rollback v6.232 blob 0442e026. Messaging 4x62 now clips 19 px at bottom (no emulator frame yet).

## v6.234 (5 Oct 16:45)
- Options menu restyled to Moti's Names Options emulator frame (Black theme): grey translucent panel under the title, uniform 30 px rows, 16px text, dark rounded selected row, small submenu arrows. Item list unchanged (View conversations / Find on map kept, pending Moti). Messaging root rows 56 px so the 4th row no longer clips (fit, not a measurement). Rollback v6.233 blob 7922befa.
