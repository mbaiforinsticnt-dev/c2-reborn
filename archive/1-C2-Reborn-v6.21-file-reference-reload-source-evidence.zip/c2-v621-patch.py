from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.20-deleted-file-reload-candidate.html').read_text().replace('v6.20 handset parity','v6.21 handset parity').replace('C2 Reborn v6.20 |','C2 Reborn v6.21 |')
a="for(let [a,b] of Object.entries(x[key]).slice(0,200))if(typeof b==='string')d[key][cleanText(a,164)]=cleanText(b,key==='galFileNames'?164:225)"
b="for(let [a,b] of Object.entries(x[key]))if(typeof b==='string')d[key][cleanText(a,164)]=cleanText(b,key==='galFileNames'?164:225)"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.21-file-reference-reload-candidate.html').write_text(s)
