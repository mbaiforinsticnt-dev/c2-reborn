exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.117-conversation-mark-menu-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for enabled in [False,True]:
 for digits in ['0000','2359','0731']:
  ev("phoneState=migrateState(null);phoneState.alarm.on="+str(enabled).lower()+";phoneState.alarm.days=[1,3];persist();before=JSON.stringify(phoneState);beforeAlarm=phoneState.alarm;stored=localStorage.getItem('c2state');page='alarmedit';alarmDigits="+json.dumps(digits)+";history=['alarmclock'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=str(enabled)+digits
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.alarm===beforeAlarm&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save alarm time'&&document.getElementById('screen').innerText.includes(notice)&&page==='alarmedit'&&history.length===1&&alarmDigits==="+json.dumps(digits))
  if not enabled and digits=='0000':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v697-alarm-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return phoneState.alarm.on&&phoneState.alarm.time==="+json.dumps(digits[:2]+':'+digits[2:])+"&&phoneState.alarm.days===beforeAlarm.days&&page==='alarmclock'")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState.alarm.on&&phoneState.alarm.time==="+json.dumps(digits[:2]+':'+digits[2:])+"&&JSON.stringify(phoneState.alarm.days)==='[1,3]'")
print('PASS',len(checks))
