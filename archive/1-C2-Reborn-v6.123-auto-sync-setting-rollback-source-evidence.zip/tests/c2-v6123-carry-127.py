exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.123-auto-sync-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for choice in ['view','week','tone','autoDelete']:
 ev("phoneState=migrateState(null);calChoice="+json.dumps(choice))
 opts=ev('calChoiceOptions()')
 for idx,value in enumerate(opts):
  if value=='Open Gallery':continue
  ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);beforePrefs=phoneState.calPrefs;stored=localStorage.getItem('c2state');page='calchoice';calChoice="+json.dumps(choice)+";sel="+str(idx)+";history=['calsettings'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=choice+str(idx)
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.calPrefs===beforePrefs&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return notice==='Unable to save calendar setting'&&document.getElementById('screen').innerText.includes(notice)&&page==='calchoice'&&history.length===1&&sel==="+str(idx))
  if choice=='week' and idx==0:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6103-calendar-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
  t(label+' retry',"return phoneState.calPrefs[calChoice]==="+json.dumps(value)+"&&page==='calsettings'")
  call('Page.reload');time.sleep(.15)
  t(label+' reload',"return phoneState.calPrefs["+json.dumps(choice)+"]==="+json.dumps(value))
print('PASS',len(checks))
