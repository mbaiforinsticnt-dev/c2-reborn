exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.123-auto-sync-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for pg in ['camera','videorecorder','voicerecorder']:
 ev("phoneState=migrateState(null);phoneState.galCaptures=Array.from({length:100},(_,i)=>({folder:'Images',n:'DemoPhoto'+String(i+6).padStart(4,'0')+'.jpg',s:'1.2 MB'}));persist();before=JSON.stringify(phoneState);page="+json.dumps(pg)+";notice='';recording=false;cameraTimer=null;cameraShot=false;press('OK');"+("press('OK');" if pg!='camera' else ''))
 t(pg+' capacity no false success',"return notice==='Demo file memory full'&&JSON.stringify(phoneState)===before&&!cameraShot")
 call('Page.reload');time.sleep(.3)
 t(pg+' reload retains all100',"return phoneState.galCaptures.length===100")
for pg in ['camera','videorecorder','voicerecorder']:
 ev("phoneState=migrateState(null);page="+json.dumps(pg)+";recording=false;cameraTimer=null;cameraShot=false;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK');"+("press('OK');" if pg!='camera' else ''))
 t(pg+' quota rolls back and reports failure',"return notice==='Unable to save demo file'&&!phoneState.galCaptures.length&&!cameraShot")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK');"+("press('OK');" if pg!='camera' else ''))
 t(pg+' retry saves once',"return phoneState.galCaptures.length===1&&notice.includes('saved')")
 call('Page.reload');time.sleep(.3)
 t(pg+' retry persists',"return phoneState.galCaptures.length===1")
ev("phoneState.galCaptures=Array.from({length:100},(_,i)=>({folder:'Images',n:'f'+i,s:'1 B'}));page='camera';notice='';cameraTimer=null;press('OK')")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v624-demo-full.png','wb').write(base64.b64decode(d['result']['data']))
ev("page='camera';notice='';cameraTimer=3;cameraShot=false;realTimeout=window.setTimeout;window.setTimeout=function(fn,ms){if(ms===3000){timerCallback=fn;return 1}return realTimeout(fn,ms)};press('OK');window.setTimeout=realTimeout;timerCallback()")
t('Self timer capacity reports failure without shot',"return notice==='Demo file memory full'&&!cameraShot&&phoneState.galCaptures.length===100")
print('PASS',len(checks))
