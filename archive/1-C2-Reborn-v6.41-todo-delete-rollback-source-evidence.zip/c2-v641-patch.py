from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.40-note-delete-rollback-candidate.html').read_text().replace('v6.40 handset parity','v6.41 handset parity').replace('C2 Reborn v6.40 |','C2 Reborn v6.41 |')
a="phoneState.todos.splice(todoDeleteFromView?todoViewIdx:sel,1);sel=Math.max(0,Math.min(sel,phoneState.todos.length-1));persist();todoDeleteConfirm=false;"
b="let beforeTodos=phoneState.todos.slice(),beforeSel=sel;phoneState.todos.splice(todoDeleteFromView?todoViewIdx:sel,1);sel=Math.max(0,Math.min(sel,phoneState.todos.length-1));try{persist()}catch(err){phoneState.todos=beforeTodos;sel=beforeSel;notice='Unable to delete to-do note';draw();return}todoDeleteConfirm=false;"
assert s.count(a)==1;s=s.replace(a,b)
a="if(todoDelNotesConfirm){if(k==='OK'||k==='LSK'){if(todoDelNotesConfirm==='all')";b="if(todoDelNotesConfirm){if(k==='OK'||k==='LSK'){let beforeTodos=phoneState.todos.slice();if(todoDelNotesConfirm==='all')";assert s.count(a)==1;s=s.replace(a,b)
a="}persist();sel=0;todoDelNotesConfirm='';draw()}";b="}try{persist()}catch(err){phoneState.todos=beforeTodos;notice='Unable to delete to-do notes';draw();return}sel=0;todoDelNotesConfirm='';draw()}";assert s.count(a)==1;s=s.replace(a,b)
for a,b in [("if(todoDeleteConfirm){s.insertAdjacentHTML","if(todoDeleteConfirm&&!notice){s.insertAdjacentHTML"),("if(todoDelNotesConfirm){s.insertAdjacentHTML","if(todoDelNotesConfirm&&!notice){s.insertAdjacentHTML"),("Unable to delete notes?|Folder memory full|","Unable to delete notes?|Unable to delete to-do notes?|Folder memory full|")]:
 assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.41-todo-delete-rollback-candidate.html').write_text(s)
