exec(open("/tmp/hdr.py").read())
fresh2();ev("phoneState.galleryFolders=['Trip'];persist();go('gallery')")
print(ev("[page,sel,galOrder().length,screens.gallery.length]"))
mx=0
for q in range(26):
    S('DOWN');s=ev("sel");mx=max(mx,s)
print('max sel',mx,ev("galOrder().length"),ev(T)[:200])
