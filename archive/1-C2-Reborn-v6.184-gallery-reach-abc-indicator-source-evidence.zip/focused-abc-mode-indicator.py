exec(open("/tmp/hdr.py").read())
fresh2();ev("startMessage('hello','07700900999')");ev("composeFocus=1");
for m in ('abc','ABC','123'):
    ev("inputMode='%s';draw()"%m);print(m,ev("document.getElementById('statusMode').textContent"))
