# C2 Reborn v6.184 (source-evidence)
Changes (both reproduced on v6.183 first):
1. Gallery list cursor now covers newly added top-level folders. With a user folder "Trip" the list has 10 entries but Down wrapped after 9 (max sel 8), so the 10th was unreachable. Now max sel 9. selectableRows('gallery') uses galOrder().
2. Message editor mode indicator: in ABC (caps) mode it read "Abc"; now "ABC". 'abc' and '123' unchanged.
Evidence class: inferred (cursor must reach every list row; indicator must match the mode), not C2-01 handset-proven.
Not reproduced: Tab's Gallery Sort/Send/Type of view submenus needing two Ends (End from all five submenus goes to standby in one press on v6.183; check-gallery-submenu-end-not-reproduced.py).
Not changed: Gallery Send > Message picture (compose has no attachment model, images are "not implemented" there; would be new inferred UI), held Clear / long-press digits (harness cannot hold keys).
