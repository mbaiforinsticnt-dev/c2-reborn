exec(open("/tmp/hdr.py").read())
for sub in ('galsend','galsort','galview','galsortdir','galmarking'):
    fresh2();ev("go('gallery')");ev("open=true;pageSub='%s';optParent={list:['Open','Details'],os:0};sel=0;draw()"%sub)
    print(sub,ev("(()=>{try{press('END');return [page,open,pageSub,optParent&&1]}catch(e){return String(e)}})()"))
