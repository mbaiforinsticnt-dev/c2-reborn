from PIL import Image,ImageDraw
import numpy as np,os,sys
f=[x for x in os.listdir('/tmp/fw/png') if x.startswith('1056')][0]
im=Image.open('/tmp/fw/png/'+f).convert('RGBA');a=np.array(im).astype(float);W=H=56
def build(OFF,tip,ins,flapside):
    x0,x1=3,52;y0=11;vy=31;cx=28
    mask=Image.new('L',(W,H),0);ImageDraw.Draw(mask).polygon([(x0-1,y0-1),(x1+1,y0-1),(cx,vy-1)],fill=255)
    m=np.array(mask)>0
    body=a.copy();body[m]=0
    c=np.zeros_like(a)
    def sh(arr,dy):
        o=np.zeros_like(arr);o[dy:]=arr[:H-dy];return o
    top=y0+OFF  # new top edge row
    # inside (back panel) rect from top to bottom
    for y in range(top,min(47+OFF,H)):
        for x in range(x0,x1+1): c[y,x]=ins+[255]
    # outline top row and sides
    dk=[92,66,12,255]
    for x in range(x0-1,x1+2): c[top-1,x]=dk
    b=sh(body,OFF);al=b[:,:,3:4]/255.;c[:,:,:3]=b[:,:,:3]*al+c[:,:,:3]*(1-al);c[:,:,3]=np.maximum(c[:,:,3],b[:,:,3])
    # flap: triangle base at top-1, tip at tip, yellow gradient
    img=Image.fromarray(np.zeros((H,W,4),'uint8'),'RGBA');d=ImageDraw.Draw(img)
    base=top-1
    pts=[(x0-1,base),(x1+1,base),(cx,tip)]
    # gradient fill
    for y in range(tip,base+1):
        t=(y-tip)/max(1,base-tip);col=(int(255-10*t),int(226-30*t),int(70-20*t),255)
        w=(x1+1-x0+1)/2*t
        d.line([(cx-w+.5,y),(cx+w-.5,y)],fill=col)
    d.line([pts[0],pts[2],pts[1]],fill=tuple(dk),width=1)
    d.line([pts[0],pts[1]],fill=tuple(dk),width=1)
    fl=np.array(img).astype(float);al=fl[:,:,3:4]/255.
    # flap behind body? draw flap first then body where body opaque
    out=fl.copy()
    al2=c[:,:,3:4]/255.;out[:,:,:3]=c[:,:,:3]*al2+out[:,:,:3]*(1-al2);out[:,:,3]=np.maximum(out[:,:,3],c[:,:,3])
    return Image.fromarray(out.clip(0,255).astype('uint8'),'RGBA')
V={'A':(8,3,[232,170,40],0),'B':(7,2,[214,150,30],0),'C':(8,4,[240,184,60],0),'D':(8,3,[200,140,30],0)}
sheet=Image.new('RGBA',(5*130,200),(70,70,70,255))
for i,(k,(o,t,ins,s)) in enumerate(V.items()):
    r=build(o,t,ins,s);r.save('/tmp/v3%s.png'%k);sheet.alpha_composite(r.resize((112,112),Image.NEAREST),(i*130+5,5));sheet.alpha_composite(r,(i*130+30,130))
    sheet.alpha_composite(r.resize((30,30),Image.LANCZOS),(i*130+90,130))
sheet.alpha_composite(im.resize((112,112),Image.NEAREST),(4*130+5,5))
sheet.convert('RGB').save('/tmp/v3sheet.png')
