from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.01-saved-name-persistence-candidate.html').read_text().replace('v6.01 handset parity','v6.02 handset parity').replace('C2 Reborn v6.01 |','C2 Reborn v6.02 |')
a='let map={},snap=sourceKeys.map'
b="let rollback={galleryFolders:phoneState.galleryFolders.slice(),galFolderNames:{...phoneState.galFolderNames},galFolderParents:{...phoneState.galFolderParents},galFolderItems:phoneState.galFolderItems.slice(),galFolderSerial:phoneState.galFolderSerial};let map={},snap=sourceKeys.map"
assert s.count(a)==1;s=s.replace(a,b)
a='}}persist();return {key:map[source]}}'
b="}}try{persist()}catch(err){Object.assign(phoneState,rollback);return {error:'Unable to save copied folder'}}return {key:map[source]}}"
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('No connection settings found|Fax not activated','No connection settings found|Fax not activated|Unable to save copied folder',1)
Path('/downloads/C2-Reborn-v6.02-folder-copy-rollback-candidate.html').write_text(s)
