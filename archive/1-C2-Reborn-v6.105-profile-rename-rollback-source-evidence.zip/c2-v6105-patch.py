from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html').read_text().replace('v6.104 handset parity','v6.105 handset parity').replace('C2 Reborn v6.104 |','C2 Reborn v6.105 |')
a="if(k==='OK'){commitProfileName();persist();back();return}"
b="if(k==='OK'){let beforeNames=screens.profiles,beforeTones=phoneState.profileTones,beforeProfile=phoneState.profile;screens.profiles=beforeNames.slice();phoneState.profileTones={...beforeTones};commitProfileName();try{persist()}catch(err){screens.profiles=beforeNames;phoneState.profileTones=beforeTones;phoneState.profile=beforeProfile;nameEditing=true;notice='Unable to save profile name';draw();return}back();return}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save date and time|Folder memory full','Unable to save date and time|Unable to save profile name|Folder memory full')
Path('/downloads/C2-Reborn-v6.105-profile-rename-rollback-candidate.html').write_text(s)
