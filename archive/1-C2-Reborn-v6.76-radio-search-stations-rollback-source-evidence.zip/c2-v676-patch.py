from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.75-radio-save-station-rollback-candidate.html').read_text().replace('v6.75 handset parity','v6.76 handset parity').replace('C2 Reborn v6.75 |','C2 Reborn v6.76 |')
a="else{phoneState.radioFrequency=next.toFixed(1);phoneState.radioStationIndex=(phoneState.radioSaved||[]).findIndex(v=>v.frequency===phoneState.radioFrequency);persist();notice='Demo station '+phoneState.radioFrequency+' MHz'}draw();return}"
b="else{let idx=(phoneState.radioSaved||[]).findIndex(v=>v.frequency===next.toFixed(1));if(selectDemoRadioStation(idx))notice='Demo station '+phoneState.radioFrequency+' MHz'}draw();return}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.76-radio-search-stations-rollback-candidate.html').write_text(s)
