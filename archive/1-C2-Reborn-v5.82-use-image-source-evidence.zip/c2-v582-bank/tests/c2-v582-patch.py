from pathlib import Path
src=Path('/downloads/C2-Reborn-v5.81-alarm-numeric-upload-ready.html').read_text()
out=Path('/downloads/C2-Reborn-v5.82-use-image-candidate.html')
def rep(old,new,n=1):
 global src
 c=src.count(old)
 assert c==n,(old[:80],c)
 src=src.replace(old,new)
rep('content="v5.81 handset parity built-2026-09-30"','content="v5.82 handset parity built-2026-09-30"')
rep('<div class="debug">C2 Reborn v5.81 | 2026-09-30</div>','<div class="debug">C2 Reborn v5.82 | 2026-09-30</div>')
# CSS
rep(".alarmShade{position:absolute;inset:0;background:rgba(0,0,0,.42)}",
".alarmShade{position:absolute;inset:0;background:rgba(0,0,0,.42)}.homeTheme.hasWallpaper{display:block!important;position:absolute;inset:0;overflow:hidden;z-index:0}.homeTheme.hasWallpaper img{position:absolute}.galWallThumb{width:30px;height:30px;object-fit:cover;border:1px solid #666;margin-right:8px;flex:none}")
# state migration for homeWallpaper
rep("if(['Navigation key up','Navig. key down','Nav. key up/down'].includes(ms.home))d.myShortcuts.home=ms.home}",
"if(['Navigation key up','Navig. key down','Nav. key up/down'].includes(ms.home))d.myShortcuts.home=ms.home}if(x.homeWallpaper&&typeof x.homeWallpaper==='object'){let _w=x.homeWallpaper,_wm=['Centre','Fit to display','Rotate left','Rotate right'];if(typeof _w.src==='string'&&/^data:image\\//.test(_w.src)&&_wm.includes(_w.mode))d.homeWallpaper={n:cleanText(_w.n,100),src:_w.src,mode:_w.mode}}")
# home wallpaper layer
rep("s.innerHTML='<div class=\"homeTheme\"></div><div class=\"homeHeader\"'",
"s.innerHTML='<div class=\"homeTheme'+(phoneState.homeWallpaper?' hasWallpaper':'')+'\">'+(phoneState.homeWallpaper?galUseHomeWallpaperHtml():'')+'</div><div class=\"homeHeader\"'")
# contact details chosen image + Done label
rep("<img src=\"'+listIcons.CONTbust+'\" style=\"float:right;width:42px;height:42px;margin:-6px 4px 0 0\">",
"<img src=\"'+(c.image?namesImage(c):listIcons.CONTbust)+'\" style=\"float:right;width:42px;height:42px;margin:-6px 4px 0 0;object-fit:cover;border-radius:2px\">")
rep("+'</b></div></div>';soft('Options','Call','Back')}",
"+'</b></div></div>';soft('Options','Call',history[history.length-1]?.galUseReopen?'Done':'Back')}")
# names soft labels in pick mode
rep("soft(a.length||!namesQuery?'Options':'',a.length?'Details':namesQuery?'View all':'',namesQuery?'Clear':namesExitLabel())}",
"soft(galUseContactPick?'':(a.length||!namesQuery?'Options':''),galUseContactPick?(a.length?'Add':''):(a.length?'Details':namesQuery?'View all':''),galUseContactPick?'Back':(namesQuery?'Clear':namesExitLabel()))}")
# draw branches for new pages
rep("else if(page==='names'){let a=namesContacts();sel=Math.max(0,Math.min(sel,a.length-1));",
"else if(page==='galuse'){s.innerHTML='<div class=\"title\">'+esc(galUseFile?galUseFile.n:'Use image')+'</div>'+rows(['Set as wallpaper','Set as contact image','Set to new contact','Set as group image']);soft('','Select','Back')}\n else if(page==='galusewall'){let _f=galUseFile||{};s.innerHTML='<div class=\"title\">'+esc(_f.n||'Wallpaper')+'</div><div class=\"rows\" style=\"overflow:hidden\">'+['Centre','Fit to display','Rotate left','Rotate right'].map((m,i)=>'<div class=\"row'+(i===sel?' sel':'')+'\"><img class=\"galWallThumb\" src=\"'+(_f.src||'')+'\" style=\"'+(m==='Fit to display'?'object-fit:fill':m==='Rotate left'?'transform:rotate(-90deg)':m==='Rotate right'?'transform:rotate(90deg)':'')+'\">'+m+'</div>').join('')+'</div>';soft('','Select','Back')}\n else if(page==='galusegroups'){let _g=phoneState.groups||[];s.innerHTML='<div class=\"title\">Groups</div>'+(_g.length?rows(_g.map(x=>x.name)):rows(['(empty)']));soft('',_g.length?'Select':'','Back')}\n else if(page==='names'){let a=namesContacts();sel=Math.max(0,Math.min(sel,a.length-1));")
# SIM-move confirm dialog render
rep("let _ni=/^(Not available|Enter |Write message first|Check the three values|Now press|Keypad |Call ended|Flight profile|Timed profile|Interval timer|Timer repeated|Countdown finished|No numbers found|No addresses found|No user IDs found|Connect TV-out|Cannot be dialled|Name already exists)/.test(notice)",
"if(galUseContactPending){s.insertAdjacentHTML('beforeend','<div class=\"alarmShade\"></div><div class=\"alarmDialog\">Move contact to phone memory?</div>');soft('','Yes','No')}let _ni=/^(Not available|Enter |Write message first|Check the three values|Now press|Keypad |Call ended|Flight profile|Timed profile|Interval timer|Timer repeated|Countdown finished|No numbers found|No addresses found|No user IDs found|Connect TV-out|Cannot be dialled|Name already exists|Selected memory empty)/.test(notice)")
# Use image option handler
rep("else if((page==='galfolder'||page==='galphoto')&&['Use image','Zoom','Set contrast','Edit image','Print'].includes(c)){open=false;notice=c+' is not available in the HTML yet';draw()}",
"else if((page==='galfolder'||page==='galphoto')&&c==='Use image'){let _uf=galFolderFiles()[sel];if(!_uf||_uf.folderRow){notice='Use image is not available in the HTML yet';draw()}else{open=false;galUseFile=_uf;galUseFileSel=sel;go('galuse')}return}else if((page==='galfolder'||page==='galphoto')&&['Zoom','Set contrast','Edit image','Print'].includes(c)){open=false;notice=c+' is not available in the HTML yet';draw()}")
# names OK hook
rep("if(pendingAddNumber){let _c=selected;if(_c)_c.number=_c.number?_c.number+' / '+pendingAddNumber:pendingAddNumber;",
"if(galUseContactPick){let _gi=phoneState.contacts.indexOf(selected);if((selected.store||'Phone')==='SIM'){galUseContactPending={index:_gi};draw();return}galUseApplyContactImage(_gi);return}if(pendingAddNumber){let _c=selected;if(_c)_c.number=_c.number?_c.number+' / '+pendingAddNumber:pendingAddNumber;")
# back() cleanup + reopen options
rep("if(page==='names'&&contactInsertPick)contactInsertPick=false;",
"if(page==='names'&&contactInsertPick)contactInsertPick=false;if(page==='names'&&galUseContactPick){galUseContactPick=false;galUseContactPending=null}")
rep("if(h?.galFolderName)galFolderName=h.galFolderName;",
"if(h?.galFolderName)galFolderName=h.galFolderName;if(h?.galUseReopen){open=true;os=Math.max(0,currentOptions().indexOf('Use image'))}")
# press() wiring + helpers
rep("function press(k){armActivity();if(alarmPress(k))return;if(swPress(k))return;if(namesMemoryPress(k))return;if(normalTimerPress(k))return;",
"""let galUseFile=null,galUseFileSel=0,galUseContactPick=false,galUseContactPending=null;
function galUseHomeWallpaperHtml(){let w=phoneState.homeWallpaper;if(!w)return '';let st=w.mode==='Fit to display'?'left:0;top:0;width:100%;height:100%':w.mode==='Rotate left'?'left:50%;top:50%;height:100%;transform:translate(-50%,-50%) rotate(-90deg)':w.mode==='Rotate right'?'left:50%;top:50%;height:100%;transform:translate(-50%,-50%) rotate(90deg)':'left:50%;top:50%;transform:translate(-50%,-50%);max-width:100%;max-height:100%';return '<img src="'+w.src+'" style="'+st+'">'}
function galUseApplyContactImage(i){let c=phoneState.contacts[i];if(!c)return;c.image=galUseFile?galUseFile.id:c.image;persist();contactIndex=i;history=[{page:'galfolder',sel:galUseFileSel,galFolderName:galFolderName,galUseReopen:true}];page='contact';sel=0;galUseContactPick=false;draw()}
function galUsePress(k){if(galUseContactPending){if(k==='OK'||k==='LSK'){let _p=galUseContactPending;galUseContactPending=null;if(phoneState.contacts[_p.index])phoneState.contacts[_p.index].store='Phone';galUseApplyContactImage(_p.index)}else if(k==='END'){galUseContactPending=null;galUseContactPick=false;history=[];page='home';sel=0;draw()}else if(k==='RSK'||k==='BACK'){galUseContactPending=null;draw()}return true}
if(!['galuse','galusewall','galusegroups'].includes(page))return false;
if(k==='END'){galUseFile=null;galUseContactPick=false;history=[];page='home';sel=0;draw();return true}
if(k==='UP'||k==='DOWN'){let n=page==='galusegroups'?Math.max(1,(phoneState.groups||[]).length):4;sel=(sel+(k==='DOWN'?1:n-1))%n;draw();return true}
if(k==='RSK'||k==='BACK'){back();return true}
if(k==='OK'||k==='LSK'){
 if(page==='galuse'){
  if(sel===0)go('galusewall');
  else if(sel===1){galUseContactPick=true;go('names')}
  else if(sel===2){cfReset();contactImage=galUseFile?galUseFile.id:'No image';if(contactImage!=='No image')cfAdded.image=true;contactField=0;editingContact=false;go('addcontact')}
  else{if((phoneState.groups||[]).length)go('galusegroups');else{notice='Selected memory empty';draw()}}
 }else if(page==='galusewall'){
  let modes=['Centre','Fit to display','Rotate left','Rotate right'];phoneState.homeWallpaper={n:galUseFile?galUseFile.id:'',src:(galUseFile&&(galUseFile.big||galUseFile.src))||'',mode:modes[sel]};persist();history=history.filter(h=>(typeof h==='string'?h:h?.page)!=='galuse'&&(typeof h==='string'?h:h?.page)!=='galusewall');page='galfolder';sel=galUseFileSel;notice='Wallpaper applied';draw();
 }else{let g=phoneState.groups||[];if(g.length&&g[sel]){g[sel].image=galUseFile?galUseFile.id:'';persist();notice='Image applied';draw()}}
 return true}
return true}
function press(k){armActivity();if(alarmPress(k))return;if(swPress(k))return;if(namesMemoryPress(k))return;if(normalTimerPress(k))return;if(galUsePress(k))return;""")
out.write_text(src)
print('OK bytes',len(src))
