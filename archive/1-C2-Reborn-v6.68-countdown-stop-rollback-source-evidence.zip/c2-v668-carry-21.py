exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.68-countdown-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['new','edit','favourite','replace']:
 ev("phoneState=migrateState(null);persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');cfReset();contactFirst='Draft';contactName='Demo';contactNumber='123';editingContact="+('true' if mode=='edit' else 'false')+";contactIndex=0;favPending="+json.dumps('add' if mode=='favourite' else 'replace' if mode=='replace' else None)+";favReplaceIdx=0;page='addcontact';sel=0;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};saveContact()")
 t(mode+' quota exact contacts and favourites rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&notice==='Unable to save contact'")
 t(mode+' draft and pending shape retained',"return page==='addcontact'&&contactFirst==='Draft'&&contactName==='Demo'&&contactNumber==='123'&&editingContact==="+('true' if mode=='edit' else 'false')+"&&contactIndex===0&&favPending==="+json.dumps('add' if mode=='favourite' else 'replace' if mode=='replace' else None))
 if mode=='new':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v633-contact-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';saveContact()")
 t(mode+' retry contact exists once',"return phoneState.contacts.filter(c=>c.name==='Draft Demo').length===1&&phoneState.contacts.length==="+('3' if mode=='edit' else '4')+"&&!editingContact&&favPending===null")
 if mode in ['favourite','replace']:t(mode+' favourite stored in same commit',"return phoneState.favourites.filter(c=>c.name==='Draft Demo'&&c.number==='123').length===1&&page==='favourites'")
 call('Page.reload');time.sleep(.3)
 t(mode+' reload exact contact',"return phoneState.contacts.filter(c=>c.name==='Draft Demo'&&c.number==='123').length===1")
print('PASS',len(checks))
