exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.68-countdown-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['normal','target','rename']:
 for name in ['constructor','toString','__proto__','hasOwnProperty']:
  ev("phoneState=migrateState(null);phoneState.galleryFolders=['Source'];phoneState.galFolderParents={Source:'Images'};page='foldername';open=false;notice='';galRenameIdx="+('screens.gallery.length' if route=='rename' else '-1')+";galRenameOs=0;galTarget="+("{op:'Copy',folder:'Source',adding:true,browse:'Images',trail:[]}" if route=='target' else 'null')+";galAddParent='Images';folderName="+json.dumps(name)+";persist();baseline=JSON.stringify(phoneState);draw();press('OK')")
  t(route+' '+name+' guarded',"return page==='foldername'&&notice==='This folder name is not supported'&&JSON.stringify(phoneState)===baseline")
  if route=='normal' and name=='constructor':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v611-reserved-name.png','wb').write(base64.b64decode(d['result']['data']))
ev("phoneState=migrateState(null);page='foldername';open=false;notice='';galRenameIdx=-1;galTarget=null;galAddParent='Images';folderName='constructor-notes';draw();press('OK')")
t('Ordinary name containing reserved word works',"return phoneState.galleryFolders.includes('constructor-notes')&&galChildFolders('Images').includes('constructor-notes')")
print('PASS',len(checks))
