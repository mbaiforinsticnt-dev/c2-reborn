from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.67-demo-call-end-rollback-candidate.html').read_text().replace('v6.67 handset parity','v6.68 handset parity').replace('C2 Reborn v6.67 |','C2 Reborn v6.68 |')
a="else if(c==='Stop timer'){phoneState.timerEndsAt=0;persist();normalTimerSay('Timer stopped','organiser')}"
b="else if(c==='Stop timer'){let beforeEnds=phoneState.timerEndsAt;phoneState.timerEndsAt=0;try{persist()}catch(err){phoneState.timerEndsAt=beforeEnds;normalTimerSay('Unable to save timer');return true}normalTimerSay('Timer stopped','organiser')}"
assert s.count(a)==1
s=s.replace(a,b)
s=s.replace("let info=normalTimerFlash==='Minimum time is 1 second';","let info=normalTimerFlash==='Minimum time is 1 second'||normalTimerFlash==='Unable to save timer';")
Path('/downloads/C2-Reborn-v6.68-countdown-stop-rollback-candidate.html').write_text(s)
