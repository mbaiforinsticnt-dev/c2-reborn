exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.68-countdown-stop-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for choice in range(5):
 ev("phoneState=migrateState(null);phoneState.calls={dialled:[{number:'111',time:'D'}],received:[{number:'222',time:'R'}],missed:[{number:'333',time:'M'}]};phoneState.messageRecipients=[{number:'444',name:'Demo',time:'Today'}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='clearloglists';sel="+str(choice)+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(str(choice)+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(str(choice)+' page selection retained',"return page==='clearloglists'&&sel==="+str(choice))
 t(str(choice)+' visible warning',"return notice==='Unable to clear log list'&&document.getElementById('screen').innerText.includes(notice)")
 if choice==0:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v659-log-clear-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect=["Object.values(phoneState.calls).every(x=>x.length===0)&&phoneState.messageRecipients.length===1","phoneState.calls.missed.length===0&&phoneState.calls.received.length===1&&phoneState.calls.dialled.length===1","phoneState.calls.received.length===0&&phoneState.calls.missed.length===1&&phoneState.calls.dialled.length===1","phoneState.calls.dialled.length===0&&phoneState.calls.received.length===1&&phoneState.calls.missed.length===1","phoneState.messageRecipients.length===0&&Object.values(phoneState.calls).every(x=>x.length===1)"][choice]
 t(str(choice)+' retry clears intended list',"return "+expect)
 call('Page.reload');time.sleep(.15)
 t(str(choice)+' reload exact',"return "+expect)
print('PASS',len(checks))
