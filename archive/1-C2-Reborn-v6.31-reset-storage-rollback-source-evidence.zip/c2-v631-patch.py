from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.30-group-settings-preservation-candidate.html').read_text().replace('v6.30 handset parity','v6.31 handset parity').replace('C2 Reborn v6.30 |','C2 Reborn v6.31 |')
a="if(secReturn==='factoryconfirm'){let preserve="
b="if(secReturn==='factoryconfirm'){let previousState=phoneState,previousMessages=messageStore;let preserve="
assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.messageStore=messageStore;persist();locked=false;history=[];page='home';sel=0;notice=frWhich===0?"
b="phoneState.messageStore=messageStore;try{persist()}catch(err){phoneState=previousState;messageStore=previousMessages;notice='Unable to restore settings';draw();return}locked=false;history=[];page='home';sel=0;notice=frWhich===0?"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save group image|Folder memory full|';b='Unable to save group image|Unable to restore settings|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.31-reset-storage-rollback-candidate.html').write_text(s)
