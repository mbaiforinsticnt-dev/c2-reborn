import os
F=os.environ.get('C2F','c2-v6158-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v)
T="(()=>JSON.stringify({page,sel,t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|')}))()"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('profiles');sel=0;draw()})()")
fresh();ev("press('OK');0");r=ev(T);t('Select profile opens its own page, not Profileopts/itemdetail',('General|' in r or 'General ' in r) and 'Profileopts' not in r and 'Activate|Personalise|Timed' in r and '"page":"profileopts"' in r)
fresh();ev("press('DOWN');0;press('OK');0");t('Silent profile page title',ev("document.querySelector('.lcd .title').innerText.startsWith('Silent')"))
fresh();ev("press('OK');0;press('OK');0");t('Activate applies and returns home',ev("page")=='home' and ev("phoneState.profile")=='General')
fresh();ev("press('OK');0;press('DOWN');0;press('OK');0");t('Personalise opens form',ev("page")=='profiletones')
fresh();ev("profileTonesFor=0;go('profiletones');sel=14;draw()")
r=ev("(()=>{let l=document.querySelector('.lcd').getBoundingClientRect(),sk=[...document.querySelectorAll('.lcd *')].find(e=>/^(Options)$/.test(e.textContent.trim())&&e.children.length==0),c=[...document.querySelectorAll('[data-row]')].pop().getBoundingClientRect();return JSON.stringify({cb:c.bottom,sk:sk&&sk.getBoundingClientRect().top,rows:[...document.querySelectorAll('[data-row]')].length})})()")
print(r);import json;j=json.loads(r);t('last row (Profile name) fully above softkeys',j['sk'] is not None and j['cb']<=j['sk']+1)
print('checks',len(res),'pass',sum(1 for v in res if v is True))
