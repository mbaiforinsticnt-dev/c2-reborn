# Working notes (saved in repo after a workspace reset on 5 Oct 09:36)
Live builds: v6.201 blob c08432ac5b0de5a32bbfa919586f7d474b3dcc1a (run #46, archive 5a77f244). v6.202 follows this note.
Test harness: tests/hdr.py (CDP over websocket, run `bash chrome.sh` first, then `python3 rNN.py <file.html>`), crawlers a3-a7. The old 178-test regression sweep (cf-N.py) was lost in the reset and has NOT been rebuilt.
Open items: arrows on list-opening rows (Moti: follow the emulator; emulator install lost too, needs re-supplying), Black/Dark contrast: Black done (no list-row faults), Dark not crawled; Tab leads unchecked: Calendar day selection contrast Black/Dark, Keypad tones silent, unsorted new contacts, editor submenu Back collapses levels, Equaliser outline-only focus, Calendar editor last field clipped; Tab leads not reproduced: Call on highlighted contact opens empty dialler, Writing language popup off screen.
Rules: Moti's 4 rules (full-row focus, list wrap, Options sized to whole rows, expandable-row arrow). Arrow art: Moti's Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead), author not recorded.
Publishing: atomic Actions workflow 4-publish-index.yml (zip_path archive/1-<name>.zip, member index.html, new_blob, base_blob). Banked zip must byte-match a raw download pinned to the commit.

## v6.203 (2026-10-05)
- Saved-notice tick (listIcons.CHECK) replaced by a CROP of Moti's emulator screenshot (image-4fd8f09f), 56x56. Crop, not an original firmware file (Moti permission 10:15). Unicode check glyphs replaced by the same image.
- Go to profile icons and plain Settings > Profiles already match his screenshots (no change).
Base blob: c531b2156eba4434e3c2463fa0772a9edc0816b7

## v6.204 (2026-10-05)
- Memory card Options per handset video (frames in source-evidence/sheet0-5.png). Seen in footage: Set password -> Enter new password (numeric, masked, last digit shown, max 8, Options/OK/Clear) -> Verify new password -> "Password set" note; Delete password -> "Memory card will be unlocked. Continue?" Yes/No -> "Enter memory card password:" -> "Password deleted" note.
- NOT in footage (inferred): Change password flow (old, new, verify), wrong-password and mismatch messages, Rename/Format dialogs, minimum password length.
- Hold # popup: from emulator screenshot only; hold time is the existing 700 ms (Moti guessed about 0.5 s); Number mode sets 123, Writing language opens the existing page, Paste always dim (inferred).
- Paste is enabled only when the clipboard has content (Moti 10:31); selecting it in the Gallery list does nothing (no target; inferred).

## v6.205 (2026-10-05)
- Memory card row icon replaced by crop from Moti C2 photo (new listIcons.MEMCARD, 30x30, white background removed). Used in Gallery list, Gallery search, move/copy target and editor picker. 0534 (Gallery app icon) untouched.

## v6.206 (2026-10-05)
- Inbox (single messages) rows: Unicode envelope glyphs replaced by images. Unread = made closed envelope (Moti 10:46 instruction), read = VIEW_ICON_READ. CSS filter none so the Nokia selected-row invert does not recolour it.
- Conversation bubbles and Conversations list unchanged (they already use image icons).
- Memory card icon (Gallery list) REPLACED: v6.205 used a zoom of the HTML own old icon by mistake; now a 30x30 crop of Moti emulator screenshot (notch top-left, contacts left), image-821ba14f (10:53). Crop, not a firmware file. Original-file extraction from SDK package_c.bin attempted separately.

## v6.207 (2026-10-05)
- Conversation view: selected bubble scrolls fully above the softkeys (keepConvSelVisible, 34px end spacer). Tested 4 viewports x 2 themes.
- Open message view and Inbox read view: UP/DOWN scroll long text (did not scroll before).
- Sent bubble icon = crop of Moti emulator zoom (envelope + green tick bottom-right), image-e18b983a. Old one came from the HTML own VIEW_ICON_SENT (green square overlay), not a firmware file. Crop, not firmware file.
- Received bubbles in conversation view: unread/received = made closed envelope (same as Inbox), read = firmware open envelope. Nokia invert filter off for these icons.

## v6.208
- Closed (0421), open (0758), sent (0603), memory card (0533) are ORIGINAL firmware files now (from package_c.ppm). Made envelope and the two crops kept in source-evidence as rollback.
- Open envelope variant 0758 is my pick (0760/0995/0960 look the same at 30px); Moti has not picked.

## v6.209
- Contact Back-after-save fix (history dropped the add-contact form; cfVal guard). Reproduced from the external c2-audit-harness (untrusted, verify.py re-implemented), banked in source-evidence/c2-audit-harness.
- ?calc= URL param restricted to digits/operators.
- Calculator 7/0: note "Cannot divide by zero" with firmware 1053 info icon (Moti handset photo 11:28). Display keeps 7.
- Tick = firmware 1062 (replaces crop).
- Not done: Add detail empty list, 7/0 only, dark crawl, emulator.

## v6.210
- Contact details > Options > Add detail now opens the Add detail tree (Number/Internet/Multimedia/Personal info) from Moti's 11:33 handset photos; leaves reuse the Edit-contact add-field flow (opens Edit contact with the new field). Number list from contact details = General, Mobile, Home, Work, Fax (5, per photo); the Edit-contact form keeps its own 7-item list.
- Notes (.alarmDialog) are dark with white bold text in Black, Dark and Legacy Black themes.
- Inferred, not footage: after choosing a leaf the field opens in the Edit contact form; Back from the submenu root returns to the form (handset behaviour unknown).

## v6.211
- Memory card icon: Moti's emulator icon (11:40) = firmware 0533 (diff 2.2 only from JPEG artefacts). Already used as MEMCARD. The Gallery picker row "32" used GPcard = firmware 0720 (a SIM card with yellow contacts); now 0533. No other SD-card uses found (sync icons 0908/0909, 1080 are different pictures).

## v6.212
- Messaging menu Conversations row: firmware 0955 unchanged but drawn 22% larger (CSS scale) and 12% brighter (CSS filter) per Moti 11:46. Adjustment only: the PNG is the untouched firmware file. Rollback = remove the style attribute (v6.211).

## v6.213
- Open envelope (VIEW_ICON_READ) is MADE, not firmware: Moti rejected the 30x30 firmware open envelopes (0758/0760/0995/0960: dark flap, black pixel outline). Built from firmware closed envelope 0421 (V cut for the front pocket, 0421's own triangle flipped as the raised flap). Script: source-evidence/open-envelope/mkopen.py. Rollback: firmware 0758 (v6.212).

## v6.214
- Moti's emulator closed envelope = firmware 1056 (= 1057), not 0421. Unread icon = 1056. Read icon (VIEW_ICON_READ) = MADE from 1056 by mk3.py variant C: full 1056 body, straight outlined top, lighter inside, flap folded up behind, same width. Earlier "squashed flap" version rejected by Moti ("Terrible"), never published. Rollback: v6.213 blob c08536d4.

## v6.215
- v6.214 (live briefly) had a made open envelope Moti rejected. v6.215 read icon (VIEW_ICON_READ) = Moti's own open envelope image (his ChatGPT-made file image-5402b817.jpg), black background keyed to transparent, Lanczos-downscaled to 56x56 canvas (content 54x47), no recolouring. Unread = firmware 1056. Rollback: v6.214 blob 1dbb8adf (or v6.213 c08536d4).

## v6.216
- Calculator "Cannot divide by zero" note matched to Moti's handset photo (image-65390d87): info icon 29 px (was 40), 23 px from right edge, vertically centred; panel full-width, 135 px tall, text wraps "Cannot divide / by zero", font 1.25em. Applies to .alarmDialog.calcNote only (the only note using this style). Comparison: source-evidence/cmp231.png.
- Font audit: Nokia faces embedded (Sans, Cn, Title SemiBold, Digi, Title A). Gaps: .key and .brand use Arial (outside LCD); 24 symbol glyphs (arrows/radio/media glyphs) not in any Nokia font and fall back. Rollback: v6.215 blob 04ec06ae.

## v6.217
- Read icon = Moti's ChatGPT open envelope with the horizontal band removed (clean.py steps in source-evidence/open-envelope-final), 56 px. Replaces firmware open-envelope slots 0758/0760/0960/0995 in the icon packs. Originals remain in earlier archive/ zips. Rollback: v6.216 blob 1694839b.

## v6.218
- Conversation view centre key: truncated (3-line clamp, scrollHeight>clientHeight+8) selected message => "Open" (opens full message, marks read: closed -> open envelope); fully shown incoming => "Reply"; outgoing => "Open" (unchanged). The hardware OK key follows the same rule (before it always replied). Tests t232/t233. No handset footage for this view was found; rule is Moti's. Rollback v6.217 blob 763a0e3c.

## v6.219
- Opened message view: received message => centre "Reply" (OK replies to the conversation number), sent => "Send" (unchanged). Options list unchanged (Delete, Send copy, Edit, Move, Use detail, Copy to Calendar, Copy as template, Select). Tests t234. Rules file: BEHAVIOUR-RULES.md. Rollback v6.218 blob 3400ae50.
- a7.py = label-vs-action crawl (first run found compose screens with empty softkey labels that still act - see a7 output when finished).

## v6.220
- Open envelope body now matches the closed 1056 body: body x 4..52 (49 px), bottom y=46; flap rises above (open icon y 4..46). Master: source-evidence/open-envelope-final/open56m3.png. Rollback v6.219 blob b3cca1a3.

## v6.221
- Rule 7 key auto-repeat (shared in pressStart/pressEnd for UP/DOWN/LEFT/RIGHT, 0.8 s delay, 250 ms step). Rollback v6.220 blob 520ad386.

## v6.222
- Keypad (.key) and .brand font: Arial -> Nokia Sans Wide (maisfontes.com, name table "Nokia Sans Wide", 233 glyphs, embedded woff2 base64), fallback Nokia Sans S40, Arial. In-screen fonts unchanged (bundled firmware S40 fonts). Symbols not in Wide (◉ ⌂ ✶ ↻ ▲ ◀ ▶ ▼) still fall back. Rollback v6.221 blob 7be6dacd.
- Full Nokia Sans family (13 files) stored under fonts/ in the repo (non-site folder); URLs in fonts/SOURCES.txt.

## v6.223
- Message editor attachment strip rebuilt from Moti's emulator video (13:11): 11 items in emulator order (Image, Sound clip, Calendar note, Business card, Theme, Streaming link, Gallery file, Text field, Text template, Video clip, Camera), starts on Image, name tooltip ~1 s, Insert centre key, Close right key in multimedia, header "New multimedia 1/1". Business card converts SMS->MMS with note "Message changed to multimedia". Icons are CROPS from Moti's emulator footage (30x30, source-evidence/sms-strip-icons-from-moti-video), not firmware, blurry. Invented "not implemented" notice removed. Other items (image gallery flow, sound, video, camera, theme, stream, gallery file, calendar note, text field/template, attachments preview, remove) still TODO. Rollback v6.222 blob dc3263f7.

## v6.224
- SMS attachment flow, part 2 (Moti video): Business card is an object in composeObjs; Preview -> Attachments list (VCARD.vcf 0.1 kB, Options/Open/Back); Open -> "No data to display" (info); Options Save/Details; Save -> "Business card saved to phone memory"; Options > Remove -> "Remove object? VCARD.vcf" Yes/No; Yes -> note "Message changed to text message", header back to New text message. Missing vs emulator: yellow file icon on the Attachments row, Details content, Image gallery flow, other items, "Save message?" on close. Rollback v6.223 blob d1e82772.

## v6.225 (5 Oct 14:09)
- Confirm prompts (Delete N items?, Delete folder?, Delete?, Format memory card?, Delete favourite?, Remove object?, Save message?) are now a half-height grey box (from 42% down to the softkeys) over a dimmed page, as in Moti's emulator video (S10 t=284, t=196). Was full-screen dark panel (.optionsPanel inset:0).
- Note tick (CHECK) is byte-identical to firmware 1062 (also 1058/1061); no change.
- Icon audit sent to Moti: 123 non-exact icons, sheets A-D.

## v6.226 (5 Oct 14:19)
- SMS attachment strip icons (11) replaced with firmware files downscaled to 18x18 (LANCZOS, no video crops): sound 0513, calendar 0559, bcard 0589, theme 0608, gallery 0697, template 1023, video 0521, camera 0567 (the Media-folder camera). 
- SUBSTITUTES, no firmware match for the emulator art found: image (fw 0716, picture), stream (fw 0532, globe+arrow; emulator shows globe+phone), textfield (fw 0948, plain text doc; emulator shows doc+pencil). Need 100% emulator screenshots from Moti.

## v6.227 (5 Oct 14:31)
- Strip icons now the exact firmware set 0349 image, 0350 textfield, 0351 template, 0352 calendar, 0353 gallery, 0354 sound, 0355 bcard, 0356 theme, 0357 stream, 0358 video (50x66 files, trimmed to the art, LANCZOS to 18px) + 0567 camera (Media folder). Found by matching Moti's emulator reference screenshots. No substitutes left.
- Display settings > Fonts (row 10, last): Default (current firmware look), Regular, Light, Bold, Condensed, Wide. Nokia Sans family from fonts/ zip, subset to Latin, woff2 (+~135 kB). Applies to the screen UI (.lcd). Saved in dispVals[9]; Restore default resets it.
- Display list navigation wraps at 10 rows.
- Keypad symbols (1 voicemail, 0 refresh, # house/star): no firmware icons exist for the printed keypad art; not changed.

## v6.228 (5 Oct 14:48)
- Equal-height list rows rule (BEHAVIOUR-RULES 8). Display settings: 4 rows at equal height, dark rounded highlight, value bottom. Generic normaliser fixes any other list with unequal rows; crawl a8 records rowh per screen. Rollback v6.227 blob f8381e3e.

## v6.229 (5 Oct 15:20)
- Moti 15:17: equal rows must fill the list area down to the softkey bar. Display settings: 4 rows x 57 px fill exactly (no strip above the soft keys). Row count per page type is reported with the crawl (a8 now logs gap per list). Rollback v6.228 blob 594ba545.

## v6.230 (5 Oct 16:15)
- Messaging and Create message: 4 rows x 58 px fill the list area (were 4x62 overflowing 13 px / 4x47 with 47 px blank). Names list (Black theme): dark rounded highlight bar and smaller text as in Moti's 14:52 emulator frame; row count unchanged (3 contacts). Rollback v6.229 blob 2de11714.

## v6.231 (5 Oct 16:22)
- Moti 16:19: Create message / Messaging row sizes were too big vs emulator. Reverted to the original heights (Create message 4 x 47, Messaging 4 x 62) from v6.229. Names highlight change from v6.230 kept. Lesson: fill-to-bottom must not resize pages whose original height matches the emulator; only Display settings was normalised (Moti's frame). Rollback v6.230 blob af0183bd.

## v6.232 (5 Oct 16:32)
- Create message from Moti's handset photo (16:28, real C2): row pitch 34 px (handset 32-34 at 240 wide), icon 22 px (handset about 20), item text 24px (handset text width about 149 units vs ours 115 at 20px; the handset font is wider, 24px gives 138). Highlight left white (handset photo shows theme lavender, theme differs). No emulator frame yet; Messaging root untouched. Rollback v6.231 blob 6a96b447.

## v6.233 (5 Oct 16:40)
- Moti 16:36 gap rule: title centre to first row top was 13 units on rows pages (handset 17.8, emulator Names/Display/Options 23.6). Now 19 (rows pages) / 22 (Display, Names). Rollback v6.232 blob 0442e026. Messaging 4x62 now clips 19 px at bottom (no emulator frame yet).

## v6.234 (5 Oct 16:45)
- Options menu restyled to Moti's Names Options emulator frame (Black theme): grey translucent panel under the title, uniform 30 px rows, 16px text, dark rounded selected row, small submenu arrows. Item list unchanged (View conversations / Find on map kept, pending Moti). Messaging root rows 56 px so the 4th row no longer clips (fit, not a measurement). Rollback v6.233 blob 7922befa.

## v6.235 (5 Oct 17:10)
- Names > Options > Call now opens a submenu: Voice call (calls as before) and Video call (notice "Video call not available. Calling with voice." then voice call after 1.8 s). No Internet call (C2 has none; Moti asked only voice and video). Submenu appears only from Options; the green key and every other Call path are unchanged. Submenu styled like Moti's 17:06 frame. Rule 11 added (C2-only features such as View conversations are not removals). Rollback v6.234 blob 3eca64b8.

## v6.236
Call-log pages (All calls, Missed, Received, Dialled): Options now lists Call, Video call, View conversations first, then the existing items. Centre key and green key stay a direct voice call. Video call shows "Video call not available. Calling with voice." then calls. View conversations opens the SMS thread for the record's number (C2-only, rule 11).

## v6.237
- Call-log Options: Call, Video call, View conversations, Details, then rest. Save to contacts / Save / Add to contact hidden when the number is already a saved contact. Details page: name/number, type, date, time, duration (missed has no duration). Dialled calls record their duration on end.
- Conversations: Options > Local search, and typing on the list opens a bottom search bar over a separate index of the conversations (name and number per conversation, not the contacts). Digit keys multi-tap like Names; the cycle ends on the digit itself. Letters match names, digits match numbers. Clear (right key) removes one character, then closes the bar.

## v6.238
Call-log Options follow Moti's 17:38 emulator frame (All calls, Jane Doe): Call duration, Send message >, View, Edit number, Delete, Call >. C2-only additions: View conversations (before Call >), Call > submenu = Voice call, Video call. Save and Add to contact appear (after Edit number) only when the number is not a saved contact. The v6.237 Details page is no longer reachable (held until Moti sends emulator frames). View title follows the list (Missed calls, Received calls, Dialled numbers) and shows the saved contact's name.

## v6.239
Removed "Find on map" from Names > Options (Moti 20:30, explicit word: "Remove find on maps"). View conversations stays (C2-only, rule 11).

## v6.240
Conversations local search is plain (Moti 20:40/20:43): typed letters match only the start of a word in the name (Alex or Morgan; not "lex" or "rgan"); digits match the start of the number (as stored, or national form with 0 for 44). Mid-name and mid-number matching ("enhanced") is shelved. Includes v6.239 (Find on map removed); v6.239 was archived but its publish run was cancelled during the GitHub Actions incident, so v6.240 carries it.

## v6.241 (5 Oct 23:0x)
Message Options > Use detail now opens the "Numbers" list first (recipient/sender number, then numbers found in the text), then Options (Voice call, Internet call, Video call, Add to contact, Send message >, Send number, Edit number). Evidence: Moti's 22:58 SDK emulator recording. Copy to Calendar and Select left in place (no removals without Moti). Message details already existed (hidden below the 7-row window).

## v6.242 (6 Oct 00:2x)
- Moti 00:21 rule (handset photo of Contacts menu): in icon rows the label sits in the UPPER part of the row, not vertically centred. Emulator frames agree (Memory card row, Display settings rows). Applied to every list row that has an icon (about 55 pages): label shifted up ~30% of its height, icon unchanged. Rows with a second sub-line unchanged.
- Scroll thumb: was visible/total; now one item tall (track / N) and moves with the selected item. Evidence: Moti's emulator Display settings frame (10 items, small thumb) and handset Contacts menu (10 items, small thumb).
- Not changed: Contacts menu softkeys (handset shows Select/Back only, ours Options/Select/Back) - no emulator frame, removal needs Moti.
- Row-size categories (Moti 00:23): handset 4 rows/page = largest. Handset 4/page pages: Messaging root, Names, Contacts menu, Contacts Settings. Audit of ours in HANDOVER.

## v6.243 (6 Oct 00:3x)
- Text-up shift now only on large rows (row height > 15% of screen, the 4-5 rows/page pages). Handset photos of 7-row pages (Create message, Media menu) show the label centred with the icon. v6.242 shifted every icon row; v6.243 corrects that.
- Row-size categories per Moti (handset): 4/page largest (Messaging root, Names with number, Contacts menu, Contacts Settings); 6/page (Names, Name list view: already 6 in ours); 7/page (Media menu, Create message, Messaging > Options menu e.g. Sent Items). Ours: Contacts menu and about 60 pages are ~5/page; Media menu ~5/page; not restyled (Moti: do not restyle yet).

## v6.245 (6 Oct 00:4x)
Fix: v6.243 shifted the label up on two-line rows too (Organiser "Alarm clock / Off" lost its top). Two-line rows (label + sub-line) now stay as before; only single-line icon rows on large-row pages shift up. (No v6.244 published.)

## v6.246 (6 Oct 01:0x)
- Moti 01:00/01:05 approved: Contacts menu, Apps, Organiser, Go to now 4 rows/page, rows fill the list to the softkeys (25% each), icons and text same size.
- Organiser > Maps icon replaced by Moti's own supplied image (pin over folded map): checkerboard removed, cropped, scaled to 54x49 in the 56x56 slot. Source and result in source-evidence/maps-icon-moti-*. Overrides the firmware-only icon rule for this one icon (his decision).
- Names (Name list) already 6 rows/page, unchanged.

## v6.247 (6 Oct 01:1x)
Moti 01:10 "go through all screens": 4 rows/page (main category) now also for two-line setting pages (label + value line): Bluetooth, Call duration, Charger, Configuration, Connectivity, Date and time, GPRS edit/modem, Internet telephone, Message log, Packet counter/data/timer, PC sync, Phone settings, Security, Server sync, Slide call, TV cable. Evidence: handset Contacts > Settings (4 rows with value lines) and emulator Display settings (4 rows).
7 rows/page (7.1.0 options-style) for: Media (handset photo), Writing language, Prediction options, Sending options, Save message, Slide options, Compose insert, Call divert, Call waiting, Divert destination/options, Restore factory settings, Memory status. Evidence: handset Sent Items options menu and Media menu photos.
Unplaced (need Moti's call, screenshot each): see HANDOVER open items.
- v6.248: Home screen key 7 rows (7.1.0) + firmware radio markers (was blue arrows).
- v6.249 (Moti answers 01:24-01:35): categories 4 rows: accessories appmemory datatransfer graphicdownloads logtimers phonememory phoneswitch saved store templates themes tofolder collection galpicker games generalmsg. 7 rows (7.1.0): appdownloads deletecontacts deletemessages homescreenkey infomessages recipientpicker screensaver wallpaperlist. messageview 7 rows (7.2.0 floating asked; geometry not verified). groups 6 rows, icon at right edge (handset photo image-fa4c267a). speeddials 6 rows contact icons.
- Calendar-12 fallback removed: firmware icons by logic (0617,0628,MEMCARD,0562,0560->0593,0584,0723,0879,0720 added from firmware,0602,0582,9001,0463,0639,0415,0912,0605,0564). No icons on deletecontacts/deletemessages and option-style lists (writing language, prediction/sending/save/slide options, compose insert).
- Home screen key radio markers (firmware RADIO_ON/OFF).
- v6.250: Conversation details page rebuilt per Moti handset footage (video-bf65e3ee): Name, Size, Number of messages in conversation, Unread, Received, Sent, First message, Last message; softkey Back only.
- v6.251: Conversation details body font 14px normal weight + scroll thumb (Moti: handset font thin and skinny). Screen saver Analogue clock icon = firmware face 0246 + hour hand 0256 (mirrored) + minute hand 0273 composed to 30x30 (composite of firmware parts; hands 10:10).
- v6.252: Groups centre key View; mmsconfig 7 rows (7.1 Options style, assumed, unanswered by Moti); Data transfer icons Server sync=firmware 1076, PC sync=firmware 1064 (logic pick; alternates 0626, 0917). Memory card icon verified already = firmware 0533.
- v6.253: Inbox view (messageview) is now a floating radio popup (Conversations / Inbox) over Messaging, same geometry as the Main menu view popup (derived, not from handset evidence); centre Select stores phoneState.msgView, Back closes. Kept as emulator-follows (assumed, no removals): Contacts menu softkeys, compose Preview/Search, Edit number, plain search.
- v6.254: Inbox view popup now drawn over the real Messaging page (was a wrong short list with Calendar-12 icons and ghost text); popup background opaque. Calendar-fallback sweep (t306) clean: only organiser Calendar.
- v6.255: Conversation view / Inbox view notices (Messages shown as conversations / single messages) had a second inline green tick wrapped to the bottom-left; removed it. The remaining tick is the generic notice tick = firmware 1058 (identical to 1061/1062).
- v6.256: Conversation details computed live from the thread: size from real text bytes (was per-message prewritten size, 8.0 kB), first/last message = oldest/newest by real date+time, counts by direction/unread unchanged (live). Page banner showed v6.240 (stale string); now C2 Reborn v6.256 | 2026-10-06.
- v6.257: view notices (Messages shown as conversations / single messages): text now normal weight and sits in the top part of the notice like the emulator 'Changes saved' frame (image-4fd8f09f: text top-left, square tick bottom-right). Tick unchanged (firmware 1058/1061/1062); no long/wide tick exists in the firmware set (candidates checked: wide green icons 0298/0299 progress bars, battery 0848-0851, 1115).
- v6.258: thread bubble icon now derived live from direction/unread (sent = closed envelope with green tick, firmware); 'I am very happy to hear that' shows sent icon (was stored as read). 'Thank you very much for calling!' flipped to RECEIVED per Moti 10:19 (thread now 3 received, 1 sent; also migrated in persisted state). Sent bubbles indented right, received left (assumed, margin 14%). Banner v6.258.
v6.259: tick = recreated in code from Moti's emulator crop (image-4fd8f09f, 'Changes saved' notice), approved by Moti 6 Oct 11:44; replaces firmware 1062 CHECK on every tick spot. Sent-envelope tick unchanged (his image-e18b983a).
v6.260: Messaging list rows with a count (Conversations, Drafts, Sent items): label stays full width, count is smaller (12px) and sits BELOW the label instead of at the right edge (Moti 6 Oct 11:45).
v6.261: (1) selected thread bubble: grey outline now continues around the tail (box-shadow + clip-path tail outline, both sides). (2) NEW C2-only (non-Nokia) item "Mark as unread"/"Mark as read" in the Conversations Options menu, right after Conversation details; derived live from message unread flags (status-bar envelope, counts, row preview, details). (3) Notice icon (tick/info/warn) now rendered square (35x35); audit of all 122 pages, with and without notices, found no other stretched image. (4) Status bar about 15% bigger (29px bar, icons 22x16, text 14.5px); LCD 3px taller so nothing clips.
v6.262: Drafts rows match handset footage (Moti video 12:49): bold first line = recipient or date when empty, second line = message text, real envelope icon (no Unicode glyph), top-right number = total drafts.
v6.263: C2-ONLY (not Nokia) missed-call Snooze: Log row 'Simulate missed call' (14th row) creates a missed entry and shows a full-screen 'You have one missed call / N missed calls' notice (Options, Call back, Dismiss). Options: Call back, Snooze 10 min, Send message, Dismiss, Call details. Snooze = real 10-min setTimeout, due time persisted in localStorage c2snooze (re-armed on page load, fires at once if overdue); re-ping text 'You have a missed call from <name>'. Missed-call count and log entry stay while snoozed.

## v6.279 changes
- Inbox/missed-call name lookup matches on the last 9 digits, so a contact saved in local format shows its name for a +44 number.
- Copy to Calendar removed from opened-message Options (emulator-only, Moti 17:11). Code path removed; marker comment left in source.
- Missed-call and new-message popups: no Options softkey (left empty); View in the middle, Exit right. Green call key on the missed-call popup calls back the most recent missed call (already worked).

## v6.280 changes
- ONE number rule: findContact(number) / contactLabel(number) (last 9 digits compared). Every screen that shows a number goes through it: Inbox, Sent, Drafts, conversations list and thread header, all call logs, missed-call list, call details, call view, Calling screen, missed-call popup, message recipients, speed dial picks. The 9 per-screen copies were removed (they compared raw digits, digit-only strings or the tail, differently per screen).
- number-rule-check.py drives each screen with a contact saved in local format and a +44 number and fails (LEAK) if a raw number shows instead of the name.
- Calling screen: "Calling" + number, then "Calling." + name, End call only, then the in-call screen (from handset video, low resolution; layout colours are approximate).

## v6.281 changes
- Thread: bubbles use the full screen width (right edge leaves room for the scroll rail), received and sent bubbles share the right edge, sent keeps its 6px left offset. From handset photo of a 3/133 thread (Moti 17:04). Was: bubbles stopped about 18% short of the right edge.

## v6.282 changes (call flow, from handset video 18:08)
- Calling phase: operator label top-left (no NOKIA), "Calling" / "Calling." with a phone icon and the number or name, progress bar, End call only.
- In-call screen: block at bottom-left (phone icon + number or name, then "In call" for the first second, then the timer), operator label top-left, softkeys Options / Menu / Loudsp. The timer now starts when the call connects (after the Calling phase) instead of at the key press.
- Not copied: the "Note: active incoming call diverts" popup (shown between Calling and In call on his phone because he has a call divert on). Icon is the existing missed-call phone glyph, approximate.

## v6.283 changes (call flow complete; v6.282 was never published, its changes are in here)
Timing read from Moti's 18:08 video (2.5 frames per second, so about 0.4 s resolution):
- Calling phase 2.0 s: "Calling" about 0.8 s, then "Calling." (bar runs), End call only.
- Note popup "Note: active incoming call diverts" (info icon, no softkeys) about 3.2 s. Shown on every outgoing call (Moti 18:16), whatever the Call divert setting.
- In call: "In call" for 1 s, then the timer. Timer starts when the call connects (5.2 s after the key press).
- End call key: "Disconnecting" for about 0.4 s in the timer line, then "Call summary" with the duration (bold, no softkeys) for about 2.5 s, then the home screen (Go to / Menu / Names). The summary shows when Call settings > Summary after call is On (default); with Off the phone goes straight to the home screen.
- The recorded call duration and call timers now use the connected time only.

## v6.284 thread bubble tails (Moti 18:23 zoom screenshot)
Errors found at 4x zoom: the tail was a two-border CSS triangle, which draws a bent edge; the bubble's rounded bottom corner left a dark notch beside the tail; the selected bubble's grey outline broke where the tail began. Now: the tail is a straight clip-path triangle in the bubble's own colour, the bottom corner on the tail side is square, and the selected bubble has a grey outline triangle behind the tail so the outline is continuous. Includes all v6.283 call-flow changes (v6.282 never shipped).

## v6.285 warning and info icons on notes
Notes that are errors (Invalid ..., Wrong password, Unable to ..., Passwords do not match, Code error, already exists, list full, built-in folder refusals) now show the firmware red warning icon; "not implemented / not available / needs handset evidence / No images / Select a date range" style notes show the firmware blue info icon. Success notes keep the green tick. Icons are existing firmware glyphs (listIcons.WARN / INFO); nothing drawn. r-tests unchanged (4/4 baseline).

## v6.286 in-call mute (Moti's handset photos 18:40)
While muted: right softkey reads "Unmute" and pressing it unmutes (then Loudsp./Handset returns). Muted screen shows the firmware muted-handset icon (firmware image 0167, 118x118) on a plain CSS rounded tile, centred; not muted: no tile. The "Muted" text line is gone: number then timer, as on the handset. The tile is a CSS box (colour sampled by eye from the photo), the icon is firmware.

## v6.287 in-call Options and Send DTMF (Moti's 18:40 handset video)
In-call Options now, in video order: Loudspeaker (Handset when on), Hold (Unhold), Mute (hidden while muted, the right softkey is Unmute), Contacts, New call, Lock keypad, Record, Voice clarity, End call, Send DTMF. Working: Loudspeaker, Hold, Mute, Contacts, Lock keypad, Voice clarity (toggles Call settings > Voice clarity), End call, Send DTMF. New call and Record show an info note (behaviour not in the video).
Send DTMF: screen "Send DTMF" with "Number:" box; softkeys Options / Search / Back (empty) or Options / DTMF / Clear (typed). Search lists contacts (Select / Back) and fills the number. DTMF shows "Sending" with the number and a striped progress bar for about 6 s, right softkey Quit, then back to the call. Options on this screen is a placeholder note. Not done: the status-bar "123" and in-call glyph on that screen; the real tones are not played.

## v6.288 icon proportions
Muted tile was squashed wide (tile sized by percent of a non-square screen, icon height forced). Now the tile is square (aspect-ratio 1:1) and the icon keeps its own proportions. Audit of every <img> over all 265 page states, plain and with Options open (1746 images): found 4 kinds drawn with unequal x/y scale: status signal bars (37x28 shown 22x16), contact-field icons (20x17, 25x26, 19x14 shown 13x13), collection icon (46x48 shown 32x32). Fixed with object-fit:contain on all images. The audit is the check: for each img compare rendered width/height with naturalWidth/naturalHeight, tolerance 1.5%, skipping object-fit:contain. Result after fix: 0 of 1746. Wallpaper backgrounds stretched to the screen on purpose are not icons and are excluded. Not covered: images that exist only in popups or states not reachable by go(page).

## v6.289 green key and banner
Review leads reproduced on build 6.288: green call key on Names, Conversations and inside a conversation opened an empty dialler. Now it calls the highlighted contact / the conversation's number (same as Contact details, All calls, Missed calls). Version banner had stayed at v6.283 since that build; it now reads v6.289 (the publish step must check banner = version).

## v6.290 green key calls the shown number (Moti 19:20 decision)
Green call key now calls the number on screen for: Call details, Call log view, Use number, Use detail, Sent items, Drafts (first recipient number, none = dialler), Recipient contacts (highlighted contact), Message details. No number shown, so unchanged: Message view (Conversations/Inbox chooser), Saved messages, Outbox (empty), Message log counts. Red on Delivery reports: re-checked on a fresh screen, it already goes Home (the earlier audit row was an artifact of a leftover state). Red on compose keeps the keep-draft behaviour. Key audit pass: 260 of 265 screens driven with 7 keys.

## v6.291 green key on message screens
Adds the green call key (calls the sender) on Message read, Message open and Message details, same rule as v6.290 (the v6.290 archive zip exists in archive/ but v6.290 was never published; v6.291 contains it). Banner v6.291.
Decision recorded: select box and tick (galCheck) signed off by Moti 19:26/19:29, see BEHAVIOUR-RULES rule 17. Not to be changed.

## v6.292 (6 Oct)
- Green call key on the SMS compose screen now sends (calls sendDraft, same checks as the Send softkey). Was: it opened the dialler. Banner v6.292.
- Rule 18 (one number, one name) and rule 19 added to BEHAVIOUR-RULES.md.
- Icon pool viewer published separately at icon-pool/1-index.html (unlisted, noindex).

## v6.293 (6 Oct)
- Games and Collection: the list now shows 4 rows (the 5th sat behind the softkey bar, so the last row's highlight was invisible). Reproduced on v6.292 by pressing Down to the last row (row top 397 = softkey top 397). Source: lead from an unverified third-party audit, reproduced here first.
- Other leads from that audit: see the report; no change made without evidence.

## v6.294 (6 Oct)
- SMS compose: empty text now sends (Moti 20:07), for both the green key and the Send softkey. A recipient is still required. Save as template and Save to folder still need text. Banner v6.294.

## v6.295 (6 Oct)
Both from an unverified third-party audit of v6.284, each reproduced on the live page first.
- F1: during the first 2 s of an outgoing call ("Calling"), the right softkey reads "End call" but switched the loudspeaker on. It now ends the call.
- F6: Reply in a thread put the raw number in the To field even for a saved contact. It now shows "Name (number);" like the contact picker (rule 18).

## v6.296 (6 Oct)
- Reverted the v6.295 change to the right softkey in the Calling phase (Moti 21:03: it must not end the call). The right key is back to its v6.294 behaviour (loudspeaker). The label question is open with Moti; no emulator evidence for the label yet.
- Kept: Reply shows "Name (number);" (F6).
- Lesson logged in BEHAVIOUR-RULES.md rule 20: leads from outside audits are checked against the emulator or Moti's footage BEFORE any change.

## v6.297 (6 Oct)
- Calling phase (dialling): same softkeys and options as an answered call, no "End call" key (Moti 21:15-21:16, rule 21, deliberate deviation). Right key = Loudsp. / Handset. Red key ends the call. Options opens the answered-call options list.
- Rules 22-27 added from Moti's rule book PDF (not all built yet; 22 is a potential rule).

## v6.298 (6 Oct)
- Add to group in Contacts, Conversations, Call log (rule 28). Name display picker shows "Name display selected" (rule 29).

## v6.299 (6 Oct)
- Icon evenness in lists (rule 30). 16 modern emoji (rule 31). Emoji art: Twemoji, Copyright Twitter, Inc and other contributors, licensed CC-BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

## v6.300 (6 Oct)
- Groups in Names, group view, group details, group options (rules 32-33). Symbol picker star toggle and moving scroll thumb (rule 34).

## v6.301 (6 Oct)
- Notes over group pages, Delete group confirm, group mark ticks, space symbol glyph, Hebrew shekel sign (rule 35).

## v6.302 (6 Oct)
- Name display order takes effect, default First name first (rule 36).
