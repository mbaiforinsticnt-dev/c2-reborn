C2 Reborn v6.173 (source evidence)
Base: v6.172 (blob 9104e1ee). Reverts the v6.172 "S1" change (unlabelled left softkey ignored in radio lists): it broke 14 existing radio-list left-softkey regression scripts (143-148, 153, 156, 158, 160, 162, 166, 168, 169) that encode the earlier accepted behaviour, and Tab's lead is not handset-proven. Left softkey selects in radio lists again.
Keeps from v6.172: D1 (dialler middle key labelled Save now saves the number; Call key still calls; label-driven, not handset footage), GA1 (empty Gallery rename refused).
N4/N5/CD1 End leads already fixed by the v6.171 End rule; tests included.
Focused tests 19/19. Emulator/CDP evidence, not handset.
