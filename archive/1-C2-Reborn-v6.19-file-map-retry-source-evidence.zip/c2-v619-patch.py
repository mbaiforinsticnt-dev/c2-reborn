from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.18-file-map-recovery-candidate.html').read_text().replace('v6.18 handset parity','v6.19 handset parity').replace('C2 Reborn v6.18 |','C2 Reborn v6.19 |')
for key in ['galMoved','galCopied','galFileNames']:
 s=s.replace('phoneState.'+key+'||{}','phoneState.'+key+'||Object.create(null)')
 s=s.replace('phoneState.'+key+'=old'+key[3:]+';', 'phoneState.'+key+'=Object.assign(Object.create(null),old'+key[3:]+');')
s=s.replace('phoneState.galFileNames=previousNames;','phoneState.galFileNames=Object.assign(Object.create(null),previousNames);')
Path('/downloads/C2-Reborn-v6.19-file-map-retry-candidate.html').write_text(s)
