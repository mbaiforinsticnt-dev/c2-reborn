from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.35-contact-transfer-rollback-candidate.html').read_text().replace('v6.35 handset parity','v6.36 handset parity').replace('C2 Reborn v6.35 |','C2 Reborn v6.36 |')
a="if(b.action==='Copy'){let copies=b.records.map(c=>({...JSON.parse(JSON.stringify(c)),store:b.destination,marked:false}));phoneState.contacts.push(...copies)}else b.records.forEach(c=>c.store=b.destination);persist();b.stage='result';"
b="let previousContacts=phoneState.contacts.slice(),previousStores=b.records.map(c=>({c,had:Object.prototype.hasOwnProperty.call(c,'store'),store:c.store}));if(b.action==='Copy'){let copies=b.records.map(c=>({...JSON.parse(JSON.stringify(c)),store:b.destination,marked:false}));phoneState.contacts.push(...copies)}else b.records.forEach(c=>c.store=b.destination);try{persist()}catch(err){phoneState.contacts=previousContacts;for(let row of previousStores){if(row.had)row.c.store=row.store;else delete row.c.store}b.stage='question';notice='Unable to save contact transfer';draw();return}b.stage='result';"
assert s.count(a)==1;s=s.replace(a,b)
a="if(bulkContactPending){let b=bulkContactPending,txt=";b="if(bulkContactPending&&!notice){let b=bulkContactPending,txt=";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.36-bulk-contact-rollback-candidate.html').write_text(s)
