import sys
exec(open('/tmp/nm4.py').read().split("ev(\"go('conversations')")[0].replace('w268','w280'))
time.sleep(1.2)
def p(k): ev("press('%s')"%k);time.sleep(.25)
N1='+44 7700 900999';N2='07700 900999'
ev("phoneState.contacts.push({name:'Test Local',number:'%s'});phoneState.calls.missed.unshift({number:'%s',time:'Today 17:30',n:1});phoneState.calls.received.unshift({number:'%s',time:'Today 17:31'});phoneState.calls.dialled.unshift({number:'%s',time:'Today 17:32'});messageStore.inbox.unshift({id:'t1',number:'%s',name:'',preview:'hi',unread:false});messageStore.threads['number-447700900999']=[{id:'x1',dir:'in',number:'%s',text:'hello',time:'17:30',createdAt:1}];messageStore.threads['number-447700900998']=[{id:'x2',dir:'out',number:'%s',text:'sent one',time:'17:31',createdAt:2}];phoneState.drafts=[{kind:'sms',to:'%s',body:'dr'}];numberedThreadKeys&&numberedThreadKeys();"%(N2,N1,N1,N1,N1,N1,N1,N1))
def check(name,setup):
    ev(setup);time.sleep(.3)
    t=ev("document.querySelector('#screen').innerText")
    leaks='900999' in t.replace(' ','') and 'Test Local' not in t
    print(('LEAK ' if leaks else 'ok   ')+name, 'Test Local' in t)
    return leaks
bad=0
for nm,st in [('inbox',"messageViewMode='inbox';go('inbox');sel=0;draw()"),('sent',"go('sent');sel=0;draw()"),('drafts',"go('drafts');sel=0;draw()"),('missed',"go('missed');sel=0;draw()"),('received',"go('received');sel=0;draw()"),('dialled',"go('dialled');sel=0;draw()"),('allcalls',"go('allcalls');sel=0;draw()"),('calldetail',"callDetailRec={number:'%s',time:'Today 17:30'};callDetailType='Missed call';go('calldetail');draw()"%N1),('calllogview',"window.callViewRec={number:'%s',time:'Today 17:30'};go('calllogview');draw()"%N1),('incall',"activeCall='%s';callStarted=Date.now()-5000;go('incall');draw()"%N1),('missedalert',"maShow('%s','17:30',false)"%N1),('convlist',"messageViewMode='conversation';go('conversations');sel=0;draw()")]:
    bad+=check(nm,st)
# thread header
ev("messageViewMode='conversation';go('conversations');sel=0;draw()")
n=ev("(function(){for(var i=0;i<300;i++){var k=rowKey(i);if(k&&k.indexOf('447700900999')>0)return i}return -1})()");print('thread row',n)
if n>=0: bad+=check('thread',"openConversationRow(%d);draw()"%n)
print('LEAKS',bad)
ev("go('missed');sel=0;draw()");print(ev("document.querySelector('#screen').innerText.replace(/\\n/g,' / ')"))
