import os,json
F=os.environ.get('C2F','c2-v6168-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(bool(v))
T="document.querySelector('.lcd').innerText.replace(/\\n/g,'|')"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.5)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';draw()})()")
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK')})()");t('Settings > Date and time opens list',ev("page")=='datetime')
ev("(()=>{sel=0;draw();press('OK')})()");r=ev(T);t('Date & time settings OK opens editor (Date/Time/Time zone)',ev("page")=='caldatetime' and 'Date:' in r and 'Time:' in r and 'Time zone:' in r)
ev("(()=>{press('RSK')})()");r=ev(T);t('Back (no change) returns to Date and time list',ev("page")=='datetime')
ev("(()=>{sel=0;draw();press('OK');press('LSK')})()");r=ev(T);print(r);t('Options > Save path reachable',ev("page")=='caldatetime')
ev("(()=>{press('OK')})()");t('OK/Save returns to Date and time list',ev("page")=='datetime')
ev("(()=>{sel=1;draw();press('OK')})()");t('Date and time format row unchanged (not editor)',ev("page")!='caldatetime')
ev("(()=>{go('calendar');draw()})()");t('Calendar still opens',ev("page")=='calendar')
print('checks',len(res),'pass',sum(res))
