import os,json
F='c2-v6169-cand.html'
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(bool(v))
T="document.querySelector('.lcd').innerText.replace(/\\n/g,'|')"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.5)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';draw()})()")
def keys(*ks):
 for k in ks: ev("press(%s)"%json.dumps(k))
fresh();ev("go('calculator')");keys('2','UP','3','UP','4','OK');t('calc 2+3+4=9',ev("calc")=='9')
fresh();ev("go('calculator')");keys('2','UP','DOWN','5','OK');t('calc operator change 2 + then - 5 = -3',ev("calc")=='-3')
fresh();ev("go('calculator')");keys('9','DOWN','3','LEFT','2','OK');t('calc 9-3x2=12',ev("calc")=='12')
fresh();ev("go('calculator')");keys('8','RIGHT','2','OK');t('calc 8/2=4',ev("calc")=='4')
fresh();ev("(()=>{phoneState.calcMode='scientific';go('scientific')})()")
ev("(()=>{calc='2';calcSel=14;press('OK')})()") if False else None
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK');sel=0;draw();press('OK')})()");keys('DOWN','0','9','3','0');r=ev(T);t('time 0930 -> 09:30',('09:30' in r) and '03:90' not in r)
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK');sel=0;draw();press('OK')})()");keys('DOWN','2','5');r=ev("calTimeDraft");t('hour 25 clamps to 23',r.startswith('23'))
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK');sel=0;draw();press('OK')})()");keys('DOWN','1','2','7','5');r=ev("calTimeDraft");t('minute 75 clamps 59',r=='12:59')
fresh();ev("(()=>{phoneState.alarm={on:true,time:'07:00',repeat:false,tone:'Standard',snooze:10,days:[]};persist();go('alarmring')})()")
keys('RSK');t('snooze keeps saved time',ev("phoneState.alarm.time")=='07:00' and ev("alarmSnoozeAt")!='' and ev("page")=='home')
ev("notice='';go('alarmring')");print(ev('page'),repr(ev('alarmSnoozeAt')));keys('LSK');print(ev('page'),repr(ev('alarmSnoozeAt')));t('stop clears snooze',ev('alarmSnoozeAt')=='')
print(sum(res),'/',len(res));assert all(res)
