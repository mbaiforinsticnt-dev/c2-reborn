exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.83-calculator-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['new','edit']:
 ev("phoneState=migrateState(null);phoneState.calendar=[{type:'Reminder',text:'Old',date:'01-10-2026',repeat:'Never',alarm:false,time:''}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='calendar';calDate=parseCalDate('01-10-2026');calNoteStart('Reminder',"+('0' if mode=='edit' else '-1')+");noteText='New note';calNoteDirty=true;calNoteAlarm=true;calNoteTime='10:31';calNoteRepeat=1;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};calNoteSave()")
 t(mode+' exact calendar rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' draft fields retained',"return page==='calnote'&&noteText==='New note'&&calNoteDirty&&calNoteAlarm&&calNoteTime==='10:31'&&calNoteRepeat===1&&calNoteEdit==="+('0' if mode=='edit' else '-1'))
 t(mode+' visible warning',"return notice==='Unable to save calendar note'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='new':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v642-calendar-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';calNoteSave()")
 t(mode+' retry commits once',"return phoneState.calendar.length==="+('1' if mode=='edit' else '2')+"&&phoneState.calendar[0].text==='New note'&&phoneState.calendar[0].alarm&&phoneState.calendar[0].time==='10:31'&&phoneState.calendar[0].repeat===CAL_REPEATS[1]&&page==='calendar'&&noteText===''")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return phoneState.calendar.length==="+('1' if mode=='edit' else '2')+"&&phoneState.calendar[0].text==='New note'&&phoneState.calendar[0].alarm&&phoneState.calendar[0].time==='10:31'")
print('PASS',len(checks))
