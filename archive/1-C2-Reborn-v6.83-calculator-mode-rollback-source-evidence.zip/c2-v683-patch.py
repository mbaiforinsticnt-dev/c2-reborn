from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.82-home-colour-save-rollback-candidate.html').read_text().replace('v6.82 handset parity','v6.83 handset parity').replace('C2 Reborn v6.82 |','C2 Reborn v6.83 |')
repls=[("c==='Scientific calculator'){page='scientific';phoneState.calcMode='scientific';persist();", "c==='Scientific calculator'){let beforeMode=phoneState.calcMode;phoneState.calcMode='scientific';try{persist()}catch(err){phoneState.calcMode=beforeMode;notice='Unable to save calculator mode';draw();return}page='scientific';"), ("c==='Standard calculator'){page='calculator';phoneState.calcMode='standard';persist();", "c==='Standard calculator'){let beforeMode=phoneState.calcMode;phoneState.calcMode='standard';try{persist()}catch(err){phoneState.calcMode=beforeMode;notice='Unable to save calculator mode';draw();return}page='calculator';"), ("c==='Loan calculator'){page='loanintro';phoneState.calcMode='loan';persist();", "c==='Loan calculator'){let beforeMode=phoneState.calcMode;phoneState.calcMode='loan';try{persist()}catch(err){phoneState.calcMode=beforeMode;notice='Unable to save calculator mode';draw();return}page='loanintro';")]
for a,b in repls:
 assert s.count(a)==1,a
 s=s.replace(a,b)
s=s.replace('Unable to save home colour|Folder memory full','Unable to save home colour|Unable to save calculator mode|Folder memory full')
Path('/downloads/C2-Reborn-v6.83-calculator-mode-rollback-candidate.html').write_text(s)
