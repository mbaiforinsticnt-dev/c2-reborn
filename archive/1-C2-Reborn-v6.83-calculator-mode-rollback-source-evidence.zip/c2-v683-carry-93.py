exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.83-calculator-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for change in ['true','false']:
 ev("phoneState=migrateState(null);phoneState.timerValue='00:01:00';phoneState.timerEndsAt=Date.now()+120000;persist();stored=localStorage.getItem('c2state');beforeEnd=phoneState.timerEndsAt;page='normaltimer';normalTimerChange="+change+";timerParts=['00','02','00'];normalTimerFlash='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(change+' exact state rollback',"return phoneState.timerEndsAt===beforeEnd&&phoneState.timerValue==='00:01:00'&&localStorage.getItem('c2state')===stored")
 t(change+' entry kept and error visible',"return page==='normaltimer'&&timerParts.join(':')==='00:02:00'&&normalTimerFlash==='Unable to save timer'&&document.getElementById('screen').innerText.includes(normalTimerFlash)")
 if change=='true':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v669-countdown-time-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("press('OK');press('OK')")
 t(change+' repeat rollback',"return phoneState.timerEndsAt===beforeEnd&&phoneState.timerValue==='00:01:00'")
 ev("Storage.prototype.setItem=oldStore;press('OK');writes=0;Storage.prototype.setItem=function(k,v){writes++;return oldStore.call(this,k,v)};press('OK');Storage.prototype.setItem=oldStore")
 t(change+' retry one persist',"return writes===1&&phoneState.timerValue==='00:02:00'&&JSON.parse(localStorage.getItem('c2state')).timerValue==='00:02:00'")
 t(change+' retry next screen exact',"return "+("page==='normaltimer'&&normalTimerFlash==='Timer running'&&phoneState.timerEndsAt>beforeEnd-1000" if change=='true' else "page==='timernote'&&phoneState.timerEndsAt===beforeEnd"))
 call('Page.reload');time.sleep(.15)
 t(change+' reload saved time',"return phoneState.timerValue==='00:02:00'")
print('PASS',len(checks))
