# C2 Reborn v6.179 (source-evidence)
Change: Messaging > Conversations list shows threads for newly used numbers directly under the Alex Morgan row, newest first, above the demo filler rows. Row identities/index state are unchanged, only the display order in visibleRows().
Source: Tab v6.176 lead 1 (unverified), reproduced on v6.178: new thread landed at row 179 of 180. Evidence class: inferred ordering (Nokia S40 lists newest conversation first), not C2-01 handset-proven.
Focused check: focused-new-conversation-top.py (two sends: rows [0,180,179,1...], newest first).
Not done: Calls leads (Clear log confirm etc.), other messaging leads - not yet reproduced.
Image emu-6260-timer-name-form.png: 6260 profile, not C2-01 proof.
