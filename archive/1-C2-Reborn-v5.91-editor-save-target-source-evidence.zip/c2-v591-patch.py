from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.90-editor-image-picker-candidate.html').read_text().replace('v5.90 handset parity','v5.91 handset parity').replace('C2 Reborn v5.90 |','C2 Reborn v5.91 |')
s=s.replace("soft('Options',rows.length?'Open':'','Back');if(e.stage==='imageOptions')", "soft('Options',e.pickerMode==='save'?'Save to':rows.length?'Open':'','Back');if(e.stage==='imageOptions')",1)
s=s.replace("else{e.stage='options';e.choice=3}}else if(k==='LSK')", "else{e.stage=e.pickerMode==='save'?'view':'options';e.choice=3;e.pickerMode=''}}else if(k==='LSK')",1)
s=s.replace("else if(k==='OK')galEditorPickerOpen()}draw();return true}", "else if(k==='OK'){if(e.pickerMode==='save'){e.returnStage='imagePicker';e.stage='unsupported'}else galEditorPickerOpen()}}draw();return true}",1)
s=s.replace("e.stage='imagePicker';e.pickerBrowse='';e.pickerChoice=0;e.pickerTrail=[]", "e.stage='imagePicker';e.pickerMode='insert';e.pickerBrowse='';e.pickerChoice=0;e.pickerTrail=[]",1)
s=s.replace("else if(k==='OK'){e.returnStage='view';e.stage='unsupported'}draw();return true}", "else if(k==='OK'){e.stage='imagePicker';e.pickerMode='save';e.pickerBrowse='';e.pickerChoice=0;e.pickerTrail=[]}draw();return true}",1)
Path('/downloads/C2-Reborn-v5.91-editor-save-target-candidate.html').write_text(s)
