C2 Reborn v6.197 source evidence (base v6.196, blob 179d5577927c6ecdfcfd32267388c662fbeaccec)

Changes
- Alarm ring uses Moti's first mp3 (481,115 B, 30.04 s), shrunk copy embedded.
- Default call ringtone "Nokia tune" plays Moti's second mp3 (465,650 B, 29.07 s; shrunk mono 22 kHz 24 kbps, 87.5 KB embedded) in the Ringing-tone chooser preview and Options > Play. Gallery Tones firmware file and other tone rows untouched.
- Focused Snooze time-out and Alarm time rows: full-row dark band, white label, blue digit highlight (from Moti's handset photo). Checked in 4 themes (r119).

Not changed / not done
- No incoming-call ringing screen exists in the HTML, none invented.
- Alarm-time row only checked visually in 4 themes, not against its own handset photo.
- Which file the "Standard" alarm tone plays is unknown.
- Items for v6.198, not in this build: Alarm clock list wrap, Options menu blank space and stray box, focused-row subtitle colour on Conversations and other lists.

Sweep: 170 pass, 8 fail. 4 obsolete (104, 134, 135, 136: old alarm tests superseded by handset footage), 4 reload-race flakes (107, 141, 143, 163) passed solo.
