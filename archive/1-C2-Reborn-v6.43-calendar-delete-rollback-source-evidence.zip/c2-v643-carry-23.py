exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.43-calendar-delete-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for op in ['Move','Copy']:
 ev("phoneState=migrateState(null);phoneState.galleryFolders=['Custom'];phoneState.galFolderItems=[{folder:'Custom',n:'__proto__',s:'1 B',source:'Photo0001.jpg'}];galFolderName='Custom';page='galtarget';history=['galfolder'];galTarget={op:"+json.dumps(op)+",from:'Custom',names:['__proto__']};sel=0;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(op+' rollback retains dictionary type',"return Object.getPrototypeOf(phoneState.galMoved)===null&&Object.getPrototypeOf(phoneState.galCopied)===null&&galTarget.names[0]==='__proto__'")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 key='galMoved' if op=='Move' else 'galCopied'
 t(op+' retry actually stores proto identity',"return galOwnText(phoneState."+key+",'__proto__')==='Images'&&galActualFiles('Images').some(f=>f.n==='__proto__')")
 call('Page.reload');time.sleep(.3)
 t(op+' reload confirms committed identity',"return galOwnText(phoneState."+key+",'__proto__')==='Images'")
ev("galFolderName='Images';page='galfolder';notice='';sel=galFolderFiles().findIndex(f=>f.id==='__proto__');draw()")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v619-retry-file.png','wb').write(base64.b64decode(d['result']['data']))
ev("phoneState=migrateState(null);phoneState.galleryFolders=['Custom'];phoneState.galFolderItems=[{folder:'Custom',n:'__proto__',s:'1 B'}];galFolderName='Custom';page='galfilerename';history=['galfolder'];galFileRenameFrom='__proto__';galFileRename='Recovered.jpg';galFileCursor=13;notice='';open=false;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
t('Rename rollback keeps dictionary and draft',"return Object.getPrototypeOf(phoneState.galFileNames)===null&&galFileRename==='Recovered.jpg'&&page==='galfilerename'")
ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
t('Rename retry stores proto identity',"return galOwnText(phoneState.galFileNames,'__proto__')==='Recovered.jpg'")
call('Page.reload');time.sleep(.3)
t('Rename reload commits exact name',"galFolderName='Custom';return galFolderFiles()[0].n==='Recovered.jpg'")
print('PASS',len(checks))
