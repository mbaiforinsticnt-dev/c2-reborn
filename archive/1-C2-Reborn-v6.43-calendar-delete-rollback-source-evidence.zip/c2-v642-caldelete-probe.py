exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.42-calendar-save-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.calendar=[{type:'Reminder',text:'One',date:fmtCalDate(new Date()),repeat:'Never',alarm:false,time:''}];persist();stored=localStorage.getItem('c2state');page='calendar';calOv='delnotes';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};calOvPick('All notes')")
print(ev("JSON.stringify({calendar:phoneState.calendar,calOv,diskSame:localStorage.getItem('c2state')===stored})"))
