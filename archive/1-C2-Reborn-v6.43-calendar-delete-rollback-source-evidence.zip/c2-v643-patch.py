from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.42-calendar-save-rollback-candidate.html').read_text().replace('v6.42 handset parity','v6.43 handset parity').replace('C2 Reborn v6.42 |','C2 Reborn v6.43 |')
a="else if(calOv==='delnotes'){if(item==='All notes')";b="else if(calOv==='delnotes'){let beforeCalendar=phoneState.calendar.slice();if(item==='All notes')";assert s.count(a)==1;s=s.replace(a,b)
a="persist();calOv='';notice='Calendar notes deleted';draw()";b="try{persist()}catch(err){phoneState.calendar=beforeCalendar;notice='Unable to delete calendar notes';draw();return}calOv='';notice='Calendar notes deleted';draw()";assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.calendar.splice(sel,1);sel=0;persist();notice='Calendar note deleted';draw()";b="if(!calDeleteAt(sel)){draw();return}sel=0;notice='Calendar note deleted';draw()";assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.calendar.splice(phoneState.calendar.indexOf(a[Math.min(sel,a.length-1)]),1);persist();sel=0;notice='Calendar note deleted'";b="if(!calDeleteAt(phoneState.calendar.indexOf(a[Math.min(sel,a.length-1)]))){draw();return}sel=0;notice='Calendar note deleted'";assert s.count(a)==1;s=s.replace(a,b)
a="phoneState.calendar.splice(calNoteView,1);persist();notice='Calendar note deleted';go('calview');return";b="if(!calDeleteAt(calNoteView)){draw();return}notice='Calendar note deleted';go('calview');return";assert s.count(a)==1;s=s.replace(a,b)
a='function calOpenEdit()';b="function calDeleteAt(i){let beforeCalendar=phoneState.calendar.slice();phoneState.calendar.splice(i,1);try{persist()}catch(err){phoneState.calendar=beforeCalendar;notice='Unable to delete calendar note';return false}return true}\nfunction calOpenEdit()";assert s.count(a)==1;s=s.replace(a,b)
a="if(calOv&&calOv!=='matches'){let a=calOvRows()";b="if(calOv&&calOv!=='matches'&&!(calOv==='delnotes'&&notice)){let a=calOvRows()";assert s.count(a)==1;s=s.replace(a,b)
a="Unable to save calendar note|Folder memory full|";b="Unable to save calendar note|Unable to delete calendar notes?|Folder memory full|";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.43-calendar-delete-rollback-candidate.html').write_text(s)
s=Path('/downloads/C2-Reborn-v6.43-calendar-delete-rollback-candidate.html').read_text()
a="let phoneState=JSON.parse(JSON.stringify(defaultState));try{phoneState=migrateState(JSON.parse(localStorage.getItem('c2state')||'null'))}"
b="let loadedCalendar=false;let phoneState=JSON.parse(JSON.stringify(defaultState));try{let saved=JSON.parse(localStorage.getItem('c2state')||'null');loadedCalendar=Array.isArray(saved?.calendar);phoneState=migrateState(saved)}"
assert s.count(a)==1;s=s.replace(a,b)
a="if(!phoneState.calendar.length){phoneState.calendar.unshift";b="if(!loadedCalendar&&!phoneState.calendar.length){phoneState.calendar.unshift";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.43-calendar-delete-rollback-candidate.html').write_text(s)
