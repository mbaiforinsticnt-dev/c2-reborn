# C2 Reborn v5.73: bounded scientific percent fix

Frozen source, no index change. Implements the existing % grid operation as current operand divided by 100. SDK physical-key replay: 50 -> Select % -> 0.5; pending 200 + 10 -> % gives 200+0.1, then = gives 200.1. Both captures included. HTML before left operand unchanged; after matches these two outcomes.

6 focused + 242 carried checks pass. JavaScript syntax passes. Actual mobile 390x844 % result pixels inspected; source patch rebuild byte-exact.

Not full scientific calculator parity: SDK has Calculator title, DEG/RAD control, 4-column grid, sign, C, MS/MR and further scrollable operations. Existing HTML layout and those missing controls remain unchanged, awaiting handset grounding. Broader Stopwatch, interval editor and other v5.72 caveats remain.
