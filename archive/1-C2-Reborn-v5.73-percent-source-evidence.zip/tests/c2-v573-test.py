exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.73-percent-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
n=0
def check(name,expr):
 global n
 z=ev(expr);print(name,z);assert z is True,(name,z);n+=1
for value,result in [('50','0.5'),('0','0'),('-50','-0.5'),('12.5','0.125')]:
 ev("page='scientific';open=false;notice='';calcStored=null;calcOp='';calc="+repr(value)+";calcSel=9;draw();press('OK')")
 check('Unary percent '+value,"calc==="+repr(result))
ev("page='scientific';calc='200';calcSel=13;calcStored=null;calcOp='';draw();press('OK');calc='10';calcSel=9;press('OK')")
check('Pending percent transforms operand',"calc==='0.1'&&calcStored===200&&calcOp==='+'")
ev("calcSel=14;press('OK')")
check('Pending equals retains transformed operand',"calc==='200.1'&&calcStored===null&&calcOp===''")
ev("calcSel=9;calc='50';press('OK')")
z=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});open('/downloads/c2-v573-percent.png','wb').write(base64.b64decode(z['result']['data']))
print('PASS',n)
