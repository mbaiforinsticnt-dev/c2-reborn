exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.73-percent-candidate.html'))
checks=[
('fresh Contacts route',"phoneState=migrateState(null);cfReset();page='contacts';sel=1;open=false;detailSub=null;press('OK');return page==='addcontact'&&CF_KEYS.join('|')==='last|first|mobile|home|email|image'&&CF_LABELS.join('|')==='Last name:|First name:|Mobile number:|Home number:|E-mail address:|Image:'"),
('blank softkeys',"draw();return [sl.textContent,sm.textContent,sr.textContent].join('|')==='Options|Save|Back'"),
('all six fields reachable',"contactField=0;let seen=[];for(let i=0;i<6;i++){seen.push(CF_KEYS[contactField]);press('DOWN')}return seen.join('|')==='last|first|mobile|home|email|image'&&contactField===0"),
('Add detail root',"contactField=0;press('LSK');os=0;press('OK');return detailSub==='root'&&DETAILSUBS.root.join('|')==='Number ▸|Internet ▸|Multimedia ▸|Personal info ▸'"),
('optional Company works',"ds=3;press('OK');ds=5;press('OK');return CF_KEYS.includes('company')&&CF_KEYS[contactField]==='company'"),
('saving retains all fields',"cfReset();contactName='Test';contactFirst='Contact';contactNumber='123';contactHome='456';contactEmail='contact@test.invalid';contactImage='Photo0001.jpg';editingContact=false;saveContact();let x=phoneState.contacts[contactIndex];return x.last==='Test'&&x.first==='Contact'&&x.home==='456'&&x.email==='contact@test.invalid'&&x.image==='Photo0001.jpg'"),
('edit retains defaults and optional',"loadContactToForm({...phoneState.contacts[contactIndex],company:'C'});return ['last','first','mobile','home','email','image','company'].every(k=>CF_KEYS.includes(k))&&contactCompany==='C'"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for n,e in [('top',"cfReset();page='contacts';sel=1;open=false;detailSub=null;notice='';editingContact=false;press('OK')"),('bottom',"for(let i=0;i<5;i++)press('DOWN')"),('add-detail',"contactField=0;press('LSK');os=0;press('OK')")]:
 ev(e);time.sleep(.2);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path='/downloads/c2-v558-contact-'+n+'.png';open(path,'wb').write(base64.b64decode(r['result']['data']));print(path)
print('PASS',len(checks))
