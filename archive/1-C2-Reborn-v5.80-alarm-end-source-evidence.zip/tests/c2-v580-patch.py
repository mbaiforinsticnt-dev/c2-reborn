from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.79-alarm-days-upload-ready.html').read_text().replace('v5.79','v5.80')
def patch(a,b):
 global s
 assert a in s,a
 s=s.replace(a,b,1)
patch('alarmFlashTimer=0;','alarmFlashTimer=0,alarmExitHome=false;')
patch("alarmMode=alarmEntry=''}","alarmMode=alarmEntry='';alarmExitHome=false}")
patch("function alarmFinish(){clearTimeout(alarmFlashTimer);alarmMode='';alarmDraft=null;history=history.filter(h=>(typeof h==='string'?h:h.page)!=='alarmclock');page='organiser';sel=0;draw()}","function alarmFinish(){clearTimeout(alarmFlashTimer);alarmMode='';alarmDraft=null;if(alarmExitHome){history=[];page='home'}else{history=history.filter(h=>(typeof h==='string'?h:h.page)!=='alarmclock');page='organiser'}alarmExitHome=false;sel=0;draw()}")
patch("if(k==='END'){clearTimeout(alarmFlashTimer);alarmMode='';alarmDraft=null;history=[];page='home';sel=0;draw();return true}","if(k==='END'){alarmExitHome=true;if(alarmDirty()){alarmMode='endcancel';draw()}else alarmFinish();return true}")
patch("if(alarmMode==='cancel'){if(k==='LSK')alarmFinish();", "if(alarmMode==='endcancel'){if(k==='OK')alarmSave();else if(k==='RSK'||k==='BACK')alarmFinish();return true}\n if(alarmMode==='cancel'){if(k==='LSK')alarmFinish();")
patch("({cancel:'Save changes?',saved:","({cancel:'Save changes?',endcancel:'Save changes?',saved:")
patch("if(alarmMode==='cancel')soft('No','Yes','Back');", "if(alarmMode==='cancel')soft('No','Yes','Back');else if(alarmMode==='endcancel')soft('','Yes','No');")
Path('/downloads/C2-Reborn-v5.80-alarm-end-candidate.html').write_text(s)
