import os
F=os.environ.get('C2F','c2-v6157-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v)
def fresh(row):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';profileTonesFor=0;go('profiletones');sel=%d;draw()})()"%row)
fresh(0);seen=[]
for q in range(16):
 seen.append(ev("sel"));ev("press('DOWN');0")
t('DOWN visits all 15 rows then wraps',seen==list(range(15))+[0])
fresh(0);ev("press('UP');0");t('UP from first reaches row 14',ev("sel")==14)
fresh(14);ev("press('OK');0");t('row 14 OK edits profile name',ev("nameEditing")==True)
fresh(13);ev("press('OK');0");t('row 13 Alert for OK opens its list',ev("page")=='alertformark')
fresh(12);ev("press('OK');0");t('row 12 application tones OK opens chooser',ev("page")=='radiolist')
fresh(14);ev("press('LSK');0;press('OK');0");t('Options>Change on name edits',ev("nameEditing")==True)
print('checks',len(res),'pass',sum(1 for v in res if v is True))
