import os,json
F=os.environ.get('C2F','c2-v6156-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v)
def fresh(row):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';profileTonesFor=0;go('profiletones');sel=%d;draw()})()"%row)
S="(()=>({page,sel,notice,rc:radioCtx&&radioCtx.title,n:radioCtx&&radioCtx.opts.length}))()"
for row,name in [(1,'Ringing tone'),(7,'E-mail alert tone')]:
 fresh(row);ev("press('OK');0");r=ev(S);t(name+' OK opens chooser',r['page']=='radiolist' and r['n']==38 and 'Saved' not in r['notice'])
 k='tone' if row==1 else 'emailtone';cur=ev("profileToneStore(screens.profiles[profileTonesFor]).%s"%k);exp=ev("(()=>{let l=PROFILE_TONE_LIST,c=l.indexOf(profileToneStore(screens.profiles[profileTonesFor]).%s);return l[(c-1+l.length)%%l.length]})()"%k)
 ev("press('UP');0;press('OK');0");t(name+' OK commits and returns',ev("page")=='profiletones' and ev("profileToneStore(screens.profiles[profileTonesFor]).%s"%k)==exp and exp!=cur)
 fresh(row);ev("press('LSK');0");ev("press('OK');0");r=ev(S);t(name+' Options>Change opens chooser',r['page']=='radiolist' and 'Not implemented' not in r['notice'])
 ev("press('RSK');0");t(name+' chooser Back returns to Options',ev("page")=='profiletones' and ev("open")==True)
for row,name,k in [(2,'volume','volume'),(9,'keypad','keypad')]:
 fresh(row);b=ev("profileToneStore(screens.profiles[profileTonesFor]).%s"%k);ev("press('LSK');0;press('OK');0");a=ev("profileToneStore(screens.profiles[profileTonesFor]).%s"%k);t(name+' Change steps no stub',a==min(7,b+1) and 'Not implemented' not in ev("notice"))
fresh(0);ev("press('OK');0");t('alert row OK opens chooser',ev("page")=='radiolist')
fresh(1);ev("localStorage.clear();0");
print('checks',len(res),'pass',sum(1 for v in res if v is True))
