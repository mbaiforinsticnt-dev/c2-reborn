exec(open("/tmp/hdr.py").read())
fresh2();ev("phoneState.todos=[{s:'Pay rent',p:'High',d:'05-10-2026',t:'09:00',done:false}];go('todolist')");S('LSK')
for q in range(9):S('DOWN')
print(ev('os'));S('OK');print(ev('page'),repr(ev('notice')),ev("JSON.stringify(phoneState.calendar[0])"))
fresh2();ev("phoneState.calls.dialled.unshift({number:'7770001',time:'Today 00:01'});persist();go('allcalls')");S('RSK') if False else None
# clear log then END
fresh2();ev("go('log')");
for q in range(5):S('DOWN')
S('OK');S('OK');print('clear',repr(ev('notice')),ev('page'));S('END');print('END',ev('page'))
