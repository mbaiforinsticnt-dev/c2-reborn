C2 Reborn v6.192 (base v6.191). Focused scripts r105-r110: python3 rNN.py index.html. Every item reproduced on v6.191 first (Tab's retest leads, unverified; screenshots taken locally).
Fixed:
- Item alarm screen: the white bell panel (alarmRing styling) covered the reminder text and date. Now a compact icon + text + date row (screenshot checked).
- In-call "On hold"/"Muted": the line was drawn under the softkey bar (measured: overlapped softkeys). Now shown beside the timer ("On hold  00:03"), screenshot checked.
- Standby clock did not repaint while idle (shown 18:57 after handset reached 18:58). Home repaints when the handset minute changes.
- To-do "Save to Calendar" only opened the Calendar. It now adds a Reminder calendar note with the to-do text and due date (alarm off), notice "Saved to calendar". Inferred shape, no handset footage.
- Calls: dialler Options Save / Send message / Add to contact and call-log Options > Call showed a false "Not implemented in this prototype" (branches lacked return). Fixed.
- END now works in one press: in a call with Options open, on a notice (e.g. after Clear log lists), and on the "Delete selected call?" prompt (which also now clears with END).
Not changed (no evidence): Gallery folder rename returning with Options open (deliberate old code), Notes Via calendar OK (intended behaviour unknown), Clear log confirm (handset says none), call timer during hold, list vs detail duration (Video & voice 2s vs 8s, not yet reproduced), volume step, speed-dial name.
