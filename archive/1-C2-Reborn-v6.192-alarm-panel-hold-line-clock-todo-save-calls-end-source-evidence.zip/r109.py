exec(open("/tmp/hdr.py").read())
import time as tm,re
fresh2();ev("go('home')")
CL="document.querySelector('.lcd').innerText.replace(/\\n/g,'|')"
g=lambda:re.search(r'\d\d:\d\d',ev(CL)).group(0)
a=g()
for q in range(70):
    tm.sleep(1)
    if ev("handsetNow().toTimeString().slice(0,5)")!=a:break
tm.sleep(2.5);print('clock handset',ev("handsetNow().toTimeString().slice(0,5)"),'shown',g())
fresh2();ev("phoneState.todos=[{s:'Pay rent',p:'High',d:'05-10-2026',t:'09:00',done:false}];go('todolist')");S('LSK')
for q in range(9):
    S('DOWN')
print(ev(T)[-80:])
