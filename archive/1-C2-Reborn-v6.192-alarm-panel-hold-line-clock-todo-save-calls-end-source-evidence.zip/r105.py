exec(open("/tmp/hdr.py").read())
import base64
def shot(n):
    d=call('Page.captureScreenshot',{'format':'png'});open('/tmp/'+n,'wb').write(base64.b64decode(d['result']['data']))
fresh2()
ev("itemAlarm={kind:'Reminder',text:'Dentist appointment at the clinic',when:'03-10-2026 17:10'};page='itemalarm';draw()");shot('s-alarm.png')
fresh2();ev("go('home')")
for k in '5551234':S(k)
S('CALL');S('LSK');S('DOWN');S('DOWN');S('OK');import time as tm;tm.sleep(2.5);shot('s-hold.png')
print(ev("document.querySelector('.inCall small')&&JSON.stringify(document.querySelector('.inCall small').getBoundingClientRect())"),ev("JSON.stringify(document.querySelector('.softkeys, .soft, #soft')&&document.querySelector('.softkeys, .soft, #soft').getBoundingClientRect())"))
