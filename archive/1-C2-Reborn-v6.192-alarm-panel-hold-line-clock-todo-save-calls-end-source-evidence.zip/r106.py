exec(open("/tmp/hdr.py").read())
import time as tm,re
fresh2();ev("go('home')")
CL="document.querySelector('.lcd').innerText.replace(/\\n/g,'|')"
g=lambda:re.search(r'\d\d:\d\d',ev(CL)).group(0)
a=g();print('start',a)
for q in range(70):
    tm.sleep(1)
    if ev("handsetNow().toTimeString().slice(0,5)")!=a:break
tm.sleep(3);print('handset',ev("handsetNow().toTimeString().slice(0,5)"),'shown',g())
