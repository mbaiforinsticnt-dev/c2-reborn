exec(open("/tmp/hdr.py").read())
import time as tm
for nm,n in (('Call',0),('Save',1),('Send message',2),('Add to contact',3)):
    fresh2();ev("go('home')")
    for k in '5551234':S(k)
    S('LSK')
    for q in range(n):S('DOWN')
    S('OK');print(nm,ev('page'),repr(ev('notice')),ev(T)[:110])
fresh2();ev("phoneState.calls.dialled.unshift({number:'7770001',time:'Today 00:01'});persist();go('allcalls')");S('LSK');S('OK');print('logCall',ev('page'),repr(ev('notice')),ev(T)[:100])
