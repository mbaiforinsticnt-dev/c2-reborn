from PIL import Image, ImageDraw
items=[("closed envelope (made)","env36.png"),("open envelope (firmware)","v_READ.png"),("green tick (crop)","../crops/tick_tight.png"),("memory card (crop)","mc_em3.png")]
W=230;H=340
S=Image.new("RGB",(W*4,H),"white");d=ImageDraw.Draw(S)
for i,(n,f) in enumerate(items):
    im=Image.open(f).convert("RGBA");w,h=im.size
    k=min(170/w,170/h);big=im.resize((int(w*k),int(h*k)),Image.NEAREST)
    x=i*W
    d.rectangle([x,0,x+W-1,H-1],outline="#888")
    S.paste(big,(x+(W-big.width)//2,10),big)
    S.paste(im,(x+(W-w)//2,190),im)
    d.text((x+8,H-40),n,fill="black");d.text((x+8,H-24),"actual size %dx%d, large x%.1f"%(w,h,k),fill="black")
S.save("/tmp/icons-sheet.png")
