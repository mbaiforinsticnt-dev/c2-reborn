# SMS attachment flow - Moti emulator video 13:11 5 Oct (AnyDesk recording of SDK emulator, 3 parts, 301 s)
Frames: S00-S11 contact sheets (2 s sampling, labelled with video time). Tooltips read by OCR on 4 fps frames.

## Attachment strip (message editor, 11 items, cyclic, left to right)
Image, Sound clip(?), Calendar note, Business card, Theme (palette icon), Streaming link (globe+phone), Gallery file (film+note icon, OCR "?? file"), Text field (notepad+pencil), Text template (abc), Video clip, Camera, back to Image.
Tooltip (white box above the selected icon, ~1 s after landing): "Image", "Camera", "Video clip", "Text template", "Text field", "Streaming link", "Theme", "Calendar note", "Business card". Sound clip and Gallery file tooltips not read cleanly - verify.
Entering strip (Down from Text) selects Image first. Selected icon has black highlight tile. Arrows < > at the ends.
Softkeys: To field = Options / Add / Back; Text field = Options / Send / Back; strip = Options / Insert / Back.
## SMS -> MMS
- Text template and Text field insert text only; message stays SMS (narration).
- Gallery file / Streaming link probably stay SMS (his guess, not shown).
- Business card (and image, calendar note, sound ...) converts. Note shown ~2 s: "Message changed to multimedia" with green tick. Header "New text message 1000/01" -> "New multimedia 1/1"; status bar shows a paperclip icon; right softkey Back -> Close.
- Preview of business card message: "Attachments" list, one row "VCARD.vcf 0.1 kB", softkeys Options / Open / Back. Open -> note "No data to display" (info icon). Options: Save, Details. Save -> note "Business card saved to phone memory" (tick).
- Calendar note with no notes: opens the calendar (month view, wk 41), then "(no notes)", softkeys Options / View / Back.
- Image: Insert -> Gallery (Memory card, Images, Video clips, Music files, Graphics, Tones, Recordings, Received files) -> Graphics (Wallpapers, Clip-art, Frames) -> Wallpapers (Hot Air Balloon, Jungle.jpg, Leaves.jpg, Satin.jpg, Squirrel.jpg, Typescape Green) softkeys Options / Insert / Back. After insert: "New multimedia 1/1" with an "Image:" field showing thumbnail + "Typescape Green...." above Text; softkeys Options / Send / Close.
- MM options menu: Send, Preview, Insert, Add recipient >, Add subject, Remove >, Slide options >. SMS options: Send, Preview, Insert, Add recipient >, Add subject, Clear field, Insert contact detail, Insert symbol >, ... (there is also "Change to multimedia" item, OCR "to multimedia").
- Remove > Image: dialog "Remove object? Typescape Green.jpg" Yes / No. After removing the only object: note "Message changed to text message" (tick), header back to "New text message 1000/01".
- Close with unsaved MM: "Save message?" No / Yes / Back; No -> "Message not saved" (info icon).
## Spoken rules
1 Insert template/text field = text only, stays SMS. 2 Any real object converts to MMS with a note. 3 Removing the last object converts back with a note. 4 Tooltip shows the name above the icon for about 1 s.
