from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.103-calendar-setting-rollback-candidate.html').read_text().replace('v6.103 handset parity','v6.104 handset parity').replace('C2 Reborn v6.103 |','C2 Reborn v6.104 |')
a='phoneState.calPrefs.zone=calZoneDraft;phoneState.calPrefs.dst=calDstDraft;phoneState.calPrefs.clockAt=new Date(d.getFullYear(),d.getMonth(),d.getDate(),+a[0],+a[1],0,0).getTime();phoneState.calPrefs.clockSavedAt=Date.now();calDateDirty=false;persist();back();'
b="let beforePrefs=phoneState.calPrefs,beforeDirty=calDateDirty;phoneState.calPrefs={...beforePrefs,zone:calZoneDraft,dst:calDstDraft,clockAt:new Date(d.getFullYear(),d.getMonth(),d.getDate(),+a[0],+a[1],0,0).getTime(),clockSavedAt:Date.now()};try{persist()}catch(err){phoneState.calPrefs=beforePrefs;calDateDirty=beforeDirty;calSavePrompt=true;notice='Unable to save date and time';draw();return true}calDateDirty=false;back();"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save calendar setting|Folder memory full','Unable to save calendar setting|Unable to save date and time|Folder memory full')
Path('/downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html').write_text(s)
