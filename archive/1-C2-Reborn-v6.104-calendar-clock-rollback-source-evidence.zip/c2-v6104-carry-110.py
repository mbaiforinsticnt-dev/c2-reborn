exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for playing in ['false','true']:
 ev("phoneState=migrateState(null);phoneState.player.playing="+playing+";phoneState.player.elapsed=15;playerTickBase=Date.now()-5000;persist();before=JSON.stringify(phoneState);beforePlayer=phoneState.player;beforeTick=playerTickBase;stored=localStorage.getItem('c2state');page='player';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(playing+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.player===beforePlayer&&playerTickBase===beforeTick&&localStorage.getItem('c2state')===stored")
 t(playing+' visible warning',"return notice==='Unable to save player'&&document.getElementById('screen').innerText.includes(notice)")
 if playing=='false':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v686-player-toggle-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(playing+' repeat failure exact',"return phoneState.player===beforePlayer&&JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';writes=0;Storage.prototype.setItem=function(k,v){writes++;return oldStore.call(this,k,v)};press('OK');Storage.prototype.setItem=oldStore")
 t(playing+' retry atomic toggle',"return writes===1&&phoneState.player.playing!=="+playing)
 t(playing+' retry elapsed',"return "+("phoneState.player.elapsed>=20&&phoneState.player.elapsed<22" if playing=='true' else "phoneState.player.elapsed===15"))
 t(playing+' saved exact',"return JSON.stringify(JSON.parse(localStorage.getItem('c2state')).player)===JSON.stringify(phoneState.player)")
ev("phoneState.player.playing=true;phoneState.player.elapsed=89;playerTickBase=Date.now()-3000;page='player';notice='';writes=0;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){writes++;return oldStore.call(this,k,v)};press('OK');Storage.prototype.setItem=oldStore")
t('Finished playback pause preserves zero reset',"return phoneState.player.playing===false&&phoneState.player.elapsed===0&&writes===1")
print('PASS',len(checks))
