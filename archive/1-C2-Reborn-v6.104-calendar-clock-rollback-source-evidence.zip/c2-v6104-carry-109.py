exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for muted in [None,False,True]:
 for playing in ['true','false']:
  setup="delete phoneState.player.muted" if muted is None else "phoneState.player.muted="+str(muted).lower()
  ev("phoneState=migrateState(null);phoneState.player.playing="+playing+";phoneState.player.elapsed=15;playerTickBase=Date.now();"+setup+";persist();before=JSON.stringify(phoneState);beforePlayer=phoneState.player;stored=localStorage.getItem('c2state');page='player';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('#')")
  t(str(muted)+playing+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.player===beforePlayer&&localStorage.getItem('c2state')===stored")
  t(str(muted)+playing+' warning visible',"return notice==='Unable to save player'&&document.getElementById('screen').innerText.includes(notice)")
  if muted is None and playing=='false':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v685-player-mute-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('#')")
  t(str(muted)+playing+' repeat failure exact',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';press('#')")
  expected='false' if muted is True else 'true'
  t(str(muted)+playing+' retry once',"return phoneState.player.muted==="+expected+"&&phoneState.player.playing==="+playing)
  ev("phoneState.player.playing=false;persist()")
  call('Page.reload');time.sleep(.15)
  t(str(muted)+playing+' reload exact',"return phoneState.player.muted==="+expected)
print('PASS',len(checks))
