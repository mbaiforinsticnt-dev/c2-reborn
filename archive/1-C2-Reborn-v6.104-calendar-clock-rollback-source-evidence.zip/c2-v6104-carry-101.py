exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for volume,key in [(None,'UP'),(6,'UP'),(6,'DOWN'),(0,'DOWN'),(10,'UP')]:
 setup="delete phoneState.callVolume" if volume is None else "phoneState.callVolume="+str(volume)
 ev("phoneState=migrateState(null);"+setup+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='incall';activeCall='Demo';callHeld=true;callHeldAt=12;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
 t(str(volume)+key+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(str(volume)+key+' warning visible',"return notice==='Unable to save call volume'&&document.getElementById('screen').innerText.includes(notice)&&page==='incall'&&activeCall==='Demo'&&callHeld")
 if volume is None:
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v677-call-volume-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('"+key+"')")
 t(str(volume)+key+' repeated failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
 expected=max(0,min(10,(6 if volume is None else volume)+(1 if key=='UP' else -1)))
 t(str(volume)+key+' retry exact',"return phoneState.callVolume==="+str(expected)+"&&notice==='Volume "+str(expected)+"'")
 call('Page.reload');time.sleep(.15)
 t(str(volume)+key+' reload exact',"return phoneState.callVolume==="+str(expected))
print('PASS',len(checks))
