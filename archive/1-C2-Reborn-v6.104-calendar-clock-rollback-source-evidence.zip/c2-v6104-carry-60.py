exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html'))
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for label,value,expect in [('absent',None,1),('empty',{'calendar':[]},0),('invalid calendar',{'calendar':'bad'},1),('malformed JSON','{broken',1),('existing',{'calendar':[{'type':'Reminder','text':'Kept','date':'01-10-2026','repeat':'Never','alarm':False,'time':''}]},1)]:
 if value is None:ev("localStorage.removeItem('c2state')")
 else:ev("localStorage.setItem('c2state',"+json.dumps(value if isinstance(value,str) else json.dumps(value))+")")
 call('Page.reload');time.sleep(.15)
 t(label+' seed rule',"return phoneState.calendar.length==="+str(expect)+( "&&phoneState.calendar[0].text==='Kept'" if label=='existing' else ''))
print('PASS',len(checks))
