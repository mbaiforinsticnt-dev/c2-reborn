exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.104-calendar-clock-rollback-candidate.html'))
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
t('Palette256 entries',"let a=new Uint8ClampedArray([255,0,0,255,0,255,0,255,0,0,255,255]);return galEditorPalette(a).palette.length===256")
t('Separate exact primary colours',"let a=new Uint8ClampedArray([255,0,0,255,0,255,0,255,0,0,255,255]),q=galEditorPalette(a);return q.palette.some(c=>c.join(',')==='255,0,0')&&q.palette.some(c=>c.join(',')==='0,255,0')&&q.palette.some(c=>c.join(',')==='0,0,255')")
t('Deterministic quantization',"let a=new Uint8ClampedArray(256*4);for(let j=0;j<256;j++){a[j*4]=j;a[j*4+1]=255-j;a[j*4+3]=255}return JSON.stringify(galEditorPalette(a).palette)===JSON.stringify(galEditorPalette(a).palette)")
t('Uniform black',"let q=galEditorPalette(new Uint8ClampedArray([0,0,0,255,0,0,0,255]));return q.palette[0].join(',')==='0,0,0'&&q.indices.get(0)===0")
for name,width,height,expr in [('primary',3,1,'new Uint8ClampedArray([255,0,0,255,0,255,0,255,0,0,255,255])'),('gradient',240,320,"(()=>{let a=new Uint8ClampedArray(240*320*4);for(let j=0;j<240*320;j++){a[j*4]=Math.floor(j/240)*255/319;a[j*4+1]=(j%240)*255/239;a[j*4+2]=160;a[j*4+3]=255}return a})()"),('max',400,500,"(()=>{let a=new Uint8ClampedArray(400*500*4);for(let j=0;j<a.length;j+=4){a[j]=123;a[j+1]=145;a[j+2]=67;a[j+3]=255}return a})()")]:
 r=ev(f'galEditorGif({width},{height},{expr}).src');open('/downloads/c2-v595-palette-'+name+'.gif','wb').write(base64.b64decode(r.split(',')[1]))
from PIL import Image
p=Image.open('/downloads/c2-v595-palette-primary.gif').convert('RGB');assert list(p.getdata())==[(255,0,0),(0,255,0),(0,0,255)];print('Exact primary roundtrip True')
for name,size in [('gradient',(240,320)),('max',(400,500))]:
 p=Image.open('/downloads/c2-v595-palette-'+name+'.gif');p.load();assert p.size==size;print(name+' decode full dimensions True')
print('PASS',len(checks)+3)
