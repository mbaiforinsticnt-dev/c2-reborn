C2 Reborn v6.177 (source evidence)
Base: v6.176 (blob 03d35acc). Reproduced on v6.176 first (emulator/CDP, not handset):
- SW2: interval timer completion drew nothing until a key press. The finish branch now redraws.
Not implemented (evidence, not guess):
- SW5 interval/rest time editing and ST1 stub groups (Bluetooth paired devices, Security rows, Packet data access point).
  6260 SDK emulator probe (emu-6260-interval-timers.png, 6260 slide profile, NOT C2-01 proof): Countd. timer > Interval timer is a list "Interval timers" with "Add new timer" and a "Timer name:" form, a different structure from the C2 build's Intervals/Interval time/Rest time rows. No C2-01 handset footage for either. Left as is until handset evidence exists.
Focused tests 41/41.
