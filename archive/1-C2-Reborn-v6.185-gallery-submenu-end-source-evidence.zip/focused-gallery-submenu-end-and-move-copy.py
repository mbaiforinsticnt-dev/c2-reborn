exec(open("/tmp/hdr.py").read())
st="[page,open,pageSub,sel]"
def img():
    fresh2();ev("go('gallery')");S('DOWN');S('OK')
for name,seq in (('sort',['LSK']+['UP']*7+['OK']),('send',['LSK']+['DOWN']*3+['OK']),('view',['LSK']+['UP']*8+['OK']),('delete',['LSK']+['DOWN']*4+['OK']),('move',['LSK']+['DOWN']*5+['OK'])):
    img();print(name,'pre',ev(st),ev(T)[:80])
    for k in seq:S(k)
    print(name,'after seq',ev(st),ev(T)[-160:])
    S('END');print(name,'END',ev(st),ev(T)[:80])
