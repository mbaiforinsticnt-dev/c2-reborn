# C2 Reborn v6.185 (source-evidence)
Changes (both reproduced on v6.184 with Tab's key paths, from the Images file list):
1. End from a Gallery file-list Options submenu (Sort, Send, Type of view) closed only the submenu and left the Images list with Options open (state: page galfolder, open True). Now End returns to standby in one press; pageSub/optParent/open are part of the cleared pending state.
2. Gallery file Move / Copy showed "Not implemented in this prototype" over the destination list with blank softkeys (branch did not return). Now the destination list shows Options / Move (or Copy) / Back, no stray note. Same fix for Move marked / Copy marked.
Evidence class: inferred (End always to standby; the destination list is the real screen), not C2-01 handset-proven.
Not tested: Add/Rename folder inside Images returning to the wrong level.
