C2 Reborn v5.85 - empty alarm repeat weekday seed
Frozen 30 September 2026. Not deployed.
SDK replay: empty-day Repeat On seeds Wednesday at 30-09-2026; after editing SDK date to 29-09-2026 it seeds Tuesday. The prototype uses its configured handset clock, not an independent browser clock.
Change menu and Left/Right share the same toggle helper. Nonempty day selections are preserved. Seeding stays draft until Save.
Correction to interim report: Unmark all followed by Back turning Repeat Off already matched the existing code. It was verified, not patched.
12 new checks; carried Print 12, Zoom/Contrast 30, Use image 30, numeric 13, End 9, Alarm 29. Alarm carried test explicitly clears seeded days before the existing picker marking replay. Print carried expectation updated to the v5.84 confirmation behavior.
Pixels inspected in both Tuesday and Wednesday HTML screens and both SDK seed screens. Full broader historical regression set was not rerun for this two-path bounded helper repair.
