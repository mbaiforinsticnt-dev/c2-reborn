from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.84-print-confirmation-upload-ready.html').read_text()
assert s.count("alarmDraft[f]=!alarmDraft[f]")==2
s=s.replace('v5.84 handset parity','v5.85 handset parity').replace('C2 Reborn v5.84 |','C2 Reborn v5.85 |')
s=s.replace('function alarmChoose(){',"function alarmToggle(f){alarmDraft[f]=!alarmDraft[f];if(f==='repeat'&&alarmDraft.repeat&&!alarmDraft.days.length)alarmDraft.days=[(handsetNow().getDay()+6)%7]}\nfunction alarmChoose(){")
s=s.replace("alarmDraft[f]=!alarmDraft[f];else if(f==='days')","alarmToggle(f);else if(f==='days')")
s=s.replace("alarmDraft[f]=!alarmDraft[f];else if(f==='tone'||f==='days')","alarmToggle(f);else if(f==='tone'||f==='days')")
assert s.count('alarmToggle(f);')==2
Path('/downloads/C2-Reborn-v5.85-alarm-weekday-seed-candidate.html').write_text(s)
