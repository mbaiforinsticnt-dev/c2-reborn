# Moti's rules - status on v6.219 (5 Oct 12:35)
Verified pass (tested): 15 envelopes closed/open in Inbox + conversation; 16 made open envelope = his; 19 Conversations icon; 20 calc info icon size; 23 centre key (conversation: truncated => Open; received full => Reply; sent => Send; OK follows label); 22 icon packs.
Crawl running (a8.py, Nokia theme): rule 2 wrap-up on every list, label vs action (rule 23 system-wide).
Not yet checked system-wide: 1 whole-row highlight, 3 Options panel height, 4 arrows with white border, 6 white-on-white (a6 Dark/Light crawl results exist for some themes), 21 Nokia font (gap list sent 12:11: Arial on keypad labels + 24 glyphs), 9, 12, 13, 18.
Defaults chosen for open questions: a snooze on any key except red end/power incl. side keys; b/c centre = most common action, truncated sent => Open; d wrap on lists + tab/value pickers only where emulator wraps; e follow emulator; h emulator wins.
