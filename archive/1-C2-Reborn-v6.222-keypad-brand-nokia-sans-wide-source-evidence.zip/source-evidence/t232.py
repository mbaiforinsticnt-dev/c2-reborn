exec(open("/tmp/hdr.py").read())
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
call('Page.navigate',{'url':'file://'+F+'?page=conversations'});time.sleep(1.5)
ev('openConversationRow(0)');time.sleep(.8)
def soft():return ev("[...document.querySelectorAll('.soft *')].map(e=>e.children.length?'':e.innerText).filter(x=>x).join('|')")
def sel():return ev("(function(){var b=document.querySelector('.bubble.sel');return b?b.querySelector('.msgText').innerText.slice(0,30)+' T='+(b.querySelector('.msgText').scrollHeight>b.querySelector('.msgText').clientHeight+1):''})()")
for i in range(6):
    print(i,sel(),soft());ev("press('DOWN')");time.sleep(.4)
shot('/tmp/o232.png')
