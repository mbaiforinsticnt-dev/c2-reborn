from PIL import Image,ImageDraw
import numpy as np,os,sys
f=[x for x in os.listdir('/tmp/fw/png') if x.startswith('0421')][0]
im=Image.open('/tmp/fw/png/'+f).convert('RGBA')
x0,y0,x1,y1=4,13,52,46
cx=28;vy=31
W,H=im.size
mask=Image.new('L',(W,H),0);ImageDraw.Draw(mask).polygon([(x0,y0-1),(x1,y0-1),(cx,vy)],fill=255)
m=np.array(mask)>0
a=np.array(im).astype(float)
# body: everything except flap triangle
body=a.copy();body[m]=0
# inside back: darker orange gradient within the triangle bbox region
inside=np.zeros_like(a)
for y in range(H):
    for x in range(W):
        if m[y,x]:
            t=(y-y0)/(vy-y0)
            inside[y,x]=[224-26*t,162-30*t,34,255]
# flap flipped: take triangle pixels, flip vertically around the top edge
tri=a.copy();tri[~m]=0
ys=np.where(m.any(1))[0];ta,tb=ys[0],ys[-1]
flap=np.zeros_like(a)
flap_crop=tri[ta:tb+1][::-1]
flap_crop[:,:,:3]*=0.97
OFF=int(sys.argv[1]) if len(sys.argv)>1 else 9
def shift(arr,dy):
    out=np.zeros_like(arr);
    if dy>=0: out[dy:]=arr[:H-dy]
    else: out[:H+dy]=arr[-dy:]
    return out
canvas=np.zeros_like(a)
b2=shift(body,OFF);i2=shift(inside,OFF)
def over(dst,src):
    al=src[:,:,3:4]/255.;dst[:,:,:3]=src[:,:,:3]*al+dst[:,:,:3]*(1-al)*(dst[:,:,3:4]/255.)/(1) if False else src[:,:,:3]*al+dst[:,:,:3]*(1-al);dst[:,:,3:4]=np.maximum(dst[:,:,3:4],src[:,:,3:4])
over(canvas,i2);over(canvas,b2)
# flap sits above top edge: its base (last row after flip is the wide edge? flipped: first row = V tip, last row = wide) -> place so wide edge at top edge
top=y0-1+OFF
fp=np.zeros_like(a)
h=flap_crop.shape[0]
# flipped crop: row 0 is the tip, row h-1 is wide base; base touches top edge
start=top-h
fp[start:start+h]=flap_crop
over(canvas,fp)
out=Image.fromarray(canvas.clip(0,255).astype('uint8'),'RGBA');print(out.getbbox())
out.save('/tmp/open56.png')
bg=Image.new('RGBA',(56*8,56*4),(60,60,60,255));
o=out.resize((224,224),Image.NEAREST);bg.alpha_composite(o,(0,0));bg.alpha_composite(im.resize((224,224),Image.NEAREST),(230,0));bg.convert('RGB').save('/tmp/open56sheet.png')
