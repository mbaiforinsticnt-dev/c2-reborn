# Firmware icon extraction (5 Oct 2026)
Source: S40 6th Edition SDK, bin/Resources/Packages/package_c.ppm (product profile RM-368, 04.08.12).
package_c.bin is encrypted (NoSE header). The .ppm is not: it contains 1433 standard PNG files, 41 GIF, 98 JPEG.
Carved by PNG signature to IEND (python). Names are index_offsethex. 491 are 30x30, 258 are 56x56.
Used in v6.208: 0421 closed envelope (56), 0758 open envelope (30), 0603 sent (56, envelope+green tick), 0533 memory card (56).
Rollback assets: made envelope (screenshot cut+mirror), memory card crop, sent crop in this folder.
Sweep: tests/sweep.py compares every named PNG in the HTML to the firmware set (mean abs diff at 32px; 0.0 = identical).
