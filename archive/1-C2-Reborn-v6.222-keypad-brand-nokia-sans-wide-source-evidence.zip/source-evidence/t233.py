exec(open("/tmp/hdr.py").read())
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
call('Page.navigate',{'url':'file://'+F+'?page=conversations'});time.sleep(1.5)
ev('openConversationRow(0)');time.sleep(.8)
ic="JSON.stringify([...document.querySelectorAll('.bubble')].slice(0,2).map(b=>(b.querySelector('img')||{}).src?(b.querySelector('img').src.length):0))"
print('before',ev(ic));shot('/tmp/o233a.png')
ev("press('OK')");time.sleep(.6);print('page',ev("page"),ev("document.querySelector('.msgOpenText')&&document.querySelector('.msgOpenText').innerText.slice(0,60)"));shot('/tmp/o233b.png')
ev("press('BACK')") if False else ev("back()");time.sleep(.6);print('after',ev(ic),ev("page"));shot('/tmp/o233c.png')
