# C2 Reborn audit harness (5 Oct 2026, v6.201)

Playwright + headless Chromium scripts used for the deep audit. Each script points at
`file:///tmp/c2-reborn/index.html`; change `URL`/`U` to your checkout path.

    pip install playwright && python -m playwright install chromium

| Script | What it does |
| --- | --- |
| `verify.py` | Re-checks every headline finding in one run (freeze, XSS, old-build overwrite, corrupt-save reset, small-phone clipping, Enter on Call, submenu key leak, empty Add detail, 7 / 0 = Infinity). Run it after fixing; each line should change. |
| `fuzz.py SESSIONS STEPS OUT.json` | Random walk: weighted keys, 4% long-presses, fake clock advanced between batches. Records exceptions and `undefined`/`NaN`/`null`/`[object`/`Infinity` on screen. Audit run: `80 3000`. |
| `fuzz2.py SESSIONS EPISODES OUT.json SEED` | Directed walk: descends 1-5 menu levels, then presses randomly. Audit run: `10 120 out.json 5000`. |
| `repro2.py "<error text>" FIRST LAST N` | Finds the first seed whose key log hits an error containing the text, then shrinks the log to a minimal reproduction. |
| `clicks.py '["5","OK",...]' shot.png` | Replays keys as real button clicks and prints the screen after each. |

Suggested CI gate before publishing: `python fuzz.py 20 2000 out.json` and fail if `errors` is non-empty.
