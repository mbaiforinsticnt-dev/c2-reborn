"""Directed exploration: walk deep into menu trees, then random-press there. Records errors, text glitches, coverage, and full key logs."""
import asyncio, json, sys, random, collections
from playwright.async_api import async_playwright

URL = __import__('os').environ.get('C2_URL','file:///tmp/c2-reborn/index.html')
SESS = int(sys.argv[1]); EPIS = int(sys.argv[2]); OUT = sys.argv[3]; BASE = int(sys.argv[4]) if len(sys.argv) > 4 else 1000

EP_JS = r"""
([evs]) => {
  const out = { errors: [], text: [], pages: {}, blanks: {}, softBad: [] };
  const bad = /\bundefined\b|\bNaN\b|\[object |\bnull\b|Infinity/;
  for (let i = 0; i < evs.length; i++) {
    const ev = evs[i], from = String(page);
    try { ev.startsWith('hold:') ? pressHold(ev.slice(5)) : press(ev); }
    catch (e) { out.errors.push({ msg: String(e.message||e), stack: String(e.stack||'').split('\n').slice(0,3).join(' | '), from, page: String(page), idx: i }); if (out.errors.length > 3) break; }
    const p = String(page); out.pages[p] = (out.pages[p]||0)+1;
    const lcd = document.querySelector('.lcd'); const t = lcd ? lcd.innerText : '';
    const m = t.match(bad); if (m) out.text.push({ page: p, hit: m[0], snip: t.replace(/\s+/g,' ').slice(Math.max(0,m.index-50), m.index+50), idx: i });
    const scr = document.getElementById('screen');
    if (scr && !scr.innerText.trim() && !scr.querySelector('img,canvas,svg,video')) out.blanks[p] = (out.blanks[p]||0)+1;
  }
  return out;
}
"""

KEYS = [('OK',10),('DOWN',12),('UP',6),('LEFT',6),('RIGHT',6),('LSK',12),('RSK',6),('CALL',2),('END',1),
        ('1',2),('2',3),('3',2),('4',2),('5',2),('6',2),('7',2),('8',2),('9',2),('0',2),('*',2),('#',2)]

def episode(rng):
    evs = ['END', 'END']
    # descend through menus
    start = rng.choice(['OK', 'OK', 'OK', 'RSK', 'LSK', 'DOWN', 'UP', 'LEFT', 'RIGHT', 'CALL'])
    evs.append(start)
    for _ in range(rng.randint(1, 5)):
        evs += ['DOWN'] * rng.randint(0, 14)
        evs.append(rng.choice(['OK', 'OK', 'LSK', 'LSK', 'RIGHT']))
        if rng.random() < 0.3:  # dip into options
            evs.append('LSK'); evs += ['DOWN'] * rng.randint(0, 8); evs.append(rng.choice(['OK', 'LSK']))
    tot = sum(w for _, w in KEYS)
    for _ in range(rng.randint(20, 90)):
        r = rng.random() * tot
        for k, w in KEYS:
            r -= w
            if r < 0: break
        evs.append(('hold:' if rng.random() < 0.04 else '') + k)
    return evs

async def session(b, sid, agg):
    ctx = await b.new_context(viewport={'width': 390, 'height': 844})
    pg = await ctx.new_page(); await pg.clock.install()
    perr = []; pg.on('pageerror', lambda e: perr.append(str(e)))
    await pg.goto(URL)
    rng = random.Random(BASE + sid)
    log = []
    for ep in range(EPIS):
        if rng.random() < 0.15:
            await pg.evaluate('localStorage.clear()'); await pg.reload(); log = []
        evs = episode(rng)
        res = await pg.evaluate(EP_JS, [evs])
        for e in res['errors']:
            e['sid'] = sid; e['ep'] = ep; e['keys'] = (log + evs[:e['idx'] + 1])[-60:]; agg['errors'].append(e)
        for t in res['text']:
            t['sid'] = sid; t['keys'] = (log + evs[:t['idx'] + 1])[-30:]; agg['text'].append(t)
        for p, c in res['pages'].items(): agg['pages'][p] += c
        for p, c in res['blanks'].items(): agg['blanks'][p] += c
        log = (log + evs)[-200:]
        if res['errors']:
            await pg.evaluate('localStorage.clear()'); await pg.reload(); log = []
        await pg.clock.run_for(rng.choice([50, 400, 1500, 4000, 65000]))
        while perr:
            agg['timer'].append({'sid': sid, 'ep': ep, 'msg': perr.pop()[:300], 'keys': log[-40:]})
    await ctx.close()

async def main():
    agg = {'errors': [], 'text': [], 'pages': collections.Counter(), 'blanks': collections.Counter(), 'timer': []}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        sem = asyncio.Semaphore(2)
        async def one(i):
            async with sem:
                try: await session(b, i, agg)
                except Exception as ex: agg['timer'].append({'sid': i, 'msg': 'HARNESS ' + str(ex)[:200]})
        await asyncio.gather(*(one(i) for i in range(SESS)))
        await b.close()
    agg['pages'] = dict(agg['pages']); agg['blanks'] = dict(agg['blanks'])
    json.dump(agg, open(OUT, 'w'), indent=1)
    print('pages', len(agg['pages']), 'errors', len(agg['errors']), 'timer', len(agg['timer']), 'text', len(agg['text']))
    for m, n in collections.Counter(e['msg'][:150] + ' @ ' + e['stack'].split('|')[1].strip()[:60] for e in agg['errors']).most_common(30): print(n, m)
    print(collections.Counter((t['page'], t['hit']) for t in agg['text']).most_common(20))
    print(collections.Counter(t['msg'][:140] for t in agg['timer']).most_common(10))

asyncio.run(main())
