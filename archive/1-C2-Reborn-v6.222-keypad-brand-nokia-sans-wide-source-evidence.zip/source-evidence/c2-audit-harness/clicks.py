import asyncio, json, sys
from playwright.async_api import async_playwright
async def main():
    evs=json.loads(sys.argv[1])
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':390,'height':844}, device_scale_factor=2, has_touch=False)
        pg=await ctx.new_page()
        errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
        await pg.goto('file:///tmp/c2-reborn/index.html')
        for i,e in enumerate(evs):
            n=len(errs)
            await pg.click(f'button[data-k="{e}"]'); await pg.wait_for_timeout(120)
            t=await pg.evaluate("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ').slice(0,90)")
            print(f'{i+1:2} {e:5} -> {t}' + ('   !! '+errs[-1][:80] if len(errs)>n else ''))
        await pg.screenshot(path=sys.argv[2])
        await pg.reload(); await pg.wait_for_timeout(300)
        t=await pg.evaluate("String(page)+' | '+document.querySelector('.lcd').innerText.replace(/\\s+/g,' ').slice(0,80)")
        print('after reload ->', t)
        await b.close()
asyncio.run(main())
