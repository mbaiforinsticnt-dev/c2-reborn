import asyncio, json, sys, random, collections
from playwright.async_api import async_playwright

URL = __import__('os').environ.get('C2_URL','file:///tmp/c2-reborn/index.html')
SEEDS = int(sys.argv[1]) if len(sys.argv) > 1 else 40
STEPS = int(sys.argv[2]) if len(sys.argv) > 2 else 600
OUT = sys.argv[3] if len(sys.argv) > 3 else 'fuzz_out.json'

# Runs a batch of key presses inside the page with a seeded RNG and checks invariants after each one.
BATCH_JS = r"""
([seed, n, trail]) => {
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const keys = [['OK',14],['DOWN',14],['UP',6],['LEFT',5],['RIGHT',5],['LSK',12],['RSK',8],['CALL',2],['END',2],
                ['1',2],['2',3],['3',2],['4',2],['5',2],['6',2],['7',2],['8',2],['9',2],['0',2],['*',2],['#',2]];
  const tot = keys.reduce((a,b)=>a+b[1],0);
  const pick = () => { let r = rnd()*tot; for (const [k,w] of keys) { if ((r-=w) < 0) return k; } return 'OK'; };
  const res = { errors: [], textBugs: [], pages: {}, blanks: {}, maxHist: 0, trail };
  const bad = /\bundefined\b|\bNaN\b|\[object |\bnull\b|Infinity/;
  for (let i = 0; i < n; i++) {
    const hold = rnd() < 0.04;
    const k = pick();
    const before = (typeof page === 'string') ? page : String(page);
    res.trail.push((hold ? 'hold:' : '') + k);
    if (res.trail.length > 40) res.trail.shift();
    try { hold ? pressHold(k) : press(k); }
    catch (e) {
      res.errors.push({ msg: String(e && e.message || e), stack: String(e && e.stack || '').split('\n').slice(0,3).join(' | '),
                        key: (hold?'hold:':'')+k, from: before, page: String(page), trail: res.trail.slice(-25) });
      if (res.errors.length > 30) break;
    }
    const p = String(page);
    res.pages[p] = (res.pages[p]||0) + 1;
    const lcd = document.querySelector('.lcd');
    const txt = lcd ? lcd.innerText : '';
    const m = txt.match(bad);
    if (m) res.textBugs.push({ page: p, hit: m[0], snippet: txt.replace(/\s+/g,' ').slice(Math.max(0, m.index-60), m.index+60), trail: res.trail.slice(-20) });
    const scr = document.getElementById('screen');
    if (scr && !scr.innerText.trim() && !scr.querySelector('img,canvas,svg,video')) res.blanks[p] = (res.blanks[p]||0)+1;
    try { if (Array.isArray(history) && history.length > res.maxHist) res.maxHist = history.length; } catch(e) {}
  }
  return res;
}
"""

async def run_seed(browser, seed, agg):
    ctx = await browser.new_context(viewport={'width': 390, 'height': 844})
    pg = await ctx.new_page()
    await pg.clock.install()
    page_errors = []
    pg.on('pageerror', lambda e: page_errors.append(str(e)))
    await pg.goto(URL, wait_until='load')
    rng = random.Random(seed)
    trail = []
    done = 0
    while done < STEPS:
        n = rng.randint(10, 60)
        r = await pg.evaluate(BATCH_JS, [rng.randint(1, 2**31), n, trail])
        trail = r['trail']
        for e in r['errors']: e['seed'] = seed; agg['errors'].append(e)
        for t in r['textBugs']: t['seed'] = seed; agg['textBugs'].append(t)
        for p, c in r['pages'].items(): agg['pages'][p] += c
        for p, c in r['blanks'].items(): agg['blanks'][p] += c
        agg['maxHist'] = max(agg['maxHist'], r['maxHist'])
        if r['errors'] and len(r['errors']) > 30: break
        # let timers (notices, holds, alarms) fire
        await pg.clock.run_for(rng.choice([100, 800, 2500, 6000]))
        done += n
    for e in page_errors:
        agg['timerErrors'].append({'seed': seed, 'msg': e[:300], 'trail': trail[-20:]})
    await ctx.close()

async def main():
    agg = {'errors': [], 'textBugs': [], 'pages': collections.Counter(), 'blanks': collections.Counter(), 'maxHist': 0, 'timerErrors': []}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        sem = asyncio.Semaphore(6)
        async def one(sd):
            async with sem:
                try: await run_seed(b, sd, agg)
                except Exception as ex: agg['timerErrors'].append({'seed': sd, 'msg': 'HARNESS: ' + str(ex)[:300]})
        await asyncio.gather(*(one(sd) for sd in range(SEEDS)))
        await b.close()
    agg['pages'] = dict(agg['pages']); agg['blanks'] = dict(agg['blanks'])
    json.dump(agg, open(OUT, 'w'), indent=1)
    print('distinct pages', len(agg['pages']), 'errors', len(agg['errors']), 'timerErrors', len(agg['timerErrors']),
          'textBugs', len(agg['textBugs']), 'maxHist', agg['maxHist'])
    c = collections.Counter(e['msg'] for e in agg['errors'])
    for m, n in c.most_common(25): print(n, m[:160])
    c2 = collections.Counter((t['page'], t['hit']) for t in agg['textBugs'])
    print('text bugs by page:', c2.most_common(20))
    c3 = collections.Counter(e['msg'][:120] for e in agg['timerErrors'])
    print('timer errors:', c3.most_common(10))

asyncio.run(main())
