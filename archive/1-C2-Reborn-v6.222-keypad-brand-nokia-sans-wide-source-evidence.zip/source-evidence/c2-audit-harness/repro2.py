"""Generate a seeded key sequence, find the first error matching a target, then shrink it. Replays run in one page call each."""
import asyncio, json, sys, random
from playwright.async_api import async_playwright

URL = __import__('os').environ.get('C2_URL','file:///tmp/c2-reborn/index.html')
KEYS = [('OK',14),('DOWN',14),('UP',6),('LEFT',5),('RIGHT',5),('LSK',12),('RSK',8),('CALL',2),('END',2),
        ('1',2),('2',3),('3',2),('4',2),('5',2),('6',2),('7',2),('8',2),('9',2),('0',2),('*',2),('#',2)]

RUN_JS = r"""
([evs, target]) => {
  for (let i = 0; i < evs.length; i++) {
    const ev = evs[i];
    try { if (ev.startsWith('hold:')) pressHold(ev.slice(5)); else press(ev); }
    catch (e) { const m = String(e.message || e); if (!target || m.includes(target)) return {i, m, stack: String(e.stack||'').split('\n').slice(0,4).join(' | ')}; }
  }
  return null;
}
"""

async def main():
    target = sys.argv[1]
    seeds = range(int(sys.argv[2]), int(sys.argv[3]))
    n_events = int(sys.argv[4]) if len(sys.argv) > 4 else 4000
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={'width': 390, 'height': 844})
        pg = await ctx.new_page()
        await pg.goto(URL)
        async def run(evs):
            await pg.evaluate("localStorage.clear()")
            await pg.reload(wait_until='load')
            return await pg.evaluate(RUN_JS, [evs, target])
        for seed in seeds:
            rng = random.Random(seed)
            tot = sum(w for _, w in KEYS)
            def pick():
                r = rng.random() * tot
                for k, w in KEYS:
                    r -= w
                    if r < 0: return k
                return 'OK'
            evs = [('hold:' if rng.random() < 0.04 else '') + pick() for _ in range(n_events)]
            hit = await run(evs)
            if not hit: continue
            evs = evs[:hit['i'] + 1]
            chunk = max(1, len(evs) // 2)
            while chunk >= 1:
                i = 0; changed = False
                while i < len(evs) - 1:
                    cand = evs[:i] + evs[i + chunk:]
                    h = await run(cand)
                    if h: evs = cand[:h['i'] + 1]; changed = True; continue
                    i += chunk
                if not changed: chunk //= 2
            h = await run(evs)
            lcd = await pg.evaluate("String(page)+' :: '+document.querySelector('.lcd').innerText.replace(/\\s+/g,' ').slice(0,200)")
            print(json.dumps({'seed': seed, 'error': h['m'], 'stack': h['stack'], 'minimal': evs, 'state': lcd}), flush=True)
            break
        await b.close()

asyncio.run(main())
