import asyncio, json
from urllib.parse import quote
from playwright.async_api import async_playwright
U='file:///tmp/c2-reborn/'
async def fresh(b, **kw):
    ctx=await b.new_context(viewport=kw.get('vp',{'width':390,'height':844})); pg=await ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    return ctx,pg,errs
async def click(pg,k): await pg.click(f'button[data-k="{k}"]'); await pg.wait_for_timeout(80)
async def lcd(pg): return await pg.evaluate("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')")
async def main():
    R={}
    async with async_playwright() as p:
        b=await p.chromium.launch()
        # 1 soft-lock via clicks
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html')
        for k in ["5","OK","5","LSK","OK","DOWN","LSK","OK","DOWN","OK"]: await click(pg,k)
        saved='Contact details' in await lcd(pg); await click(pg,'RSK'); n=len(errs)
        for k in ['OK','DOWN','LSK']: await click(pg,k)
        R['1 soft-lock']=f"saved={saved} throws_on_back={n>0} msg={errs[0][:60] if errs else None} further_throws={len(errs)-n}"
        await ctx.close()
        # 1b back to blank form
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html')
        for k in ["5","OK","5","OK","RSK"]: await click(pg,k)
        R['1b back->blank form']=(await lcd(pg))[:60]; await ctx.close()
        # 2 XSS
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html?page=calculator&calc='+quote('<img src=x onerror="window.__x=1">')); await pg.wait_for_timeout(300)
        R['2 xss fired']=await pg.evaluate('window.__x===1'); await ctx.close()
        # 3 old build overwrite
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html'); await pg.evaluate("phoneState.templates.push('mine');persist()")
        k1=len(json.loads(await pg.evaluate("localStorage.getItem('c2state')")))
        await pg.goto(U+'2-index.html'); await pg.wait_for_timeout(200)
        for k in ['OK','DOWN','OK','RSK','RSK']:
            try: await pg.evaluate(f"press('{k}')")
            except Exception: pass
        await pg.evaluate("typeof persist==='function'&&persist()")
        k2=len(json.loads(await pg.evaluate("localStorage.getItem('c2state')")))
        await pg.goto(U+'index.html'); kept=await pg.evaluate("phoneState.templates.includes('mine')")
        R['3 old build']=f"fields {k1}->{k2}, template kept={kept}"; await ctx.close()
        # 4 corrupt reset
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html'); await pg.evaluate("phoneState.contacts.push({name:'Keep Me',number:'1'});persist();localStorage.setItem('c2state',localStorage.getItem('c2state').slice(0,-30))")
        await pg.reload(); R['4 corrupt->defaults']=await pg.evaluate("phoneState.contacts.map(c=>c.name).join(',')"); await ctx.close()
        # 5 clipping
        ctx,pg,errs=await fresh(b,vp={'width':360,'height':640}); await pg.goto(U+'index.html'); await pg.wait_for_timeout(200)
        R['5 360x640 # key bottom vs viewport']=await pg.evaluate("Math.round(document.querySelector('button[data-k=\"#\"]').getBoundingClientRect().bottom)+' / '+innerHeight"); await ctx.close()
        # 6 Enter on focused Call
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html'); await pg.keyboard.press('5'); await pg.focus('button[data-k="CALL"]'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(150)
        R['6 Enter on focused Call ->']=await pg.evaluate('String(page)'); await ctx.close()
        # 7 key leak
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html')
        for k in ["5","OK","LSK","OK","5"]: await click(pg,k)
        R['7 leak (Last name has J, submenu open)']=(await lcd(pg))[30:120]; await ctx.close()
        # 8 add detail empty
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html')
        for k in ["RSK","OK","LSK","OK"]: await click(pg,k)
        R['8 contact add detail']=(await lcd(pg))[:50]; await ctx.close()
        # 9 calc
        ctx,pg,errs=await fresh(b); await pg.goto(U+'index.html?page=calculator')
        for k in ['7','RIGHT','0','OK']: await click(pg,k)
        R['9 7/0=']=await pg.evaluate("document.querySelector('.calc').innerText"); await ctx.close()
        await b.close()
    for k,v in R.items(): print(k,'::',v)
asyncio.run(main())
