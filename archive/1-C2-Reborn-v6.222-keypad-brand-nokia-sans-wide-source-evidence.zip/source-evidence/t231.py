import sys
exec(open("/tmp/hdr.py").read())
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
call('Page.navigate',{'url':'file://'+F+'?page=calculator'});time.sleep(1.5)
[ev("press('%s')"%k) for k in ['7','RIGHT','0','OK']];time.sleep(.5)
print(ev("(function(){var l=document.querySelector('.lcd').getBoundingClientRect(),d=document.querySelector('.calcNote'),i=d&&d.querySelector('img');if(!d)return 'none';var a=d.getBoundingClientRect(),b=i.getBoundingClientRect();return JSON.stringify([l.x,l.y,l.width,l.height,a.x,a.y,a.width,a.height,b.x,b.y,b.width,b.height])})()"))
shot('/tmp/o231.png')
