from PIL import Image
import numpy as np
from scipy.ndimage import median_filter,gaussian_filter1d
im=Image.open('/downloads/image-5402b817.jpg').convert('RGB');a=np.array(im).astype(float)
H,W,_=a.shape
# find step row per column: max positive G diff between y 420..480
G=a[:,:,1]
ys=np.arange(425,475)
step_row=np.zeros(W,int);step=np.zeros((W,3))
for x in range(W):
    d=G[ys+3,x]-G[ys-3,x]
    i=d.argmax();step_row[x]=ys[i]
    if d[i]>18:
        y=ys[i];step[x]=a[y+4:y+7,x].mean(0)-a[y-6:y-3,x].mean(0)
valid=(step[:,1]>18)
print(valid.sum(), np.median(step_row[valid]))
yr=int(np.median(step_row[valid]))
# smooth step across columns within valid span
xs=np.where(valid)[0];x0,x1=xs.min(),xs.max();print(x0,x1)
S=step.copy()
for c in range(3):
    S[:,c]=median_filter(S[:,c],size=31);S[:,c]=gaussian_filter1d(S[:,c],6)
out=a.copy()
L=170
for x in range(W):
    if not valid[x]:continue
    y0=step_row[x] if abs(step_row[x]-yr)<8 else yr
    s=S[x]
    for k in range(-6,L):
        y=y0+k
        t=0 if k>=L else (1-k/L) if k>=0 else 0
        if k<0: t=1  # make hard edge region smooth: blend start
        # smoothstep taper
        u=min(max(k/L,0),1);w=1-(3*u*u-2*u**3) if k>=0 else 1
        out[y,x]=a[y,x]-s*w
# smooth the transition right at the line vertically
for x in range(W):
    if valid[x]:
        y0=step_row[x] if abs(step_row[x]-yr)<8 else yr
        seg=out[y0-5:y0+6,x]
        out[y0-5:y0+6,x]=gaussian_filter1d(seg,2,axis=0,mode='nearest')
Image.fromarray(out.clip(0,255).astype('uint8')).save('/tmp/open_clean.png')
