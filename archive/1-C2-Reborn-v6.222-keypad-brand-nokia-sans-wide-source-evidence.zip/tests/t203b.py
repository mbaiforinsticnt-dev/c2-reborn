exec(open("/tmp/hdr.py").read())
fresh2()
print(ev("(()=>{let o=[];for(const p of ['profiles','profilelist','profile']){try{go(p);sel=0;draw();o.push(p+':'+page+':'+document.querySelector('.screen').innerHTML.slice(0,400))}catch(e){o.push(p+' ERR')}}return o.join('\\n')})()"))
