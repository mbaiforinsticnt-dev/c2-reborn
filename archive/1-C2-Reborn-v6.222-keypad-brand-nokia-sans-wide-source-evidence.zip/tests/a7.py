exec(open("/tmp/hdr.py").read())
import json,hashlib
TH=sys.argv[2];LOG=open('/tmp/a7-%s.out'%TH.split('.')[0],'w')
import io,base64
from PIL import Image,ImageStat
def out(*a):
    LOG.write(' '.join(str(x) for x in a)+'\n');LOG.flush()
JS_SEL="""(()=>{let sc=document.querySelector('.screen'),W=sc.getBoundingClientRect().width;
return JSON.stringify([...sc.querySelectorAll('.sel,.focus')].filter(e=>e.getBoundingClientRect().height>6&&e.getBoundingClientRect().height<70).map(e=>({c:e.tagName+'.'+e.className,w:Math.round(e.getBoundingClientRect().width),W:Math.round(W),i:[...e.parentElement.children].indexOf(e),n:e.parentElement.children.length})))})()"""
JS_ARW="""(()=>{let r=[];document.querySelectorAll('.screen *').forEach(e=>{if(e.children.length==0&&e.offsetParent!==null){let t=e.innerText||'';if(/^\\s*[>›▸▶]\\s*$/.test(t)||/\\s[>▸]\\s*$/.test(t))r.push(e.tagName+'.'+e.className+':'+t.trim().slice(-20))}});return JSON.stringify(r)})()"""
JS_SIG="page+'|'+document.querySelector('.lcd').innerText.replace(/\\n/g,'|').slice(0,160)"
seen={}
def replay(path):
    fresh2();ev("document.body.setAttribute('data-theme','%s')"%TH)
    for k in path: S(k)
def labels():
    r=ev("JSON.stringify([...document.querySelectorAll('.soft > *')].map(e=>e.innerText.trim()))")
    try:return json.loads(r)
    except Exception:return None
def probe(path):
    sig=ev(JS_SIG)
    if sig in seen:return None
    seen[sig]=path
    lab=labels();pg=ev('page');r={'path':path,'page':pg,'lab':lab}
    if lab and len(lab)>=3:
        for idx,key in ((0,'LSK'),(1,'OK'),(2,'RSK')):
            replay(path)
            b=ev(JS_SIG);S(key);a=ev(JS_SIG);ap=ev('page')
            r['k'+key]=[lab[idx],ap if a!=b else '=']
            L=lab[idx]
            if L=='Reply' and ap!='compose':r.setdefault('flags',[]).append('Reply-not-compose')
            if L=='Open' and ap=='compose':r.setdefault('flags',[]).append('Open-to-compose')
            if L=='' and a!=b:r.setdefault('flags',[]).append(key+'-empty-label-acts')
            if L in('Options','Back','Exit','Open','Select','Reply','Send') and a==b:r.setdefault('flags',[]).append(key+'-'+L+'-no-effect')
        replay(path)
    out(json.dumps(r,ensure_ascii=False))
    return True
def children(path):
    sel=probe(path)
    return True

cnt_states=0
def explore(path,depth):
    global cnt_states
    cnt_states+=1
    sel=probe(path)
    if sel is None or depth>=4 or cnt_states>260: return
    base=ev(JS_SIG)
    n=ev("(()=>{let e=document.querySelector('.screen .sel,.screen .focus');return e?e.parentElement.children.length:0})()")
    n=min(int(n or 0),12)
    for j in range(n):
        if ev(JS_SIG)!=base:
            replay(path); [S('DOWN') for _ in range(j)]
        S('OK')
        if ev(JS_SIG)!=base:
            explore(path+['DOWN']*j+['OK'],depth+1)
            S('RSK')
            if ev(JS_SIG)!=base: replay(path); [S('DOWN') for _ in range(j)]
        S('DOWN')
replay(['OK'])
explore(['OK'],0)
out('DONE',cnt_states)
