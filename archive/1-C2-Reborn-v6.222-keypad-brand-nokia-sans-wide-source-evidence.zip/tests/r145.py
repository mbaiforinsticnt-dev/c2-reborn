exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','UP','LEFT','OK','OK','DOWN');
print(ev("document.getElementById('screen').innerHTML.replace(/\\s+/g,' ').slice(0,900)"))
