exec(open("/tmp/hdr.py").read())
fresh2()
ev("go('conversation');conversationName='Alex Morgan';sel=0;draw()")
R="""(()=>{let t=document.querySelector('.thread'),b=document.querySelector('.bubble.sel'),sk=document.querySelector('.softkeys,.soft,#soft'),s=document.getElementById('screen');if(!b)return 'nosel';let br=b.getBoundingClientRect(),tr=t.getBoundingClientRect(),sr=s.getBoundingClientRect();let k=document.querySelector('.softbar,.softkeys,.sk,#softkeys');return JSON.stringify({sel:sel,top:Math.round(br.top-sr.top),bot:Math.round(br.bottom-sr.top),h:Math.round(br.height),thTop:Math.round(tr.top-sr.top),thBot:Math.round(tr.bottom-sr.top),scr:Math.round(sr.height),st:t.scrollTop,sh:t.scrollHeight,ch:t.clientHeight})})()"""
for i in range(5):
    print(ev(R)); ev("press('DOWN')")
