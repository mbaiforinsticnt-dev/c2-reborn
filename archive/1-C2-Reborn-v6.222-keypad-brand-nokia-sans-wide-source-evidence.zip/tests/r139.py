exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','UP','OK','OK');print(ev('page'))

for n in (1,2,3,4):
    S('DOWN');time.sleep(.2)
    r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o138-%d.png'%n,'wb').write(base64.b64decode(r['result']['data']))
