exec(open("/tmp/hdr.py").read())
fresh2();print(ev("JSON.stringify(phoneState.calendar)"))
print(ev("calNotesOn.toString().slice(0,200)"))
