exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Light.nth')")
S('OK','OK','DOWN','OK','OK');print(ev('page'))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o137.png','wb').write(base64.b64decode(r['result']['data']))
