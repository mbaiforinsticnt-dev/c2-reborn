exec(open("/tmp/hdr.py").read())
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
for p in ['inbox','conversation']:
    call('Page.navigate',{'url':'file://'+F+'?page='+p});time.sleep(1.5)
    print(p,ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ').slice(0,120)"));shot('/tmp/o230_%s.png'%p)
