exec(open("/tmp/hdr.py").read())
import json,hashlib
TH=sys.argv[2];LOG=open('/tmp/a6-%s.out'%TH.split('.')[0],'w')
import io,base64
from PIL import Image,ImageStat
def out(*a):
    LOG.write(' '.join(str(x) for x in a)+'\n');LOG.flush()
JS_SEL="""(()=>{let sc=document.querySelector('.screen'),W=sc.getBoundingClientRect().width;
return JSON.stringify([...sc.querySelectorAll('.sel,.focus')].filter(e=>e.getBoundingClientRect().height>6&&e.getBoundingClientRect().height<70).map(e=>({c:e.tagName+'.'+e.className,w:Math.round(e.getBoundingClientRect().width),W:Math.round(W),i:[...e.parentElement.children].indexOf(e),n:e.parentElement.children.length})))})()"""
JS_ARW="""(()=>{let r=[];document.querySelectorAll('.screen *').forEach(e=>{if(e.children.length==0&&e.offsetParent!==null){let t=e.innerText||'';if(/^\\s*[>›▸▶]\\s*$/.test(t)||/\\s[>▸]\\s*$/.test(t))r.push(e.tagName+'.'+e.className+':'+t.trim().slice(-20))}});return JSON.stringify(r)})()"""
JS_SIG="page+'|'+document.querySelector('.lcd').innerText.replace(/\\n/g,'|').slice(0,160)"
seen={}
def replay(path):
    fresh2();ev("document.body.setAttribute('data-theme','%s')"%TH)
    for k in path: S(k)
def probe(path):
    sig=ev(JS_SIG)
    if sig in seen: return None
    seen[sig]=path
    r={'path':path,'page':ev('page'),'sig':sig[:90]}
    try:
        info=json.loads(ev("""(()=>{let sc=document.querySelector('.screen');let e=[...sc.querySelectorAll('.sel,.focus')].filter(e=>{let h=e.getBoundingClientRect().height;return h>6&&h<70&&e.parentElement.children.length>1})[0];if(!e)return 'null';let rc=r=>({x:r.left,y:r.top,w:r.width,h:r.height});let sibs=[...e.parentElement.children].filter(x=>x!==e&&x.getBoundingClientRect().height>6&&x.getBoundingClientRect().height<70).map(x=>rc(x.getBoundingClientRect()));return JSON.stringify({f:rc(e.getBoundingClientRect()),s:sibs.slice(0,6),c:getComputedStyle(e).color})})()"""))
    except Exception as ex: info=None
    if info:
        res=call('Page.captureScreenshot',{'format':'png'});im=Image.open(io.BytesIO(base64.b64decode(res['result']['data']))).convert('L')
        def lum(rc):
            x,y,w,h=[int(v) for v in (rc['x'],rc['y'],rc['w'],rc['h'])]
            if w<4 or h<4: return None
            return ImageStat.Stat(im.crop((x+2,y+2,x+w-2,y+h-2))).mean[0]
        fl=lum(info['f']);sl=[v for v in (lum(c) for c in info['s']) if v is not None]
        if fl is not None and sl:
            d=min(abs(fl-v) for v in sl)
            r['fl']=round(fl);r['nb']=round(sum(sl)/len(sl));r['d']=round(d)
            if d<45: r['lowcontrast']=True
    out(json.dumps(r,ensure_ascii=False))
    return True
def children(path):
    sel=probe(path)
    return True

cnt_states=0
def explore(path,depth):
    global cnt_states
    cnt_states+=1
    sel=probe(path)
    if sel is None or depth>=4 or cnt_states>400: return
    base=ev(JS_SIG)
    n=ev("(()=>{let e=document.querySelector('.screen .sel,.screen .focus');return e?e.parentElement.children.length:0})()")
    n=min(int(n or 0),12)
    for j in range(n):
        if ev(JS_SIG)!=base:
            replay(path); [S('DOWN') for _ in range(j)]
        S('OK')
        if ev(JS_SIG)!=base:
            explore(path+['DOWN']*j+['OK'],depth+1)
            S('RSK')
            if ev(JS_SIG)!=base: replay(path); [S('DOWN') for _ in range(j)]
        S('DOWN')
replay(['OK'])
explore(['OK'],0)
out('DONE',cnt_states)
