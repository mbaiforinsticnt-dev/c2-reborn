exec(open("/tmp/hdr.py").read())
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep(.1)
fresh2()
ev("window.__e=[];addEventListener('error',e=>window.__e.push(e.error&&e.error.stack))")
for k in ["5","OK","5","LSK","OK","DOWN","LSK","OK","DOWN","OK","RSK","OK"]:clk(k)
print(ev("window.__e[0]"))
