exec(open("/tmp/hdr.py").read())
import base64,time
out=[]
for th in ('Nokia.nth','Light.nth'):
    fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','%s')"%th)
    S('OK','UP','LEFT','OK','OK','DOWN');print(th,ev('page'))
    time.sleep(.5);r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o144-%s.png'%th[:3],'wb').write(base64.b64decode(r['result']['data']))
