exec(open("/tmp/hdr.py").read())
fresh2()
ev("go('conversation');conversationName='Alex Morgan';sel=0;messageStore.threads.alex[0].text='"+"long text word "*60+"';draw();openMsgIdx=0;go('msgopen');draw()")
q="(()=>{let t=document.querySelector('.msgOpen'),x=document.querySelector('.msgOpenText');return JSON.stringify({page:page,mo:t&&[t.scrollTop,t.scrollHeight,t.clientHeight],tx:x&&[x.scrollTop,x.scrollHeight,x.clientHeight]})})()"
print(ev(q))
for i in range(4):ev("press('DOWN')");time.sleep(.1)
print(ev(q))
