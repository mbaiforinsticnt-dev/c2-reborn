exec(open("/tmp/hdr.py").read())
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
call('Page.navigate',{'url':'file://'+F+'?page=messaging&sel=1'});time.sleep(1.5)
print(ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')"));shot('/tmp/o229.png')
