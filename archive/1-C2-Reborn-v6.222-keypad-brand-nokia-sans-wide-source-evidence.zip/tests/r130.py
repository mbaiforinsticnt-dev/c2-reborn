exec(open("/tmp/hdr.py").read())
fresh2();ev("document.body.setAttribute('data-theme','Nokia.nth')")
ev("profileTonesFor=0;go('profiletones');sel=0;draw();profRowOpen()")
st="JSON.stringify({page:page,sel:sel,opt:radioCtx&&radioCtx.opts[sel],cur:toneCur,aud:!!toneAudio,av:toneAudio&&+toneAudio.volume.toFixed(2),paused:toneAudio&&toneAudio.paused,timer:!!alertTimer})"
print('open',ev(st))
import time
time.sleep(1);print('1s',ev(st))
S('UP');print('Ringing',ev(st))
S('DOWN','DOWN');print('Ring once',ev(st))
S('DOWN');print('Beep once',ev(st))
S('DOWN');print('Off',ev(st))
S('UP','UP','UP');print('Ringing',ev(st));S('DOWN');print('Asc',ev(st));time.sleep(2);print('asc 2s',ev(st));time.sleep(2.5);print('asc 4.5s',ev(st))
S('RSK');print('closed',ev(st))
