exec(open("/tmp/hdr.py").read())
import base64
def shot(n):
    r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o134-%s.png'%n,'wb').write(base64.b64decode(r['result']['data']))
M="JSON.stringify([...document.querySelectorAll('.screen .overlay')].filter(e=>e.getBoundingClientRect().height>20).map(e=>({c:e.className,h:Math.round(e.getBoundingClientRect().height),sh:e.scrollHeight,ch:e.clientHeight,rows:e.querySelectorAll('.opt,.cm').length,bot:Math.round(e.getBoundingClientRect().bottom)})))"
def run(n,keys):
    fresh2();ev("document.body.setAttribute('data-theme','Black.nth')")
    S(*keys);print(n,ev('page'),ev(M));shot(n)
run('notes_usedetail',['OK','UP','OK','DOWN','DOWN','DOWN','DOWN','OK','OK','LSK','DOWN','OK'])
run('notes_opts',['OK','UP','OK','DOWN','DOWN','DOWN','DOWN','OK','OK','LSK'])
run('gal_downloads',['OK','LEFT','OK','OK','OK']+['DOWN']*7+['LSK','OK'])
