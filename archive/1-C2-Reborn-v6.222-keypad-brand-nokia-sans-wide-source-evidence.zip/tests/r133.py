exec(open("/tmp/hdr.py").read())
import base64
def shot(n):
    r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o133-%s.png'%n,'wb').write(base64.b64decode(r['result']['data']))
M="JSON.stringify([...document.querySelectorAll('.screen .overlay,.screen [class*=Panel],.screen [class*=Ov]')].filter(e=>e.getBoundingClientRect().height>20).map(e=>({c:e.className,top:Math.round(e.getBoundingClientRect().top),h:Math.round(e.getBoundingClientRect().height),sh:e.scrollHeight,ch:e.clientHeight,rows:e.querySelectorAll('.opt').length,sk:Math.round(document.querySelector('.soft').getBoundingClientRect().top),bot:Math.round(e.getBoundingClientRect().bottom)})))"
fresh2();ev("document.body.setAttribute('data-theme','Black.nth')")
S('OK','UP','OK','OK','LSK');print('ALARM opts',ev('page'),ev(M));shot('alarmopt')
fresh2();ev("document.body.setAttribute('data-theme','Black.nth')")
S('OK','UP','OK','DOWN','OK','LSK');print('CAL opts',ev('page'),ev(M));shot('calopt')
