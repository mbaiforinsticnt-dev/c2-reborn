exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','OK','OK','OK');print(ev('page'))
S('DOWN');S('LSK');time.sleep(.3)
print(ev("(()=>{let r=[...document.querySelectorAll('.optionsPanel,.submenuPanel,.calMenu')].map(e=>[e.className,e.clientHeight,e.scrollHeight,e.innerText.replace(/\\n/g,'|').slice(0,200)]);return JSON.stringify(r)})()"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o147.png','wb').write(base64.b64decode(r['result']['data']))
