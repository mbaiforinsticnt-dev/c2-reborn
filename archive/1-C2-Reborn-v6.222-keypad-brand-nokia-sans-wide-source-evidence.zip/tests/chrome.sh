pgrep -f remote-debugging-port=9223 >/dev/null || (setsid nohup google-chrome --headless=new --no-sandbox --remote-debugging-port=9223 --remote-allow-origins=* --allow-file-access-from-files --user-data-dir=/tmp/chrprof about:blank >/dev/null 2>&1 &)
sleep 3
