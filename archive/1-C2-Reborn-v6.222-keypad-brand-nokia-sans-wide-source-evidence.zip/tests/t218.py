exec(open("/tmp/hdr.py").read())
fresh2()
ev("go('conversation');conversationName='Alex Morgan';sel=0;convScroll=0;draw()");shot('/tmp/o218a.png')
