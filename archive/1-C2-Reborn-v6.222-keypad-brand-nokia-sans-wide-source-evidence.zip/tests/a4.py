exec(open("/tmp/hdr.py").read())
import json,hashlib
LOG=open('/tmp/a3.out','w')
def out(*a):
    LOG.write(' '.join(str(x) for x in a)+'\n');LOG.flush()
JS_SEL="""(()=>{let sc=document.querySelector('.screen'),W=sc.getBoundingClientRect().width;
return JSON.stringify([...sc.querySelectorAll('.sel,.focus')].filter(e=>e.getBoundingClientRect().height>6&&e.getBoundingClientRect().height<70).map(e=>({c:e.tagName+'.'+e.className,w:Math.round(e.getBoundingClientRect().width),W:Math.round(W),i:[...e.parentElement.children].indexOf(e),n:e.parentElement.children.length})))})()"""
JS_ARW="""(()=>{let r=[];document.querySelectorAll('.screen *').forEach(e=>{if(e.children.length==0&&e.offsetParent!==null){let t=e.innerText||'';if(/^\\s*[>›▸▶]\\s*$/.test(t)||/\\s[>▸]\\s*$/.test(t))r.push(e.tagName+'.'+e.className+':'+t.trim().slice(-20))}});return JSON.stringify(r)})()"""
JS_SIG="page+'|'+document.querySelector('.lcd').innerText.replace(/\\n/g,'|').slice(0,160)"
seen={}
def replay(path):
    fresh2()
    for k in path: S(k)
def probe(path):
    sig=ev(JS_SIG)
    if sig in seen: return None
    seen[sig]=path
    r={'path':path,'page':ev('page'),'sig':sig[:90]}
    try:
        sel=json.loads(ev(JS_SEL))
    except Exception as e: sel=[]
    narrow=[s for s in sel if s['w']<0.8*s['W'] and s['n']>1 and not s['c'].startswith('DIV.cell')]
    if narrow: r['narrow']=narrow[:3]
    try: a=json.loads(ev(JS_ARW))
    except Exception: a=[]
    if a: r['arrow']=a[:4]
    # options
    try:
        sk=ev("[...document.querySelectorAll('.soft b,.soft span,.soft div')].map(e=>e.innerText).join('|')")
    except Exception: sk=''
    r['soft']=str(sk)[:60]
    # wrap check
    if sel and sel[0]['n']>2:
        s0=sel[0]
        S('UP');a1=json.loads(ev(JS_SEL));i1=a1[0]['i'] if a1 else None
        if s0['i']==0 and i1==0 and ev('page')==r['page']: r['nowrap_up']=True
        replay(path)
    out(json.dumps(r,ensure_ascii=False))
    return sel
def children(path):
    sel=probe(path)
    return sel

cnt_states=0
def explore(path,depth):
    global cnt_states
    cnt_states+=1
    sel=probe(path)
    if sel is None or depth>=4 or cnt_states>400: return
    base=ev(JS_SIG)
    n=ev("(()=>{let e=document.querySelector('.screen .sel,.screen .focus');return e?e.parentElement.children.length:0})()")
    n=min(int(n or 0),12)
    for j in range(n):
        if ev(JS_SIG)!=base:
            replay(path); [S('DOWN') for _ in range(j)]
        S('OK')
        if ev(JS_SIG)!=base:
            explore(path+['DOWN']*j+['OK'],depth+1)
            S('RSK')
            if ev(JS_SIG)!=base: replay(path); [S('DOWN') for _ in range(j)]
        S('DOWN')
replay(['OK'])
explore(['OK'],0)
out('DONE',cnt_states)
