exec(open("/tmp/hdr.py").read())
fresh2()
ev("go('gallery');sel=0;draw()");shot('/tmp/o208.png');print(ev(T)[:60])
ev("sel=1;draw()");shot('/tmp/o208b.png')
