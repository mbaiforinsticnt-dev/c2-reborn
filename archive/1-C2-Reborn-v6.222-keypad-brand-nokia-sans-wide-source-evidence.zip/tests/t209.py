exec(open("/tmp/hdr.py").read())
fresh2()
for th in ['Nokia.nth','Light.nth','Black.nth']:
    ev("document.body.setAttribute('data-theme','%s')"%th)
    ev("go('inbox');sel=0;draw()");print(th,ev("page"),ev("document.querySelectorAll('.messageRow img.mailGlyph').length"));shot('/tmp/o209-%s.png'%th.split('.')[0])
