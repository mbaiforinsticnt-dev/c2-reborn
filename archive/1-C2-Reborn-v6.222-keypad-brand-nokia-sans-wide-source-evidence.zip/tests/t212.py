exec(open("/tmp/hdr.py").read())
fresh2()
print(ev("(()=>{let s=document.getElementById('screen');let o=[];s.parentElement.querySelectorAll('*').forEach(e=>{let r=e.getBoundingClientRect(),sr=s.getBoundingClientRect();if(r.bottom>sr.bottom-40&&r.height<60&&r.height>10&&r.width>100)o.push(e.tagName+'.'+e.className+'#'+e.id+' '+Math.round(r.top-sr.top)+'-'+Math.round(r.bottom-sr.top))});return o.slice(0,8).join(' | ')})()"))
