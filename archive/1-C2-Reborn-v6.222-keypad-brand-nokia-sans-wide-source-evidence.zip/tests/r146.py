exec(open("/tmp/hdr.py").read())
import base64,time
out=[]
for th in ('Nokia.nth','Light.nth'):
    fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','%s')"%th)
    S('OK','UP','LEFT','OK','OK','DOWN');print(th,ev('page'))
    print(ev("(()=>{let f=document.querySelector('.namesRow.picked');let c=getComputedStyle(f);return c.backgroundImage.slice(0,80)+' '+c.color+' '+document.body.getAttribute('data-theme')})()"));r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o144-%s.png'%th[:3],'wb').write(base64.b64decode(r['result']['data']))
