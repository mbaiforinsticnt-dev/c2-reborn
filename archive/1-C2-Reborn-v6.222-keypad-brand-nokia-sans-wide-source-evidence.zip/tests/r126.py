exec(open("/tmp/hdr.py").read())
import base64
th=sys.argv[2] if len(sys.argv)>2 else 'Light.nth'
fresh2();ev("document.body.setAttribute('data-theme','%s')"%th)
ev("profileTonesFor=0;go('profiletones');sel=0;draw()");ev('sel=0;profRowOpen()');S('DOWN','DOWN')
print(ev('page'))
print(ev("[...document.querySelectorAll('.screen .row,.screen .opt,.screen [class*=radio]')].slice(0,12).map(e=>e.tagName+'.'+e.className+' bg='+getComputedStyle(e).backgroundColor+' bi='+getComputedStyle(e).backgroundImage.slice(0,40)+' c='+getComputedStyle(e).color).join('\\n')"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o126-%s.png'%th.split('.')[0],'wb').write(base64.b64decode(r['result']['data']))
