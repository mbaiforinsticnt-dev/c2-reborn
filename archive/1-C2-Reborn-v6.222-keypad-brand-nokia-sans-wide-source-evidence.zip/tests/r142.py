exec(open("/tmp/hdr.py").read())
import base64,time
call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False});fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','UP','OK','OK');print(ev('page'))

M="(()=>{let w=document.querySelector('.alarmWrap,.nfWrap');let r=w.getBoundingClientRect();let sk=document.querySelector('.soft');let sr=sk&&sk.getBoundingClientRect();let sc=document.getElementById('screen').getBoundingClientRect();let last=[...w.querySelectorAll('.alarmField,.nfBox,.cal-field,div')].pop();return JSON.stringify({wtop:r.top,wb:r.bottom,sktop:sr&&sr.top,scb:sc.bottom,ch:w.clientHeight,sh:w.scrollHeight})})()"
print(ev(M))
for n in range(4):
    S('DOWN');print(ev(M))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o142.png','wb').write(base64.b64decode(r['result']['data']))
