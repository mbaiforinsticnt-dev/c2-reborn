exec(open("/tmp/hdr.py").read())
fresh2()
for (w,hh) in [(420,900),(360,640),(390,780),(1280,720)]:
    call('Emulation.setDeviceMetricsOverride',{'width':w,'height':hh,'deviceScaleFactor':1,'mobile':w<500})
    for th in ['Nokia.nth','Light.nth']:
        ev("document.body.setAttribute('data-theme','%s')"%th)
        ev("go('conversation');conversationName='Alex Morgan';sel=0;convScroll=0;messageStore.threads.alex.push({id:'long1',icon:'read',dir:'in',number:'1',date:'01-01-2026',time:'10:00',text:'"+"long text word "*60+"'});draw()")
        bad=[]
        n=ev("threadMessages().length")
        for i in range(n+1):
            r=ev("""(()=>{let b=document.querySelector('.bubble.sel'),sf=document.querySelector('.soft'),s=document.getElementById('screen');let br=b.getBoundingClientRect(),sr=s.getBoundingClientRect(),f=sf.getBoundingClientRect();let lim=Math.min(sr.bottom,f.top>sr.top?f.top:sr.bottom);return [sel,Math.round(br.top),Math.round(br.bottom),Math.round(lim),Math.round(br.height)]})()""")
            if r[2]>r[3]+1: bad.append(r)
            ev("press('DOWN')");time.sleep(0.12)
        print(w,hh,th,'n=',n,'bad',bad)
        ev("messageStore.threads.alex.pop()")
