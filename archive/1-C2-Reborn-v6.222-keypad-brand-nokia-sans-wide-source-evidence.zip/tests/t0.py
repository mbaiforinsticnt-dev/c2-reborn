exec(open('/tmp/hdr.py').read())
fresh2();print(ev('page'),ev("document.body.innerText.match(/C2 Reborn v[0-9.]+/)&&document.body.innerText.match(/C2 Reborn v[0-9.]+/)[0]"))
S('OK','OK');print(ev('page'))
