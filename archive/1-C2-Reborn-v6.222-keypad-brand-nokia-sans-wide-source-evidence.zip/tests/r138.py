exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','UP','OK','OK');print(ev('page'))
for n in range(6):
    print(n,ev("(()=>{let s=document.getElementById('screen');let r=s.getBoundingClientRect();let f=s.querySelector('.focus,.sel,.fsel,.cur');return JSON.stringify({f:alarmFocus,sh:s.scrollHeight,ch:s.clientHeight,st:s.scrollTop,ftop:f&&Math.round(f.getBoundingClientRect().top-r.top),fb:f&&Math.round(f.getBoundingClientRect().bottom-r.top),cls:f&&f.className,rh:r.height})})()"))
    S('DOWN')
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o138.png','wb').write(base64.b64decode(r['result']['data']))
