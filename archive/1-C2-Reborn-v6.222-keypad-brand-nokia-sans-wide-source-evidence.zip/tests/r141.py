exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','UP','OK','OK');print(ev('page'))

print(ev("(()=>{let w=document.querySelector('.alarmWrap');let c=getComputedStyle(w);return JSON.stringify({ch:w.clientHeight,sh:w.scrollHeight,st:w.scrollTop,h:c.height,mh:c.maxHeight,bg:c.background.slice(0,60),ov:c.overflow})})()"))
S('DOWN','DOWN','DOWN')
print(ev("(()=>{let w=document.querySelector('.alarmWrap');return JSON.stringify({ch:w.clientHeight,sh:w.scrollHeight,st:w.scrollTop})})()"))
