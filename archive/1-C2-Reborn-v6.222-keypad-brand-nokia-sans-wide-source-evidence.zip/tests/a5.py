exec(open("/tmp/hdr.py").read())
import json
LOG=open('/tmp/a5.out','w')
rows=[json.loads(l) for l in open('/tmp/a3.out') if l.startswith('{')]
JS="""(()=>{let p=document.querySelector('.optionsPanel,.submenuPanel');if(!p)return JSON.stringify({none:1,page:page});let r=p.getBoundingClientRect(),o=[...p.querySelectorAll('.opt')],sc=document.querySelector('.screen').getBoundingClientRect(),sk=document.querySelector('.soft').getBoundingClientRect();
let last=o.length?o[o.length-1].getBoundingClientRect():r;let sel=p.querySelector('.opt.sel');let sr=sel?sel.getBoundingClientRect():null;
return JSON.stringify({page:page,n:o.length,h:Math.round(r.height),rowsH:Math.round(o.reduce((a,e)=>a+e.getBoundingClientRect().height,0)),gap:Math.round(r.bottom-last.bottom),bot:Math.round(r.bottom),sk:Math.round(sk.top),top:Math.round(r.top),scTop:Math.round(sc.top),selFull:sr?Math.round(sr.width)+'/'+Math.round(r.width):null,txt:[...o].filter(e=>/[>▸›]/.test(e.innerText)&&!e.classList.contains('hasSub')).map(e=>e.innerText).slice(0,3),sc:p.scrollHeight>p.clientHeight+1})})()"""
n=0
for r in rows:
    if 'Options' not in r.get('soft',''): continue
    fresh2()
    for k in r['path']: S(k)
    S('LSK') if r['soft'].split('|')[0]=='Options' else S('RSK')
    try: d=json.loads(ev(JS))
    except Exception as e: d={'err':str(e)}
    d['path']=r['path'];d['from']=r['page']
    LOG.write(json.dumps(d,ensure_ascii=False)+'\n');LOG.flush();n+=1
LOG.write('DONE %d\n'%n)
