exec(open("/tmp/hdr.py").read())
import base64,time
fresh2();time.sleep(1.5);ev("document.body.setAttribute('data-theme','Nokia.nth')")
S('OK','UP','OK','OK');print(ev('page'))

print(ev("document.getElementById('screen').innerHTML.replace(/\s+/g,' ').slice(0,1800)"))
print(ev("JSON.stringify([...document.querySelectorAll('#screen *')].filter(e=>e.children.length>1).slice(0,6).map(e=>[e.tagName,e.className,Math.round(e.getBoundingClientRect().top),Math.round(e.getBoundingClientRect().bottom),getComputedStyle(e).overflow]))"))
