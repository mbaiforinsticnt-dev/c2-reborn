exec(open("/tmp/hdr.py").read())
import json
def lcd():return ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')")
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep(.1)
def errs():
    return ev("window.__errs||[]")
fresh2()
ev("window.__errs=[];addEventListener('error',e=>window.__errs.push(e.message))")
# 1 soft-lock
for k in ["5","OK","5","LSK","OK","DOWN","LSK","OK","DOWN","OK"]:clk(k)
print('1 saved',('Contact details' in lcd()),lcd()[:80])
clk('RSK')
for k in ['OK','DOWN','LSK']:clk(k)
print('1 errs',errs(),lcd()[:80])
fresh2()
for k in ["5","OK","5","OK","RSK"]:clk(k)
print('1b',lcd()[:70])
# 2 xss
import urllib.parse
call('Page.navigate',{'url':'file://'+F+'?page=calculator&calc='+urllib.parse.quote('<img src=x onerror="window.__x=1">')});time.sleep(1.5)
print('2 xss',ev("window.__x===1"))
# 4 corrupt
fresh2()
ev("phoneState.contacts.push({name:'Keep Me',number:'1'});persist();localStorage.setItem('c2state',localStorage.getItem('c2state').slice(0,-30))")
call('Page.navigate',{'url':'file://'+F});time.sleep(1.5)
print('4',ev("phoneState.contacts.map(c=>c.name).join(',')"))
# 6 enter on call
fresh2();S('5')
print('6 page before',ev("String(page)"))
# 7 leak
fresh2()
for k in ["5","OK","LSK","OK","5"]:clk(k)
print('7',lcd()[30:120])
# 8
fresh2()
for k in ["RSK","OK","LSK","OK"]:clk(k)
print('8',lcd()[:60])
# 9
call('Page.navigate',{'url':'file://'+F+'?page=calculator'});time.sleep(1.5)
for k in ['7','RIGHT','0','OK']:clk(k)
print('9',ev("document.querySelector('.calc').innerText"))
