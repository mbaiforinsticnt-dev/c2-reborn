import sys,json,time,subprocess,urllib.request,websocket,base64
F=sys.argv[1] if len(sys.argv)>1 else '/tmp/c2-v6201-live.html'
if not F.startswith('/'):F='/tmp/'+F
def _tab():
    for _ in range(20):
        try:
            t=json.load(urllib.request.urlopen('http://localhost:9223/json'))
            p=[x for x in t if x['type']=='page']
            if p:return p[0]['webSocketDebuggerUrl']
        except Exception:time.sleep(.5)
    raise SystemExit('no chrome')
_ws=websocket.create_connection(_tab(),max_size=None)
_id=[0]
def call(m,p=None):
    _id[0]+=1;_ws.send(json.dumps({'id':_id[0],'method':m,'params':p or {}}))
    while True:
        r=json.loads(_ws.recv())
        if r.get('id')==_id[0]:return r
def ev(js):
    r=call('Runtime.evaluate',{'expression':js,'returnByValue':True,'awaitPromise':True})
    r=r.get('result',{})
    if 'exceptionDetails' in r:return str(r['exceptionDetails'])[:300]
    return r.get('result',{}).get('value')
def fresh2():
    call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
    call('Page.navigate',{'url':'file://'+F});time.sleep(1.2)
    ev("localStorage.clear()");call('Page.navigate',{'url':'file://'+F});time.sleep(1.5)
    for _ in range(30):
        if ev("typeof press==='function'&&typeof phoneState!=='undefined'")is True:break
        time.sleep(.3)
    ev("try{history_clear&&0}catch(e){}")
def safe(k):
    return ev("(()=>{try{press(%s);return 'ok'}catch(e){return 'ERR '+e.message}})()"%json.dumps(k))
def S(*ks):
    for k in ks:safe(k)
T="document.querySelector('.lcd').innerText.replace(/\\n/g,'|')"
def shot(path):
    r=call('Page.captureScreenshot',{'format':'png'});open(path,'wb').write(base64.b64decode(r['result']['data']))
def lcdshot(path):
    r=json.loads(ev("(()=>{let b=document.querySelector('.lcd').getBoundingClientRect();return JSON.stringify([b.x,b.y,b.width,b.height])})()"))
    s=call('Page.captureScreenshot',{'format':'png','clip':{'x':r[0],'y':r[1],'width':r[2],'height':r[3],'scale':2}});open(path,'wb').write(base64.b64decode(s['result']['data']))
