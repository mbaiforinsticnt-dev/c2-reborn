exec(open("/tmp/hdr.py").read())
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep(.1)
fresh2()
for k in ["5","OK","5","LSK","OK","DOWN","LSK","OK","DOWN","OK"]:
    clk(k);print(k,ev("String(page)+' cf='+contactField+' '+typeof CF_KEYS[contactField]"), ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ').slice(6,60)"))
clk('RSK');print(ev("String(page)+' cf='+contactField"))
