exec(open("/tmp/hdr.py").read())
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep(.1)
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
call('Page.navigate',{'url':'file://'+F+'?page=calculator'});time.sleep(1.5)
for k in ['7','RIGHT','0','OK']:clk(k)
print(ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')"));shot('/tmp/o222.png')
clk('5');print(ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')"))
