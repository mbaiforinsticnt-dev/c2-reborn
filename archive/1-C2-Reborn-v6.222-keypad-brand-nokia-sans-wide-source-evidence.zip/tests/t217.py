exec(open("/tmp/hdr.py").read())
fresh2()
ev("go('conversation');conversationName='Alex Morgan';sel=3;draw()")
print(ev("messageStore.threads.alex.map(m=>m.icon+m.dir).join(',')"))
for th in ['Nokia.nth','Light.nth']:
    ev("document.body.setAttribute('data-theme','%s')"%th);ev("draw()");shot('/tmp/o217-%s.png'%th.split('.')[0])
