exec(open("/tmp/hdr.py").read())
fresh2()
ev("messageStore.inbox[0].body='"+"long text word "*60+"';go('inbox');sel=0;draw();press('OK');draw()")
q="(()=>{let o=[...document.querySelectorAll('#screen *')].filter(e=>e.scrollHeight>e.clientHeight+4&&getComputedStyle(e).overflowY!='visible').map(e=>e.className+':'+e.scrollTop+'/'+e.scrollHeight+'/'+e.clientHeight);return page+' '+o.join(' ; ')})()"
print(ev(q))
for i in range(4):ev("press('DOWN')");time.sleep(.1)
print(ev(q))
