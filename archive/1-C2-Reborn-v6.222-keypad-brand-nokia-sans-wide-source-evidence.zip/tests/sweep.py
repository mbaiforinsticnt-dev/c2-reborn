import re,base64,io,glob,os,sys
from PIL import Image
import numpy as np
h=open(sys.argv[1]).read()
items=[]
for m in re.finditer(r"([A-Za-z_][\w\.]*|\"[\w]+\")\s*[:=]\s*(['\"])data:image/png;base64,([A-Za-z0-9+/=]+)\2",h):
    items.append((m.group(1).strip('"'),m.group(3)))
print(len(items),'named data PNGs')
fw={}
for f in glob.glob('/tmp/fw/png/*.png'):
    im=Image.open(f).convert('RGBA');fw[os.path.basename(f)[:4]]=im
def prep(im,size):
    r=im.resize(size,Image.LANCZOS);bg=Image.new('RGBA',size,(128,128,128,255));bg.alpha_composite(r);return np.asarray(bg.convert('RGB'),dtype=float)
rows=[]
seen={}
for n,b in items:
    key=b[:200]+str(len(b))
    raw=base64.b64decode(b);im=Image.open(io.BytesIO(raw)).convert('RGBA')
    if im.size[0]>120:continue
    a=prep(im,(32,32));best=(1e9,None)
    for k,f in fw.items():
        if max(f.size)>120:continue
        d=np.abs(a-prep(f,(32,32))).mean()
        if d<best[0]:best=(d,k)
    rows.append((n,im.size,round(best[0],1),best[1]))
rows.sort(key=lambda r:-r[2])
for r in rows:print(r)
