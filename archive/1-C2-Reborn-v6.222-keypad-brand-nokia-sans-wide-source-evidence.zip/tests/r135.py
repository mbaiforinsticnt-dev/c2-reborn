exec(open("/tmp/hdr.py").read())
import base64
def shot(n):
    r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o135-%s.png'%n,'wb').write(base64.b64decode(r['result']['data']))
fresh2();ev("document.body.setAttribute('data-theme','Black.nth')")
S('OK','UP','OK','DOWN','OK','LSK','OK','OK');print(ev('page'));F="JSON.stringify({f:calNoteFocus,page:page})"
print('start',ev(F));S('UP');print('UP',ev(F));shot('up')
for n in range(9): S('DOWN')
print('DOWN x9',ev(F));shot('down')
fresh2();ev("document.body.setAttribute('data-theme','Black.nth')")
S('OK','UP','OK','OK');print(ev('page'));F="JSON.stringify({f:alarmFocus,page:page})"
print('alarm start',ev(F));S('UP');print('UP',ev(F))
S('DOWN');print('DOWN',ev(F))
for n in range(3): S('DOWN')
print('4 down',ev(F));shot('alarm_snooze')
