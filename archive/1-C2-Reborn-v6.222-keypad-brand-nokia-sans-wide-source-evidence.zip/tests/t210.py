exec(open("/tmp/hdr.py").read())
fresh2()
ev("messageStore.inbox[1].unread=true;messageStore.inbox[2].unread=true;go('inbox');sel=0;draw()")
for th in ['Nokia.nth','Light.nth']:
    ev("document.body.setAttribute('data-theme','%s')"%th);ev("draw()");shot('/tmp/o210-%s.png'%th.split('.')[0])
ev("sel=1;draw()");shot('/tmp/o210-sel.png')
