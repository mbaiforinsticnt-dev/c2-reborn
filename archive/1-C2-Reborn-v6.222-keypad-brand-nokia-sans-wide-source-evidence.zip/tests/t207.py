exec(open("/tmp/hdr.py").read())
fresh2()
ev("go('gallery');sel=2;draw()")
ev("pressHold('#')");print(ev(T)[-80:]);shot('/tmp/o207.png')
S('DOWN');S('DOWN');print(ev('galHs'));S('OK');print(ev('page'),ev('galDialog'))
ev("go('gallery');draw()");ev("pressHold('#')");S('RSK');print(ev('galDialog'));
ev("pressHold('#')");S('UP');S('OK');print(ev('page'),ev('inputMode'))
