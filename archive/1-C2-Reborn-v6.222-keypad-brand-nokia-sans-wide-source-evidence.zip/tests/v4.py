exec(open("/tmp/hdr.py").read())
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep(.1)
fresh2()
for k in ["RSK","OK","LSK","OK"]:
    clk(k);print(k,ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')"))
