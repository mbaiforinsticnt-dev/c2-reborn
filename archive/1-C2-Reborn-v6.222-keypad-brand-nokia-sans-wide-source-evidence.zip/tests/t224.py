exec(open("/tmp/hdr.py").read())
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep=time.sleep
    time.sleep(.12)
def L():return ev("document.querySelector('.lcd').innerText.replace(/\\s+/g,' ')")
fresh2()
ev("window.__e=[];addEventListener('error',e=>window.__e.push(e.message))")
for k in ["RSK","OK","LSK","OK"]:clk(k)
print(L());shot('/tmp/o224a.png')
clk('OK');print(L());shot('/tmp/o224b.png')
clk('DOWN');clk('OK');print(L())
for k in ['OK']:clk(k)
print(L()); print(ev("window.__e"))
