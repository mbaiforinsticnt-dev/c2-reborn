exec(open("/tmp/hdr.py").read())
import base64
fresh2();ev("document.body.setAttribute('data-theme','Nokia.nth')")
ev("go('themeselect');sel=2;draw()")
print(ev("[...document.querySelectorAll('.screen .sel,.screen .focus')].map(e=>e.tagName+'.'+e.className+' bg='+getComputedStyle(e).backgroundColor+'|'+getComputedStyle(e).backgroundImage.slice(0,60)+' c='+getComputedStyle(e).color+' h='+e.getBoundingClientRect().height).join('\\n')"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o127a.png','wb').write(base64.b64decode(r['result']['data']))
ev("go('drafts');sel=0;draw()")
print(ev("[...document.querySelectorAll('.screen .sel,.screen .focus')].map(e=>e.tagName+'.'+e.className+' bg='+getComputedStyle(e).backgroundColor+'|'+getComputedStyle(e).backgroundImage.slice(0,60)+' c='+getComputedStyle(e).color+' h='+e.getBoundingClientRect().height).join('\\n')"))
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o127b.png','wb').write(base64.b64decode(r['result']['data']))
