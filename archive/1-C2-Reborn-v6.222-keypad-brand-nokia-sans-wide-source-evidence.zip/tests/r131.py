exec(open("/tmp/hdr.py").read())
import base64
def shot(n):
    r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o131-%s.png'%n,'wb').write(base64.b64decode(r['result']['data']))
def st(): return ev("JSON.stringify({page:page,sel:sel,n:(document.querySelectorAll('.screen .sel,.screen .focus')||[]).length,t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|').slice(0,200)})")
# calendar day view
fresh2();ev("document.body.setAttribute('data-theme','Black.nth')")
ev("['Lunch with Sam|12:00','Dentist|15:00','Bins out|20:00'].forEach(x=>{let a=x.split('|');phoneState.calendar.push({type:'Reminder',date:'05-10-2026',time:a[1],alarm:false,repeat:'Never',text:a[0]})})");S('OK','UP','OK','DOWN','OK');print('CAL',st())
S('OK');print('after OK',st());shot('cal_ok')
S('DOWN');print('after DOWN',st());shot('cal_down');S('DOWN','DOWN','DOWN');print('DOWN x4 total',st());S('UP');print('UP',st())
