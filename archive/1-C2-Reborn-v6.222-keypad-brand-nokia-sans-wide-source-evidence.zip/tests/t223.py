exec(open("/tmp/hdr.py").read())
import sys
def clk(k):
    ev("document.querySelector('button[data-k=\"%s\"]').click()"%k);time.sleep(.1)
for th in ['Nokia','Light','Black','Dark']:
    call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
    call('Page.navigate',{'url':'file://'+F+'?page=calculator'});time.sleep(1.2)
    print(th,ev("(()=>{try{phoneState.theme=%r+'.nth';persist();return 'ok'}catch(e){return e.message}})()"%(th)))
    call('Page.navigate',{'url':'file://'+F+'?page=calculator'});time.sleep(1.2)
    for k in ['7','RIGHT','0','OK']:clk(k)
    print(ev("document.body.dataset.theme"));shot('/tmp/th_%s.png'%th)
