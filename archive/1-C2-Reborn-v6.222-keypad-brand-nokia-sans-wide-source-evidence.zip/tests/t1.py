exec(open('/tmp/hdr.py').read())
OV="JSON.stringify([...document.querySelectorAll('.optionsPanel,.submenuPanel')].map(e=>{let r=e.getBoundingClientRect(),k=document.querySelector('.soft').getBoundingClientRect();return [e.className.slice(0,28),Math.round(r.bottom-k.top)]}))"
def go(th,*ks):
    fresh2();ev("document.body.setAttribute('data-theme','%s')"%th);S(*ks)
go('Nokia.nth','OK','OK','DOWN','OK','LSK','DOWN','DOWN','DOWN','DOWN','DOWN','OK');print('mark',ev(OV));lcdshot('/tmp/t1a.png')
for th in ('Black.nth','Dark.nth','Light.nth','Nokia.nth'):
    go(th,'OK','LSK','OK');print(th,ev("JSON.stringify([...document.querySelectorAll('.optionsPanel .opt')].map(e=>getComputedStyle(e).color))"));lcdshot('/tmp/t1-%s.png'%th[:3])
