exec(open("/tmp/hdr.py").read())
call('Page.enable');call('Emulation.setDeviceMetricsOverride',{'width':420,'height':900,'deviceScaleFactor':1,'mobile':False})
call('Page.navigate',{'url':'file://'+F+'?page=galpicker&sel=6'});time.sleep(1.5);shot('/tmp/o226.png')
