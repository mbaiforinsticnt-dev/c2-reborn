Emulator recipe (stock S40 6th SDK) 5 Oct:
- /tmp/emu/x = unshield-extracted SDK; copied to C:\Nokia\Devices\S40_6th_Edition_SDK; JRE7 at C:\jre6 (reg JavaHome fixed); vcredist installed; NCF installed.
- Launch: cd bin; wine cmd /c 'set PATH=C:\jre6\bin;%PATH%&& S40_6th_Edition_SDK_em.exe'; dismiss Error + Preferences via xdotool key --window <id> Return (mouse clicks fail).
- Problem: launcher exits after Prefs, log says "Connection Terminated"; phone window never appears.
- Firmware graphics are in bin/Resources/Packages/package_c.bin (no loose PNGs).
Moti 10:15 permits cropping from his emulator screenshots (tick + Go to profile icons); show crop vs his reference before publishing; tell him it is a crop.
Crops in /tmp/crops (tick_tight.png from image-4fd8f09f, 98x96; prof_pink_tight.png from image-3ae0ae4f). Other profile icons (My style 2/1, Outdoor, Meeting, Silent) crop from image-8104dc8e (scale 921/719=1.281 vs displayed).
10:16: crops saved /tmp/crops/ic_{s2,s1,out,meet,sil}.png (110x110 incl. wallpaper), prof_a.png (Profiles pink), tick_tight.png. Next: round-mask the icons (circle ~ 70px), wire into Go to list rows (Profiles pink, My style 2 dark, My style 1 red, Outdoor green, Meeting blue, Silent white) + replace tick; check Settings>Profiles rows stay plain.
