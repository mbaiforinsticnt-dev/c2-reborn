exec(open("/tmp/hdr.py").read())
import base64
fresh2();ev("document.body.setAttribute('data-theme','Nokia.nth')");S('RSK','LSK','DOWN','DOWN')
r=call('Page.captureScreenshot',{'format':'png'});open('/tmp/o125.png','wb').write(base64.b64decode(r['result']['data']))
