# C2 Reborn v6.199 - source evidence

On top of v6.198:
1. Stopwatch lists (times, saved times): Up on the first row goes to the last, Down on the last goes to the first.
2. Conversations list: same wrap (it used to stop at the ends).
3. Every "Option >" and "Option ▸" label in Options and sub-menu panels shows the arrow image (previously only ">").
4. Gallery editor text/layer option rows: the "›" character is replaced by the arrow image.

Audit by behaviour (crawl-261-screens.jsonl, a3/a4.py): 261 distinct screens reached by opening list rows to depth 4. Checks per screen: focused-row width vs screen, leftover text arrows, Up wrap from the first row. Results: 0 narrow focused rows, wrap failures on Conversations (fixed), Themes list (flagged by the crawler; its code already wraps, see report), text arrows only on value pickers (‹ › ◀ ▶) which change a value rather than open a list, so they were left.
Options panels (options-panels-88.jsonl, a5.py): 82 of 88 measured with panel height equal to row heights and no gap above the softkey bar; 6 are alarm and calendar menus using their own overlay, not measured.

Arrow images: Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead), chosen and downloaded by Moti; author not recorded; Flaticon free licence requires attribution to the author and Flaticon.

Not done: radio-list focus contrast, tone/volume previews, alarm popup layout, depth >4 screens, the 6 alarm/calendar Options menus.
