exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.107-call-divert-number-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['dialled','received','missed','allcalls']:
 ev("phoneState=migrateState(null);phoneState.calls={dialled:[],received:[],missed:[]};let key="+json.dumps('dialled' if mode=='allcalls' else mode)+";phoneState.calls[key]=[{number:'+44 7700 900888',time:'Delete'},{number:'+44 7700 900999',time:'Keep'}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps(mode)+";sel=0;callDeletePending={list:key,record:phoneState.calls[key][0]};pendingBefore=callDeletePending;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' selection pending retained',"return page==="+json.dumps(mode)+"&&sel===0&&callDeletePending===pendingBefore&&phoneState.calls[callDeletePending.list][0]===callDeletePending.record")
 t(mode+' warning visible',"return notice==='Unable to delete call'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='dialled':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v652-call-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect="phoneState.calls["+json.dumps('dialled' if mode=='allcalls' else mode)+"].length===1&&phoneState.calls["+json.dumps('dialled' if mode=='allcalls' else mode)+"][0].number==='+44 7700 900999'"
 t(mode+' retry intended deletion once',"return "+expect+"&&!callDeletePending")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
