exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.107-call-divert-number-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for existing in [False,True]:
 for mode in ['split','lap']:
  ev("phoneState=migrateState(null);"+("phoneState.stopwatchSaves=[{name:'Prior',mode:'lap',total:500,marks:[100]}];" if existing else "delete phoneState.stopwatchSaves;")+"persist();before=JSON.stringify(phoneState);beforeSaves=phoneState.stopwatchSaves;stored=localStorage.getItem('c2state');page='swsave';swName=' New time ';swSession={mode:"+json.dumps(mode)+",total:1000,marks:[500],running:false,stopped:true};beforeSession=swSession;history=['swtiming'];oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  label=str(existing)+mode
  t(label+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.stopwatchSaves===beforeSaves&&localStorage.getItem('c2state')===stored")
  t(label+' warning/context',"return swFlash==='Unable to save time'&&document.getElementById('screen').innerText.includes(swFlash)&&page==='swsave'&&history.length===1&&swName===' New time '&&swSession===beforeSession")
  if not existing and mode=='split':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6101-stopwatch-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("swFlash='';clearTimeout(swFlashTimer);press('OK')")
  t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;swFlash='';clearTimeout(swFlashTimer);expected=JSON.stringify([...(beforeSaves||[]),{name:'New time',mode:swSession.mode,total:1000,marks:[500]}]);press('OK')")
  t(label+' retry',"return JSON.stringify(phoneState.stopwatchSaves)===expected&&page==='swtiming'&&swFlash==='Saved'")
  saved=ev('expected');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(phoneState.stopwatchSaves)==="+json.dumps(saved))
print('PASS',len(checks))
