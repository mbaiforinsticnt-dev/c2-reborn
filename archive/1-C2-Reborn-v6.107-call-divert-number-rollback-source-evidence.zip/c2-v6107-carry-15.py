exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.107-call-divert-number-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['new','edit']:
 ev("phoneState=migrateState(null);phoneState.todos=[{s:'Old',p:'Low',d:todoToday(),t:'09:00',done:true}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='todoedit';noteText='New todo';todoPri=0;todoDate=todoTodayDigits();todoTime='1130';todoAlarm=0;todoEditIdx="+('0' if mode=='edit' else '-1')+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(mode+' exact todo rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' draft edit identity retained',"return page==='todoedit'&&noteText==='New todo'&&todoPri===0&&todoTime==='1130'&&todoEditIdx==="+('0' if mode=='edit' else '-1'))
 t(mode+' visible warning',"return notice==='Unable to save to-do note'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='new':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v645-todo-save-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect="phoneState.todos.length==="+('1' if mode=='edit' else '2')+"&&phoneState.todos[0].s==='New todo'&&phoneState.todos[0].p==='High'&&phoneState.todos[0].t==='11:30'&&phoneState.todos[0].done==="+('true' if mode=='edit' else 'false')
 t(mode+' retry commits once',"return "+expect+"&&page==='todolist'&&noteText===''")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
