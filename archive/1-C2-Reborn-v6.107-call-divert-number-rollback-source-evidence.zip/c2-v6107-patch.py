from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.106-sync-setting-rollback-candidate.html').read_text().replace('v6.106 handset parity','v6.107 handset parity').replace('C2 Reborn v6.106 |','C2 Reborn v6.107 |')
a="phoneState.callDiverts[divertScope+':'+divertName]={active:true,number:n};persist();notice='Call divert activated';"
b="let beforeDiverts=phoneState.callDiverts;phoneState.callDiverts={...beforeDiverts,[divertScope+':'+divertName]:{active:true,number:n}};try{persist()}catch(err){phoneState.callDiverts=beforeDiverts;notice='Unable to save call divert';draw();return true}notice='Call divert activated';"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save sync setting|Folder memory full','Unable to save sync setting|Unable to save call divert|Folder memory full')
Path('/downloads/C2-Reborn-v6.107-call-divert-number-rollback-candidate.html').write_text(s)
