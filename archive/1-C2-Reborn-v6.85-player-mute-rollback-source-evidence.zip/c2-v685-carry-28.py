exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.85-player-mute-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['list mark','view mark','list unmark','view unmark','sort']:
 done='true' if 'unmark' in mode else 'false'
 act="sortTodoDeadlines()" if mode=='sort' else "open=true;os=currentOptions().indexOf('Mark note as done');press('OK')"
 ev("phoneState=migrateState(null);phoneState.todos=[{s:'Late',p:'Medium',d:'03-10-2026',t:'09:00',done:false},{s:'Early',p:'High',d:'01-10-2026',t:'10:00',done:"+done+"}];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps('todoview' if mode.startswith('view') else 'todolist')+";sel=1;todoViewIdx=1;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' selection retained',"return sel===1&&todoViewIdx===1")
 t(mode+' warning visible',"return notice==="+json.dumps('Unable to sort to-do notes' if mode=='sort' else 'Unable to save to-do status')+"&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='list mark':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v646-todo-status-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="phoneState.todos[0].s==='Early'&&phoneState.todos[1].s==='Late'&&sel===0" if mode=='sort' else "phoneState.todos[1].done==="+('false' if 'unmark' in mode else 'true')
 t(mode+' retry commits',"return "+expect)
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+( "phoneState.todos[0].s==='Early'&&phoneState.todos[1].s==='Late'" if mode=='sort' else expect))
print('PASS',len(checks))
