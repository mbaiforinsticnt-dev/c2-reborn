from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.84-player-directional-rollback-candidate.html').read_text().replace('v6.84 handset parity','v6.85 handset parity').replace('C2 Reborn v6.84 |','C2 Reborn v6.85 |')
a="if(page==='player'&&k==='#'){phoneState.player.muted=!phoneState.player.muted;persist();draw();return}"
b="if(page==='player'&&k==='#'){let hadMuted=Object.prototype.hasOwnProperty.call(phoneState.player,'muted'),beforeMuted=phoneState.player.muted;phoneState.player.muted=!beforeMuted;try{persist()}catch(err){if(hadMuted)phoneState.player.muted=beforeMuted;else delete phoneState.player.muted;notice='Unable to save player';draw();return}draw();return}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.85-player-mute-rollback-candidate.html').write_text(s)
