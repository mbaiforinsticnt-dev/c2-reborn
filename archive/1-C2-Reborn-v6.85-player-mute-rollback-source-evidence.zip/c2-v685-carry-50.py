exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.85-player-mute-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['list','view','all']:
 ev("phoneState=migrateState(null);phoneState.notes=['Keep A','Delete B','Keep C'];phoneState.noteStamps=['A','B','C'];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps('noteview' if mode=='view' else 'notes')+";sel=1;noteIndex=1;deleteNoteConfirm="+('false' if mode=='all' else 'true')+";deleteNotesConfirm="+('1' if mode=='all' else '0')+";noteDeleteFromView="+('true' if mode=='view' else 'false')+";notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')"+(";press('OK')" if mode=='all' else ''))
 t(mode+' exact notes and stamps rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' selection confirmation retained',"return sel===1&&noteIndex===1&&"+('deleteNotesConfirm===2' if mode=='all' else 'deleteNoteConfirm')+"&&noteDeleteFromView==="+('true' if mode=='view' else 'false'))
 t(mode+' warning visible',"return notice==="+json.dumps('Unable to delete notes' if mode=='all' else 'Unable to delete note')+"&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='list':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v640-note-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 expect="phoneState.notes.length===0&&phoneState.noteStamps.length===0" if mode=='all' else "JSON.stringify(phoneState.notes)==='[\"Keep A\",\"Keep C\"]'&&JSON.stringify(phoneState.noteStamps)==='[\"A\",\"C\"]'"
 t(mode+' retry intended deletion once',"return "+expect+"&&!deleteNoteConfirm&&!deleteNotesConfirm")
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
