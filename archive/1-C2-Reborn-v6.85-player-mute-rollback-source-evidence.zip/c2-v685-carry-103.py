exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.85-player-mute-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for pick in [5,6]:
 for existing in [False,True]:
  ev("phoneState=migrateState(null);phoneState.eqCustom="+('{[EQ_PRESETS['+str(pick)+']]:[5,4,3,2,1]}' if existing else '{}')+";persist();beforeCustom=phoneState.eqCustom;before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='equaliser';sel="+str(pick)+";eqEdit={band:2,heights:[1,2,3,4,5]};beforeEdit=eqEdit;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('LSK')")
  t(str(pick)+str(existing)+' exact aliases retained',"return phoneState.eqCustom===beforeCustom&&eqEdit===beforeEdit&&JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
  t(str(pick)+str(existing)+' warning visible',"return notice==='Unable to save equaliser'&&document.getElementById('screen').innerText.includes(notice)")
  if pick==5 and not existing:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v679-equaliser-save-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press('LSK')")
  t(str(pick)+str(existing)+' repeated failure keeps edits',"return eqEdit===beforeEdit&&phoneState.eqCustom===beforeCustom")
  ev("Storage.prototype.setItem=oldStore;notice='';press('LSK')")
  t(str(pick)+str(existing)+' retry saves',"return eqEdit===null&&notice==='Saved'&&JSON.stringify(phoneState.eqCustom[EQ_PRESETS["+str(pick)+"]])==='[1,2,3,4,5]'")
  call('Page.reload');time.sleep(.15)
  t(str(pick)+str(existing)+' reload exact',"return JSON.stringify(phoneState.eqCustom[EQ_PRESETS["+str(pick)+"]])==='[1,2,3,4,5]'")
print('PASS',len(checks))
