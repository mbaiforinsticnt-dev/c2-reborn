# C2 Reborn v6.182 (source-evidence)
Change: Calendar note date and alarm-time entry. Two digits fill a segment (four for the year) and then advance; day is clamped to 1-31, month 1-12, hour 0-23, minute 0-59 when a segment completes.
Reproduced on v6.181 (Tab lead, unverified until reproduced): typing 15112026 in the date field gave 12-26-2610 (every digit advanced a segment); 3199 gave 39-01-0269; alarm 2561 gave 26:51. On v6.182: 15-11-2026, 31-12-2026 and 23:59, alarm 1802 gives 18:02.
Evidence class: inferred (standard S40 numeric field behaviour), not C2-01 handset-proven. Not changed: Go to date prompt (separate code, same garble reported, not yet reproduced).
Dismissed lead: Calls "Clear log lists" confirmation. C2-01 handset footage OCR (c2-clear-ocr.txt frames 19-45) shows selecting a list goes straight to "<list> cleared" with no confirm, so the current behaviour matches the handset.
Reproduced, not fixed: All calls Call-Call redial dials the first row (Alex Morgan demo missed call) because All calls lists missed, received, dialled in that order; touches several index sites. Deferred.
