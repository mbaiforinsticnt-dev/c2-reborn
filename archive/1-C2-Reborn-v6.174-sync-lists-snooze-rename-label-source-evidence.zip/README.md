C2 Reborn v6.174 (source evidence)
Base: v6.173 (blob 551907a7). Tab's leads, each reproduced on v6.173 first (emulator/CDP, not handset):
- B2: Phone switch, Data transfer, Server sync, PC sync no longer auto-select their first row on open (generic list fall-through guarded by page-changed check).
- N2: same-minute snooze re-rang within seconds (the ring condition also fired for the saved alarm minute while a snooze was pending). Fixed.
- Rename screen: right softkey now reads Clear while there is text before the cursor (it deletes), Back when empty (and Back then leaves). Label parity with S40 per Tab, not handset-proven.
- Build label (debug bar) now reads v6.174 | 2026-10-03.
Not changed: OK hit area stays 26x26 (trade-off for the D-pad fix); seeded missed-call time "Today 22:41" is static seed data; lowercase-first typing unchanged.
Focused tests 29/29.
