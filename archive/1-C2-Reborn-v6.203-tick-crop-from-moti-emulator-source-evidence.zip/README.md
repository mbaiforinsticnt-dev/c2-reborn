# C2 Reborn v6.203 (built on v6.202, blob c531b2156eba4434e3c2463fa0772a9edc0816b7)
- Saved-notice tick is now a crop of Moti emulator screenshot (not an original firmware file); Unicode tick glyphs replaced by it.
- Main menu view radio labels are white in the Black and Dark themes (were dark on dark).
- Submenu panels that run under the softkeys (Conversation > Mark) are moved up to fit.
Tests: 178-test sweep did NOT run (lost). Fresh: r126,r127,r129,r130 identical on v6.202 and v6.203; screenshots of Go to + saved notice.
See NOTES.md.
