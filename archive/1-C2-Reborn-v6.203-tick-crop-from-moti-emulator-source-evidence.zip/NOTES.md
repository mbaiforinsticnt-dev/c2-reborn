# Working notes (saved in repo after a workspace reset on 5 Oct 09:36)
Live builds: v6.201 blob c08432ac5b0de5a32bbfa919586f7d474b3dcc1a (run #46, archive 5a77f244). v6.202 follows this note.
Test harness: tests/hdr.py (CDP over websocket, run `bash chrome.sh` first, then `python3 rNN.py <file.html>`), crawlers a3-a7. The old 178-test regression sweep (cf-N.py) was lost in the reset and has NOT been rebuilt.
Open items: arrows on list-opening rows (Moti: follow the emulator; emulator install lost too, needs re-supplying), Black/Dark contrast: Black done (no list-row faults), Dark not crawled; Tab leads unchecked: Calendar day selection contrast Black/Dark, Keypad tones silent, unsorted new contacts, editor submenu Back collapses levels, Equaliser outline-only focus, Calendar editor last field clipped; Tab leads not reproduced: Call on highlighted contact opens empty dialler, Writing language popup off screen.
Rules: Moti's 4 rules (full-row focus, list wrap, Options sized to whole rows, expandable-row arrow). Arrow art: Moti's Flaticon arrowhead (https://www.flaticon.com/free-icons/arrowhead), author not recorded.
Publishing: atomic Actions workflow 4-publish-index.yml (zip_path archive/1-<name>.zip, member index.html, new_blob, base_blob). Banked zip must byte-match a raw download pinned to the commit.

## v6.203 (2026-10-05)
- Saved-notice tick (listIcons.CHECK) replaced by a CROP of Moti's emulator screenshot (image-4fd8f09f), 56x56. Crop, not an original firmware file (Moti permission 10:15). Unicode check glyphs replaced by the same image.
- Go to profile icons and plain Settings > Profiles already match his screenshots (no change).
Base blob: c531b2156eba4434e3c2463fa0772a9edc0816b7
