from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.78-equaliser-activation-rollback-candidate.html').read_text().replace('v6.78 handset parity','v6.79 handset parity').replace('C2 Reborn v6.78 |','C2 Reborn v6.79 |')
a="if(k==='LSK'){phoneState.eqCustom=phoneState.eqCustom||{};phoneState.eqCustom[EQ_PRESETS[sel]]=eqEdit.heights.slice();eqEdit=null;persist();notice='Saved';draw();return true}"
b="if(k==='LSK'){let beforeCustom=phoneState.eqCustom;phoneState.eqCustom={...(beforeCustom||{}),[EQ_PRESETS[sel]]:eqEdit.heights.slice()};try{persist()}catch(err){phoneState.eqCustom=beforeCustom;notice='Unable to save equaliser';draw();return true}eqEdit=null;notice='Saved';draw();return true}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.79-equaliser-custom-save-rollback-candidate.html').write_text(s)
