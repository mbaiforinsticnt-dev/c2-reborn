s=open('/tmp/h/live.html').read()
assert s.count('v6.342 | 2026-10-07')==1
s=s.replace('v6.342 | 2026-10-07','v6.343 | 2026-10-11')
js=r'''<script id="numberOptions343">
// Numbers offer Contact / Save a contact; Mark as read / unread on messages.
(function(){
function target343(){try{if(page==='incall'&&activeCall)return {number:activeCall,contact:findContact(activeCall)};return rule308Target()}catch(e){return null}}
function plain343(){return !subParent&&!pageSub&&!namesSubmenu&&!optParent}
function msgRec343(){
 if(page==='inbox')return messageStore.inbox[sel]||null;
 if(page==='messageread')return messageStore.inbox[readMessageIndex]||null;
 if(page==='conversation')return currentMessage();
 if(page==='msgopen')return threadMessages()[openMsgIdx]||null;
 return null}
function markable343(m){return m&&m.dir!=='out'}
var cur343=currentOptions;
currentOptions=function(){
 let a=cur343.apply(this,arguments);
 if(!Array.isArray(a)||!plain343())return a;
 a=a.slice();
 let m=msgRec343();
 if(markable343(m)&&!a.includes('Mark as read')&&!a.includes('Mark as unread')){
  let lab=m.unread?'Mark as read':'Mark as unread',at=a.findIndex(x=>x==='Message details'||x==='Conversation details');
  if(at<0)at=a.length;else at++;a.splice(at,0,lab)}
 let t=target343();
 if(t){
  if(['names','contact'].includes(page))a=a.filter(x=>x!=='Add to contact');
  else{
   if(['conversation','msgopen','conversations'].includes(page))a=a.filter(x=>x!=='Send message'&&x!=='View conversations');
   if(!a.includes('Contact')&&!a.includes('Save a contact')&&!a.includes('Save')&&!a.includes('Save to contacts')){
    let at=a.indexOf('Add to contact');if(at<0)at=a.length;
    a.splice(at,0,t.contact?'Contact':'Save a contact')}}
  if(activeCall)a=a.filter(x=>x!=='Call');
  if(page==='incall'&&!a.includes('Send message'))a.splice(Math.max(0,a.indexOf('Contact')>=0?a.indexOf('Contact'):a.indexOf('Save a contact')),0,'Send message')}
 return a};
function openContact343(t){contactIndex=phoneState.contacts.indexOf(t.contact);go('contact')}
function saveContact343(t){cfReset();contactNumber=t.number;contactField=0;editingContact=false;go('addcontact')}
function toggle343(m,wantRead){
 let before=[m.unread,m.icon];
 m.unread=!wantRead;if(m.icon!==undefined||page==='conversation'||page==='msgopen')m.icon=wantRead?'read':'unread';
 try{persist()}catch(e){m.unread=before[0];m.icon=before[1];notice='Unable to save read status';draw();return}
 notice=wantRead?'Marked as read':'Marked as unread';draw()}
var prs343=press;
press=function(k){
 if(open&&!notice&&plain343()&&(k==='OK'||k==='LSK')&&!rule308Incoming&&!rule308Details&&!contactDeleteConfirm&&!callDeletePending){
  let c=currentOptions()[os];
  if(c==='Mark as read'||c==='Mark as unread'){let m=msgRec343();if(m){open=false;toggle343(m,c==='Mark as read');return true}}
  if(c==='Send message'&&page==='incall'){open=false;startMessage('',activeCall);return true}
  if(c==='Contact'||c==='Save a contact'){let t=target343();if(t){open=false;if(c==='Contact'&&t.contact)openContact343(t);else saveContact343(t);return true}}}
 return prs343.apply(this,arguments)};
var lx343=listingExtras341;
listingExtras341=function(t){let a=lx343.apply(this,arguments).slice();
 if(['rcptcontacts','logpicker','recentused','tomatches','divertpick','newnumber'].includes(page))a.splice(Math.max(0,a.indexOf('Add to contact')),0,t&&t.contact?'Contact':'Save a contact');
 return a};
var la343=listingAction341;
listingAction341=function(it,t){
 if(it==='Contact'&&t.contact){openContact343(t);return}
 if(it==='Save a contact'){saveContact343(t);return}
 return la343.apply(this,arguments)};
draw()})();
</script></body></html>'''
assert s.endswith('</script></body></html>') or s.rstrip().endswith('</body></html>')
s=s.rstrip()
assert s.endswith('</body></html>')
s=s[:-len('</body></html>')]+js
open('/tmp/h/w343.html','w').write(s)
