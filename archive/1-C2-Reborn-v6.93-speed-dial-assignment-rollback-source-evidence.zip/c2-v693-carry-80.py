exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.93-speed-dial-assignment-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);messageStore=seedMessageStore();messageStore.threads={alex:[{id:'a',text:'A',dir:'in',unread:false}], 'number-447700900888':[{id:'b',text:'B',dir:'out',unread:false}]};messageStore.numberedKeys=['number-447700900888'];messageStore.inbox=[{id:'i',body:'I',name:'Demo',unread:false}];messageStore.saved=[{id:'s',body:'S'}];messageStore.hidden=[4];messageStore.marked=['alex'];messageStore.markFilter='marked';phoneState.messageStore=messageStore;DEMO_THREAD=messageStore.threads.alex;phoneState.drafts=[{body:'D',kind:'sms',to:'Alex'}];phoneState.sent=['Old'];phoneState.thread=['Thread'];phoneState.legacySent=['Legacy'];persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page='confirmdelete';sel=0;history=[{page:'messaging',sel:12}];notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
t('Exact complete message rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&DEMO_THREAD===messageStore.threads.alex")
t('Confirmation selection history retained',"return page==='confirmdelete'&&sel===0&&history.length===1")
t('Visible warning',"return notice==='Unable to delete messages'&&document.getElementById('screen').innerText.includes(notice)")
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v660-delete-all-error.png','wb').write(base64.b64decode(d['result']['data']))
ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
expect="phoneState.drafts.length===0&&phoneState.sent.length===0&&phoneState.thread.length===0&&phoneState.legacySent.length===0&&Object.values(messageStore.threads).every(x=>x.length===0)&&messageStore.inbox.length===0&&messageStore.saved.length===0&&messageStore.hidden.length===0&&messageStore.marked.length===0&&messageStore.markFilter===''&&messageStore.numberedKeys.length===0"
t('Retry clears intended stores',"return "+expect+"&&page==='messaging'&&sel===12")
call('Page.reload');time.sleep(.15)
t('Reload exact',"return "+expect)
print('PASS',len(checks))
