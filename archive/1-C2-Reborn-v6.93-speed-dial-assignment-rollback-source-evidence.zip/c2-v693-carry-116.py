exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.93-speed-dial-assignment-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for value in ['true','false']:
 ev("phoneState=migrateState(null);phoneState.lights="+value+";persist();before=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');page='lights';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
 t(value+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(value+' warning visible',"return notice==='Unable to save lights'&&document.getElementById('screen').innerText.includes(notice)")
 if value=='true':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v692-lights-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("notice='';press('OK')")
 t(value+' repeat failure exact',"return JSON.stringify(phoneState)===before")
 ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
 t(value+' retry toggles once',"return phoneState.lights!=="+value+"&&JSON.parse(localStorage.getItem('c2state')).lights===phoneState.lights")
 call('Page.reload');time.sleep(.15)
 t(value+' reload exact',"return phoneState.lights!=="+value)
print('PASS',len(checks))
