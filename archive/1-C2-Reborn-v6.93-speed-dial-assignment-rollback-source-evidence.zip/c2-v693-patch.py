from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.92-lights-toggle-rollback-candidate.html').read_text().replace('v6.92 handset parity','v6.93 handset parity').replace('C2 Reborn v6.92 |','C2 Reborn v6.93 |')
repls=[("phoneState.speedDial[String(sel+2)]=ct.number;persist();notice='Speed dial '", "if(!saveSpeedDial(String(sel+2),ct.number)){draw();return}notice='Speed dial '"), ("phoneState.speedDial[speedPickKey]=phoneState.contacts[sel].number;persist();back();notice='Speed dial '", "if(!saveSpeedDial(speedPickKey,phoneState.contacts[sel].number)){draw();return}back();notice='Speed dial '")]
for a,b in repls:
 assert s.count(a)==1,a
 s=s.replace(a,b)
s=s.replace('function activateProfileIdx(',"function saveSpeedDial(key,number){let beforeSpeed=phoneState.speedDial;phoneState.speedDial={...beforeSpeed,[key]:number};try{persist()}catch(err){phoneState.speedDial=beforeSpeed;notice='Unable to save speed dial';return false}return true}\nfunction activateProfileIdx(").replace('Unable to save lights|Folder memory full','Unable to save lights|Unable to save speed dial|Folder memory full')
Path('/downloads/C2-Reborn-v6.93-speed-dial-assignment-rollback-candidate.html').write_text(s)
