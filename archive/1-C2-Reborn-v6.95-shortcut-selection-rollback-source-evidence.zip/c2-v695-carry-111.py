exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.95-shortcut-selection-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for choice,flag in [('Shuffle','shuffle'),('Repeat','repeat')]:
 for value in [False,True]:
  ev("phoneState=migrateState(null);phoneState.player."+flag+"="+str(value).lower()+";persist();before=JSON.stringify(phoneState);beforePlayer=phoneState.player;stored=localStorage.getItem('c2state');page='player';open=true;os=currentOptions().indexOf('"+choice+"');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
  t(choice+str(value)+' exact rollback',"return JSON.stringify(phoneState)===before&&phoneState.player===beforePlayer&&localStorage.getItem('c2state')===stored")
  t(choice+str(value)+' no false flag success',"return notice==='Unable to save player'&&document.getElementById('screen').innerText.includes(notice)")
  if choice=='Shuffle' and not value:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v687-player-flags-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';open=true;os=currentOptions().indexOf('"+choice+"');press('OK')")
  t(choice+str(value)+' repeated failure exact',"return JSON.stringify(phoneState)===before")
  ev("Storage.prototype.setItem=oldStore;notice='';open=true;os=currentOptions().indexOf('"+choice+"');press('OK')")
  t(choice+str(value)+' retry exact',"return phoneState.player."+flag+"!=="+str(value).lower()+"&&notice==='"+choice+(' off' if value else ' on')+"'")
  call('Page.reload');time.sleep(.15)
  t(choice+str(value)+' reload exact',"return phoneState.player."+flag+"!=="+str(value).lower())
print('PASS',len(checks))
