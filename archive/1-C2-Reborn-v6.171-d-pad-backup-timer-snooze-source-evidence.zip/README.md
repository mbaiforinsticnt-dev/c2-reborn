C2 Reborn v6.171 (source evidence)
Base: v6.170 (blob e7b4ba4d). Changes, each reproduced on the build first:
- Snooze: absolute timestamp, keeps saved time.
- Saved date/time drives standby clock, message times, alarm check (handsetNow).
- End key: goes home unless a prompt/ring/call page is showing (replaces v6.170 rule, which broke "dirty End asks Yes/No").
- Timer: digits fill sequentially (000105 = 00:01:05), minutes clamp 59, End on running note goes home, timer tone persists.
- D-pad: LEFT/RIGHT/DOWN/UP/OK each fire own key (hit areas tightened, 360/390/430px).
- Backup/Restore/Phone switch/Server sync/PC sync/Data transfer no longer auto-run on entry; OK on page still saves/restores.
- Organiser DOWN wraps: INFERRED from Tab's note, not handset-proven.
Not reproduced/not fixed: dialler Save key placing call (middle softkey did not call; OK=Call), empty Gallery rename .jpg, call divert End, radio softkeys, interval timer redraw, Media All songs static page.
Tab claims are unverified leads. Evidence class: emulator/CDP tests, not handset.
