exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.148-radio-station-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['left','right','search']:
 for absentIndex in [False]:
  for absentFrequency in [False,True]:
   ev("phoneState=migrateState(null);phoneState.radioSaved=[{name:'Demo 1',frequency:'90.0'},{name:'Demo 2',frequency:'100.0'}];"+("delete phoneState.radioStationIndex;" if absentIndex else "phoneState.radioStationIndex=0;")+("delete phoneState.radioFrequency;" if absentFrequency else "phoneState.radioFrequency='90.0';")+"persist();before=JSON.stringify(phoneState);hadI=Object.prototype.hasOwnProperty.call(phoneState,'radioStationIndex');hadF=Object.prototype.hasOwnProperty.call(phoneState,'radioFrequency');stored=localStorage.getItem('c2state');page="+json.dumps('radio')+";sel=1;history=['radio'];notice='';noticeBack=false;open=false;pickerDraft=null;radioCtx="+("null")+";alias=radioCtx;"+("open=true;os=currentOptions().indexOf('Search stations');" if route=='search' else '')+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press("+json.dumps('LEFT' if route=='left' else 'RIGHT' if route=='right' else 'OK')+")")
   label=f'{route} {absentIndex} {absentFrequency}'
   t(label+' rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'radioStationIndex')===hadI&&Object.prototype.hasOwnProperty.call(phoneState,'radioFrequency')===hadF&&localStorage.getItem('c2state')===stored")
   t(label+' context',"return radioCtx===alias&&notice==='Unable to save radio station'")
   if route=='number' and not absentIndex and not absentFrequency:
    d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6148-radio-error.png','wb').write(base64.b64decode(d['result']['data']))
   ev("Storage.prototype.setItem=oldStore;notice='';"+("open=true;os=currentOptions().indexOf('Search stations');" if route=='search' else '')+"press("+json.dumps('LEFT' if route=='left' else 'RIGHT' if route=='right' else 'OK')+")")
   t(label+' retry',"return phoneState.radioStationIndex==="+('0' if route=='search' and absentFrequency else '1')+"&&phoneState.radioFrequency==="+json.dumps('90.0' if route=='search' and absentFrequency else '100.0'))
   call('Page.reload');time.sleep(.15)
   t(label+' reload',"return phoneState.radioStationIndex==="+('0' if route=='search' and absentFrequency else '1')+"&&phoneState.radioFrequency==="+json.dumps('90.0' if route=='search' and absentFrequency else '100.0'))
print('PASS',len(checks))
