exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.148-radio-station-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices=ev('MS_RADIO')
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for row,field in [(0,'left')]:
 for choice,val in enumerate(choices):
  if choice==2 or choice<0 or choice>=30:continue
  for absent in [False,True]:
   for key in ['OK','LSK']:
    ev("phoneState=migrateState(null);"+("delete phoneState.myShortcuts."+field+";" if absent else "")+"persist();before=JSON.stringify(phoneState);beforeShortcuts=phoneState.myShortcuts;stored=localStorage.getItem('c2state');history=['myshortcuts'];notice='';noticeBack=false;open=false;page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'myshortcuts',row:"+str(row)+",title:'Selection key',opts:MS_RADIO,grey:[2]};alias=radioCtx;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('"+key+"')")
    label=f'{row} {choice} {absent} {key}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.myShortcuts===beforeShortcuts&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return radioCtx===alias&&page==='radiolist'&&notice==='Unable to save shortcut setting'&&document.getElementById('screen').innerText.includes(notice)")
    if row==0 and choice==0 and not absent and key=='OK':
     d=call('Page.captureScreenshot',{'format':'png'});open('/tmp/c2-v6141-carry-selection.png','wb').write(base64.b64decode(d['result']['data']))
    ev("Storage.prototype.setItem=oldStore;notice='';press('"+key+"')")
    t(label+' retry',"return phoneState.myShortcuts."+field+"==="+json.dumps(val)+"&&page==='myshortcuts'&&radioCtx===null")
    call('Page.reload');time.sleep(.15)
    for wait in range(20):
     if ev("typeof phoneState!=='undefined'") is True:break
     time.sleep(.05)
    t(label+' reload',"return phoneState.myShortcuts."+field+"==="+json.dumps(val))
print('PASS',len(checks))
