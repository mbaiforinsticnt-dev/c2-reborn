from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.95-shortcut-selection-rollback-candidate.html').read_text().replace('v6.95 handset parity','v6.96 handset parity').replace('C2 Reborn v6.95 |','C2 Reborn v6.96 |')
a="if(k==='OK'){phoneState.menuView=['List','Grid','Grid with labels','Tab'][sel];persist();menuViewChoosing=false;sel=lastMenuSel;open=false;os=0}"
b="if(k==='OK'){let beforeView=phoneState.menuView;phoneState.menuView=['List','Grid','Grid with labels','Tab'][sel];try{persist()}catch(err){phoneState.menuView=beforeView;notice='Unable to save menu view';draw();return}menuViewChoosing=false;sel=lastMenuSel;open=false;os=0}"
assert s.count(a)==1
s=s.replace(a,b).replace('Unable to save shortcut|Folder memory full','Unable to save shortcut|Unable to save menu view|Folder memory full')
Path('/downloads/C2-Reborn-v6.96-menu-view-rollback-candidate.html').write_text(s)
