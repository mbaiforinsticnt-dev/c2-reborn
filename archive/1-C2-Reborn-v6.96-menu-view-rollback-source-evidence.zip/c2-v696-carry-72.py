exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.96-menu-view-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['delfile','delmarked','delfolder']:
 ev("phoneState=migrateState(null);phoneState.galleryFolders=['Source','Child'];phoneState.galFolderParents={Source:'Memory card',Child:'Source'};phoneState.galFolderNames={Source:'Visible',Child:'Nested'};phoneState.galFolderItems=[{folder:'Child',n:'Probe',s:'100 B'}];page='galfolder';galFolderName='Images';sel=0;galDialog="+json.dumps(mode)+";galText="+json.dumps('Source' if mode=='delfolder' else 'Photo0001.jpg')+";galDeleteId='Photo0001.jpg';galMarked=new Set(['Photo0001.jpg','Photo0002.jpg']);galMarkMode=true;persist();baseline=JSON.stringify(phoneState);stored=localStorage.getItem('c2state');oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};draw();press('LSK')")
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===baseline&&localStorage.getItem('c2state')===stored")
 t(mode+' confirmation retained',"return galDialog==="+json.dumps(mode)+"&&notice==='Unable to save deletion'&&galMarked.size===2")
 if mode=='delfile':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v606-delete-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';press('LSK')")
 t(mode+' retry commits',"return !galDialog&&"+("phoneState.galleryFolders.length===0&&phoneState.galFolderItems.length===0" if mode=='delfolder' else "phoneState.galDeleted.length==="+('2' if mode=='delmarked' else '1')))
 call('Page.reload');time.sleep(.3)
 t(mode+' reload retains committed deletion',"return "+("phoneState.galleryFolders.length===0&&phoneState.galFolderItems.length===0" if mode=='delfolder' else "phoneState.galDeleted.length==="+('2' if mode=='delmarked' else '1')))
print('PASS',len(checks))
