# C2 Reborn v6.202 (built on v6.201, blob c08432ac5b0de5a32bbfa919586f7d474b3dcc1a)
- Main menu view radio labels are white in the Black and Dark themes (were dark on dark).
- Submenu panels that run under the softkeys (Conversation > Mark) are moved up to fit.
Tests: the 178-test sweep did NOT run (workspace reset lost it). Fresh checks: screenshots of the Mark submenu and Main menu view in Nokia/Black/Dark/Light, and r126, r127, r129, r130, r131, r133, r134, r135, r136, r137, r139, r141 give identical output on v6.201 and v6.202.
See NOTES.md.
