import os,json
F='index.html'
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(bool(v))
T="document.querySelector('.lcd').innerText.replace(/\\n/g,'|')"
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.5)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';draw()})()")
def keys(*ks):
 for k in ks: ev("press(%s)"%json.dumps(k))
fresh();ev("go('calculator')");keys('2','UP','3','UP','4','OK');t('calc 2+3+4=9',ev("calc")=='9')
fresh();ev("go('calculator')");keys('2','UP','DOWN','5','OK');t('calc operator change 2 + then - 5 = -3',ev("calc")=='-3')
fresh();ev("go('calculator')");keys('9','DOWN','3','LEFT','2','OK');t('calc 9-3x2=12',ev("calc")=='12')
fresh();ev("go('calculator')");keys('8','RIGHT','2','OK');t('calc 8/2=4',ev("calc")=='4')
fresh();ev("(()=>{phoneState.calcMode='scientific';go('scientific')})()")
ev("(()=>{calc='2';calcSel=14;press('OK')})()") if False else None
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK');sel=0;draw();press('OK')})()");keys('DOWN','0','9','3','0');r=ev(T);t('time 0930 -> 09:30',('09:30' in r) and '03:90' not in r)
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK');sel=0;draw();press('OK')})()");keys('DOWN','2','5');r=ev("calTimeDraft");t('hour 25 clamps to 23',r.startswith('23'))
fresh();ev("(()=>{go('settings');sel=5;draw();press('OK');sel=0;draw();press('OK')})()");keys('DOWN','1','2','7','5');r=ev("calTimeDraft");t('minute 75 clamps 59',r=='12:59')
fresh();ev("(()=>{phoneState.alarm={on:true,time:'07:00',repeat:false,tone:'Standard',snooze:10,days:[]};persist();go('alarmring')})()")
keys('RSK');t('snooze keeps saved time',ev("phoneState.alarm.time")=='07:00' and ev("alarmSnoozeAt")!='' and ev("page")=='home')
ev("notice='';go('alarmring')");print(ev('page'),repr(ev('alarmSnoozeAt')));keys('LSK');print(ev('page'),repr(ev('alarmSnoozeAt')));t('stop clears snooze',ev('alarmSnoozeAt')=='')
def fresh2():
 ev("localStorage.clear()");call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.8)
def safe(k):
 return ev("(()=>{try{press(%s);return 'ok'}catch(e){return 'ERR '+e.message}})()"%json.dumps(k))

def S(*ks):
 for kk in ks: safe(kk)
def home(): return ev('page')
fresh2();ev("go('dial')");S('0','7','7','0','0','OK');t('D1 OK on dialler with digits saves (addcontact), no call',home()=='addcontact' and ev('contactNumber')=='07700')
fresh2();ev("go('dial')");S('0','7','7','0','0','CALL');t('D1 Call key still calls',home()=='incall')
fresh2();ev("go('settings');sel=13;draw()");S('OK','OK','OK');t('S1 OK still selects',home()!='radiolist')
fresh2();S('OK','LEFT','OK','DOWN','OK','LSK',*['DOWN']*6);S('OK');S(*['RSK']*9);S('OK');t('GA1 empty rename refused',ev('notice')=='Enter a file name' and ev('JSON.stringify(phoneState.galFileNames)')=='{}')
fresh2();S('OK','LEFT','OK','DOWN','OK','LSK',*['DOWN']*6);S('OK');S(*['RSK']*9);S('4');S('OK');print(ev('notice'),ev('JSON.stringify(phoneState.galFileNames)'));t('GA1 normal rename still works',ev('JSON.stringify(phoneState.galFileNames)').find('.jpg')>0 and ev('page')=='galfolder')
fresh2();S('CALL','LSK','END');t('N4 End on Log Options -> home',home()=='home')
fresh2();S('5','LSK','END');t('N4 End on Dial Options -> home',home()=='home')
fresh2();S('OK','RIGHT','RIGHT','RIGHT','OK',*['DOWN']*14,'OK','OK','END');t('N5 End on factory explanation -> home',home()=='home')
fresh2();S('OK','RIGHT','RIGHT','RIGHT','OK',*['DOWN']*9,'OK','DOWN','OK','OK','OK','OK','DOWN','OK','END');t('CD1 End on divert number -> home',home()=='home')
fresh2();ev("go('syncbackup');sel=2;draw()");ev("phoneState.contacts.push({name:'Zed',number:'1',store:'Phone'});persist()");n0=ev("phoneState.contacts.length");S('OK');t('backup: OK on restore menu row opens page without wiping',ev('phoneState.contacts.length')==n0)


fresh2();S('OK','RIGHT','RIGHT','RIGHT','OK',*['DOWN']*7,'OK');t('B2 Phone switch opens as list (not details)',home()=='syncbackup');S('OK');t('B2 Phone switch OK from sync menu shows list',home()=='phoneswitch')
fresh2();ev("go('syncbackup');sel=3;draw()");S('OK');t('B2 Data transfer opens as list',home()=='datatransfer');S('OK');t('B2 Server sync opens as its page',home()=='serversync')
fresh2();ev("go('datatransfer');sel=1;draw()");S('OK');t('B2 PC sync opens as its page',home()=='pcsync')
import time
fresh2()
ev("(()=>{let d=handsetNow();phoneState.alarm={on:true,time:String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'),repeat:false,tone:'Standard',snooze:10,days:[]};persist()})()")
for i2 in range(8):
    time.sleep(1)
    if ev('page')=='alarmring':break
S('RSK');time.sleep(4);t('N2 same-minute snooze does not re-ring',home()=='home' and ev('alarmSnoozeAt')!='')
fresh2();S('OK','LEFT','OK','DOWN','OK','LSK',*['DOWN']*6);S('OK');t('rename RSK label Clear when text',ev(T).endswith('Clear'))
S(*['RSK']*9);t('rename RSK label Back when empty',ev(T).endswith('Back'));S('RSK');t('rename Back at empty leaves screen',home()!='galfilerename')
t('build label matches',ev("document.querySelector('.debug').innerText").startswith('C2 Reborn v6.175'))


fresh2();ev("go('serversync');sel=0;draw()");S('OK');t('B3 Server sync row0 opens info and stays',home()=='syncinfo')
fresh2();ev("go('serversync');sel=1;draw()");S('OK');t('B3 Server sync row1 opens info and stays',home()=='syncinfo');S('OK');t('B3 info OK returns to Server sync',home()=='serversync')
fresh2();ev("go('pcsync');sel=0;draw()");S('OK');t('B3 PC sync User name opens visible editor',home()=='pcsyncname' and ev('syncEditing')==True)
S('END');S('5');t('B3 End leaves editor; standby digit dials, not captured',home()=='dial' and ev('dial')=='5' and ev('syncEditing')==False)
fresh2();ev("go('pcsync');sel=0;draw()");S('OK');S('4');S('OK');t('B3 editor OK saves',ev('phoneState.syncUser')=='userg' and home()=='pcsync')
fresh2();ev("go('pcsync');sel=1;draw()");S('OK');t('B3 PC sync Password opens editor',home()=='pcsyncpass')
print(sum(res),'/',len(res))
