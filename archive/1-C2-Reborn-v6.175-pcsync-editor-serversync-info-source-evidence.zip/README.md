C2 Reborn v6.175 (source evidence)
Base: v6.174 (blob 25218870). Tab's v6.174 leads, reproduced on v6.174 first (emulator/CDP, not handset):
- Server sync rows 0/1 opened the info page and the same keypress closed it again (second ladder ran the syncinfo back branch). Fixed with a page-changed guard.
- PC sync User name/Password: OK opened the editor and the same keypress backed out, leaving syncEditing true (hidden editor). Editor now stays open and visible.
- syncEditing is cleared on End so standby digits are no longer captured (reproduced: after End, standby 5 did not reach the dialler).
- Build label reads v6.175 | 2026-10-03.
- Empty Gallery rename replayed on v6.174: refused ("Enter a file name"), not saved as .jpg. No change needed.
Not changed (leads not reproduced or not defects): Date and time left softkey, one-off alarm turning Off after Stop (S40 behaviour), WLAN Select, Server sync "Rules for incom. sync" generic page.
Focused tests 36/36.
