exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.94-home-profile-toggle-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['mark','unmark']:
 choice='Mark' if mode=='mark' else 'Unmark' if mode=='unmark' else 'Mark as read'
 act="open=true;os=currentOptions().indexOf("+json.dumps(choice)+");press('OK')"
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();let m={id:'status',body:'Status',text:'Status',name:'Demo',dir:'in',unread:true,icon:'unread'"+(',marked:true' if mode=='unmark' else '')+"};messageStore.inbox=[m];messageStore.threads={alex:[m]};phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps('inbox' if mode=='inbox' else 'conversation')+";sel=0;conversationKey='alex';notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};"+act)
 t(mode+' exact rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored")
 t(mode+' source retained',"return page==="+json.dumps('inbox' if mode=='inbox' else 'conversation')+"&&sel===0&&messageStore.threads.alex[0].id==='status'")
 t(mode+' visible warning',"return notice==='Unable to save message status'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='mark':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v656-message-status-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';"+act)
 expect="messageStore.threads.alex[0].marked==="+('false' if mode=='unmark' else 'true') if mode in ['mark','unmark'] else "messageStore.threads.alex[0].unread===false&&messageStore.threads.alex[0].icon==='read'"
 t(mode+' retry exact',"return "+expect)
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return "+expect)
print('PASS',len(checks))
