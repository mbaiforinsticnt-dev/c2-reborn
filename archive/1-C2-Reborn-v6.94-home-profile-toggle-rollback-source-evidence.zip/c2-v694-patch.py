from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.93-speed-dial-assignment-rollback-candidate.html').read_text().replace('v6.93 handset parity','v6.94 handset parity').replace('C2 Reborn v6.93 |','C2 Reborn v6.94 |')
a="if(k==='#'){phoneState.profile=phoneState.profile==='Silent'?'General':'Silent';persist();notice=phoneState.profile+' profile activated';draw();return}"
b="if(k==='#'){let beforeProfile=phoneState.profile;phoneState.profile=beforeProfile==='Silent'?'General':'Silent';try{persist()}catch(err){phoneState.profile=beforeProfile;notice='Unable to save profile';draw();return}notice=phoneState.profile+' profile activated';draw();return}"
assert s.count(a)==1
s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.94-home-profile-toggle-rollback-candidate.html').write_text(s)
