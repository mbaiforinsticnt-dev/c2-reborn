exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.94-home-profile-toggle-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for mode in ['home','conversation']:
 ev("phoneState=migrateState(null);messageStore=seedMessageStore();messageStore.threads={alex:[{id:'keep',text:'Keep',dir:'in',unread:false}]};DEMO_THREAD=messageStore.threads.alex;phoneState.messageStore=messageStore;persist();stored=localStorage.getItem('c2state');before=JSON.stringify(phoneState);page="+json.dumps(mode)+";sel=0;conversationKey='alex';newMsgAlert=null;notice='';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};simReply()")
 t(mode+' exact store id rollback',"return JSON.stringify(phoneState)===before&&localStorage.getItem('c2state')===stored&&DEMO_THREAD===messageStore.threads.alex")
 t(mode+' no false incoming alert',"return newMsgAlert===null&&!window._simT&&page==="+json.dumps(mode))
 t(mode+' visible warning',"return notice==='Unable to save demo reply'&&document.getElementById('screen').innerText.includes(notice)")
 if mode=='home':
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v657-demo-reply-error.png','wb').write(base64.b64decode(d['result']['data']))
 ev("Storage.prototype.setItem=oldStore;notice='';simReply()")
 t(mode+' retry exact reply',"return messageStore.threads.alex.length===2&&messageStore.threads.alex[0].text==='Thanks - got it, will take a look.'&&messageStore.threads.alex[1].id==='keep'&&"+('newMsgAlert?.name===\'Alex Morgan\'' if mode=='home' else 'newMsgAlert===null'))
 call('Page.reload');time.sleep(.15)
 t(mode+' reload exact',"return messageStore.threads.alex.length===2&&messageStore.threads.alex[0].text==='Thanks - got it, will take a look.'&&messageStore.threads.alex[1].id==='keep'")
print('PASS',len(checks))
