from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.52-call-delete-rollback-candidate.html').read_text().replace('v6.52 handset parity','v6.53 handset parity').replace('C2 Reborn v6.52 |','C2 Reborn v6.53 |')
a="if(m){messageStore.saved.unshift({...m});a.splice(openMsgIdx,1);sel=Math.max(0,Math.min(openMsgIdx,a.length-1));persist();back();back()}"
b="if(m){let beforeList=a.slice(),beforeSaved=messageStore.saved.slice(),beforeSel=sel;messageStore.saved.unshift({...m});a.splice(openMsgIdx,1);sel=Math.max(0,Math.min(openMsgIdx,a.length-1));try{persist()}catch(err){a.splice(0,a.length,...beforeList);messageStore.saved=beforeSaved;sel=beforeSel;notice='Unable to move message';draw();return}back();back()}"
assert s.count(a)==1;s=s.replace(a,b)
a="if(m){messageStore.saved.unshift({...m});messageStore.inbox.splice(i,1);sel=Math.max(0,Math.min(i,messageStore.inbox.length-1));persist();if(page==='messageread')back();else draw()}"
b="if(m){let beforeInbox=messageStore.inbox.slice(),beforeSaved=messageStore.saved.slice(),beforeSel=sel;messageStore.saved.unshift({...m});messageStore.inbox.splice(i,1);sel=Math.max(0,Math.min(i,messageStore.inbox.length-1));try{persist()}catch(err){messageStore.inbox=beforeInbox;messageStore.saved=beforeSaved;sel=beforeSel;notice='Unable to move message';draw();return}if(page==='messageread')back();else draw()}"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to delete call|Folder memory full|';b='Unable to delete call|Unable to move message|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.53-message-move-rollback-candidate.html').write_text(s)
