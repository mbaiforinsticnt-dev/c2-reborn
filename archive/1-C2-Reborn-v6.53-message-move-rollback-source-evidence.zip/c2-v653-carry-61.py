exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.53-message-move-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';sel=0;open=true;os=currentOptions().indexOf('Edit image');draw();press('OK');press('LSK');press('OK');press('2');press('2');press('2');press('2');press('OK');press('OK');press('OK');press('DOWN');press('OK');press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('End to end keys default saved copy',"return galEditor.stage==='saved'&&phoneState.galEditedImages[0].n==='Photo0001.gif'")
call('Page.reload',{});time.sleep(.4)
t('Reload retained source bytes',"return phoneState.galEditedImages[0].n==='Photo0001.gif'")
ev("page='galfolder';galFolderName='Images';sel=galFolderFiles().findIndex(f=>f.n==='Photo0001.gif');draw();go('galphoto');draw()")
t('Saved copy actual image loaded',"return document.querySelector('#screen img[src^=\"data:image/gif\"]').naturalWidth===240")
time.sleep(.1);d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v596-reopened.png','wb').write(base64.b64decode(d['result']['data']))
ev("galEditor={src:'invalid',sourceName:'Bad.jpg',saveName:'Bad',stage:'saveName'};draw();press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('Bad source no false Saved',"return galEditor.stage==='saveError'&&phoneState.galEditedImages.length===1")
t('Error Back returns name',"press('BACK');return galEditor.stage==='saveName'")
ev("galEditor.src=GAL_PHOTOS[0];galEditor.stage='saveName';letStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
for attempt in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('Quota rollback no false success',"Storage.prototype.setItem=letStore;return galEditor.stage==='saveError'&&phoneState.galEditedImages.length===1")
t('Async End no late save',"galEditor.stage='saveName';press('OK');press('END');return !galEditor")
time.sleep(.1)
t('No completion after End',"return phoneState.galEditedImages.length===1&&page==='home'")
print('PASS',len(checks))
