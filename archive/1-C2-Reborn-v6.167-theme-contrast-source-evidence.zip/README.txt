v6.167: theme contrast fixes (Moti 11:07 / 11:11 reports).
1. Status bar icons (signal/battery/envelope) were white on the light status bar of Light, Simple and Abstract themes; they now use the same dark rendering of the original assets that Nokia.nth already used (CSS brightness(0)). Dark themes unchanged.
2. Abstract and Mountains pictures were drawn behind every screen; now home screen only. Other screens use a flat theme background (Abstract white, Mountains black - the black is a guess).
3. Unselected Names rows were white on light themes; now dark. Other white-on-light labels on Simple/Abstract (timers, stopwatch, folder name, PC sync, contact memory, etc.) now dark.
4. Divert Number: label (v6.165) was white on a light box on dark themes; now dark.
5. Mountains home "My style 1" label was dark on a black bar; now white.
Tests: v6167 focused 27/27, v6166 10/10, v6165 15/15, v6164 15/15, v6163 23/23, v6158 5/5. Full sweep running.
Audit: c2-v6167-audit.py renders 282 pages x 8 themes and flags text/background contrast <2.2; audit-after.json is the output (still has false positives: dark panels with gradient backgrounds, chevron glyphs).
