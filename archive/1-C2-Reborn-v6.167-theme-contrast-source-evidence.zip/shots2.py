import os,json,base64,sys
F=os.environ.get('C2F','c2-v6167-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
th=sys.argv[1];pgs=sys.argv[2].split(',');out=sys.argv[3]
from PIL import Image
ims=[]
for pg in pgs:
 ev("(()=>{notice='';open=false;pageSub=null;phoneState.theme=%s;document.body.dataset.theme=%s;page=%s;sel=1;draw()})()"%(json.dumps(th),json.dumps(th),json.dumps(pg)));time.sleep(.2)
 r=json.loads(ev("(()=>{let b=document.querySelector('.lcd').getBoundingClientRect();return JSON.stringify([b.x,b.y,b.width,b.height])})()"))
 d=call('Page.captureScreenshot',{'format':'png','clip':{'x':r[0],'y':r[1],'width':r[2],'height':r[3],'scale':2}})
 open('/tmp/_s.png','wb').write(base64.b64decode(d['result']['data']));ims.append(Image.open('/tmp/_s.png').convert('RGB').copy())
w,h=ims[0].size;S=Image.new('RGB',((w+6)*len(ims),h),'red')
for k,i in enumerate(ims):S.paste(i,(k*(w+6),0))
S.save(out);print(S.size)
