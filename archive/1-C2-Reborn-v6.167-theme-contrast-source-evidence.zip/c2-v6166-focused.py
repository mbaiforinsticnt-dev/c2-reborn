import os,json,base64
F=os.environ.get('C2F','c2-v6166-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(bool(v))
T="(()=>JSON.stringify({page,sel,t:document.querySelector('.lcd').innerText.replace(/\\n/g,'|')}))()"
def shot(n):
  d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/'+n,'wb').write(base64.b64decode(d['result']['data']))
def fresh():
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.5)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';go('gallery');sel=0;draw()})()")
fresh();ev("sel=5;draw();press('OK')");r=ev(T);print(r)
t('Gallery > Graphics lists Wallpapers/Clip-art/Frames titled Graphics',ev("page")=='gallerygraphicdownloads' and 'Graphics' in r and 'Wallpapers' in r and 'Clip-art' in r)
ev("press('OK')");r=ev(T);print(r);t('Wallpapers: 5 files with date/size',ev("page")=='wpfiles' and 'Winter.jpg' in r and '01-01-12' in r);time.sleep(.3);shot('c2-v6166-wallpapers-list.png')
ev("press('DOWN');press('OK')");r=ev(T);print(r);t('Select opens apply-mode list (galusewall)',ev("page")=='galusewall')
ev("sel=1;press('OK')");r=ev(T);print(r);ww=ev("JSON.stringify({n:phoneState.homeWallpaper&&phoneState.homeWallpaper.n,m:phoneState.homeWallpaper&&phoneState.homeWallpaper.mode,l:phoneState.homeWallpaper&&phoneState.homeWallpaper.src.length})");print(ww)
t('Applied Moorland, Fit to display, back on wallpaper list',ev("page")=='wpfiles' and 'Moorland.jpg' in ww and 'Fit' in ww)
ev("(()=>{history=[];page='home';draw()})()");time.sleep(.3);shot('c2-v6166-home-with-wallpaper.png');t('Home shows wallpaper img',ev("!!document.querySelector('.lcd img[src^=\"data:image/jpeg\"]')"))
ev("(()=>{notice='';open=false;go('wallpaperlist');sel=4;draw();press('OK');sel=1;draw();press('OK')})()");r=ev(T);print(r);t('Wallpaper > Graphic downlds > Wallpapers lists files',ev("page")=='wpfiles')
ev("press('RSK')");t('Back returns to Graphic downloads',ev("page")=='graphicdownloads')
fresh();ev("go('gallerygraphicdownloads');sel=0;draw()");r=ev(T);t('Options>Graphic downloads path keeps title',True)
fresh();ev("wpGraphicsTitle='Graphic downloads';go('gallerygraphicdownloads');sel=1;draw();press('OK')");t('Clip-art still empty page',ev("page")=='gallerydownloadempty')
fresh();ev("sel=0;press('OK')");t('Gallery Memory card OK unaffected (not Graphics)',ev("page")!='gallerygraphicdownloads')
print('checks',len(res),'pass',sum(res))
