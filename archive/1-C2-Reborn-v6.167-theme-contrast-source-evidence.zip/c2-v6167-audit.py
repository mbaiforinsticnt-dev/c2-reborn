import os,json,sys
F=os.environ.get('C2F','c2-v6167-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
js=r'''(()=>{let source=document.documentElement.outerHTML,from=source.indexOf('const screens='),to=source.indexOf('const route=',from),p=[...source.slice(from,to).matchAll(/\b([a-z][a-z0-9]+):\s*\[/g)].map(m=>m[1]);p.push(...[...source.matchAll(/page===['"]([a-z][a-z0-9]+)['"]/g)].map(m=>m[1]));p.push(...[...source.matchAll(/page=['"]([a-z][a-z0-9]+)['"]/g)].map(m=>m[1]));return [...new Set(p)]})()'''
pages=ev(js)
JS=r'''(th,pg)=>{try{notice='';open=false;pageSub=null;phoneState.theme=th;document.body.dataset.theme=th;page=pg;sel=1;draw();let s=document.querySelector('.screen');if(!s)return null;
const lum=c=>{let m=c.match(/[\d.]+/g);if(!m)return null;let [r,g,b]=m.slice(0,3).map(Number),a=m[3]===undefined?1:Number(m[3]);return {l:(r*.2126+g*.7152+b*.0722)/255,a}};
let sb=lum(getComputedStyle(s).backgroundColor);let sbl=(sb&&sb.a>.5)?sb.l:0;
let R=[];for(let e of s.querySelectorAll('*')){let txt=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();if(!txt||e.offsetWidth<3||e.offsetHeight<3)continue;let c=getComputedStyle(e);let t=lum(c.color);if(!t)continue;let bl=sbl,x=e;while(x&&x!==s){let b=lum(getComputedStyle(x).backgroundColor);let bi=getComputedStyle(x).backgroundImage;if(b&&b.a>.5){bl=b.l;break}if(bi&&bi!=='none'){bl=-1;break}x=x.parentElement}if(bl<0)continue;let hi=Math.max(t.l,bl),lo=Math.min(t.l,bl);let ratio=(hi+.05)/(lo+.05);if(ratio<2.2)R.push({c:(e.className||e.tagName).toString().slice(0,50),t:txt.slice(0,25),col:c.color,bgl:bl.toFixed(2),r:ratio.toFixed(1)})}return R}catch(ex){return {error:String(ex)}}}'''
out={}
for th in ['Nokia.nth','Light.nth','Simple.nth','Abstract.nth','Black.nth','Dark.nth','Legacy Black.nth','Mountains.nth']:
 res=[];err=0
 for pg in pages:
  r=ev("("+JS+")(%s,%s)"%(json.dumps(th),json.dumps(pg)))
  if isinstance(r,dict):err+=1;continue
  if r:res+= [dict(page=pg,**x) for x in r]
 out[th]=res
 from collections import Counter
 c=Counter((x['c'],x['col']) for x in res)
 print('\n',th,'flagged',len(res),'pages',len(set(x['page'] for x in res)),'err',err)
 for (cl,col),n in c.most_common(12):
  x=next(z for z in res if z['c']==cl and z['col']==col);print('  ',n,cl,col,x['page'],repr(x['t']),'ratio',x['r'])
json.dump(out,open('/tmp/c2-audit-%s.json'%F,'w'))
