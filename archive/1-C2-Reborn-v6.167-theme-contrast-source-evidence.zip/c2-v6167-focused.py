import os,json
F='c2-v6167-cand.html'
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(bool(v))
def setp(th,pg,unread=True):
 ev("(()=>{phoneState.theme=%s;document.body.dataset.theme=%s;messageStore.inbox[0].unread=%s;page=%s;sel=1;draw()})()"%(json.dumps(th),json.dumps(th),'true' if unread else 'false',json.dumps(pg)))
for th in ['Nokia.nth','Light.nth','Simple.nth','Abstract.nth']:
 for pg in ['home','names','menu']:
  setp(th,pg)
  f=ev("[...document.querySelectorAll('#statusBar .statusAsset')].filter(e=>e.offsetParent).map(e=>getComputedStyle(e).filter).join(',')")
  t('%s %s status icons dark (brightness(0))'%(th,pg),f and all(x=='brightness(0)' for x in f.split(',').__iter__() if x) or f.replace('brightness(0)','').replace(',','').replace(' ','')=='' and f!='')
for th in ['Black.nth','Dark.nth','Legacy Black.nth','Mountains.nth']:
 setp(th,'home');f=ev("[...document.querySelectorAll('#statusBar .statusAsset')].filter(e=>e.offsetParent).map(e=>getComputedStyle(e).filter).join(',')")
 t(th+' status icons unfiltered (white on black bar)',f.replace('none','').replace(',','')=='')
for th in ['Abstract.nth','Mountains.nth']:
 setp(th,'names');t(th+' Names has no theme picture',ev("getComputedStyle(document.querySelector('.screen')).backgroundImage")=='none')
 setp(th,'home');t(th+' home keeps theme picture',ev("getComputedStyle(document.querySelector('.screen')).backgroundImage")!='none')
for th in ['Simple.nth','Abstract.nth','Light.nth','Nokia.nth']:
 setp(th,'names');t(th+' unselected Names text dark',ev("getComputedStyle(document.querySelectorAll('.namesName')[2]).color")=='rgb(17, 17, 17)')
for th in ['Black.nth','Light.nth']:
 setp(th,'divertnum');t(th+' divert Number: label dark',ev("getComputedStyle(document.querySelector('.nfLabel')).color")=='rgb(17, 17, 17)')
setp('Mountains.nth','home');t('Mountains home theme label white',ev("getComputedStyle(document.getElementById('statusTheme')).color")=='rgb(255, 255, 255)')
print('checks',len(res),'pass',sum(res))
