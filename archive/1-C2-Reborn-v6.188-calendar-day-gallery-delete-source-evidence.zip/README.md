# C2 Reborn v6.188 (source-evidence)
Changes (both reproduced on v6.187):
1. Calendar note date: 31-02-2026 was accepted and the note jumped to March. Save now rejects impossible dates with notice "Invalid date" and stays on the note (valid dates such as 28-02-2026 save as before). Same intent as the To-do "Invalid due date/time" check.
2. Gallery file Options > Delete showed "Not implemented in this prototype" over the "Delete?" question (branch did not return). Fixed for Delete and Delete marked.
Evidence class: inferred (impossible dates invalid; a stray note over a working dialog), not C2-01 handset-proven.
Not changed: Calendar note delete confirm (no handset evidence), Notes Send as message, To-do RSK "Back" label, alarms (Calendar/To-do), Rename-in-Images level (not reproduced yet).
