exec(open("/tmp/hdr.py").read())
fresh2();ev("page='calendar';calDate=new Date(2026,9,3);calNoteStart('Reminder',-1)");ev("noteText='x';calNoteDateStr='31-02-2026'")
ev("calNoteSave()");print('bad',ev("[page,notice,phoneState.calendar.length]"))
ev("notice='';calNoteDateStr='28-02-2026'");ev("calNoteSave()");print('good',ev("[page,notice,phoneState.calendar.length]"))
st="[page,open,pageSub,sel,!!galDialog]"
def img():
    fresh2();ev("go('gallery')");S('DOWN');S('OK')
img();S('LSK');
for q in range(3):S('DOWN')
S('OK');print('delete seq',ev(st),ev(T)[-140:])
img();S('LSK');S('UP');S('UP');S('UP');S('UP');S('UP');print(ev(T)[-170:])
