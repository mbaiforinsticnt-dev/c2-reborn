exec(open("/tmp/hdr.py").read())
st="[page,open,pageSub,sel,!!galDialog,notice]"
for n in (1,2,3):
    fresh2();ev("go('gallery')");S('DOWN');S('OK');S('LSK')
    for q in range(n):S('DOWN')
    S('OK');print(n,ev(st),ev(T)[-110:])
fresh2();ev("go('gallery')");S('DOWN');S('OK');ev("galMarkMode=true;galMarked.add(galFolderFiles()[0].id||galFolderFiles()[0].n)");S('LSK')
for q in range(6):
    S('DOWN');print('mark opt',q,ev(T)[-60:])
