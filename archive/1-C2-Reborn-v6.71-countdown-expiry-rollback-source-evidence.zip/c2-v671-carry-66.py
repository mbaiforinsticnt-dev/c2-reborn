exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.71-countdown-expiry-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],sourceName:'a'.repeat(160)+'.jpg',stage:'view'};draw();press('OK');press('DOWN');press('OK')")
t('Default stem160 characters',"return galEditor.saveName.length===160")
ev("press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
t('Save164-character filename',"return galEditor.stage==='saved'&&phoneState.galEditedImages[0].n==='a'.repeat(160)+'.gif'")
call('Page.reload');time.sleep(.3)
t('Reload exact name retains extension',"return phoneState.galEditedImages[0].n==='a'.repeat(160)+'.gif'")
t('Moved identity key exact on migration',"let n=phoneState.galEditedImages[0].n;phoneState.galMoved={[n]:'Graphics'};let d=migrateState(phoneState);return d.galMoved[n]==='Graphics'")
t('Copied identity key exact',"let n=phoneState.galEditedImages[0].n;phoneState.galCopied={[n]:'Images'};let d=migrateState(phoneState);return d.galCopied[n]==='Images'")
t('Renamed identity key and display exact',"let n=phoneState.galEditedImages[0].n,m='b'.repeat(160)+'.gif';phoneState.galFileNames={[n]:m};let d=migrateState(phoneState);return d.galFileNames[n]===m")
t('Folder copy display and source exact',"let n=phoneState.galEditedImages[0].n;phoneState.galleryFolders=['L'];phoneState.galFolderItems=[{folder:'L',n:'copyfile-1',display:n,source:n,src:phoneState.galEditedImages[0].src}];let d=migrateState(phoneState);return d.galFolderItems[0].display===n&&d.galFolderItems[0].source===n")
t('Lengths remain bounded',"let d=migrateState({...phoneState,galFileNames:{x:'q'.repeat(1000)}});return d.galFileNames.x.length===164")
ev("phoneState.galMoved={};phoneState.galCopied={};phoneState.galFileNames={};galEditor=null;galFolderName='Images';page='galfolder';sel=galFolderFiles().findIndex(f=>f.n.endsWith('.gif'));open=true;os=currentOptions().indexOf('Details');draw();press('OK')")
time.sleep(.1)
d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v601-long-name-details.png','wb').write(base64.b64decode(d['result']['data']))
print('PASS',len(checks))
