from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.70-countdown-start-rollback-candidate.html').read_text().replace('v6.70 handset parity','v6.71 handset parity').replace('C2 Reborn v6.70 |','C2 Reborn v6.71 |')
a="if(phoneState.timerEndsAt&&Date.now()>=phoneState.timerEndsAt){let dur=phoneState.timerValue.split(':').reduce((a,x)=>a*60+(+x),0);if(phoneState.countdownAutoRepeat&&dur){phoneState.timerEndsAt=Date.now()+dur*1000;notice='Timer repeated'}else{phoneState.timerEndsAt=0;notice='Countdown finished'}persist();draw()}"
b="if(phoneState.timerEndsAt&&Date.now()>=phoneState.timerEndsAt){let beforeEnds=phoneState.timerEndsAt,dur=phoneState.timerValue.split(':').reduce((a,x)=>a*60+(+x),0),repeat=phoneState.countdownAutoRepeat&&dur;phoneState.timerEndsAt=repeat?Date.now()+dur*1000:0;try{persist();notice=repeat?'Timer repeated':'Countdown finished'}catch(err){phoneState.timerEndsAt=beforeEnds;notice='Unable to save timer'}draw()}"
assert s.count(a)==1
s=s.replace(a,b)
s=s.replace('Unable to save demo call|Folder memory full','Unable to save demo call|Unable to save timer|Folder memory full')
Path('/downloads/C2-Reborn-v6.71-countdown-expiry-rollback-candidate.html').write_text(s)
