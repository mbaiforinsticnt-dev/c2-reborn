from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.94-editor-gif-palette-candidate.html').read_text().replace('v5.94 handset parity','v5.95 handset parity').replace('C2 Reborn v5.94 |','C2 Reborn v5.95 |')
a=s.index('code(256);for(let i=0;i<w*h;');b=s.index('code(257);',a)
s=s[:a]+"""let dictionary=new Map(),next=258,prefix=-1;code(256);for(let i=0;i<w*h;i++){let p=i*4,index=quant.indices.get(((rgba[p]>>3)<<10)|((rgba[p+1]>>3)<<5)|(rgba[p+2]>>3));if(prefix<0){prefix=index;continue}let key=prefix*256+index,found=dictionary.get(key);if(found!==undefined){prefix=found;continue}code(prefix);if(next<500)dictionary.set(key,next++);else{code(256);dictionary.clear();next=258}prefix=index}if(prefix>=0)code(prefix);"""+s[b:]
Path('/downloads/C2-Reborn-v5.95-editor-gif-compression-candidate.html').write_text(s)
