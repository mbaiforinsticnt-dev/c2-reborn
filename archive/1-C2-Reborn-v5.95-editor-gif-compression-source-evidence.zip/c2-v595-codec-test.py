exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.95-editor-gif-compression-candidate.html'))
from PIL import Image
import numpy as np
checks=[]
for width,height in [(1,1),(2,1),(17,29),(240,320),(400,500)]:
 r=ev(f"(()=>{{let a=new Uint8ClampedArray({width}*{height}*4),seed=42;for(let p=0;p<a.length;p+=4){{seed=(seed*1664525+1013904223)>>>0;a[p]=(seed>>24);a[p+1]=(seed>>16)&255;a[p+2]=(seed>>8)&255;a[p+3]=255}}let q=galEditorPalette(a),expected=[];for(let p=0;p<a.length;p+=4)expected.push(...q.palette[q.indices.get(((a[p]>>3)<<10)|((a[p+1]>>3)<<5)|(a[p+2]>>3))]);return {{src:galEditorGif({width},{height},a).src,expected}}}})()")
 path=f'/tmp/c2-v595-random-{width}-{height}.gif';open(path,'wb').write(base64.b64decode(r['src'].split(',')[1]));a=np.asarray(Image.open(path).convert('RGB'));assert a.shape==(height,width,3);assert np.array_equal(a.flatten(),r['expected']);print('Random exact palette pixel decode',width,height,True);checks.append(True)
for name in ['AuditCopy','palette-primary','palette-gradient','palette-max']:
 a=Image.open('/downloads/c2-v594-'+name+'.gif').convert('RGB');b=Image.open('/downloads/c2-v595-'+name+'.gif').convert('RGB');assert np.array_equal(np.asarray(a),np.asarray(b));print('No palette pixel change',name,True);checks.append(True)
print('PASS',len(checks))
