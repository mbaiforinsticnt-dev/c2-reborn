# C2 Reborn behaviour rules (Moti)
Source: Moti's messages, kept in the repo (non-site folder). Add new rules at the bottom.

1. Centre key = the most common action on that screen.
2. Conversation view: selected message truncated in the list (cut at 3 lines with "...") => centre key "Open" (opens full message, marks it read: closed envelope -> open envelope). Fully visible received message => "Reply". Outgoing => "Open" (unchanged).
3. Opened message view: received => centre key "Reply"; sent/outgoing => "Send" (forward / resend to someone else). OK key follows the label. (v6.219)
4. The hardware OK key must always do what the centre label says (v6.218 fixed Conversation view; v6.219 opened message view).
5. Icons: original firmware files or sources Moti chose; never drawn, never Unicode glyphs; disclose crop/made/firmware.
6. Handset footage outranks emulator evidence, except list-opening arrows (follow emulator). Additions ship; removals need Moti's word or footage.
7. Key auto-repeat (Moti 12:46, 5 Oct): on every scrolling list/menu/text, holding Up/Down (and Left/Right where they move through items) for more than 0.8 s starts auto-scroll at 4 steps per second until release; stops on release; list end follows the emulator's wrap rule. A short press moves one step. One shared mechanism in pressStart/pressEnd (v6.221). Test: t240.py (short=1, 1.0s=1, 2.0s=5, release stops).
8. Equal row heights (Moti 14:43/14:44, 5 Oct; evidence: emulator Display settings frame): in every list, all rows on a page have the same height whether or not a row has a value line. Rows without a value leave the space empty; label at top, value text at the bottom of the row; selected row shows "‹ value ›" with a dark rounded highlight (Black/Nokia themes). Implemented v6.228 as a generic normaliser (any list with unequal rows gets equal rows) plus crawl check (rowh in a8 output).
