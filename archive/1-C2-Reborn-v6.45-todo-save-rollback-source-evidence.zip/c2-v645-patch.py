from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.44-note-save-rollback-candidate.html').read_text().replace('v6.44 handset parity','v6.45 handset parity').replace('C2 Reborn v6.44 |','C2 Reborn v6.45 |')
a="if(todoEditIdx>=0){if(phoneState.todos[todoEditIdx])_it.done=phoneState.todos[todoEditIdx].done;phoneState.todos[todoEditIdx]=_it;todoEditIdx=-1}else phoneState.todos.unshift(_it);persist();noteText='';"
b="let beforeTodos=phoneState.todos.slice(),beforeEditIdx=todoEditIdx;if(todoEditIdx>=0){if(phoneState.todos[todoEditIdx])_it.done=phoneState.todos[todoEditIdx].done;phoneState.todos[todoEditIdx]=_it;todoEditIdx=-1}else phoneState.todos.unshift(_it);try{persist()}catch(err){phoneState.todos=beforeTodos;todoEditIdx=beforeEditIdx;notice='Unable to save to-do note';draw();return}noteText='';"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save note|Folder memory full|';b='Unable to save note|Unable to save to-do note|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.45-todo-save-rollback-candidate.html').write_text(s)
