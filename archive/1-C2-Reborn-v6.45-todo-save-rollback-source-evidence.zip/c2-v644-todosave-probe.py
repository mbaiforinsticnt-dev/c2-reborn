exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.44-note-save-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);persist();stored=localStorage.getItem('c2state');page='todoedit';noteText='New todo';todoPri=1;todoDate=todoTodayDigits();todoTime='0900';todoAlarm=0;todoEditIdx=-1;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({todos:phoneState.todos,page,noteText,todoEditIdx,diskSame:localStorage.getItem('c2state')===stored})"))
