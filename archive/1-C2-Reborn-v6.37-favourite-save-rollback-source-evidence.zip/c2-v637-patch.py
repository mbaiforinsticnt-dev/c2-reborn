from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.36-bulk-contact-rollback-candidate.html').read_text().replace('v6.36 handset parity','v6.37 handset parity').replace('C2 Reborn v6.36 |','C2 Reborn v6.37 |')
a="function favApply(x){let f=phoneState.favourites=phoneState.favourites||[];if(favMode==='replace'){f[favReplaceIdx]=x;sel=favReplaceIdx}else{if(!f.some(e=>e.name===x.name&&e.number===x.number))f.push(x);sel=f.length-1}persist();go('favourites')}"
b="function favApply(x){let before=(phoneState.favourites||[]).slice(),previousSel=sel,f=phoneState.favourites=phoneState.favourites||[];if(favMode==='replace'){f[favReplaceIdx]=x;sel=favReplaceIdx}else{if(!f.some(e=>e.name===x.name&&e.number===x.number))f.push(x);sel=f.length-1}try{persist()}catch(err){phoneState.favourites=before;sel=previousSel;notice='Unable to save favourite';draw();return false}go('favourites');return true}"
assert s.count(a)==1;s=s.replace(a,b)
a='Unable to save contact transfer|Folder memory full|';b='Unable to save contact transfer|Unable to save favourite|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.37-favourite-save-rollback-candidate.html').write_text(s)
