from pathlib import Path
p=Path('/downloads/C2-Reborn-v5.56-contact-candidate.html');s=p.read_text()
s=s.replace('v5.55','v5.56').replace("CF_KEYS=['first','last'];","CF_KEYS=['last','first'];").replace("(k==='mobile'||cfAdded[k])","(k==='mobile'||k==='home'||cfAdded[k])").replace(".filter(k=>cfAdded[k]&&!cfHidden[k])",".filter(k=>(['email','image'].includes(k)||cfAdded[k])&&!cfHidden[k])").replace("cfNumType={mobile:0,home:2}","cfNumType={mobile:1,home:2}")
s=s.replace("let _cfN=CF_KEYS.length-1;contactField=(contactField+(k==='DOWN'?1:_cfN-1))%_cfN;","let _cfN=CF_KEYS.length;contactField=(contactField+(k==='DOWN'?1:_cfN-1))%_cfN;")
p.write_text(s)
import re
Path('/tmp/c2-v556.js').write_text('\n'.join(re.findall(r'<script[^>]*>(.*?)</script>',s,re.S)))
