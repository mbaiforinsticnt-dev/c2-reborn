import json,urllib.request,websocket,itertools,time,base64,sys
pages=json.load(urllib.request.urlopen('http://localhost:9223/json/list',timeout=3));p=next(x for x in pages if x.get('type')=='page');w=websocket.create_connection(p['webSocketDebuggerUrl'],timeout=7,suppress_origin=True);i=itertools.count(1)
def call(method,params={}):
 n=next(i);w.send(json.dumps({'id':n,'method':method,'params':params}));
 while True:
  x=json.loads(w.recv())
  if x.get('id')==n:return x

call('Page.navigate',{'url':'file:///downloads/C2-Reborn-v5.56-contact-upload-ready.html'});time.sleep(0.5)
def ev(expr):
 r=call('Runtime.evaluate',{'expression':expr,'returnByValue':True}).get('result',{});return r.get('result',{}).get('value',r.get('exceptionDetails'))
