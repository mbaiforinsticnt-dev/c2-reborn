# v5.56 contact correction, 30 September 2026

Exact source is the enclosed HTML and source.js. No index.html deployment.
Handset film first showed six fields; user confirmed completely fresh on 30 September at 12:14 BST. Defaults now Last name, First name, Mobile number, Home number, E-mail address, Image (No image), in that order. Blank softkeys Options / Save / Back. Add detail retains Number / Internet / Multimedia / Personal info. The earlier three-field assumption is superseded, not an SDK verdict.

Fixed final-field reachability (old length-1 navigation skipped Image) and scrolling to keep the entire active field visible above softkeys. Existing details and save payload preserved. 45 checks passed: 15 prior feature checks updated for six-field defaults, 9 Move/context, 14 old regressions, 7 focused contacts. Syntax passed. Mobile screenshots visually inspected top/bottom and Add detail.

Handset source evidence: first film 15.569 seconds, second 29.386 seconds. Half-second sampling inspected throughout, enlarged key frames included. First audio no speech detected; second commentary confirms Add detail categories and references the Amazon Web Service PDF. Media starts inside form; user confirmation establishes it was fresh. No personal contact values in screenshots.

This corrects field content/order and active-field visibility, not full pixel parity. Target picker Options, populated folder Move and collision dialogs remain open from v5.55.

HTML SHA-256 d6b51611707f9fb281b603e48aa6ab14cd5be2beac5d966e45a83446661efdb9
