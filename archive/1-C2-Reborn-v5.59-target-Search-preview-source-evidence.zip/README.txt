C2 Reborn v5.59 - destination Search and image preview, 2026-09-30
No index.html deployment.

Change:
- Prefix Search filters destination folders and files, using case-insensitive names.
- Search Options includes View all; Clear removes one character; empty-query Back closes Search in place.
- Open image preview stays in destination context. Back from Search preview retains query and resets to the first result, as captured in SDK 1414-1416.
- Preview Options includes View full screen and Details. Details Back returns to that menu.
- JPEG format derives from filename; resolution comes from loaded image dimensions, never an invented camera size.
- Details scroll reveals resolution. Two zoom stages change softkeys; Back steps down.
- Fixed preview softkey duplication and clipped Options overlay.

Checked:
17 target actions, 14 Search checks, 13 preview/context checks, 13 target edge checks;
contact 7, additional behavior 9, Move 6, general regression 15, older regression 14.
JavaScript syntax passed. Mobile pixels inspected for Search, preview, Options, Details, scrolling and both zoom stages.
SDK captures include actual 240 x 320 resolution, preview Details return, zoom stages and stepped Back, Search file Open and return, empty-query Search Back.

Limits:
This is a bounded candidate, not full screen-by-screen parity certification.
Root recursive Search remains explicitly unimplemented.
Exact zoom scale, panning and full-screen rotation parity are not certified.
Sample image sizes and dates remain fixture data, not hardware camera evidence.
Details does not yet model SDK Copyright data.
Handset evidence remains authoritative over SDK findings.

Rebuild:
Apply v5.58-to-v5.59.patch to the byte-exact v5.58 upload-ready HTML (SHA recorded in SHA256SUMS).
The included final HTML is authoritative. Test scripts use a local browser harness; adjust the local path when reproducing.
