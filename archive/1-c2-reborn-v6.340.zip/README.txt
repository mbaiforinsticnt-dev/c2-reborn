Group contact fix. Rebuild from314 using groupfix340.py then replace debug version v6.314 with v6.340. Demo only. No339/338 parity work included. Merge contact remains guarded.
