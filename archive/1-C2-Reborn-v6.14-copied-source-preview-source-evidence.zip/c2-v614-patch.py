from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.13-recovered-file-names-candidate.html').read_text().replace('v6.13 handset parity','v6.14 handset parity').replace('C2 Reborn v6.13 |','C2 Reborn v6.14 |')
a='function galFolderFiles()'
b="function galResolveFileSource(f){let original=Object.values(GAL_FILES).flat().find(v=>v.n===f.source);return {...f,src:f.src||original?.src,big:f.big||original?.big}}\nfunction galFolderFiles()"
assert s.count(a)==1;s=s.replace(a,b)
a="galActualFiles(folder).map(f=>({...f,key:f.n,n:galOwnText(phoneState.galFileNames,f.n)||f.display||f.n,folderRow:false}))"
b="galActualFiles(folder).map(galResolveFileSource).map(f=>({...f,key:f.n,n:galOwnText(phoneState.galFileNames,f.n)||f.display||f.n,folderRow:false}))";assert s.count(a)==1;s=s.replace(a,b)
a="galActualFiles(b).map(f=>({...f,n:galOwnText(phoneState.galFileNames,f.n)||f.display||f.n,folderRow:false}))"
b="galActualFiles(b).map(galResolveFileSource).map(f=>({...f,n:galOwnText(phoneState.galFileNames,f.n)||f.display||f.n,folderRow:false}))";assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.14-copied-source-preview-candidate.html').write_text(s)
