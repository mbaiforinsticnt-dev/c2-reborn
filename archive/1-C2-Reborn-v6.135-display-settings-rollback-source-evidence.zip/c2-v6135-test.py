exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.135-display-settings-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices={3:['Off','On'],4:['Show','Hide'],8:['On','Off']}
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in [3,4,8]:
  for choice in range(len(choices[row])):
   for absent in [False,True]:
    val=choices[row][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.dispVals;" if absent else "phoneState.dispVals=pickerDefaults('display');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.dispVals;stored=localStorage.getItem('c2state');history=['display'];notice='';noticeBack=false;open=false;"+("page='display';sel="+str(row)+";pickerDraft={page:'display',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'display',row:"+str(row)+",title:'Call setting',opts:"+json.dumps(choices[row])+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.dispVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='display'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save display setting'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and row==3 and choice==1 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6135-display-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.dispVals["+str(row)+"]==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.dispVals["+str(row)+"]==="+json.dumps(val))
print('PASS',len(checks))
