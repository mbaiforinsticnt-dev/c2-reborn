from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.26-contact-image-rollback-candidate.html').read_text().replace('v6.26 handset parity','v6.27 handset parity').replace('C2 Reborn v6.26 |','C2 Reborn v6.27 |')
s=s.replace("let modes=['Centre','Fit to display','Rotate left','Rotate right'];phoneState.homeWallpaper=","let had=Object.prototype.hasOwnProperty.call(phoneState,'homeWallpaper'),old=phoneState.homeWallpaper,modes=['Centre','Fit to display','Rotate left','Rotate right'];phoneState.homeWallpaper=")
s=s.replace('Unable to save contact image|Folder memory full|','Unable to save contact image|Unable to save wallpaper|Folder memory full|')
s=s.replace('mode:modes[sel]};persist();history=history.filter','mode:modes[sel]};try{persist()}catch(err){if(had)phoneState.homeWallpaper=old;else delete phoneState.homeWallpaper;notice=\'Unable to save wallpaper\';draw();return true}history=history.filter')
Path('/downloads/C2-Reborn-v6.27-wallpaper-rollback-candidate.html').write_text(s)
