exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.134-usb-mode-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices={4:['Ask on conn.','PC Suite','Printing & media','Data storage']}
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in [4]:
  for choice in range(len(choices[row])):
   for absent in [False,True]:
    val=choices[row][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.connVals;" if absent else "phoneState.connVals=pickerDefaults('connectivity');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.connVals;stored=localStorage.getItem('c2state');history=['connectivity'];notice='';noticeBack=false;open=false;"+("page='connectivity';sel="+str(row)+";pickerDraft={page:'connectivity',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'connectivity',row:"+str(row)+",title:'Call setting',opts:"+json.dumps(choices[row])+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.connVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='connectivity'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save USB mode'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and row==4 and choice==3 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6134-usb-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.connVals["+str(row)+"]==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.connVals["+str(row)+"]==="+json.dumps(val))
print('PASS',len(checks))
