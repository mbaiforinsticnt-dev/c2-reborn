from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.93-editor-save-copy-candidate.html').read_text().replace('v5.93 handset parity','v5.94 handset parity').replace('C2 Reborn v5.93 |','C2 Reborn v5.94 |')
a=s.index('let sum=Array.from({length:256}');b=s.index('b(44);',a)
s=s[:a]+"let quant=galEditorPalette(rgba);for(let v of quant.palette){b(v[0]);b(v[1]);b(v[2])}"+s[b:]
s=s.replace("code(((rgba[p]>>5)<<5)|((rgba[p+1]>>5)<<2)|(rgba[p+2]>>6))", "code(quant.indices.get(((rgba[p]>>3)<<10)|((rgba[p+1]>>3)<<5)|(rgba[p+2]>>3)))",1)
s=s.replace('function galEditorGif',Path('/tmp/c2-v594-palette.js').read_text()+'\nfunction galEditorGif',1)
Path('/downloads/C2-Reborn-v5.94-editor-gif-palette-candidate.html').write_text(s)
