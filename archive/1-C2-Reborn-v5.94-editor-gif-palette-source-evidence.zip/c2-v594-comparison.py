exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.94-editor-gif-palette-candidate.html'))
r=ev('GAL_PHOTOS[0]');open('/downloads/c2-v594-original.png','wb').write(base64.b64decode(r.split(',')[1]))
from PIL import Image
import numpy as np
original=np.asarray(Image.open('/downloads/c2-v594-original.png').convert('RGB')).astype(float)
for v in ['593','594']:
 a=np.asarray(Image.open('/downloads/c2-v'+v+'-AuditCopy.gif').convert('RGB')).astype(float)
 mask=np.ones(a.shape[:2],dtype=bool);mask[140:180,90:150]=False
 print(v,'RGB mean absolute error excluding text region',round(np.abs(a-original)[mask].mean(),3))
