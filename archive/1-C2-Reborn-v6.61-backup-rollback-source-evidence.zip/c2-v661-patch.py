from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.60-delete-all-messages-rollback-candidate.html').read_text().replace('v6.60 handset parity','v6.61 handset parity').replace('C2 Reborn v6.60 |','C2 Reborn v6.61 |')
a="localStorage.setItem('c2-local-backup',JSON.stringify({createdAt:Date.now(),data:snap}));return true}"
b="try{localStorage.setItem('c2-local-backup',JSON.stringify({createdAt:Date.now(),data:snap}))}catch(err){notice='Unable to save backup';return false}return true}"
assert s.count(a)==1;s=s.replace(a,b)
a="if(!b?.data)return false;phoneState=migrateState(b.data);messageStore=normalizeMessageStore(phoneState.messageStore)||seedMessageStore();phoneState.messageStore=messageStore;persist();return true}"
b="if(!b?.data)return false;let beforeState=phoneState,beforeStore=messageStore;phoneState=migrateState(b.data);messageStore=normalizeMessageStore(phoneState.messageStore)||seedMessageStore();phoneState.messageStore=messageStore;try{persist()}catch(err){phoneState=beforeState;messageStore=beforeStore;notice='Unable to restore backup';return null}return true}"
assert s.count(a)==1;s=s.replace(a,b)
a="makeLocalBackup();notice='Backup saved in this browser';draw();return";b="if(makeLocalBackup())notice='Backup saved in this browser';draw();return";assert s.count(a)==2;s=s.replace(a,b)
a="notice=restoreLocalBackup()?'Backup restored from this browser':'No local backup found';draw();return";b="let result=restoreLocalBackup();if(result!==null)notice=result?'Backup restored from this browser':'No local backup found';draw();return";assert s.count(a)==2;s=s.replace(a,b)
a='Unable to delete messages|Folder memory full|';b='Unable to delete messages|Unable to save backup|Unable to restore backup|Folder memory full|';assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.61-backup-rollback-candidate.html').write_text(s)
