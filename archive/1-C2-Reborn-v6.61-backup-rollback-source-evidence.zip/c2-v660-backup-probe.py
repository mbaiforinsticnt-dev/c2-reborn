exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.60-delete-all-messages-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
ev("phoneState=migrateState(null);phoneState.notes=['Backup'];makeLocalBackup();phoneState.notes=['Current'];persist();stored=localStorage.getItem('c2state');page='restorebackup';oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
print(ev("JSON.stringify({notes:phoneState.notes,page,notice,diskSame:localStorage.getItem('c2state')===stored})"))
