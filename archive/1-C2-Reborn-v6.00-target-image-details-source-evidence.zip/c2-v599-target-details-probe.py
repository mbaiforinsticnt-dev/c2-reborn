exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.99-copied-image-bytes-candidate.html'))
ev("phoneState=migrateState(null);page='galphoto';galFolderName='Images';galEditor={src:GAL_PHOTOS[0],stage:'saveName',saveName:'TargetProbe'};draw();press('OK')")
for _ in range(40):
 if ev('galEditor.stage')!='saving':break
 time.sleep(.05)
ev("galEditor=null;galTarget={op:'Copy',folder:'ProbeFolder',browse:'Images',trail:[]};page='galfoldertarget';sel=galTargetRows().findIndex(x=>x.n==='TargetProbe.gif');draw();press('OK');press('LSK');press('DOWN');press('OK')")
time.sleep(.1)
print(ev("JSON.stringify({pane:galTarget.pane,text:document.getElementById('screen').innerText})"))
