from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.99-copied-image-bytes-candidate.html').read_text().replace('v5.99 handset parity','v6.00 handset parity').replace('C2 Reborn v5.99 |','C2 Reborn v6.00 |')
a="format:/\\.jpe?g$/i.test(t.preview.n)?'JPEG':'',src:t.preview.big||t.preview.src||''"
b="format:/^data:image\\/gif;base64,/.test(t.preview.big||t.preview.src||'')?'GIF':/\\.jpe?g$/i.test(t.preview.n)?'JPEG':'',src:t.preview.big||t.preview.src||''"
assert s.count(a)==1;s=s.replace(a,b)
a="t.detail={n:r.n,s:r.s,d:r.folderRow?galFolderCreated(r.key):(r.d||'')};"
b="t.detail={n:r.n,s:r.s,d:r.folderRow?galFolderCreated(r.key):(r.d||''),...(!r.folderRow&&/^data:image\\/gif;base64,/.test(r.big||r.src||'')?{format:'GIF',src:r.big||r.src}:{})};"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v6.00-target-image-details-candidate.html').write_text(s)
