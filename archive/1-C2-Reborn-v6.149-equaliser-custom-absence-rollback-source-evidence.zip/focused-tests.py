exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.149-equaliser-custom-absence-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for preset in ['Set 1','Loudest']:
 for state in ['absent','undefined','existing']:
  ev("phoneState=migrateState(null);"+{'absent':"delete phoneState.eqCustom;",'undefined':"phoneState.eqCustom=undefined;",'existing':"phoneState.eqCustom={'Set 1':[1,2,3,4,5],Loudest:[5,4,3,2,1]};"}[state]+"persist();before=JSON.stringify(phoneState);beforeOwn=Object.prototype.hasOwnProperty.call(phoneState,'eqCustom');beforeCustom=phoneState.eqCustom;stored=localStorage.getItem('c2state');notice='';noticeBack=false;page='home';history=[];open=false;eqEdit=null;go('equaliser');sel=EQ_PRESETS.indexOf("+json.dumps(preset)+");draw();press('LSK');press('OK');press('RIGHT');press('DOWN');editor=eqEdit;draftBands=eqEdit.heights.slice();beforeHistory=JSON.stringify(history);oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('LSK')")
  name=preset+' '+state
  t(name+' exact rollback',"return JSON.stringify(phoneState)===before&&Object.prototype.hasOwnProperty.call(phoneState,'eqCustom')===beforeOwn&&phoneState.eqCustom===beforeCustom&&localStorage.getItem('c2state')===stored")
  t(name+' active editor retained',"return page==='equaliser'&&eqEdit===editor&&JSON.stringify(eqEdit.heights)===JSON.stringify(draftBands)&&JSON.stringify(history)===beforeHistory&&notice==='Unable to save equaliser'")
  if preset=='Set 1' and state=='absent':
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6149-equaliser-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("Storage.prototype.setItem=oldStore;notice='';press('LSK')")
  t(name+' retry',"return eqEdit===null&&notice==='Saved'&&JSON.stringify(phoneState.eqCustom["+json.dumps(preset)+"])===JSON.stringify(draftBands)")
  if state=='existing':t(name+' other preset retained',"return JSON.stringify(phoneState.eqCustom["+json.dumps('Loudest' if preset=='Set 1' else 'Set 1')+"])===JSON.stringify(beforeCustom["+json.dumps('Loudest' if preset=='Set 1' else 'Set 1')+"])")
  expected=ev("JSON.stringify(phoneState.eqCustom)")
  call('Page.reload')
  for _ in range(40):
   time.sleep(.025)
   if ev("typeof phoneState!=='undefined'") is True:break
  t(name+' reload',"return JSON.stringify(phoneState.eqCustom)==="+json.dumps(expected))
print('PASS',len(checks))
