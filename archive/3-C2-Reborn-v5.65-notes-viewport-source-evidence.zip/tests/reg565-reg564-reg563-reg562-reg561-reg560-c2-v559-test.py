exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.65-notes-viewport-candidate.html'))
checks=[
('start target',"phoneState=migrateState(null);phoneState.galleryFolders=['P','C'];phoneState.galFolderParents.P='Graphics';phoneState.galFolderParents.C='P';phoneState.galCopied={'Photo0001.jpg':'P'};page='galfolder';galFolderName='Graphics';sel=0;open=true;os=currentOptions().indexOf('Move folder');history=[];notice='';pageSub=null;galFolderMoveStart();return page==='galfoldertarget'&&galTarget.folder==='P'&&galTargetRows()[0].key==='Memory card'"),
('root exact options',"return currentOptions().join('|')==='Open drive|Add folder|Details|Type of view ▸|Sort ▸|Search'"),
('card only real children',"press('LSK');press('OK');return galTarget.browse==='Memory card'&&galTargetRows().length===0"),
('empty centre Add',"press('OK');return page==='foldername'&&galTarget.adding"),
('add no source mutation',"folderName='M';press('OK');return page==='galfoldertarget'&&galTargetRows()[sel].n==='M'&&phoneState.galFolderParents.P==='Graphics'&&phoneState.galFolderParents.M==='Memory card'"),
('open new folder',"press('LSK');press('OK');return galTarget.browse==='M'&&galTargetRows().length===0"),
('nested Back restores',"press('RSK');return galTarget.browse==='Memory card'&&galTargetRows()[sel].n==='M'"),
('back root',"press('RSK');return galTarget.browse===''&&sel===0"),
('open Images',"sel=1;press('LSK');press('OK');return galTarget.browse==='Images'&&galTargetRows().some(r=>!r.folderRow)"),
('file options no folder open',"sel=galTargetRows().findIndex(r=>!r.folderRow);return currentOptions().join('|')==='Add folder|Details|Type of view ▸|Sort ▸|Search'"),
('file Details and Back',"press('LSK');press('DOWN');press('OK');let ok=page==='galfoldertarget'&&galTarget.pane==='details';press('RSK');return ok&&page==='galfoldertarget'&&galTarget.browse==='Images'"),
('view submenu reachable',"press('LSK');press('DOWN');press('DOWN');press('OK');return galTarget.pane==='view'&&galTargetMenuRows().length===3"),
('view changes',"press('DOWN');press('OK');return phoneState.galView==='List'&&!galTarget.pane"),
('sort and direction',"press('LSK');os=currentOptions().indexOf('Sort ▸');press('OK');press('DOWN');press('OK');press('DOWN');press('OK');return phoneState.galSort==='By date Descending'&&notice==='Sorted'"),
('root fixed order',"notice='';press('RSK');return galTargetRows()[0].key==='Memory card'&&galTargetRows()[1].key==='Images'"),
('cancel restores source',"press('RSK');return page==='galfolder'&&galFolderName==='Graphics'&&open&&currentOptions()[os]==='Move folder'&&phoneState.galFolderParents.P==='Graphics'"),
('nested move complete subtree',"open=false;sel=0;galFolderMoveStart();sel=1;press('LSK');press('OK');phoneState.galleryFolders.push('Dest');phoneState.galFolderParents.Dest='Images';sel=galTargetRows().findIndex(r=>r.key==='Dest');press('OK');return phoneState.galFolderParents.P==='Dest'&&phoneState.galFolderParents.C==='P'&&galActualFiles('P').length===1&&page==='galfolder'"),
]
for label,x in checks:
 z=ev('(()=>{'+x+'})()');print(label,z);assert z is True,(label,z)
print('PASS',len(checks))
