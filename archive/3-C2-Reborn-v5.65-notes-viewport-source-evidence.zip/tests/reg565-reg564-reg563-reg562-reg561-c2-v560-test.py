exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.65-notes-viewport-candidate.html'))
checks=[
('seed full contacts',"phoneState=migrateState(null);phoneState.contacts=[{name:'Jane Doe',number:'123',store:'SIM',home:'456',email:'j@example.invalid',image:'Photo0001.jpg',company:'C',extra:{a:1},marked:true},{name:'John Doe',number:'789',store:'Phone'}];page='names';sel=0;history=[];open=true;os=currentOptions().indexOf('Edit >');notice='';noticeArmed='';clearTimeout(noticeTimer);draw();namesSubmenu=null;press('OK');press('DOWN');press('DOWN');return namesSubmenu==='Edit'&&os===2"),
('Copy asks without mutation',"press('OK');return contactMemoryPending.action==='Copy'&&contactMemoryPending.destination==='Phone'&&phoneState.contacts.length===2&&sm.textContent==='Yes'&&sr.textContent==='No'&&sl.textContent===''"),
('prompt escaped',"return document.querySelector('#screen').textContent.includes('Copy Jane Doe to phone memory?')"),
('unrelated key no-op',"press('UP');press('CALL');press('LSK');return !!contactMemoryPending&&phoneState.contacts.length===2"),
('No restores exact submenu',"press('RSK');return !contactMemoryPending&&namesSubmenu==='Edit'&&os===2&&optParent.list[optParent.os]==='Edit >'&&phoneState.contacts.length===2"),
('Copy Yes performs deep copy',"press('OK');press('OK');let a=phoneState.contacts;return page==='contact'&&contactIndex===1&&a.length===3&&a[0].store==='SIM'&&a[1].store==='Phone'&&a[0]!==a[1]&&a[0].extra!==a[1].extra&&a[1].email==='j@example.invalid'&&a[1].home==='456'&&a[1].image==='Photo0001.jpg'&&a[1].company==='C'&&!a[1].marked&&a[0].marked"),
('Back selects copied row',"press('RSK');return page==='names'&&sel===1&&!open&&!namesSubmenu&&!optParent"),
('move collision stays honest',"press('LSK');os=currentOptions().indexOf('Edit >');press('OK');press('DOWN');press('OK');let asks=contactMemoryPending.destination==='SIM';press('OK');return asks&&notice==='Not implemented in this prototype'&&phoneState.contacts.length===3&&phoneState.contacts[1].store==='Phone'&&namesSubmenu==='Edit'&&os===1"),
('move noncollision asks',"notice='';noticeArmed='';clearTimeout(noticeTimer);draw();namesSubmenu=null;optParent=null;open=false;sel=2;draw();press('LSK');os=currentOptions().indexOf('Edit >');press('OK');press('DOWN');press('OK');return contactMemoryPending.action==='Move'&&contactMemoryPending.destination==='SIM'&&phoneState.contacts[2].store==='Phone'"),
('Move Cancel no mutation',"press('BACK');return namesSubmenu==='Edit'&&os===1&&phoneState.contacts[2].store==='Phone'"),
('Move Yes changes only memory',"press('OK');press('OK');return page==='contact'&&contactIndex===2&&phoneState.contacts.length===3&&phoneState.contacts[2].store==='SIM'&&phoneState.contacts[2].number==='789'"),
('editing preserves SIM store',"editingContact=true;loadContactToForm(phoneState.contacts[2]);contactFirst='John';contactName='Doe';saveContact();return phoneState.contacts[2].store==='SIM'"),
('reload retains memory copies',"let a=migrateState(JSON.parse(localStorage.getItem('c2state'))).contacts;return a.length===3&&a[0].store==='SIM'&&a[1].store==='Phone'&&a[2].store==='SIM'&&a[1].company==='C'&&a[1].email==='j@example.invalid'"),
('END cancels pending copy',"page='names';sel=0;open=true;os=currentOptions().indexOf('Edit >');press('OK');os=2;press('OK');press('END');return page==='home'&&!contactMemoryPending&&!namesSubmenu&&phoneState.contacts.length===3"),
]
for n,e in checks:
 z=ev('(()=>{'+e+'})()');print(n,z);assert z is True,(n,z)
print('PASS',len(checks))
