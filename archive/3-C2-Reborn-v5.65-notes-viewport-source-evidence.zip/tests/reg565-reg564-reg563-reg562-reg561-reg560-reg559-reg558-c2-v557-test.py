exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.65-notes-viewport-candidate.html'))
import base64
checks=[
('handset 6 defaults',"cfReset();return CF_KEYS.join('|')==='last|first|mobile|home|email|image'&&CF_LABELS[2]==='Mobile number:'"),
('existing rich contact retained',"loadContactToForm({first:'A',last:'B',number:'123',home:'456',email:'a@test.invalid',inet:'sip:a@test.invalid',image:'Photo0001.jpg',web:'https://example.com'});return ['home','email','inet','image','web'].every(k=>CF_KEYS.includes(k))&&contactHome==='456'"),
('optional home add',"cfReset();page='addcontact';detailSub='number';ds=2;open=false;press('OK');return CF_KEYS.includes('home')&&contactField===CF_KEYS.indexOf('home')"),
('optional email add',"cfReset();detailSub='internet';ds=1;press('OK');return CF_KEYS.includes('email')&&contactField>=0"),
('optional image add',"cfReset();detailSub='multimedia';ds=1;press('OK');return CF_KEYS.includes('image')&&contactField>=0"),
('empty shared explorer menu',"phoneState=migrateState(null);phoneState.galleryFolders=['Empty'];page='galfolder';galFolderName='Empty';sel=0;open=false;detailSub=null;draw();return currentOptions().join('|')===galExplorerOptions().join('|')&&document.body.innerText.includes('Options')"),
('empty Add nested parent',"press('OK');return page==='foldername'&&galAddParent==='Empty'"),
('nested row shared explorer menu',"phoneState.galFolderParents.Empty='Images';page='galfolder';galFolderName='Images';sel=0;open=false;draw();return galFolderFiles()[sel].folderRow&&currentOptions().join('|')===galExplorerOptions().join('|')"),
('photo item specific menu',"sel=1;return currentOptions().includes('Use image')&&currentOptions().includes('Open in sequence')"),
('plain open retains index',"phoneState=migrateState(null);galFolderName='Images';page='galfolder';sel=2;history=[];open=false;pageSub=null;press('OK');return page==='galphoto'&&sel===2"),
('sequence selected start',"back();sel=1;galSequenceStart();clearTimeout(galSequence.timer);return page==='galphoto'&&sel===1&&galFullScreen&&galSequence.indices[0]===1"),
('sequence arrows ignored',"let before=sel;for(let k of ['LEFT','RIGHT','UP','DOWN','OK'])press(k);return sel===before&&!!galSequence"),
('sequence Stop current photo',"galSequenceAdvance();clearTimeout(galSequence.timer);let before=sel;press('RSK');return page==='galphoto'&&sel===before&&!galSequence&&!galFullScreen"),
('sequence back original list selection',"back();sel=1;galSequenceStart();let orig=galSequence.start;while(galSequence){clearTimeout(galSequence.timer);galSequenceAdvance()}return page==='galfolder'&&sel===orig&&history.length===0"),
('sequence no images honest',"galFolderName='Empty';phoneState.galleryFolders=['Empty'];page='galfolder';sel=0;galSequenceStart();return !galSequence&&notice==='No images'"),
]
for label,expr in checks:
 z=ev('(()=>{'+expr+'})()');print(label,z);assert z is True,(label,z)
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for label,expr in [('empty-explorer',"phoneState=migrateState(null);phoneState.galleryFolders=['Empty'];page='galfolder';galFolderName='Empty';sel=0;notice='';open=false;draw()"),('empty-options',"press('LSK')"),('contact-defaults',"open=false;pageSub=null;cfReset();page='addcontact';contactField=0;notice='';draw()"),('slideshow',"phoneState=migrateState(null);galFolderName='Images';page='galfolder';sel=0;open=false;history=[];galSequenceStart();clearTimeout(galSequence.timer)"),('slideshow-stop',"press('RSK')")]:
 ev(expr);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path='/downloads/c2-v558-'+label+'.png';open(path,'wb').write(base64.b64decode(r['result']['data']));print(path)
print('PASS',len(checks))
