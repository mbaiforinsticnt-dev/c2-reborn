exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v5.65-notes-viewport-candidate.html'))
import base64
checks=[
('populated subtree preserved',"phoneState=migrateState(null);phoneState.galleryFolders=['P','C'];phoneState.galFolderParents.C='P';phoneState.galCopied={'Photo0001.jpg':'P','Photo0002.jpg':'C'};let b=galFolderBytes('P');let r=galMoveEmptyFolderTo('P','Images');return r.key==='P'&&galChildFolders('Images').includes('P')&&galChildFolders('P').includes('C')&&galActualFiles('P').length===1&&galActualFiles('C').length===1&&galFolderBytes('P')===b"),
('reload preserves subtree',"phoneState=migrateState(JSON.parse(localStorage.getItem('c2state')));return phoneState.galFolderParents.P==='Images'&&phoneState.galFolderParents.C==='P'&&galActualFiles('C').length===1"),
('descendant cycle blocked',"let r=galMoveEmptyFolderTo('P','C');return !!r.error&&phoneState.galFolderParents.P==='Images'"),
('same-name clash no mutation',"phoneState.galleryFolders.push('D');phoneState.galFolderNames.D='P';phoneState.galFolderParents.D='Video clips';let r=galMoveEmptyFolderTo('P','Video clips');return r.error==='Name already exists'&&phoneState.galFolderParents.P==='Images'&&galActualFiles('P').length===1"),
('clash returns source Options',"page='galfolder';galFolderName='Images';sel=0;open=true;os=currentOptions().indexOf('Move folder');history=[];notice='';pageSub=null;galFolderMoveStart();sel=2;press('OK');return page==='galfolder'&&galFolderName==='Images'&&open&&currentOptions()[os]==='Move folder'&&notice==='Name already exists'&&galTarget===null"),
('successful populated action clamps source',"notice='';open=true;os=currentOptions().indexOf('Move folder');galFolderMoveStart();sel=3;press('OK');return page==='galfolder'&&galFolderName==='Images'&&phoneState.galFolderParents.P==='Music files'&&!open&&sel<galFolderFiles().length&&notice==='Moved to Music files'"),
]
for label,expr in checks:
 z=ev('(()=>{'+expr+'})()');print(label,z);assert z is True,(label,z)
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
for label,expr in [('populated-destination',"notice='';open=false;galFolderName='P';page='galfolder';sel=0;draw()"),('collision',"page='galfolder';galFolderName='Music files';sel=0;history=[];open=false;os=currentOptions().indexOf('Move folder');galFolderMoveStart();sel=2;press('OK')")]:
 ev(expr);r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});path='/downloads/c2-v558-'+label+'.png';open(path,'wb').write(base64.b64decode(r['result']['data']));print(path)
print('PASS',len(checks))
