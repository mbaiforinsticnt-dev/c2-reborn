from pathlib import Path
s=Path('/downloads/C2-Reborn-v5.64-note-identity-upload-ready.html').read_text()
s=s.replace('v5.64','v5.65')
a="let a=phoneState.notes.map(x=>x.length>32?x.slice(0,31)+'...':x);s.innerHTML='<div class=\"title\">Notes</div><div class=\"rows\">'+a.map((x,i)=>'<div class=\"row '+(i===sel?'sel':'')+'\"><span>'+esc(x)+'</span></div>').join('')+'</div>';"
b="let a=phoneState.notes.map(x=>x.length>32?x.slice(0,31)+'...':x);sel=Math.max(0,Math.min(sel,a.length-1));let start=Math.max(0,Math.min(sel-3,a.length-5));s.innerHTML='<div class=\"title\">Notes</div><div class=\"rows\" style=\"overflow:hidden\">'+a.slice(start,start+5).map((x,j)=>'<div class=\"row '+(start+j===sel?'sel':'')+'\"><span>'+esc(x)+'</span></div>').join('')+'</div>';"
assert s.count(a)==1;s=s.replace(a,b)
Path('/downloads/C2-Reborn-v5.65-notes-viewport-candidate.html').write_text(s)
