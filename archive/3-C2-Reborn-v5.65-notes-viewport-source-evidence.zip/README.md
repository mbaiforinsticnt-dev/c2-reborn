# C2 Reborn v5.65: Notes list viewport

No index deployment. v5.64 baseline is delivered but pending remote banking after two browser submission failures. This snapshot includes its Notes identity and paired-metadata fixes.

Notes now renders a five-row window following its selected index, matching the existing list-window policy. Selection clamps when a list shrinks. No item/action indices or metadata are remapped.

12 focused checks and 143 carried checks pass. JavaScript syntax checked. First/middle/last/wrap mobile pixels inspected. Before capture shows selection Note 12 outside LCD while only 1-5 are visible; after capture shows Note 12 visible and selected. View/Back, last-row Delete plus stamp, wrap, short lists, stale selection and escaping tested.

This is a build visibility repair, not a fresh handset/SDK pixel-parity certificate. Wider Notes Send as message/calendar/Bluetooth workflows remain unclaimed. All earlier Contacts evidence gaps remain. No public index change.
