import os,json
F=os.environ.get('C2F','c2-v6153-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({ps:JSON.stringify(phoneState),page,sel,notice,td:tonesFormDirty,rc:!!radioCtx}))()"
def run(name,pg,row,pre=[]):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';profileTonesFor=1;go('%s');sel=%d;draw()})()"%(pg,row))
 print(name,ev("(()=>{press('LSK');return [page,open,JSON.stringify(opts[page]),os]})()"))
 ev("press('OK')");print(' after Change:',ev("[page,!!radioCtx,radioCtx&&radioCtx.title,radioCtx&&JSON.stringify(radioCtx.opts)]"))
 b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{let o=[];for(const k of ['DOWN','OK']){try{press(k)}catch(e){o.push(k+' THROW '+e.message)}}return o})()")
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(' ->',r,'diff',[k for k in b if b[k]!=a[k]],'storedSame',ev("localStorage.getItem('c2state')")==st,repr(a['notice']),'td',b['td'],a['td'])
 return b,a
for row in (0,2): run('tones row%d'%row,'tones',row)
run('profiletones row0','profiletones',0)
