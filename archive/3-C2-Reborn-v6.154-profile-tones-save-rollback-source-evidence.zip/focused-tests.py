import os,json
F=os.environ.get('C2F','c2-v6154-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
res=[]
def t(n,v):print(n,v);res.append(v);assert v is True,n
SN="(()=>({ps:JSON.stringify(phoneState),td:tonesFormDirty}))()"
def fresh(setup):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice='';profileTonesFor=1;"+setup+"})()")
def keys(k): return ev("(()=>{for(const x of %s){try{press(x)}catch(e){return 'THROW '+e.message}}return 'ok'})()"%json.dumps(k))
def case(name,setup,k,note,ok):
 fresh(setup);b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=keys(k);a=ev(SN);n=ev("notice");ev('Storage.prototype.setItem=oldStore;0')
 t(name+' no throw',r=='ok');[print('DIFF',k,str(b[k])[:0],[ (str(b[k])[max(0,j-50):j+50],str(a[k])[max(0,j-50):j+50]) for j in [next((j for j in range(min(len(str(b[k])),len(str(a[k])))) if str(b[k])[j]!=str(a[k])[j]),0)]]) for k in b if b[k]!=a[k]];t(name+' state unchanged',a==b);t(name+' storage unchanged',ev("localStorage.getItem('c2state')")==st);t(name+' notice',n==note)
 fresh(setup);keys(k);t(name+' success',ev(ok))
RAD="radioCtx={title:'Incoming call alert',opts:['Ringing','Ascending','Ring once','Beep once','Off'],row:0,page:'%s'};go('radiolist');sel=1;profileToneStore(screens.profiles[1]);draw()"
case('tones radio',RAD%'tones',['OK'],'Unable to save tone setting',"JSON.parse(localStorage.getItem('c2state')).tones.alert=='Ascending'||JSON.parse(localStorage.getItem('c2state')).tones.alert!='Ringing'")
case('profiletones radio',RAD%'profiletones',['OK'],'Unable to save tone setting',"JSON.stringify(JSON.parse(localStorage.getItem('c2state')).profileTones)!='{}'")
case('tones save',"go('tones');sel=3;draw()",['OK'],'Unable to save tone settings',"notice.startsWith('Saved to profile')")
case('profiletones save',"go('profiletones');sel=3;draw()",['OK'],'Unable to save tone settings',"notice.startsWith('Saved to profile')")
print('checks',len(res))
