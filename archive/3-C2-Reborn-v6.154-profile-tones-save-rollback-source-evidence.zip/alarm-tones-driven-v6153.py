import os,json
F=os.environ.get('C2F','c2-v6153-cand.html')
exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///tmp/'+F))
SN="(()=>({ps:JSON.stringify(phoneState),page,sel,notice,td:tonesFormDirty,open}))()"
def run(name,setup,keys):
 call('Page.navigate',{'url':'file:///tmp/'+F});time.sleep(0.4)
 ev("(()=>{localStorage.clear();phoneState=migrateState(null);persist();page='home';history=[];open=false;notice=''})()")
 s=ev("(()=>{"+setup+";return [page,sel,document.getElementById('screen').innerText.replace(/\\n/g,'|').slice(0,160)]})()")
 b=ev(SN);st=ev("localStorage.getItem('c2state')")
 ev("oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};0")
 r=ev("(()=>{let o=[];for(const k of %s){try{press(k)}catch(e){o.push(k+' THROW '+e.message)}}return o})()"%json.dumps(keys))
 a=ev(SN);ev('Storage.prototype.setItem=oldStore;0')
 print(name,s[0],s[1],'->',r,'diff',[k for k in b if b[k]!=a[k]],'storedSame',ev("localStorage.getItem('c2state')")==st,repr(a['notice']))
for j in range(5): run("alarm sel%d"%j,"go('alarmclock');sel=%d;draw()"%j,['OK'])
run('tones row0 radio',"go('tones');sel=0;draw()",['OK','DOWN','OK'])
run('tones row1 radio',"go('tones');sel=1;draw()",['OK','DOWN','OK'])
run('profiletones row0 radio',"profileTonesFor=1;go('profiletones');sel=0;draw()",['OK','DOWN','OK'])
for j in (5,6,8,12): run("tones OK sel%d"%j,"go('tones');sel=%d;draw()"%j,['OK'])
run('profiletones OK sel11',"profileTonesFor=1;go('profiletones');sel=11;draw()",['OK'])
