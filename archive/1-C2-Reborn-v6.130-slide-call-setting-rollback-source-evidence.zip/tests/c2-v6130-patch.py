from pathlib import Path
s=Path('/downloads/C2-Reborn-v6.129-pin-request-setting-rollback-candidate.html').read_text().replace('v6.129 handset parity','v6.130 handset parity').replace('C2 Reborn v6.129 |','C2 Reborn v6.130 |')
repls=[("else if(p==='slidecall'){if(!phoneState.slideVals)phoneState.slideVals=pickerDefaults(p);phoneState.slideVals[i]=v}", "else if(p==='slidecall'){let had=Object.prototype.hasOwnProperty.call(phoneState,'slideVals'),before=phoneState.slideVals;phoneState.slideVals=(before||pickerDefaults(p)).slice();phoneState.slideVals[i]=v;try{persist()}catch(err){if(had)phoneState.slideVals=before;else delete phoneState.slideVals;notice='Unable to save slide call setting';return false}return true}"), ("pickerCommit('slidecall',_r,_cv);persist();radioCtx=null;back();", "if(pickerCommit('slidecall',_r,_cv)===false){draw();return}radioCtx=null;back();")]
for a,b in repls:
 assert s.count(a)==1
 s=s.replace(a,b)
s=s.replace('Unable to save PIN request setting|Folder memory full','Unable to save PIN request setting|Unable to save slide call setting|Folder memory full');Path('/downloads/C2-Reborn-v6.130-slide-call-setting-rollback-candidate.html').write_text(s)
