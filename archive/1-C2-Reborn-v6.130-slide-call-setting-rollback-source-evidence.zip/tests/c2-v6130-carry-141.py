exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.130-slide-call-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for key in ['LSK','OK']:
 for idx in range(7):
  ev("phoneState=migrateState(null);messageStore=seedMessageStore();phoneState.messageStore=messageStore;messageStore.marked=['alex','synthetic-1'];messageStore.hidden=[2];messageStore.markFilter='';persist();before=JSON.stringify(messageStore);marksAlias=messageStore.marked;hiddenAlias=messageStore.hidden;threadsAlias=messageStore.threads;alexAlias=messageStore.threads.alex;beforeDemo=DEMO_THREAD;stored=localStorage.getItem('c2state');page='conversations';sel=0;history=['messaging'];conversationListSubmenu='Mark';os="+str(idx)+";open=false;oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press("+json.dumps(key)+")")
  label=key+' '+str(idx)
  t(label+' rollback',"return JSON.stringify(messageStore)===before&&messageStore.marked===marksAlias&&messageStore.hidden===hiddenAlias&&messageStore.threads===threadsAlias&&messageStore.threads.alex===alexAlias&&DEMO_THREAD===beforeDemo&&localStorage.getItem('c2state')===stored")
  t(label+' context',"return conversationListSubmenu==='Mark'&&page==='conversations'&&sel===0&&os==="+str(idx)+"&&notice==='Unable to save conversation marks'&&document.getElementById('screen').innerText.includes(notice)")
  if key=='LSK' and idx==2:
   d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6117-marks-error.png','wb').write(base64.b64decode(d['result']['data']))
  ev("notice='';press("+json.dumps(key)+")")
  t(label+' repeat failure',"return JSON.stringify(messageStore)===before&&conversationListSubmenu==='Mark'")
  ev("Storage.prototype.setItem=oldStore;notice='';press("+json.dumps(key)+")")
  conditions=["messageStore.marked.includes('alex')","!messageStore.marked.includes('alex')","messageStore.threads.alex.length===0&&messageStore.hidden.includes(0)&&messageStore.marked.length===0","messageStore.marked.includes('alex')&&messageStore.marked.length>100&&messageStore.markFilter===''","messageStore.marked.length===0&&messageStore.markFilter===''","messageStore.markFilter==='marked'","messageStore.markFilter==='unmarked'"]
  t(label+' retry',"return conversationListSubmenu===''&&("+conditions[idx]+")")
  saved=ev('JSON.stringify(messageStore)');call('Page.reload');time.sleep(.15)
  t(label+' reload',"return JSON.stringify(messageStore)==="+json.dumps(saved))
print('PASS',len(checks))
