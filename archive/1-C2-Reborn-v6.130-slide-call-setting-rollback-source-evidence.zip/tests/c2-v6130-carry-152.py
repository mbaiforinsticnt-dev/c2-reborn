exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.130-slide-call-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices={2:['Off','On'],3:['Off','On'],5:['Off','On'],7:['GSM','Dual mode','UMTS'],8:['Automatic','Manual'],9:['On','Off'],10:['On','Off']}
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in [2,3,5,7,8,9,10]:
  for choice in range(len(choices[row])):
   for absent in [False,True]:
    if route=='radio' and row==2 and choice==1:continue
    val=choices[row][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.phoneVals;" if absent else "phoneState.phoneVals=pickerDefaults('phonesettings');")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.phoneVals;stored=localStorage.getItem('c2state');history=['phonesettings'];notice='';noticeBack=false;open=false;"+("page='phonesettings';sel="+str(row)+";pickerDraft={page:'phonesettings',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'phonesettings',row:"+str(row)+",title:'Phone setting',opts:"+json.dumps(choices[row])+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.phoneVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='phonesettings'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save phone setting'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and row==5 and choice==1 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6128-phone-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.phoneVals["+str(row)+"]==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.phoneVals["+str(row)+"]==="+json.dumps(val))
print('PASS',len(checks))
