exec(open('/tmp/c2-inventory-extract.py').read().split('x=ev(')[0].replace('file:///tmp/c2-ledger-live.html','file:///downloads/C2-Reborn-v6.130-slide-call-setting-rollback-candidate.html'))
call('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':False})
choices=[['Current profile','General','Silent','Meeting','Outdoor','My style 1','My style 2'],['Automatic','On']]
checks=[]
def t(n,s):
 v=ev('(()=>{'+s+'})()');print(n,v);checks.append((n,v));assert v is True,(n,v)
for route in ['picker','radio']:
 for row in range(2):
  for choice in range(len(choices[row])):
   for absent in [False,True]:
    if route=='radio' and row==0 and choice==0 and absent:continue
    val=choices[row][choice]
    ev("phoneState=migrateState(null);"+("delete phoneState.chgVals;" if absent else "phoneState.chgVals=pickerDefaults('charger');")+("phoneState.chgVals="+json.dumps([choices[0][(choice+1)%7],'Automatic'])+";" if row==0 and route=='radio' and not absent else "")+"persist();before=JSON.stringify(phoneState);beforeVals=phoneState.chgVals;stored=localStorage.getItem('c2state');history=['charger'];notice='';noticeBack=false;open=false;"+("page='charger';sel="+str(row)+";pickerDraft={page:'charger',row:"+str(row)+",value:"+json.dumps(val)+"};draftAlias=pickerDraft;radioCtx=null;" if route=='picker' else "page='radiolist';sel="+str(choice)+";pickerDraft=null;radioCtx={page:'charger',row:"+str(row)+",title:'Contact setting',opts:"+json.dumps(choices[row])+"};draftAlias=radioCtx;")+"oldStore=Storage.prototype.setItem;Storage.prototype.setItem=function(){throw Error('quota')};press('OK')")
    label=f'{route} {row} {choice} {absent}'
    t(label+' rollback',"return JSON.stringify(phoneState)===before&&phoneState.chgVals===beforeVals&&localStorage.getItem('c2state')===stored")
    t(label+' context',"return "+("pickerDraft===draftAlias&&page==='charger'" if route=='picker' else "radioCtx===draftAlias&&page==='radiolist'")+"&&notice==='Unable to save charger setting'&&document.getElementById('screen').innerText.includes(notice)")
    if route=='picker' and row==0 and choice==2 and not absent:
     d=call('Page.captureScreenshot',{'format':'png'});open('/downloads/c2-v6127-charger-error.png','wb').write(base64.b64decode(d['result']['data']))
    ev("notice='';press('OK')")
    t(label+' repeat failure',"return JSON.stringify(phoneState)===before")
    ev("Storage.prototype.setItem=oldStore;notice='';press('OK')")
    t(label+' retry',"return phoneState.chgVals["+str(row)+"]==="+json.dumps(val))
    call('Page.reload');time.sleep(.15)
    t(label+' reload',"return phoneState.chgVals["+str(row)+"]==="+json.dumps(val))
print('PASS',len(checks))
